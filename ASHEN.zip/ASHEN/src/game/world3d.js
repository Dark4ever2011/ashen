// ASHEN 3D — Região I · Reino das Cinzas — "O Portão do Rei" (mapa inteiro, em metros).
// Recriado a partir do mapa 2D original (1 u = 1 cm): X = (u − 1800)/100 · Z = u/100 − 12,4.
// Muralha ao norte (z = −4,4) com o Portão do Rei (torres, arco ogival, grade, friso, ameias),
// fortaleza ao fundo, praça com colunata, braseiro, cemitério de 14 lápides, 23 árvores, 20 rochas
// e o cavaleiro caído encostado na muralha.

import * as S from './sdf.js';
import { MAT } from './glyphs.js';
import { noise3, rng } from './math3d.js';
import { makeTree } from './trees3d.js';

export const WALL_Z = -4.4;
export const ARCH = { half: 1.3, spring: 2.15, top: 3.45 };
const GZ = WALL_Z + 0.6;                       // face do bloco do portão (avança 60 cm)
const X = u => (u - 1800) / 100, Z = u => u / 100 - 12.4;
export const BOUNDS = { x0: -17.4, z0: WALL_Z, x1: 17.4, z1: 12.6 };

const slab = (axis, a, b) => (x, y, z) => { const v = axis === 0 ? x : axis === 1 ? y : z; return Math.max(a - v, v - b); };
function archOpening(x, y) {
  const { half, spring } = ARCH;
  const rect = Math.max(Math.abs(x) - half, y - spring, -y - 1);
  const r = half * 2;
  const pointed = Math.max(Math.hypot(x - half, y - spring) - r, Math.hypot(x + half, y - spring) - r, spring - y - 0.001);
  return Math.min(rect, pointed);
}

// Caminho de terra batida do sul até o portão (polilinha do mapa 2D)
const PATH = [[1760, 2560], [1700, 2380], [1745, 2080], [1880, 1760], [1830, 1450], [1800, 1180], [1800, 860]].map(([x, y]) => [X(x), Z(y)]);
function pathDist(x, z) {
  let d = 1e9;
  for (let i = 0; i < PATH.length - 1; i++) {
    const [ax, az] = PATH[i], [bx, bz] = PATH[i + 1], dx = bx - ax, dz = bz - az;
    const t = Math.max(0, Math.min(1, ((x - ax) * dx + (z - az) * dz) / (dx * dx + dz * dz)));
    d = Math.min(d, Math.hypot(x - ax - dx * t, z - az - dz * t));
  }
  return d;
}
export const isPath = (x, z) => pathDist(x, z) < 0.95;
const PLAZA = { x0: -3.1, z0: WALL_Z, x1: 3.1, z1: Z(1070) };
const inPlaza = (x, z) => x > PLAZA.x0 && x < PLAZA.x1 && z > PLAZA.z0 && z < PLAZA.z1;
const GRAVEYARD = { x0: X(560), z0: Z(1180), x1: X(1300), z1: Z(1760) };
export const BRAZIER = { x: X(1640), z: Z(1215) };

// ─────────────── Objetos do mapa ───────────────
const PILLARS = [[1545, 1010, 2.4, 'pillar'], [2070, 1000, 1.8], [2105, 1160, 2.8], [1505, 1185, 1.4], [1250, 1380, 2.0]].map(([x, y, h, lore]) => ({ x: X(x), z: Z(y), h, lore }));
const GRAVES = [
  [700, 1260, 0, 'aldren'], [800, 1280, 1], [905, 1250, 2, 'sono'], [1010, 1290, 1], [1120, 1265, 3, 'rei'],
  [660, 1420, 1], [770, 1450, 2], [880, 1410, 0], [990, 1455, 1], [1100, 1430, 2],
  [720, 1600, 1], [840, 1620, 0], [960, 1590, 1], [1180, 1580, 2],
].map(([x, y, v, lore], i) => ({ x: X(x), z: Z(y), v, lore, i }));
const TREES = [
  [520, 1150, 1, 1.0], [1350, 1220, 2, 0.9], [610, 1720, 3, 1.1], [1260, 1700, 4, 0.95], [420, 1980, 5, 1.15],
  [1020, 2050, 6, 1.0], [1420, 1950, 7, 0.85], [2280, 1380, 8, 1.05], [2620, 1150, 9, 1.1], [2950, 1420, 10, 1.0],
  [3260, 1180, 11, 1.2], [2460, 1980, 12, 1.0], [2900, 2120, 13, 1.1], [3300, 1900, 14, 0.95], [220, 1400, 15, 1.1],
  [2150, 2300, 16, 0.9], [1250, 2380, 17, 1.0], [600, 2350, 18, 1.15], [3150, 2420, 19, 1.0], [2600, 2480, 20, 1.1],
  [1950, 1520, 21, 0.8], [180, 2220, 22, 1.0], [3450, 1650, 23, 1.05],
].map(([x, y, seed, size]) => ({ x: X(x), z: Z(y), seed, size, kind: ['dead', 'green', 'autumn'][seed % 3] }));
const ROCKS = [
  [1480, 1340, 1, 12, 7], [2180, 1250, 2, 9, 5], [2440, 1640, 3, 16, 9], [1580, 1620, 4, 8, 5], [1990, 1950, 5, 11, 6],
  [2750, 1300, 6, 14, 8], [3080, 1750, 7, 10, 6], [400, 1620, 8, 13, 7], [820, 1900, 9, 9, 5], [1360, 2140, 10, 15, 8],
  [2720, 1760, 11, 8, 4], [3380, 1360, 12, 12, 7], [300, 1180, 13, 10, 6], [2380, 1050, 14, 9, 5], [1160, 1080, 15, 11, 6],
  [1900, 2330, 16, 13, 7], [2840, 2300, 17, 10, 5], [520, 2140, 18, 8, 5], [3480, 2100, 19, 12, 6], [1640, 2250, 20, 7, 4],
].map(([x, y, seed, w, h]) => ({ x: X(x), z: Z(y), seed, r: w * 0.045, h: h * 0.07 }));
export const FALLEN = { x: X(2330), z: WALL_Z + 0.42 };
export const ROYAL_TOMB = { x: X(1120), z: Z(1265) };
export const SPAWN = { x: X(1712), z: Z(1335) };
const BREACHES = [-12.2, 9.6];
const BUTTRESSES = [-16.5, -7.6, 6.8, 14.2];

export const LORE = {
  brazierUnlit: 'As brasas ainda guardam calor. Ao tocá-las, a chama desperta — como se reconhecesse o juramento gravado em seu peito.',
  brazierLit: 'O fogo crepita. Por um instante você lembra de um nome… e ele se desfaz em cinzas antes de chegar à boca.',
  gate: 'A grade de ferro está selada. Na pedra-chave, o selo do rei: 王. Abaixo, riscado com a ponta de uma espada: «Só o último juramento abre o que o primeiro fechou.»',
  aldren: '«Aqui jaz Ser Aldren, Escudo do Leste. Guardou a palavra até a última cinza.»',
  sono: 'O nome foi raspado da pedra. Restou apenas um ideograma: 眠 — dormir.',
  rei: 'Um túmulo com o selo real, vazio. A terra foi revolvida… de dentro para fora.',
  fallen: 'Um cavaleiro tombado contra a muralha. A armadura é idêntica à sua — até o 誓 gravado no peito. Sob o elmo, apenas cinzas.',
  pillar: 'Restos de uma colunata. Na base, quase apagado: «Ao rei que jurou, e ao reino que ardeu por ele.»',
};

/** Pontos de interação (o HUD mostra o aviso quando o cavaleiro chega perto). */
export const INTERACT = [
  { id: 'brazier', x: BRAZIER.x, z: BRAZIER.z, r: 1.5, title: 'Chama do Último Juramento' },
  { id: 'gate', x: 0, z: GZ + 0.7, r: 1.9, title: 'Portão do Rei', prompt: 'examinar o portão', text: LORE.gate },
  ...GRAVES.filter(g => g.lore).map(g => ({ id: 'grave-' + g.lore, x: g.x, z: g.z + 0.45, r: 1.05, title: 'Lápide', prompt: 'ler a lápide', text: LORE[g.lore] })),
  { id: 'pillar', x: PILLARS[0].x, z: PILLARS[0].z + 0.5, r: 1.2, title: 'Colunata em ruínas', prompt: 'examinar a coluna', text: LORE.pillar },
  { id: 'fallen', x: FALLEN.x, z: FALLEN.z + 0.9, r: 1.3, title: 'Cavaleiro caído', prompt: 'examinar o cavaleiro', text: LORE.fallen },
];

export const LIGHTS = [
  { name: 'braseiro', pos: [BRAZIER.x, 1.6, BRAZIER.z], col: [1.0, 0.55, 0.22], radius: 7.5, base: 1.6, flicker: 0.28 },
  { name: 'tocha', pos: [-2.15, 2.55, GZ + 0.45], col: [1.0, 0.5, 0.2], radius: 5, base: 1.15, flicker: 0.35 },
  { name: 'tocha', pos: [2.15, 2.55, GZ + 0.45], col: [1.0, 0.5, 0.2], radius: 5, base: 1.15, flicker: 0.35 },
];
export const TORCHES = [[-2.15, 2.3, GZ + 0.32], [2.15, 2.3, GZ + 0.32]];
export const BANNERS = [-2.2, 2.2].map(x => ({ x, top: 5.55, z: GZ + 0.06 }));

/** Colisores no plano do chão (x, z). */
export const COLLIDERS = [
  { type: 'box', x0: -19, z0: -14, x1: 19, z1: WALL_Z + 0.05 },
  { type: 'box', x0: -2.85, z0: WALL_Z - 0.1, x1: 2.85, z1: GZ + 0.05 },
  { type: 'circle', x: -3.35, z: WALL_Z + 0.25, r: 1.45 }, { type: 'circle', x: 3.35, z: WALL_Z + 0.25, r: 1.45 },
  ...BUTTRESSES.map(bx => ({ type: 'box', x0: bx - 0.5, z0: WALL_Z - 0.1, x1: bx + 0.5, z1: WALL_Z + 1.0 })),
  { type: 'circle', x: BRAZIER.x, z: BRAZIER.z, r: 0.58 },
  ...PILLARS.map(p => ({ type: 'circle', x: p.x, z: p.z, r: 0.5 })),
  ...GRAVES.map(g => ({ type: 'circle', x: g.x, z: g.z, r: g.v === 3 ? 0.75 : 0.36 })),
  ...ROCKS.map(r => ({ type: 'circle', x: r.x, z: r.z, r: r.r * 1.15 })),
  ...TREES.map(t => ({ type: 'circle', x: t.x, z: t.z, r: 0.3 * t.size })),
  { type: 'circle', x: FALLEN.x, z: FALLEN.z + 0.2, r: 0.55 },
];

// ─────────────── Peças (SDF) ───────────────
const groundH = (x, z) => 0.04 * noise3(x * 0.7, 0, z * 0.7) + 0.02 * noise3(x * 2.3, 1, z * 2.3);
const stoneJoints = (p, n, w = 0.8, h = 0.36, top = 99) => {
  if (n[2] > 0.6 && p[1] < top) {
    const r = Math.floor(p[1] / h), off = (r % 2) * w / 2;
    const fu = ((((p[0] + off) / w) % 1) + 1) % 1, fv = (p[1] / h) % 1;
    if (fv < 0.12) return { mat: MAT.DARK, glyph: '─', size: 0.85 };
    if (fu < 0.08) return { mat: MAT.DARK, glyph: '│', size: 0.85 };
  }
  return null;
};
const weathering = (p, n) => {
  const c = noise3(p[0] * 1.3 + 4, p[1] * 1.3, p[2] * 1.3);
  if (Math.abs(c - 0.5) < 0.012 && n[2] > 0.5) return { mat: MAT.DARK, glyph: '╲', size: 0.8 };        // rachaduras
  if (p[1] < 2.6 && noise3(p[0] * 0.8, p[1] * 0.9, 9) > 0.7) return { mat: MAT.MOSS };                  // hera e musgo
  return null;
};

export function groundParts() {
  return [{
    name: 'chão', f: (x, y, z) => y - groundH(x, z) + (isPath(x, z) || inPlaza(x, z) ? 0.015 : 0),
    min: [BOUNDS.x0 - 0.5, -0.12, WALL_Z + 0.1], max: [BOUNDS.x1 + 0.5, 0.12, BOUNDS.z1 + 0.6], mat: MAT.GROUND, spacing: 0.22, size: 0.42,
    flowFn: (p) => { const a = (Math.sin(p[0] * 91.7 + p[2] * 47.3) * 43758.5) % 6.28; return [Math.cos(a), 0, Math.sin(a)]; },
    detail: (p) => {
      if (inPlaza(p[0], p[2])) {                                         // lajes da praça
        const fu = ((p[0] / 0.9) % 1 + 1) % 1, fv = ((p[2] / 0.7 + (Math.floor(p[0] / 0.9) % 2) * 0.5) % 1 + 1) % 1;
        if (fu < 0.1 || fv < 0.1) return { mat: MAT.DARK, glyph: fu < 0.1 ? '│' : '─', size: 0.8 };
        return { mat: noise3(p[0] * 2, 0, p[2] * 2) > 0.66 ? MAT.MOSS : MAT.GRAVEL };
      }
      if (isPath(p[0], p[2])) {
        const r = Math.floor(p[2] / 0.34), c = (p[0] + (r % 2) * 0.17) / 0.38, fu = c - Math.floor(c), fv = p[2] / 0.34 - r;
        if (fu < 0.14 || fv < 0.14) return { mat: MAT.DARK, glyph: fu < 0.14 ? '│' : '─', size: 0.8 };
        return { mat: MAT.GRAVEL };
      }
      if (Math.hypot(p[0] - BRAZIER.x, p[2] - BRAZIER.z) < 1.5 + 0.3 * noise3(p[0] * 2, 1, p[2] * 2)) return { mat: MAT.DARK, glyph: '·' };   // chão chamuscado
      const inGY = p[0] > GRAVEYARD.x0 - 0.6 && p[0] < GRAVEYARD.x1 + 0.6 && p[2] > GRAVEYARD.z0 - 0.6 && p[2] < GRAVEYARD.z1 + 0.6;
      if (inGY && noise3(p[0] * 0.9, 5, p[2] * 0.9) > 0.45) return { mat: MAT.MOSS, size: 0.8 };
      if (noise3(p[0] * 0.45, 3, p[2] * 0.45) > 0.6) return { mat: MAT.MOSS, size: 0.8 };
      return null;
    },
  }];
}

export function sceneParts() {
  const P = [];
  const add = o => P.push(o);

  // ── Muralhas laterais: cantaria, contrafortes, ameias, duas brechas com escombros ──
  const notch = (x, y) => Math.min(...BREACHES.map(bx => Math.abs(x - bx) * 1.6 - (y - 2.2)));          // V aberto no topo
  const wallBody = (x, y, z) => Math.max(S.box(18.6, 2.3, 0.6)(x, y - 2.3, z - (WALL_Z - 0.6)), 4.35 - Math.abs(x), -notch(x, y));
  const merlons = (x, y, z) => {
    const local = (((x + 40) % 1.1 + 1.1) % 1.1) - 0.3;
    return Math.max(Math.abs(local) - 0.3, Math.abs(y - 4.9) - 0.32, Math.abs(z - (WALL_Z - 0.2)) - 0.2, 4.4 - Math.abs(x), Math.abs(x) - 18.5, -notch(x, y) + 0.4);
  };
  const buttress = S.union(...BUTTRESSES.map(bx => S.intersect(S.xf(S.box(0.45, 2.0, 0.55), [bx, 2.0, WALL_Z + 0.35]), (x, y, z) => (y - 3.6) + (z - WALL_Z) * 0.9)));
  const rubble = S.union(...BREACHES.map((bx, i) => (x, y, z) => Math.hypot((x - bx) / 1.8, y / 0.55, (z - WALL_Z - 0.5) / 0.9) - 1 + 0.25 * noise3(x * 3, y * 3 + i, z * 3)));
  add({ name: 'muralhas', f: S.union(wallBody, merlons, buttress, rubble), min: [-18.7, -0.1, WALL_Z - 1.3], max: [18.7, 5.3, WALL_Z + 1.6], mat: MAT.STONE, spacing: 0.095, flow: [1, 0, 0],
    keep: (p, n) => n[2] > -0.5,
    detail: (p, n) => stoneJoints(p, n, 0.8, 0.36, 4.55) || weathering(p, n) });

  // ── Portão do Rei: bloco com arco ogival, aduelas, pedra-chave 王, friso, ameias, torres redondas ──
  const block = S.xf(S.box(2.85, 3.1, 0.75), [0, 3.1, GZ - 0.75]);
  const opening = (x, y, z) => Math.max(archOpening(x, y), Math.abs(z - (GZ - 0.75)) - 1.0);
  const blockMerlons = (x, y, z) => { const local = (((x + 40) % 0.95 + 0.95) % 0.95) - 0.26; return Math.max(Math.abs(local) - 0.24, Math.abs(y - 6.5) - 0.3, Math.abs(z - (GZ - 0.2)) - 0.2, Math.abs(x) - 2.7); };
  const corbel = S.xf(S.box(2.95, 0.12, 0.85), [0, 6.05, GZ - 0.72]);
  add({ name: 'portão', f: S.union(S.subtract(block, opening), blockMerlons, corbel), min: [-3, -0.05, GZ - 1.7], max: [3, 6.9, GZ + 0.25], mat: MAT.STONE, spacing: 0.078, flow: [1, 0, 0],
    keep: (p, n) => n[2] > -0.5,
    detail: (p, n, c) => {
      const ao = archOpening(p[0], p[1]);
      const inArch = ao > -0.55 && ao < 0.05 && p[2] > GZ - 1.8;
      if (inArch && Math.abs(n[2]) < 0.6) return { mat: MAT.BONE };
      if (inArch && ao > -0.4 && n[2] > 0.6) {
        const a = Math.atan2(p[1] - ARCH.spring, p[0]);
        if (p[1] > ARCH.spring && Math.abs(((a * 7) % 1 + 1) % 1 - 0.5) < 0.08) return { mat: MAT.DARK, glyph: '╲', size: 0.9 };
        return { mat: MAT.BONE };
      }
      if (Math.abs(p[1] - 4.3) < 0.28 && n[2] > 0.6) return { mat: MAT.BONE };     // faixa do friso
      return stoneJoints(p, n, 0.7, 0.34, 6.0) || weathering(p, n);
    },
    decals: [{ p: [0, ARCH.top + 0.32, GZ + 0.02], n: [0, 0, 1], glyph: '王', mat: MAT.GOLD, size: 0.34, clear: 0.22 },
      ...[...'灰の王国·誓約'].map((ch, i) => ({ p: [-1.5 + i * 0.5, 4.3, GZ + 0.02], n: [0, 0, 1], glyph: ch, mat: MAT.GOLD, size: 0.21, clear: 0.15 }))] });
  for (const s of [-1, 1]) {
    const tx = s * 3.35, tz = WALL_Z + 0.25;
    const body = (x, y, z) => Math.max(Math.hypot(x - tx, z - tz) - 1.35 - 0.03 * Math.max(0, 1.2 - y), Math.abs(y - 3.9) - 3.9);
    const crown = (x, y, z) => { const a = Math.atan2(z - tz, x - tx); const k = ((a * 8 / Math.PI) % 1 + 1) % 1; return Math.max(Math.abs(Math.hypot(x - tx, z - tz) - 1.32) - 0.2, y - (k < 0.45 ? 8.55 : 8.0), 7.75 - y); };
    const corb = (x, y, z) => Math.max(Math.hypot(x - tx, z - tz) - 1.5, Math.abs(y - 7.68) - 0.12);
    add({ name: 'torre', f: S.union(body, crown, corb), min: [tx - 1.7, -0.05, tz - 1.7], max: [tx + 1.7, 8.6, tz + 1.7], mat: MAT.STONE, spacing: 0.085, flow: [0, 1, 0],
      keep: (p, n) => n[2] > -0.6,
      detail: (p, n) => {
        const a = Math.atan2(p[2] - tz, p[0] - tx);
        for (const sa of [Math.PI / 2 - 0.55 * s, Math.PI / 2 + 0.35 * s]) if (Math.abs(a - sa) < 0.045 && ((p[1] > 2.9 && p[1] < 3.9) || (p[1] > 5.3 && p[1] < 6.4))) return { mat: MAT.DARK, glyph: '│' };   // seteiras
        if (Math.hypot(p[0] - tx, p[2] - tz) > 1.2 && p[1] < 7.5) {
          const r = Math.floor(p[1] / 0.36), off = (r % 2) * 0.2, fu = ((a * 1.35 / 0.4 + off) % 1 + 1) % 1, fv = (p[1] / 0.36) % 1;
          if (fv < 0.12) return { mat: MAT.DARK, glyph: '─', size: 0.85 };
          if (fu < 0.08) return { mat: MAT.DARK, glyph: '│', size: 0.85 };
        }
        return weathering(p, n);
      } });
  }
  // Grade levadiça (ferro)
  const bars = (x, y, z) => {
    if (archOpening(x, y) > 0.05) return 1;
    const zz = z - (GZ - 0.55);
    const vx = Math.abs(((x + 30) % 0.34 + 0.34) % 0.34 - 0.17), hy = Math.abs(((y + 30) % 0.48 + 0.48) % 0.48 - 0.24);
    return Math.max(Math.min(Math.hypot(vx, zz) - 0.026, Math.max(Math.hypot(hy, zz) - 0.02, Math.abs(x) - 1.3)), 0.02 - y);
  };
  add({ name: 'grade', f: bars, min: [-1.35, 0, GZ - 0.65], max: [1.35, 3.5, GZ - 0.45], mat: MAT.IRON, spacing: 0.036, flow: [0, 1, 0] });
  // Suportes das tochas
  for (const [tx, ty, tz] of TORCHES) add({ name: 'tocha', f: S.smooth(0.03, S.capsule([tx, ty - 0.25, GZ + 0.02], [tx, ty - 0.25, tz - 0.02], 0.03), S.xf(S.cylinder(0.07, 0.07, 0.02), [tx, ty - 0.08, tz])), min: [tx - 0.12, ty - 0.4, GZ - 0.05], max: [tx + 0.12, ty + 0.05, tz + 0.12], mat: MAT.IRON, spacing: 0.022 });

  // ── Fortaleza ao fundo (aparece por cima da muralha) ──
  const keepBody = S.xf(S.box(3.4, 5.5, 2.0), [1.4, 5.5, -9.6]);
  const keepTower = (x, y, z) => Math.max(Math.hypot(x - 4.6, z + 9.0) - 1.6, Math.abs(y - 7.2) - 7.2);
  const roof = (x, y, z) => Math.max(Math.hypot(x - 4.6, z + 9.0) - Math.max(0, (17.6 - y) * 0.55), 14.3 - y, y - 17.6);
  const keepMerl = (x, y, z) => { const local = (((x + 40) % 1.0 + 1.0) % 1.0) - 0.28; return Math.max(Math.abs(local) - 0.26, Math.abs(y - 11.3) - 0.32, Math.abs(z + 7.75) - 0.22, Math.abs(x - 1.4) - 3.3); };
  add({ name: 'fortaleza', f: S.union(keepBody, keepTower, roof, keepMerl), min: [-2.2, 4.0, -11.8], max: [6.4, 17.8, -7.3], mat: MAT.STONE, spacing: 0.13, size: 1.1, flow: [0, 1, 0],
    keep: (p, n) => n[2] > -0.3 || n[1] > 0.5,
    detail: (p, n) => {
      if (p[1] > 14.3 && Math.hypot(p[0] - 4.6, p[2] + 9) < 1.7) return { mat: MAT.IRON };                         // telhado de ardósia
      if (n[2] > 0.6 && Math.abs(((p[0] + 40) % 1.4) - 0.7) < 0.07 && ((p[1] > 6.5 && p[1] < 7.6) || (p[1] > 9 && p[1] < 10))) return { mat: MAT.EMBER, glyph: '¦', flags: 2 };   // janelas com luz
      return stoneJoints(p, n, 1.0, 0.45) || weathering(p, n);
    } });

  // ── Braseiro (sobre plinto) ──
  const { x: bx, z: bz } = BRAZIER;
  const bowl = S.intersect(S.shell(S.xf(S.sphere(0.42), [bx, 1.25, bz]), 0.03), S.below(1.18));
  const rim = S.xf(S.torus(0.4, 0.035), [bx, 1.17, bz]);
  const legs = S.union(...[0, 1, 2].map(i => { const a = i * 2.094 + 0.4; return S.capsule([bx + Math.cos(a) * 0.32, 0.24, bz + Math.sin(a) * 0.32], [bx + Math.cos(a) * 0.12, 0.92, bz + Math.sin(a) * 0.12], 0.035); }));
  add({ name: 'braseiro', f: S.smooth(0.03, bowl, rim, legs), min: [bx - 0.5, 0.15, bz - 0.5], max: [bx + 0.5, 1.25, bz + 0.5], mat: MAT.IRON, spacing: 0.026, flow: [0, 1, 0],
    detail: (p, n, c) => (c > 0.4 ? { mat: MAT.SILVER } : null) });
  add({ name: 'plinto', f: S.xf(S.box(0.5, 0.12, 0.5, 0.03), [bx, 0.12, bz]), min: [bx - 0.55, -0.02, bz - 0.55], max: [bx + 0.55, 0.26, bz + 0.55], mat: MAT.STONE, spacing: 0.035, flow: [1, 0, 0] });

  // ── Colunata: fustes canelados quebrados, plintos e tambores caídos ──
  PILLARS.forEach((pl, i) => {
    const R = rng(40 + i);
    const col = (x, y, z) => { const dx = x - pl.x, dz = z - pl.z, a = Math.atan2(dz, dx); return Math.max(Math.hypot(dx, dz) - 0.3 - 0.018 * Math.cos(a * 16), -y, y - pl.h - 0.25 * noise3(dx * 5, i, dz * 5) - 0.18 * dx); };
    const plinth = S.xf(S.box(0.46, 0.13, 0.46, 0.02), [pl.x, 0.13, pl.z]);
    const da = R() * 6.28, dr = 0.8 + R() * 0.4;
    const drum = S.xf(S.cylinder(0.3, 0.22, 0.03), [pl.x + Math.cos(da) * dr, 0.3, pl.z + Math.sin(da) * dr], [Math.PI / 2, da, 0]);
    add({ name: 'coluna', f: S.union(col, plinth, drum), min: [pl.x - 1.6, -0.02, pl.z - 1.6], max: [pl.x + 1.6, pl.h + 0.6, pl.z + 1.6], mat: MAT.STONE, spacing: 0.045, flow: [0, 1, 0],
      detail: (p, n, c) => (c > 0.4 && p[1] > pl.h - 0.5 ? { mat: MAT.BONE } : (noise3(p[0] * 3, p[1] * 3, p[2] * 3) > 0.7 ? { mat: MAT.MOSS } : null)) });
  });

  // ── Cemitério: 14 lápides (arredondada, cruz, pontiaguda, túmulo real aberto) ──
  for (const g of GRAVES) {
    const R = rng(70 + g.i);
    const tilt = (R() - 0.5) * 0.28, yaw = (R() - 0.5) * 0.3;
    let stone, mark = null;
    if (g.v === 0) stone = S.smooth(0.02, S.xf(S.box(0.3, 0.4, 0.08, 0.02), [0, 0.4, 0]), S.xf(S.cylinder(0.3, 0.08, 0.02), [0, 0.8, 0], [Math.PI / 2, 0, 0]));
    else if (g.v === 1) stone = S.union(S.xf(S.box(0.07, 0.55, 0.06, 0.01), [0, 0.55, 0]), S.xf(S.box(0.27, 0.06, 0.06, 0.01), [0, 0.78, 0]), S.xf(S.box(0.22, 0.08, 0.16, 0.02), [0, 0.08, 0]));
    else if (g.v === 2) stone = S.intersect(S.xf(S.box(0.24, 0.6, 0.09, 0.015), [0, 0.6, 0]), (x, y) => y - 1.15 + Math.abs(x) * 1.6);
    else stone = S.subtract(S.xf(S.box(0.55, 0.32, 1.0, 0.04), [0, 0.32, -0.2]), S.xf(S.box(0.4, 0.4, 0.75), [0, 0.55, -0.2]));
    const f = S.xf(stone, [g.x, 0, g.z], [tilt, yaw, tilt * 0.5]);
    if (g.lore === 'aldren') mark = '†'; else if (g.lore === 'sono') mark = '眠'; else if (g.lore === 'rei') mark = '王'; else if (g.v === 0) mark = '墓';
    const decals = mark ? [{ p: [g.x, g.v === 3 ? 0.42 : 0.6, g.z + (g.v === 3 ? 0.82 : 0.1)], n: [0, 0.1, 1], glyph: mark, mat: g.v === 3 ? MAT.GOLD : MAT.BONE, size: g.v === 3 ? 0.26 : 0.22, clear: 0.15 }] : [];
    add({ name: 'lápide', f, min: [g.x - 0.7, -0.05, g.z - 1.4], max: [g.x + 0.7, 1.3, g.z + 1.0], mat: MAT.STONE, spacing: 0.037, flow: [0, 1, 0],
      detail: (p, n, c) => (c > 0.45 ? { mat: MAT.BONE } : (noise3(p[0] * 5, p[1] * 5, g.i) > 0.72 ? { mat: MAT.MOSS } : null)), decals });
    if (g.v === 3) {   // terra revolvida de dentro para fora
      add({ name: 'terra revolvida', f: (x, y, z) => Math.hypot((x - g.x) / 1.0, y / 0.22, (z - g.z - 0.75) / 0.55) - 1 + 0.3 * noise3(x * 4, y * 4, z * 4), min: [g.x - 1.2, -0.05, g.z + 0.1], max: [g.x + 1.2, 0.3, g.z + 1.4], mat: MAT.GROUND, spacing: 0.04, flow: [1, 0, 0] });
    }
  }

  // ── Rochas ──
  ROCKS.forEach((r, i) => {
    const f = (x, y, z) => Math.hypot((x - r.x) / 1.25, (y - r.h * 0.4) / 0.8, (z - r.z)) - r.r - 0.12 * (noise3(x * 2.5, y * 2.5 + i, z * 2.5) - 0.5);
    add({ name: 'rocha', f, min: [r.x - r.r * 1.6, -0.1, r.z - r.r * 1.3], max: [r.x + r.r * 1.6, r.r * 1.3, r.z + r.r * 1.3], mat: MAT.STONE, spacing: 0.055, flow: [1, 0.2, 0],
      detail: (p, n) => (n[1] > 0.6 && noise3(p[0] * 3, p[2] * 3, i) > 0.5 ? { mat: MAT.MOSS } : null) });
  });
  return P;
}

/** Árvores (madeira como peças SDF + copas como pontos prontos). */
export function buildTrees() {
  return TREES.map(t => makeTree(t.x, t.z, t.seed, t.size, t.kind));
}

/** Áreas a evitar ao espalhar grama. */
export function avoidVeg(x, z) {
  if (isPath(x, z) || inPlaza(x, z) || z < WALL_Z + 0.5) return true;
  if (Math.abs(x) < 4.9 && z < GZ + 0.4) return true;
  if (Math.hypot(x - BRAZIER.x, z - BRAZIER.z) < 1.2) return true;
  return COLLIDERS.some(c => c.type === 'circle' && Math.hypot(x - c.x, z - c.z) < c.r + 0.08);
}
