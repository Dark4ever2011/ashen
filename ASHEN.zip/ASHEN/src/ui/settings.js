// ASHEN — Configurações gráficas e de controle (versão 3D)
// Os presets nunca simplificam o cavaleiro nem a arquitetura: mudam a resolução de tela,
// a densidade de efeitos (cinzas, chuva, névoa) e o alcance da sombra.

export const PRESETS = {
  EXTREMO: { label: 'Extremo', desc: 'O máximo: chão 3x mais denso perto do cavaleiro, sombra suave e longa, luz mais fiel, longe mais detalhado. Pesado.', dpr: 3.0, fx: 1.35, shadow: 13, shadowEvery: 1, lodNear: 9, lodMin: 0.4, far: 70, ring: true, pcf: 2 },
  ALTA: { label: 'Alta', desc: 'Resolução máxima, todos os efeitos, sombra longa.', dpr: 2.4, fx: 1, shadow: 11, shadowEvery: 1, lodNear: 5, lodMin: 0.2, far: 52 },
  EQUILIBRADA: { label: 'Equilibrada', desc: 'Mesmo estilo; resolução um pouco menor, sombra atualizada a cada 2 quadros.', dpr: 1.9, fx: 0.8, shadow: 9, shadowEvery: 2, lodNear: 4.5, lodMin: 0.16, far: 46 },
  DESEMPENHO: { label: 'Desempenho', desc: 'Cavaleiro e arquitetura intactos; menos partículas, resolução menor, longe mais leve.', dpr: 1.45, fx: 0.55, shadow: 7, shadowEvery: 3, lodNear: 3.8, lodMin: 0.12, far: 40 },
};

export const WEATHER_MODES = [['auto', 'Automático'], ['limpo', 'Limpo'], ['garoa', 'Garoa'], ['chuva', 'Chuva'], ['tempestade', 'Tempestade']];

export const DEFAULT_SETTINGS = {
  preset: 'EQUILIBRADA',
  fpsCap: 60,          // 30 | 60 | 0 (sem limite)
  showPerf: false,
  haptics: true,
  controlScale: 1,
  bindings: null,
  weather: 'auto',
  sound: true,
  volume: 0.8,
  narration: true,
};

export function effective(settings) { return PRESETS[settings.preset] || PRESETS.ALTA; }
