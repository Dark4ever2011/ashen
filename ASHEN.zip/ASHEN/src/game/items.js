// ASHEN — Inventário, ouro, equipamentos (por classe), conquistas e a loja do mercador.

import { MAT } from './glyphs.js';
import { m4 } from './math3d.js';
import { flatBones } from './renderer3d.js';
import * as S from './sdf.js';

const $ = id => document.getElementById(id);
const snd = (g, n, k) => g.audio && g.audio.play(n, k);

/** Nome e efeito de cada item, conforme a classe. */
export function itemInfo(g, id) {
  const sam = g.cls === 'samurai';
  switch (id) {
    case 'armor': return sam
      ? { name: 'Ō-yoroi Carmesim', kanji: '鎧', desc: 'Laca vermelha sobre ferro velho, tirada do baú do Profano. Recebe 25% menos dano.', slot: 'armor' }
      : { name: 'Armadura do Juramento Renascido', kanji: '鎧', desc: 'Aço enegrecido com filetes de ouro, tirada do baú do Profano. Recebe 25% menos dano.', slot: 'armor' };
    case 'crown': return { name: 'Coroa do Ogro', kanji: '冠', slot: 'head', desc: sam ? 'Ouro bruto, ainda morno. No samurai: dois cortes já fazem sangrar, e o sangramento dói 50% mais.' : 'Ouro bruto, ainda morno. No cavaleiro: rola mais rápido e gasta 25–30% menos fôlego.' };
    case 'bell': return { name: 'Sino da Lua Sombria', kanji: '鐘', desc: 'Toque no Reino Partido, à noite, para chamar a Lua Sombria.', use: true };
    case 'sword': return g.cls === 'samurai'
      ? { name: 'Katana Sangue-de-Lua', kanji: '刀', desc: 'Forjada no fundo da Cripta dos Goblins. +35% de dano e o sangramento dura o dobro.' }
      : { name: 'Montante de Ferro-Estrela', kanji: '剣', desc: 'Tirada do tesouro do Rei Goblin. +35% de dano e golpes que atravessam a guarda.' };
    case 'rose': return { name: 'Rosa', kanji: '薔', desc: 'Uma rosa vermelha. Alguém no reino gosta delas.' };
    case 'pie': return { name: 'Torta de Maçã', kanji: '餅', desc: 'Recupera 50 de vida.', use: true };
    case 'amulet': return { name: 'Trevo de Ferro', kanji: '幸', desc: '+5% de chance de achar itens nos destroços.' };
    case 'blade': return { name: sam ? 'Katana do Orvalho' : 'Lâmina do Orvalho', kanji: '刀', desc: 'Brilha em azul. Golpes 25% mais fortes.' };
    case 'water': return { name: 'Balde de Água do Poço', kanji: '水', desc: 'Para a moça da casa distante.' };
    case 'wood': return { name: 'Feixe de Lenha', kanji: '薪', desc: 'Para a moça da casa distante.' };
    case 'locket': return { name: 'Medalhão Perdido', kanji: '環', desc: 'Um medalhão com um retrato gasto. Não é seu.' };
    default: return { name: id, kanji: '?', desc: '' };
  }
}

export const SHOP = [
  { id: 'rose', price: 25 },
  { id: 'pie', price: 40 },
  { id: 'flask', price: 450, name: 'Frasco de Brasa', kanji: '薬', desc: '+1 frasco de cura (até 5).' },
  { id: 'sharpen', price: 350, name: 'Pedra de Afiar', kanji: '砥', desc: '+10% de dano, para sempre (até 3).' },
  { id: 'bell', price: 3000 },
];

export function initItems(g, sets, saved) {
  const s = (saved && saved.inv) || {};
  g.inv = Object.assign({ gold: 0, bag: {}, equip: { armor: null, head: null }, achv: [] }, s);
  g.sharpen = g.inv.sharpen || 0;
  // coroa na cabeça (mesmo esqueleto do personagem)
  g.crownMesh = g.R.addMesh(sets.crown, { occlude: false }); g.crownMesh.visible = false;
  g.baseBody = null;
  applyEquip(g);
  g.addGold = (n, where) => { g.inv.gold += Math.round(n); g.hud.notify({ kind: 'gold', amount: Math.round(n), ms: 1800 }); snd(g, 'pickup', 0.5); };
  g.addItem = (id, n = 1) => { g.inv.bag[id] = (g.inv.bag[id] || 0) + n; const I = itemInfo(g, id); if (I && g.hud && g.hud.notify) g.hud.notify({ kind: 'item', title: 'Novo item', text: I.name + (n > 1 ? ` ×${n}` : ''), kanji: I.kanji, ms: 2800 }); };
  g.hasItem = (id) => (g.inv.bag[id] || 0) > 0;
  g.takeItem = (id, n = 1) => { if ((g.inv.bag[id] || 0) < n) return false; g.inv.bag[id] -= n; if (g.inv.bag[id] <= 0) delete g.inv.bag[id]; return true; };
  g.achieve = (name) => {
    if (g.inv.achv.includes(name)) return;
    g.inv.achv.push(name); snd(g, 'victory');
    g.hud.notify({ kind: 'achv', title: 'Conquista desbloqueada', text: name, kanji: '★', ms: 4600 });
  };
  g.openInventory = () => openInventory(g);
  g.openShop = (owner) => openShop(g, owner);
  if (!g.inv.stats) g.inv.stats = { lv: 1, vida: 0, forca: 0, agil: 0 };
  g.openLevel = () => openLevel(g); g.levelCost = () => levelCost(g.inv.stats.lv);
  applyStats(g, true);
  g.extraSave = () => ({ inv: { ...g.inv, sharpen: g.sharpen } });
  window.addEventListener('keydown', e => { if (e.code === 'KeyI' && g.state === 'play') { if ($('inv').classList.contains('hidden')) openInventory(g); else closePanel(); } if (e.code === 'Escape') closePanel(); });
}

// ─────────────── nível (gasta ouro na fogueira) ───────────────
export const STAT_INFO = {
  vida: { k: '命', name: 'Vida', desc: '+12 de vida máxima por ponto.' },
  forca: { k: '力', name: 'Força', desc: '+6% de dano por ponto.' },
  agil: { k: '速', name: 'Agilidade', desc: '+8 de fôlego, recupera fôlego mais rápido, anda e rola mais rápido (+2,5% por ponto).' },
};
export const levelCost = lv => Math.round(150 * Math.pow(1.14, lv - 1) / 5) * 5;
export function applyStats(g, fill) {
  const s = g.inv.stats, p = g.player;
  p.hpMax = 100 + 12 * s.vida; p.staMax = 100 + 8 * s.agil;
  g.strK = 1 + 0.06 * s.forca; g.agiK = 1 + 0.025 * s.agil;
  if (fill) { p.hp = p.hpMax; p.sta = p.staMax; } else { p.hp = Math.min(p.hp, p.hpMax); p.sta = Math.min(p.sta, p.staMax); }
}
const atFire = g => g.restPos && Math.hypot(g.player.x - g.restPos.x, g.player.z - g.restPos.z) < 5 && g.area === g.restPos.area;
function openLevel(g) {
  const s = g.inv.stats, cost = levelCost(s.lv), can = g.inv.gold >= cost && atFire(g);
  let html = `<p class="gold">Nível ${s.lv} · ◈ ${g.inv.gold} ouro · próximo nível: ${cost} ◈</p>`;
  if (!atFire(g)) html += '<p class="none">Só é possível ficar mais forte descansando numa fogueira.</p>';
  for (const [id, I] of Object.entries(STAT_INFO)) html += row(I.k, `${I.name} · ${s[id]}`, I.desc, `<button type="button" data-st="${id}" ${can ? '' : 'disabled'}>+1</button>`);
  const p = g.player;
  html += `<p class="none">vida ${p.hpMax} · fôlego ${p.staMax} · dano ×${(g.strK).toFixed(2)} · velocidade ×${g.agiK.toFixed(3)}</p>`;
  const el = panel('Fortalecer', html);
  el.querySelectorAll('[data-st]').forEach(b => b.onclick = () => {
    const c = levelCost(s.lv); if (g.inv.gold < c || !atFire(g)) return;
    g.inv.gold -= c; s[b.dataset.st]++; s.lv++; applyStats(g, true); snd(g, 'ignite'); g.fx.burst([p.x, (p.y || 0) + 1, p.z], 40);
    g.hud.toast(`Nível ${s.lv}!`, 1600); g.save(); openLevel(g);
  });
}

/** Aplica o que está equipado: defesa, material da armadura, coroa. */
export function applyEquip(g) {
  const up = g.inv.equip.armor === 'armor';
  g.armorK = up ? 0.75 : 1;
  g.crownOn = g.inv.equip.head === 'crown';
  const m = g.knightMesh, ps = g.bodyPS;
  if (!m || !ps) return;
  if (!g.baseBody) g.baseBody = Float32Array.from(ps.attr.subarray(0, ps.n * 4));
  const map = g.cls === 'samurai'
    ? { [MAT.IRON]: MAT.CLOTH, [MAT.SILVER]: MAT.GOLD, [MAT.CLOTH_IN]: MAT.ROYAL }
    : { [MAT.STEEL]: MAT.IRON, [MAT.SILVER]: MAT.GOLD, [MAT.CLOTH]: MAT.ROYAL, [MAT.MAIL]: MAT.DARK };
  const a = ps.attr;
  const blade = g.inv.sword ? (g.cls === 'samurai' ? MAT.BLOOD : MAT.GOLD) : null;
  for (let i = 0; i < ps.n; i++) { const base = g.baseBody[i * 4]; a[i * 4] = blade != null && base === MAT.BLADE ? blade : up && map[base] != null ? map[base] : base; }
  g.R.updateMesh(m, ps);
}
export function crownRender(g, bones) {
  g.crownMesh.visible = !!g.crownOn && g.player.dead < 0.6;
  if (g.crownMesh.visible) g.crownMesh.boneData = g.knightMesh.boneData;
}

// ─────────────── painéis ───────────────
function closePanel() { $('inv').classList.add('hidden'); document.body.classList.remove('dlg'); }
function panel(title, html) {
  const el = $('inv'); if (el.classList.contains('hidden')) { el.classList.add('anim'); clearTimeout(panel.t); panel.t = setTimeout(() => el.classList.remove('anim'), 240); }
  el.classList.remove('hidden'); document.body.classList.add('dlg');
  el.innerHTML = `<div class="inv-frame"><i class="c tl">✠</i><i class="c tr">✠</i><i class="c bl">✠</i><i class="c br">✠</i><h3>${title}</h3><div class="inv-body">${html}</div><button type="button" class="inv-close">fechar</button></div>`;
  el.querySelector('.inv-close').onclick = closePanel;
  return el;
}
function row(k, name, desc, btn, extra = '') { return `<div class="inv-row"><span class="k">${k}</span><div><b>${name}</b><small>${desc}</small></div>${extra}${btn || ''}</div>`; }

function openInventory(g) {
  const p = g.player, inv = g.inv, sam = g.cls === 'samurai';
  const eq = (slot, id) => inv.equip[slot] === id;
  let html = `<p class="gold">◈ ${inv.gold} ouro · ${sam ? '侍 Samurai' : '騎 Cavaleiro'} · nível ${inv.stats.lv} · ${p.flaskMax} frasco(s) · afiação ${g.sharpen}/3</p>`;
  html += `<p class="none">命 Vida ${inv.stats.vida} · 力 Força ${inv.stats.forca} · 速 Agilidade ${inv.stats.agil} <button type="button" data-lv="1">${atFire(g) ? 'subir de nível' : 'nível'}</button></p>`;
  if (inv.sword) { const I = itemInfo(g, 'sword'); html += row(I.kanji, I.name, I.desc, ''); }
  html += '<h4>Equipamento</h4>';
  const ownsArmor = inv.bag.armor > 0, ownsCrown = inv.bag.crown > 0;
  html += row('鎧', ownsArmor ? itemInfo(g, 'armor').name : (sam ? 'Armadura laminada' : 'Armadura do Juramento'), ownsArmor ? itemInfo(g, 'armor').desc : 'A armadura com que você despertou.',
    ownsArmor ? `<button type="button" data-eq="armor">${eq('armor', 'armor') ? 'tirar' : 'vestir'}</button>` : '');
  html += row('冠', ownsCrown ? itemInfo(g, 'crown').name : 'Cabeça', ownsCrown ? itemInfo(g, 'crown').desc : 'Nada sobre o elmo.', ownsCrown ? `<button type="button" data-eq="head">${eq('head', 'crown') ? 'tirar' : 'colocar'}</button>` : '');
  html += '<h4>Itens</h4>';
  const keys = Object.keys(inv.bag).filter(k => k !== 'armor' && k !== 'crown');
  if (g.vs && g.vs.amulet) keys.push('amulet');
  if (g.blueSword) keys.push('blade');
  if (!keys.length) html += '<p class="none">A bolsa está vazia.</p>';
  for (const k of keys) { const I = itemInfo(g, k), n = inv.bag[k]; html += row(I.kanji, I.name + (n > 1 ? ` ×${n}` : ''), I.desc, I.use ? `<button type="button" data-use="${k}">usar</button>` : ''); }
  if (inv.achv.length) { html += '<h4>Conquistas</h4>' + inv.achv.map(a => `<p class="achv">★ ${a}</p>`).join(''); }
  const el = panel('Inventário', html);
  const lvb = el.querySelector('[data-lv]'); if (lvb) lvb.onclick = () => openLevel(g);
  el.querySelectorAll('[data-eq]').forEach(b => b.onclick = () => {
    const slot = b.dataset.eq, id = slot === 'armor' ? 'armor' : 'crown';
    inv.equip[slot] = inv.equip[slot] === id ? null : id; applyEquip(g); snd(g, 'swap'); g.save(); openInventory(g);
  });
  el.querySelectorAll('[data-use]').forEach(b => b.onclick = () => {
    const k = b.dataset.use;
    if (k === 'pie') { if (g.takeItem('pie')) { p.hp = Math.min(p.hpMax, p.hp + 50); snd(g, 'heal'); } }
    if (k === 'bell') { if (g.ringBell && g.ringBell()) { g.takeItem('bell'); closePanel(); return; } }
    g.save(); openInventory(g);
  });
}

function openShop(g, owner) {
  const inv = g.inv, p = g.player;
  let html = `<p class="gold">◈ ${inv.gold} ouro</p><p class="none">«${owner.greet}»</p>`;
  for (const it of SHOP) {
    const I = it.name ? it : itemInfo(g, it.id);
    let can = inv.gold >= it.price;
    if (it.id === 'flask' && p.flaskMax >= 5) can = false;
    if (it.id === 'sharpen' && g.sharpen >= 3) can = false;
    html += row(I.kanji, I.name, I.desc, `<button type="button" data-buy="${it.id}" ${can ? '' : 'disabled'}>${it.price} ◈</button>`);
  }
  const el = panel(owner.name, html);
  el.querySelectorAll('[data-buy]').forEach(b => b.onclick = () => {
    const it = SHOP.find(x => x.id === b.dataset.buy);
    if (inv.gold < it.price) return;
    inv.gold -= it.price; snd(g, 'pickup');
    if (it.id === 'flask') { p.flaskMax++; p.flasks = p.flaskMax; }
    else if (it.id === 'sharpen') g.sharpen++;
    else g.addItem(it.id);
    g.save(); openShop(g, owner);
  });
}

/** Coroa de ouro (osso da cabeça), acima do elmo de qualquer classe. */
export function crownParts() {
  const ring = (x, y, z) => Math.max(Math.abs(Math.hypot(x, z) - 0.115) - 0.012, Math.abs(y - 0.35) - 0.03);
  const spikes = (x, y, z) => { const a = Math.atan2(z, x), k = Math.abs(((a / (Math.PI / 4)) % 1 + 1) % 1 - 0.5) * 2; return Math.max(Math.abs(Math.hypot(x, z) - 0.115) - 0.01, y - (0.38 + 0.09 * (1 - k)), 0.33 - y); };
  return [{ name: 'coroa', bone: 3, f: S.union(ring, spikes), min: [-0.14, 0.3, -0.14], max: [0.14, 0.48, 0.14], mat: MAT.GOLD, spacing: 0.008, flow: [1, 0, 0],
    decals: [0, 1, 2, 3].map(i => { const a = i * Math.PI / 2 + 0.4; return { p: [Math.cos(a) * 0.13, 0.35, Math.sin(a) * 0.13], n: [Math.cos(a), 0, Math.sin(a)], glyph: '◆', mat: MAT.FLOWER_R, size: 0.03, flags: 2 }; }) }];
}
