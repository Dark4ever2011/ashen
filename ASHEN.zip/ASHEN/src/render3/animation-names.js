// ASHEN — Nomes de animação aceitos nos modelos .glb (preparação da Fase 3).
// Cada estado do combate procura, na ordem, um destes nomes de clipe dentro do .glb.
// Vale o nome padrão do ASHEN e os nomes que o Mixamo dá quando se baixa a animação
// (o Mixamo costuma nomear o clipe "mixamo.com" ou "Armature|mixamo.com|Layer0"; por isso também
// procuramos pelo NOME DO ARQUIVO, ex.: "Sword And Shield Idle.fbx" convertido → "Sword And Shield Idle").
// A comparação ignora maiúsculas, espaços, "_" e "-".

export const ANIM_NAMES = {
  idle: ['Idle', 'Sword And Shield Idle', 'Great Sword Idle', 'Standing Idle', 'Breathing Idle', 'Idle Breathing', 'Katana Idle'],
  walk: ['Walk', 'Sword And Shield Walk', 'Great Sword Walk', 'Walking', 'Standard Walk', 'Katana Walk'],
  run: ['Run', 'Sword And Shield Run', 'Great Sword Run', 'Running', 'Standard Run', 'Katana Run', 'Sprint'],
  attack1: ['Attack1', 'Attack_1', 'Sword And Shield Slash', 'Great Sword Slash', 'Stable Sword Outward Slash', 'Katana Slash', 'Slash'],
  attack2: ['Attack2', 'Attack_2', 'Sword And Shield Attack', 'Great Sword Slash 2', 'Stable Sword Inward Slash', 'Katana Slash 2', 'Slash 2'],
  attack3: ['Attack3', 'Attack_3', 'Sword And Shield Power Up', 'Great Sword High Spin Attack', 'Great Sword Jump Attack', 'Katana Slash 3', 'Heavy Attack'],
  roll: ['Roll', 'Dodge', 'Sword And Shield Roll', 'Stand To Roll', 'Running Roll', 'Sprinting Forward Roll', 'Quick Roll To Run'],
  block: ['Block', 'Sword And Shield Block', 'Sword And Shield Block Idle', 'Great Sword Blocking', 'Standing Block Idle', 'Katana Block'],
  hit: ['Hit', 'Sword And Shield Impact', 'Great Sword Impact', 'Standing React Large From Front', 'Hit Reaction', 'Big Hit To Head'],
  death: ['Death', 'Sword And Shield Death', 'Great Sword Death', 'Dying', 'Falling Back Death', 'Standing Death Backward'],
  heal: ['Heal', 'Drinking', 'Drink', 'Sword And Shield Casting', 'Standing 1H Magic Attack', 'Taking Item'],
};

/** Ossos que o jogo procura para a espada (cálculo de acerto) — padrão e Mixamo. */
export const SWORD_BONES = { sword: ['Sword', 'Weapon', 'mixamorig:RightHandIndex1', 'mixamorigRightHandIndex1', 'RightHand', 'mixamorig:RightHand'], tip: ['SwordTip', 'WeaponTip'] };

const norm = s => String(s || '').toLowerCase().replace(/^.*\|/, '').replace(/\.(fbx|glb|gltf)$/, '').replace(/[\s_\-.:]+/g, '');

/** Escolhe o clipe de um estado. clips: lista de THREE.AnimationClip (ou {name}). fileName: nome do arquivo de origem, se houver. */
export function pickClip(clips, state, fileName = '') {
  const want = (ANIM_NAMES[state] || [state]).map(norm);
  for (const w of want) { const c = clips.find(c => norm(c.name) === w); if (c) return c; }
  // clipe único com nome genérico do Mixamo: vale o nome do arquivo
  if (fileName && clips.length === 1 && /mixamo|layer0|take ?001|armature/i.test(clips[0].name) && want.includes(norm(fileName))) return clips[0];
  for (const w of want) { const c = clips.find(c => norm(c.name).includes(w)); if (c) return c; }
  return null;
}
