// ASHEN 3D — Classe Samurai: mesmo esqueleto do cavaleiro, armadura laminada (ō-yoroi) de ferro
// laqueado com cordões vermelhos e kanji gravados, kabuto com chifres em crescente, máscara menpō,
// brasão (菊) no peito e nas costas, katana longa e curva empunhada com as duas mãos.

import { MAT } from './glyphs.js';
import * as S from './sdf.js';
import { noise3 } from './math3d.js';
import { BONE } from './knight3d.js';

export const ENGRAVE = '武士道侍刀魂義勇忠誠礼名炎月影鬼龍風雷';
const hash = (p) => { const s = Math.sin(p[0] * 127.1 + p[1] * 311.7 + p[2] * 74.7) * 43758.5; return s - Math.floor(s); };
/** Placas laminadas: faixas de ferro separadas por cordões vermelhos; kanji gravados em prata aqui e ali. */
const lamellar = (pitch = 0.045, axis = 1) => (p) => {
  const v = p[axis], f = ((v / pitch) % 1 + 1) % 1;
  if (f < 0.2) return { mat: MAT.CLOTH, glyph: ['×', '+', 'x'][(Math.abs(p[0] * 300) | 0) % 3], size: 0.85 };
  const h = hash([Math.floor(p[0] / 0.03), Math.floor(v / pitch), Math.floor(p[2] / 0.03)]);
  if (h < 0.3) return { mat: MAT.SILVER, glyph: ENGRAVE[(h * 1000 | 0) % ENGRAVE.length], size: 0.95 };
  return noise3(p[0] * 30, p[1] * 30, p[2] * 30) > 0.7 ? { mat: MAT.DARK } : null;
};

export function samuraiParts() {
  const P = [], add = o => P.push(o);
  // ── tronco: dō laminado, brasão no peito e nas costas, gola (nodowa) ──
  add({ name: 'dō', bone: BONE.CHEST, f: S.smooth(0.03, S.xf(S.ellipsoid(0.2, 0.24, 0.15), [0, 0.18, 0.012]), S.xf(S.ellipsoid(0.17, 0.08, 0.13), [0, 0.32, 0])), min: [-0.24, -0.08, -0.18], max: [0.24, 0.44, 0.18], mat: MAT.IRON, spacing: 0.02, flow: [1, 0, 0],
    detail: lamellar(0.046),
    decals: [{ p: [0, 0.22, 0.16], n: [0, 0, 1], glyph: '菊', mat: MAT.GOLD, size: 0.1, clear: 0.07 }, { p: [0, 0.22, -0.145], n: [0, 0, -1], glyph: '菊', mat: MAT.GOLD, size: 0.13, clear: 0.09 }] });
  add({ name: 'nodowa', bone: BONE.CHEST, f: S.xf(S.cylinder(0.075, 0.035, 0.012), [0, 0.39, 0.005]), min: [-0.1, 0.34, -0.1], max: [0.1, 0.44, 0.1], mat: MAT.IRON, spacing: 0.012, flow: [1, 0, 0], detail: lamellar(0.02) });
  // cordão de seda (agemaki) nas costas e o obi com borlas
  add({ name: 'agemaki', bone: BONE.CHEST, f: S.union(S.xf(S.torus(0.035, 0.012), [0, 0.12, -0.155], [Math.PI / 2, 0, 0]), S.capsule([0, 0.1, -0.16], [-0.03, -0.05, -0.17], 0.01), S.capsule([0, 0.1, -0.16], [0.03, -0.05, -0.17], 0.01)), min: [-0.06, -0.08, -0.2], max: [0.06, 0.17, -0.12], mat: MAT.CLOTH, spacing: 0.009, flow: [0, 1, 0] });
  add({ name: 'obi', bone: BONE.PELVIS, f: S.union(S.xf(S.torus(0.17, 0.028), [0, 0.06, 0]), S.capsule([0.08, 0.05, 0.15], [0.12, -0.25, 0.16], 0.012), S.capsule([0.11, 0.05, 0.14], [0.17, -0.22, 0.15], 0.012)), min: [-0.21, -0.28, -0.21], max: [0.21, 0.1, 0.21], mat: MAT.CLOTH, spacing: 0.012, flow: [1, 0, 0],
    detail: (p) => (p[1] < -0.17 ? { mat: MAT.CLOTH, glyph: '⁞' } : (Math.sin(Math.atan2(p[2], p[0]) * 40) > 0.6 ? { mat: MAT.BLOOD } : null)) });
  // ── kusazuri: saia de placas em 6 painéis ──
  const skirt = (x, y, z) => {
    const r = Math.hypot(x, z), a = Math.atan2(z, x), panel = Math.abs(((a / (Math.PI / 3)) % 1 + 1) % 1 - 0.5);
    const R = 0.19 + (0.04 - y) * 0.28;
    return Math.max(Math.abs(r - R) - 0.012, y - 0.04, -0.34 - y, 0.47 - panel > 0.04 ? -1 : 1);
  };
  add({ name: 'kusazuri', bone: BONE.PELVIS, f: skirt, min: [-0.32, -0.36, -0.32], max: [0.32, 0.06, 0.32], mat: MAT.IRON, spacing: 0.018, flow: [1, 0, 0], detail: lamellar(0.055) });
  // saya (bainha) presa ao quadril esquerdo
  add({ name: 'saya', bone: BONE.PELVIS, f: S.capsule([0.2, 0.02, 0.08], [0.32, -0.28, -0.72], 0.022), min: [0.15, -0.32, -0.76], max: [0.36, 0.07, 0.12], mat: MAT.DARK, spacing: 0.012, flow: [0, 0, 1],
    detail: (p) => (p[2] > 0.03 || p[2] < -0.68 ? { mat: MAT.GOLD } : (Math.abs(((p[2] * 12) % 1 + 1) % 1) < 0.08 ? { mat: MAT.CLOTH } : null)) });
  // ── cabeça: kabuto com shikoro em camadas, fukigaeshi, maedate em crescente, menpō ──
  const bowl = S.intersect(S.shell(S.xf(S.ellipsoid(0.135, 0.13, 0.15), [0, 0.17, 0]), 0.012), S.above(0.12));
  add({ name: 'kabuto', bone: BONE.HEAD, f: bowl, min: [-0.15, 0.1, -0.17], max: [0.15, 0.31, 0.17], mat: MAT.IRON, spacing: 0.011, flow: [0, 1, 0],
    detail: (p) => (Math.abs(((Math.atan2(p[0], p[2]) * 5) % 1 + 1) % 1 - 0.5) < 0.05 ? { mat: MAT.SILVER, glyph: '│' } : (hash(p) < 0.12 ? { mat: MAT.SILVER, glyph: ENGRAVE[(hash(p) * 999 | 0) % ENGRAVE.length] } : null)) });
  const shikoro = (x, y, z) => { const r = Math.hypot(x, z), R = 0.15 + (0.14 - y) * 0.55; return Math.max(Math.abs(r - R) - 0.01, y - 0.14, -0.02 - y, z - 0.05 + (0.14 - y) * 0.3); };
  add({ name: 'shikoro', bone: BONE.HEAD, f: shikoro, min: [-0.25, -0.04, -0.25], max: [0.25, 0.16, 0.12], mat: MAT.IRON, spacing: 0.012, flow: [1, 0, 0], detail: lamellar(0.04) });
  for (const s of [-1, 1]) add({ name: 'fukigaeshi', bone: BONE.HEAD, f: S.xf(S.box(0.012, 0.045, 0.06, 0.008), [s * 0.16, 0.14, 0.08], [0, s * 0.6, s * 0.25]), min: [s * 0.16 - 0.07, 0.07, 0.0], max: [s * 0.16 + 0.07, 0.21, 0.16], mat: MAT.IRON, spacing: 0.009, flow: [0, 1, 0],
    detail: () => ({ mat: MAT.GOLD, glyph: '◆' }) });
  // chifres em crescente (dois arcos finos) com o disco do brasão no centro
  const horn = (s) => (x, y, z) => { const cx = s * 0.13, cy = 0.27; const d = Math.hypot(x - cx, y - cy); return Math.max(Math.abs(d - 0.14) - 0.008, Math.abs(z - 0.16) - 0.004, s * (cx - x) > 0 ? -1 : 1, cy - 0.02 - y); };
  add({ name: 'maedate', bone: BONE.HEAD, f: S.union(horn(1), horn(-1)), min: [-0.3, 0.24, 0.14], max: [0.3, 0.44, 0.18], mat: MAT.GOLD, spacing: 0.007, flow: [0, 1, 0], size: 1.1 });
  add({ name: 'brasão do elmo', bone: BONE.HEAD, f: S.xf(S.cylinder(0.035, 0.004), [0, 0.27, 0.165], [Math.PI / 2, 0, 0]), min: [-0.04, 0.23, 0.15], max: [0.04, 0.31, 0.18], mat: MAT.GOLD, spacing: 0.006, flow: [1, 0, 0],
    decals: [{ p: [0, 0.27, 0.172], n: [0, 0, 1], glyph: '菊', mat: MAT.BRONZE, size: 0.05 }] });
  const mask = S.intersect(S.shell(S.xf(S.ellipsoid(0.085, 0.11, 0.1), [0, 0.11, 0.025]), 0.01), (x, y, z) => Math.max(y - 0.13, 0.03 - z));
  add({ name: 'menpō', bone: BONE.HEAD, f: mask, min: [-0.1, -0.01, 0.0], max: [0.1, 0.15, 0.14], mat: MAT.DARK, spacing: 0.009, flow: [0, 1, 0],
    detail: (p) => (Math.abs(p[1] - 0.06) < 0.012 && Math.abs(p[0]) < 0.05 ? { mat: MAT.HAIR, glyph: '≈' } : (Math.abs(p[1] - 0.035) < 0.006 && Math.abs(p[0]) < 0.03 ? { mat: MAT.BONE, glyph: '─' } : null)),
    decals: [-1, 1].map(s => ({ p: [s * 0.035, 0.155, 0.095], n: [0, 0, 1], glyph: '•', mat: MAT.EMBER, size: 0.03, flags: 2 })) });
  add({ name: 'rosto sombrio', bone: BONE.HEAD, f: S.xf(S.ellipsoid(0.08, 0.1, 0.09), [0, 0.13, 0.005]), min: [-0.09, 0.02, -0.09], max: [0.09, 0.24, 0.1], mat: MAT.DARK, spacing: 0.014, flow: [0, 1, 0] });
  // ── braços: sode (ombreiras grandes), kote (mangas com talas), luvas ──
  for (const [ua, fa, hd, s] of [[BONE.UA_L, BONE.FA_L, BONE.HAND_L, 1], [BONE.UA_R, BONE.FA_R, BONE.HAND_R, -1]]) {
    add({ name: 'sode', bone: ua, f: S.xf(S.box(0.012, 0.13, 0.11, 0.01), [s * 0.085, -0.08, 0], [0, 0, s * 0.18]), min: [-0.14, -0.24, -0.13], max: [0.14, 0.06, 0.13], mat: MAT.IRON, spacing: 0.013, flow: [0, 0, 1], detail: lamellar(0.034) });
    add({ name: 'kote', bone: ua, f: S.roundCone([0, 0.01, 0], [0, -0.3, 0], 0.052, 0.044), min: [-0.08, -0.33, -0.08], max: [0.08, 0.05, 0.08], mat: MAT.CLOTH_IN, spacing: 0.016, flow: [0, 1, 0], detail: (p) => (hash(p) < 0.25 ? { mat: MAT.MAIL } : null) });
    add({ name: 'tala do antebraço', bone: fa, f: S.roundCone([0, 0, 0], [0, -0.25, 0], 0.045, 0.034), min: [-0.07, -0.28, -0.07], max: [0.07, 0.04, 0.07], mat: MAT.IRON, spacing: 0.014, flow: [0, 1, 0],
      detail: (p) => (Math.abs(((Math.atan2(p[0], p[2]) * 1.6) % 1 + 1) % 1 - 0.5) < 0.12 ? { mat: MAT.CLOTH_IN } : (hash(p) < 0.2 ? { mat: MAT.SILVER, glyph: ENGRAVE[(hash(p) * 777 | 0) % ENGRAVE.length] } : null)) });
    add({ name: 'luva', bone: hd, f: S.union(S.xf(S.ellipsoid(0.034, 0.06, 0.024), [0, -0.05, 0.005]), S.capsule([0, -0.1, 0.01], [0, -0.15, 0.04], 0.02)), min: [-0.05, -0.18, -0.04], max: [0.05, 0.02, 0.07], mat: MAT.LEATHER, spacing: 0.01, flow: [0, 1, 0] });
  }
  // ── pernas: haidate (coxas), suneate (canelas), tabi e sandálias ──
  for (const [th, sh, ft] of [[BONE.TH_L, BONE.SH_L, BONE.FT_L], [BONE.TH_R, BONE.SH_R, BONE.FT_R]]) {
    add({ name: 'hakama', bone: th, f: S.roundCone([0, 0, 0], [0, -0.44, 0], 0.085, 0.07), min: [-0.11, -0.47, -0.11], max: [0.11, 0.07, 0.11], mat: MAT.CLOTH_IN, spacing: 0.02, flow: [0, 1, 0],
      detail: (p) => (p[2] > 0.03 && p[1] > -0.3 ? lamellar(0.04)(p) || { mat: MAT.IRON } : null) });
    add({ name: 'suneate', bone: sh, f: S.intersect(S.roundCone([0, -0.02, 0], [0, -0.38, 0], 0.056, 0.045), (x, y, z) => -0.005 - z), min: [-0.08, -0.42, -0.02], max: [0.08, 0.02, 0.08], mat: MAT.IRON, spacing: 0.014, flow: [0, 1, 0],
      detail: (p) => (Math.abs(p[0]) < 0.008 ? { mat: MAT.SILVER, glyph: '│' } : (hash(p) < 0.15 ? { mat: MAT.SILVER, glyph: ENGRAVE[(hash(p) * 555 | 0) % ENGRAVE.length] } : null)) });
    add({ name: 'perna', bone: sh, f: S.roundCone([0, 0, 0], [0, -0.42, 0], 0.048, 0.04), min: [-0.07, -0.45, -0.07], max: [0.07, 0.05, 0.07], mat: MAT.CLOTH_IN, spacing: 0.02, flow: [0, 1, 0] });
    add({ name: 'tabi', bone: ft, f: S.xf(S.ellipsoid(0.045, 0.04, 0.12), [0, -0.035, 0.05]), min: [-0.06, -0.08, -0.08], max: [0.06, 0.02, 0.18], mat: MAT.LINEN, spacing: 0.012, flow: [1, 0, 0],
      detail: (p) => (p[1] < -0.06 ? { mat: MAT.THATCH } : null) });
  }
  // ── katana: lâmina longa e levemente curva, hamon claro no fio, tsuba, cabo trançado ──
  const curve = (y) => 0.035 * Math.pow(Math.max(0, y - 0.1) / 1.05, 2);
  const blade = (x, y, z) => { const t = (y - 0.1) / 1.05, w = 0.016 * (1 - 0.35 * t) + (t > 0.95 ? -(t - 0.95) * 0.3 : 0); return Math.max(Math.abs(x) - 0.004, Math.abs(z - curve(y)) - w, 0.1 - y, y - 1.15); };
  add({ name: 'lâmina', bone: BONE.SWORD, f: blade, min: [-0.02, 0.08, -0.04], max: [0.02, 1.17, 0.08], mat: MAT.BLADE, spacing: 0.011, flow: [0, 1, 0], size: 0.9,
    detail: (p) => (p[2] - curve(p[1]) > 0.008 ? { mat: MAT.SILVER, glyph: '~' } : null) });
  add({ name: 'tsuba', bone: BONE.SWORD, f: S.xf(S.cylinder(0.042, 0.005), [0, 0.085, 0]), min: [-0.05, 0.07, -0.05], max: [0.05, 0.1, 0.05], mat: MAT.GOLD, spacing: 0.008, flow: [1, 0, 0] });
  add({ name: 'tsuka', bone: BONE.SWORD, f: S.capsule([0, -0.24, 0], [0, 0.07, 0], 0.016), min: [-0.03, -0.27, -0.03], max: [0.03, 0.09, 0.03], mat: MAT.CLOTH_IN, spacing: 0.008, flow: [1, 0.5, 0],
    detail: (p) => ((Math.floor(p[1] / 0.02) % 2) ? { mat: MAT.BONE, glyph: '◆', size: 0.8 } : null) });
  return P;
}

/** Combo do samurai (chaves no espaço do peito; −x é o lado direito):
 *  1: corte horizontal da direita para a esquerda · 2: da esquerda para a direita · 3: de cima para baixo. Sempre com as duas mãos. */
export const SAMURAI_COMBO = [
  { dur: 0.56, step: 0.24, hit: [0.34, 0.5], twoHands: true,
    hand: [[0.24, [-0.32, 0.3, 0.02]], [0.36, [-0.18, 0.22, 0.4]], [0.5, [0.2, 0.18, 0.4]], [0.64, [0.34, 0.12, 0.14]]],
    dir: [[0.24, [-0.92, 0.2, -0.32]], [0.36, [-0.55, 0.08, 0.83]], [0.5, [0.62, 0.02, 0.78]], [0.64, [0.92, -0.05, -0.25]]],
    twist: [[0, 0], [0.24, 0.62], [0.45, 0.0], [0.64, -0.52], [0.85, -0.2], [1, 0]], lean: [[0, 0], [0.24, -0.04], [0.46, 0.16], [0.7, 0.1], [1, 0]] },
  { dur: 0.56, step: 0.24, hit: [0.34, 0.5], twoHands: true,
    hand: [[0.24, [0.34, 0.3, 0.02]], [0.36, [0.2, 0.22, 0.4]], [0.5, [-0.18, 0.18, 0.4]], [0.64, [-0.32, 0.12, 0.14]]],
    dir: [[0.24, [0.92, 0.2, -0.32]], [0.36, [0.55, 0.08, 0.83]], [0.5, [-0.62, 0.02, 0.78]], [0.64, [-0.92, -0.05, -0.25]]],
    twist: [[0, -0.2], [0.24, -0.62], [0.45, 0.0], [0.64, 0.52], [0.85, 0.2], [1, 0]], lean: [[0, 0.04], [0.3, 0.0], [0.5, 0.16], [1, 0]] },
  { dur: 0.84, step: 0.4, hit: [0.46, 0.58], twoHands: true,
    hand: [[0.34, [-0.02, 0.66, -0.04]], [0.46, [-0.01, 0.44, 0.34]], [0.58, [0.0, -0.02, 0.5]], [0.76, [0.0, -0.12, 0.42]]],
    dir: [[0.34, [0.0, 0.42, -0.9]], [0.46, [0.0, 0.92, 0.4]], [0.58, [0.0, -0.5, 0.86]], [0.76, [0.0, -0.78, 0.62]]],
    twist: [[0, 0], [0.34, 0.15], [0.55, -0.05], [1, 0]], lean: [[0, 0], [0.34, -0.14], [0.56, 0.34], [0.8, 0.26], [1, 0]] },
];
