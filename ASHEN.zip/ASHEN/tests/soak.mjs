// Sessão longa: anda pelo mapa inteiro, gira a tela (retrato ↔ paisagem), troca presets.
// Verifica erros, memória JS e tamanho dos caches.
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const url = process.argv[2] || 'http://localhost:8123/index.html';
const secs = +(process.argv[3] || 40);
const browser = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--enable-precise-memory-info'] });
const ctx = await browser.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 2.625, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', e => errors.push(e.message));
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
await page.goto(url);
await page.waitForFunction(() => window.__ASHEN && window.__ASHEN.state === 'title', null, { timeout: 60000 });
await page.tap('#start');
const snap = () => page.evaluate(() => { const g = window.__ASHEN; return { t: Math.round(g.world.time), x: Math.round(g.player.x), y: Math.round(g.player.y), heapMB: performance.memory ? +(performance.memory.usedJSHeapSize / 1048576).toFixed(1) : null, knightMB: +(g.player.rig.cache.bytes() / 1048576).toFixed(1), frames: g.player.rig.cache.map.size, chunks: g.world.terrain.cache.size, parts: g.world.particles.count, fps: Math.round(g.perf.fps) }; });
const keys = ['KeyW', 'KeyA', 'KeyS', 'KeyD'];
const start = Date.now();
const log = [];
let i = 0;
while ((Date.now() - start) / 1000 < secs) {
  const k1 = keys[i % 4], k2 = keys[(i * 3 + 1) % 4];
  await page.keyboard.down(k1); if (i % 3 === 0) await page.keyboard.down('ShiftLeft');
  if (i % 2) await page.keyboard.down(k2);
  await page.waitForTimeout(1200 + (i % 5) * 300);
  await page.keyboard.up(k1); await page.keyboard.up(k2); await page.keyboard.up('ShiftLeft');
  if (i === 6) { await page.evaluate(() => document.fullscreenElement && document.exitFullscreen()).catch(() => {}); await page.waitForTimeout(300); await page.setViewportSize({ width: 412, height: 915 }); await page.waitForTimeout(800); log.push(['retrato', await snap(), await page.isVisible('#rotate')]); await page.tap('#rotate-ok').catch(() => {}); }
  if (i === 8) { await page.setViewportSize({ width: 915, height: 412 }); await page.waitForTimeout(800); log.push(['paisagem', await snap(), await page.isVisible('#rotate')]); }
  if (i === 10) await page.evaluate(() => { const g = window.__ASHEN; g.settings.preset = 'DESEMPENHO'; g.applySettings(false); });
  if (i === 13) await page.evaluate(() => { const g = window.__ASHEN; g.settings.preset = 'ALTA'; g.applySettings(false); });
  if (i % 4 === 0) log.push(['t', await snap()]);
  i++;
}
log.push(['fim', await snap()]);
for (const l of log) console.log(l.map(v => typeof v === 'object' ? JSON.stringify(v) : v).join(' '));
console.log('erros:', errors.length ? [...new Set(errors)].join('\n') : 'nenhum');
await browser.close();
