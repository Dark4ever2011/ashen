// ASHEN 3D — Renderizador tipográfico em WebGL2.
// A tela só recebe caracteres. A geometria existe como pontos de superfície (com normal e
// tangente) que viram "carimbos" de caracteres instanciados na GPU.
// Passes: (1) sombra do luar, (2) oclusão invisível (só profundidade), (3) caracteres, (4) partículas.

import { m4 } from './math3d.js';
import { MATERIALS, VEG, GLINT } from './glyphs.js';

const MAX_BONES = 24, MAX_LIGHTS = 4;
const NMAT = MATERIALS.length;

const VS = `#version 300 es
precision highp float;
precision highp int;
precision highp sampler2DShadow;
layout(location=0) in vec2 aCorner;
layout(location=1) in vec3 iPos;
layout(location=2) in vec3 iNrm;
layout(location=3) in vec3 iTan;
layout(location=4) in vec4 iAttr;   // material, glifo fixo, osso, flags
layout(location=5) in vec2 iExtra;  // tamanho, semente
uniform mat4 uVP, uLightVP;
uniform mat4 uBones[${MAX_BONES}];
uniform vec3 uCam;
uniform vec2 uViewport;
uniform float uPxScale, uGlyph, uBias, uTime, uShadowSize, uExposure;
uniform int uPass;
uniform vec3 uMoonDir, uMoonCol, uSky, uGround;
uniform vec4 uLightPos[${MAX_LIGHTS}];   // xyz, raio
uniform vec4 uLightCol[${MAX_LIGHTS}];   // rgb * intensidade
uniform int uNumLights;
uniform vec3 uMatColor[${NMAT}];
uniform vec3 uMatProps[${NMAT}];        // especular, emissivo, brilho (expoente)
uniform ivec4 uRamp[${(NMAT + 1) * 2}];   // 8 caracteres por material, empacotados
int ramp(int i) { ivec4 v = uRamp[i / 4]; int k = i - (i / 4) * 4; return k == 0 ? v.x : k == 1 ? v.y : k == 2 ? v.z : v.w; }
uniform ivec4 uRim;
uniform ivec4 uVeg[4];
uniform ivec4 uGlint;
uniform vec4 uWind;    // direção xz, força, -
uniform vec3 uPlayer;
uniform vec3 uRimDir, uRimCol;          // luz lateral/de recorte (fria, de trás)
int pick(ivec4 v, int k) { return k == 0 ? v.x : k == 1 ? v.y : k == 2 ? v.z : v.w; }
int veg(int i) { return pick(uVeg[i / 4], i - (i / 4) * 4); }
uniform float uAtlasCols, uAtlasRows;
uniform vec4 uFog;                      // rgb, densidade
uniform vec3 uFocus;
uniform sampler2DShadow uShadow;
out vec2 vUV;
out vec4 vColor;
out float vDisc;

float h1(float n) { return fract(sin(n * 12.9898) * 43758.5453); }

void main() {
  mat4 B = uBones[int(iAttr.z)];
  int flags = int(iAttr.w);
  bool isVeg = (flags & 8) != 0;
  vec3 wp, wn, wt;
  vec2 wd = uWind.xy;
  float ws = uWind.z;
  if (isVeg) {
    // ── Talo de grama dobrado pelo vento (rajadas que viajam + tremulação própria + cavaleiro) ──
    float f = iTan.x, h = iTan.y, nat = iTan.z;
    vec3 root = iPos;
    float g1 = sin(dot(root.xz, wd) * 0.55 - uTime * 1.6);
    float g2 = sin(dot(root.xz, vec2(-wd.y, wd.x)) * 0.31 + uTime * 0.53 + g1 * 0.6);
    float gust = 0.5 + 0.32 * g1 + 0.18 * g2;
    float fl = sin(uTime * (4.5 + fract(iExtra.y * 0.131) * 4.0) + iExtra.y) * 0.2 + sin(uTime * 11.3 + iExtra.y * 2.1) * 0.06;
    bool plant = (flags & 32) != 0;
    vec2 bend = wd * ws * (gust + fl) * (plant ? 0.35 : 1.0) + vec2(cos(nat), sin(nat)) * 0.22;
    vec2 pd = root.xz - uPlayer.xz;
    float pdl = length(pd);
    if (pdl < 0.75) bend += pd / max(pdl, 0.05) * (0.75 - pdl) * 2.4;
    float bl = length(bend);
    if (bl > 1.5) bend *= 1.5 / bl;
    float k = pow(f, 1.6);
    float droop = min(length(bend), 1.3);
    if (plant) {
      vec2 o = vec2(cos(nat), sin(nat)) * (0.03 + f * 0.09);
      wp = root + vec3(o.x, h * (0.4 + 0.6 * (1.0 - f)), o.y) + vec3(bend.x, 0.0, bend.y) * h * 0.25;
    } else {
      wp = root + vec3(0.0, h * f * (1.0 - 0.3 * droop * droop * f), 0.0) + vec3(bend.x, 0.0, bend.y) * h * k * 0.8;
    }
    wn = normalize(vec3(bend.x * 0.6, 1.0, bend.y * 0.6));
    wt = normalize(vec3(bend.x * 1.7 * k, 1.0, bend.y * 1.7 * k));
  } else {
    wp = (B * vec4(iPos, 1.0)).xyz;
    wn = normalize(mat3(B) * iNrm);
    wt = normalize(mat3(B) * iTan);
    if ((flags & 16) != 0) {
      // ── Galhos: balanço sutil, maior nas pontas e no alto ──
      float amt = pow(clamp((wp.y - 0.8) / 4.5, 0.0, 1.0), 2.0);
      float ph = uTime * 1.25 + wp.x * 0.6 + wp.z * 0.45;
      vec2 sw = wd * ws * (0.55 + 0.45 * sin(ph)) * 0.22 + vec2(sin(uTime * 3.7 + iExtra.y), cos(uTime * 3.1 + iExtra.y)) * 0.025;
      wp += vec3(sw.x, -0.02 * length(sw), sw.y) * amt;
    }
  }
  float size = iExtra.x, ao = 1.0;
  bool hasAO = (flags & 64) != 0;
  if (hasAO) { size = floor(iExtra.x) / 2000.0; ao = fract(iExtra.x) / 0.99; }
  vDisc = 0.0;
  if (uPass == 2) {                       // sombra: discos virados para a lua
    vec4 c = uLightVP * vec4(wp, 1.0);
    gl_Position = c + vec4(aCorner * uShadowSize * size, 0.0, 0.0);
    vUV = aCorner; vDisc = 1.0; vColor = vec4(1.0);
    return;
  }
  vec3 V = normalize(uCam - wp);
  float ndv = dot(wn, V);
  bool emissive = (flags & 2) != 0;
  if (isVeg) ndv = abs(ndv) + 0.4;          // talos são finos: vistos dos dois lados
  if (ndv < -0.08 && !emissive) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return; }
  vec4 clip = uVP * vec4(wp, 1.0);
  float px = size * uGlyph * uPxScale / clip.w;
  if (uPass == 1) {                       // oclusão: disco invisível, um pouco atrás da superfície
    vec4 cb = uVP * vec4(wp - V * 0.012, 1.0);
    gl_Position = cb + vec4(aCorner * px * 0.9 / uViewport * cb.w, 0.0, 0.0);
    vUV = aCorner; vDisc = 1.0; vColor = vec4(1.0);
    return;
  }
  // ── Iluminação por caractere ──
  int mat = int(iAttr.x);
  vec3 base = uMatColor[mat];
  vec3 props = uMatProps[mat];
  float sh = 1.0;
  vec4 lc = uLightVP * vec4(wp + wn * 0.03, 1.0);
  vec3 lp = lc.xyz / lc.w * 0.5 + 0.5;
  if (lp.x > 0.0 && lp.x < 1.0 && lp.y > 0.0 && lp.y < 1.0) {
    float o = 1.0 / 2048.0;
    sh = 0.0;
    for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++)
      sh += texture(uShadow, vec3(lp.xy + vec2(float(i), float(j)) * o * 1.5, lp.z - 0.0015));
    sh /= 9.0;
  }
  float aoD = mix(1.0, ao, 0.75);                       // a luz direta também sofre nas frestas
  vec3 amb = mix(uGround, uSky, wn.y * 0.5 + 0.5) * ao;
  float dm = max(dot(wn, uMoonDir), 0.0);
  vec3 diff = uMoonCol * dm * sh * aoD;
  vec3 H = normalize(uMoonDir + V);
  float gls = props.z, gn = (gls + 8.0) / 32.0;           // brilho: metal polido = ponto pequeno e forte
  vec3 spec = uMoonCol * pow(max(dot(wn, H), 0.0), gls) * gn * props.x * sh * ao;
  vec3 specD = spec;
  float fres = pow(1.0 - clamp(ndv, 0.0, 1.0), 4.0);
  if (props.x > 0.5) {                                  // metais refletem o céu e o chão
    vec3 Rf = reflect(-V, wn);
    spec += mix(uGround * 1.5, uSky * 3.2, smoothstep(-0.3, 0.6, Rf.y)) * (0.25 + 0.75 * fres) * props.x * 0.55 * ao;
  }
  // luz lateral de recorte: separa o volume do fundo
  float rimL = pow(1.0 - clamp(abs(ndv), 0.0, 1.0), 2.2) * max(dot(wn, uRimDir), 0.0);
  diff += uRimCol * rimL * ao * (hasAO ? 1.0 : 0.35) * (0.6 + props.x * 0.6);
  for (int i = 0; i < ${MAX_LIGHTS}; i++) {
    if (i >= uNumLights) break;
    vec3 Lv = uLightPos[i].xyz - wp;
    float d = length(Lv);
    float att = clamp(1.0 - d / uLightPos[i].w, 0.0, 1.0);
    att *= att;
    vec3 L = Lv / d;
    float nl = isVeg ? (dot(wn, L) * 0.5 + 0.5) : max(dot(wn, L), 0.0);   // grama translúcida
    diff += uLightCol[i].rgb * att * (nl * 0.95 + 0.12 * ao) * aoD;
    vec3 sp1 = uLightCol[i].rgb * att * pow(max(dot(wn, normalize(L + V)), 0.0), gls) * gn * props.x * ao;
    spec += sp1; specD += sp1;
  }
  vec3 col = base * (amb + diff) + spec;
  if (isVeg) col *= 1.55;   // talos finos deixam passar luz (translucidez)
  if (wp.y < 0.35 && !hasAO) {                          // sombra de contato sob o cavaleiro
    vec2 dp = wp.xz - uPlayer.xz;
    col *= 1.0 - 0.6 * exp(-dot(dp, dp) / 0.1);
  }
  if (hasAO && (flags & 1) != 0 && props.x > 0.5) col += base * 0.12 * (0.5 + sh);   // aresta gasta: metal mais claro
  float lum = dot(col, vec3(0.3, 0.5, 0.2));
  float glint = dot(specD, vec3(0.333));
  // ── Escolha do caractere ──
  float seed = iExtra.y;
  float dither = (h1(seed) - 0.5) * (hasAO ? 0.35 : 0.9);
  float distK = clamp((distance(wp.xz, uFocus.xz) - 5.0) / 10.0, 0.0, 1.0);
  int level = clamp(int(lum * uExposure + dither + 0.5 + distK * 2.0), 0, 7);   // longe = traço mais leve
  int g = int(iAttr.y);
  bool fixedG = g >= 0;
  float rim = 1.0 - abs(ndv);
  vec2 sp = clip.xy / clip.w;
  vec4 ct = uVP * vec4(wp + wt * 0.05, 1.0);
  vec2 dir = (ct.xy / ct.w - sp) * uViewport;
  float dl = length(dir);
  dir = dl > 1e-4 ? dir / dl : vec2(1.0, 0.0);
  float squash = 1.0;
  if (emissive) {
    col = base * (1.4 + 0.5 * sin(uTime * 9.0 + seed));
    level = 7;
    if (!fixedG) g = ramp(mat * 8 + int(mod(seed + uTime * 6.0, 8.0)));
  } else if (isVeg) {
    // caractere pela inclinação real do talo na tela
    vec4 ct2 = uVP * vec4(wp + wt * 0.12, 1.0);
    vec2 v = (ct2.xy / ct2.w - sp) * uViewport;
    float a = atan(v.x, max(abs(v.y), 1e-3) * sign(v.y + 1e-6));
    float aa = abs(a);
    if ((flags & 32) != 0) g = veg(10 + int(mod(seed, 4.0)));
    else if (iTan.x > 0.7) g = fract(seed * 0.37) < 0.12 ? veg(9) : (aa < 0.35 ? veg(6) : (a > 0.0 ? veg(8) : veg(7)));
    else g = aa < 0.22 ? veg(0) : aa < 0.6 ? (a > 0.0 ? veg(1) : veg(2)) : aa < 1.15 ? (a > 0.0 ? veg(3) : veg(4)) : veg(5);
    dir = vec2(1.0, 0.0);
  } else if (!fixedG) {
    if (glint > 0.5 && props.x > 0.4 && fract(seed * 0.618) < 0.4) {
      // reflexo metálico: troca o caractere e acende conforme luz e câmera se movem
      g = pick(uGlint, clamp(int((glint - 0.5) * 5.0), 0, 3));
      col += spec * 0.6;
    } else
    if ((flags & 1) != 0) g = ramp(${NMAT} * 8 + level);
    else g = ramp(mat * 8 + level);
    // silhueta: traço perpendicular à normal projetada, mais claro (contorno)
    if (rim > 0.74) {
      vec4 cn = uVP * vec4(wp + wn * 0.05, 1.0);
      vec2 nd = (cn.xy / cn.w - sp) * uViewport;
      float nl = length(nd);
      if (nl > 1e-4) dir = vec2(-nd.y, nd.x) / nl;
      g = pick(uRim, int(mod(seed, 4.0)));
      col = col * 1.15 + base * 0.18;
    } else {
      squash = mix(0.8, 1.0, clamp(abs(ndv) * 1.6, 0.0, 1.0));
    }
  }
  if (g < 0) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return; }
  // ── Névoa de distância e de chão ──
  float dist = distance(wp.xz, uFocus.xz);
  float fogA = 1.0 - exp(-max(dist - 4.0, 0.0) * uFog.a);
  fogA = clamp(fogA + clamp(0.35 - wp.y, 0.0, 0.35) * 0.35, 0.0, 0.9);
  col = mix(col, uFog.rgb, fogA * 0.65);
  float alpha = (1.0 - fogA * 0.55) * mix(hasAO ? 0.82 : 0.62, 1.0, clamp(lum * 2.2, 0.0, 1.0));   // sombras mais translúcidas
  // ── Quad girado na direção da superfície ──
  vec4 cb = uVP * vec4(wp + V * uBias, 1.0);
  vec2 corner = vec2(aCorner.x, aCorner.y * squash) * px * 0.5;
  vec2 r = vec2(dir.x * corner.x - dir.y * corner.y, dir.y * corner.x + dir.x * corner.y);
  gl_Position = cb + vec4(r * 2.0 / uViewport * cb.w, 0.0, 0.0);
  vec2 cell = vec2(mod(float(g), uAtlasCols), floor(float(g) / uAtlasCols));
  vUV = (cell + (aCorner * vec2(0.5, -0.5) + 0.5)) / vec2(uAtlasCols, uAtlasRows);
  vColor = vec4(col * 1.35, alpha);
}`;

const FS = `#version 300 es
precision mediump float;
in vec2 vUV;
in vec4 vColor;
in float vDisc;
uniform sampler2D uAtlas;
uniform int uPass;
out vec4 o;
void main() {
  if (vDisc > 0.5) { if (dot(vUV, vUV) > 1.0) discard; o = vec4(0.0); return; }
  float a = texture(uAtlas, vUV).a * vColor.a;
  if (a < 0.03) discard;
  o = vec4(vColor.rgb * a, a);
}`;

// Partículas (fogo, brasas, cinzas, névoa): caracteres soltos no espaço, sem iluminação.
const PVS = `#version 300 es
precision highp float;
layout(location=0) in vec2 aCorner;
layout(location=1) in vec4 iPos;    // xyz, tamanho (m)
layout(location=2) in vec4 iCol;    // rgb, alfa
layout(location=3) in vec2 iGlyph;  // glifo, rotação
uniform mat4 uVP;
uniform vec2 uViewport;
uniform float uPxScale, uAtlasCols, uAtlasRows;
uniform vec4 uLightPos[${MAX_LIGHTS}];
uniform vec4 uLightCol[${MAX_LIGHTS}];
uniform int uNumLights, uLit;
uniform vec3 uAmbP;
out vec2 vUV; out vec4 vColor;
void main() {
  vec4 c = uVP * vec4(iPos.xyz, 1.0);
  float px = iPos.w * uPxScale / c.w;
  float cs = cos(iGlyph.y), sn = sin(iGlyph.y);
  vec2 k = aCorner * px * 0.5;
  vec2 r = vec2(cs * k.x - sn * k.y, sn * k.x + cs * k.y);
  gl_Position = c + vec4(r * 2.0 / uViewport * c.w, 0.0, 0.0);
  float g = iGlyph.x;
  vec2 cell = vec2(mod(g, uAtlasCols), floor(g / uAtlasCols));
  vUV = (cell + (aCorner * vec2(0.5, -0.5) + 0.5)) / vec2(uAtlasCols, uAtlasRows);
  vec3 c3 = iCol.rgb;
  if (uLit == 1) {               // cinzas, névoa e fumaça recebem a luz do fogo
    vec3 l = uAmbP;
    for (int i = 0; i < ${MAX_LIGHTS}; i++) {
      if (i >= uNumLights) break;
      float d = distance(uLightPos[i].xyz, iPos.xyz);
      float a = clamp(1.0 - d / uLightPos[i].w, 0.0, 1.0);
      l += uLightCol[i].rgb * a * a * 1.6;
    }
    c3 *= l;
  }
  vColor = vec4(c3, iCol.a);
}`;
const PFS = `#version 300 es
precision mediump float;
in vec2 vUV; in vec4 vColor;
uniform sampler2D uAtlas;
out vec4 o;
void main() {
  float a = texture(uAtlas, vUV).a * vColor.a;
  if (a < 0.01) discard;
  o = vec4(vColor.rgb * a, a);
}`;

function compile(gl, type, src) {
  const s = gl.createShader(type);
  gl.shaderSource(s, src); gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) + '\n' + src.split('\n').map((l, i) => i + 1 + ': ' + l).join('\n').slice(0, 4000));
  return s;
}
function program(gl, vs, fs) {
  const p = gl.createProgram();
  gl.attachShader(p, compile(gl, gl.VERTEX_SHADER, vs)); gl.attachShader(p, compile(gl, gl.FRAGMENT_SHADER, fs));
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  const u = {}, n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
  for (let i = 0; i < n; i++) { const info = gl.getActiveUniform(p, i); const name = info.name.replace(/\[0\]$/, ''); u[name] = gl.getUniformLocation(p, info.name); }
  return { p, u };
}

export class GlyphRenderer {
  constructor(canvas, atlas) {
    const gl = canvas.getContext('webgl2', { antialias: false, alpha: false, premultipliedAlpha: true, powerPreference: 'high-performance', depth: true });
    if (!gl) throw new Error('WebGL2 indisponível');
    this.gl = gl; this.canvas = canvas; this.atlas = atlas;
    this.prog = program(gl, VS, FS);
    this.pprog = program(gl, PVS, PFS);
    // quad base
    this.quad = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    // atlas
    this.tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.tex);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, atlas.canvas);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    // sombra
    this.shadowSize = 2048;
    this.shadowTex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.shadowTex);
    gl.texStorage2D(gl.TEXTURE_2D, 1, gl.DEPTH_COMPONENT24, this.shadowSize, this.shadowSize);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_MODE, gl.COMPARE_REF_TO_TEXTURE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_FUNC, gl.LEQUAL);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    this.shadowFB = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.shadowFB);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, this.shadowTex, 0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    this.meshes = [];
    this.particles = null;
    this.stats = { glyphs: 0, particles: 0 };
  }

  /** Conjunto de pontos (PointSet) → VAO. dynamic = posições atualizadas por quadro (capa). */
  addMesh(ps, { dynamic = false, bones = null, occlude = true, chunk = 0 } = {}) {
    const gl = this.gl;
    const n = ps.n, stride = 15;
    let data = new Float32Array(n * stride);
    this._fill(ps, data);
    let chunks = null;
    if (chunk > 0) {
      // ordena os pontos por bloco espacial → cada bloco é um intervalo contínuo no buffer
      const keyOf = i => Math.floor(data[i * 15] / chunk) * 1000 + Math.floor(data[i * 15 + 2] / chunk);
      const idx = Array.from({ length: n }, (_, i) => i).sort((a, b) => keyOf(a) - keyOf(b));
      const sorted = new Float32Array(n * stride);
      idx.forEach((src, dst) => sorted.set(data.subarray(src * 15, src * 15 + 15), dst * 15));
      data = sorted;
      chunks = [];
      let start = 0;
      for (let i = 1; i <= n; i++) {
        if (i === n || keyOf(i) !== keyOf(start)) {
          const b = [1e9, 1e9, 1e9, -1e9, -1e9, -1e9];
          for (let k = start; k < i; k++) for (let a = 0; a < 3; a++) { const v = data[k * 15 + a]; if (v < b[a]) b[a] = v; if (v > b[a + 3]) b[a + 3] = v; }
          chunks.push({ start, count: i - start, box: b });
          start = i;
        }
      }
    }
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, data, dynamic ? gl.DYNAMIC_DRAW : gl.STATIC_DRAW);
    const B = 4 * stride;
    const at = (loc, size, off) => { gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, size, gl.FLOAT, false, B, off * 4); gl.vertexAttribDivisor(loc, 1); };
    at(1, 3, 0); at(2, 3, 3); at(3, 3, 6); at(4, 4, 9); at(5, 2, 13);
    gl.bindVertexArray(null);
    const mesh = { vao, buf, n, data, dynamic, bones: bones || [m4.ident()], visible: true, castShadow: occlude, occlude, chunks };
    this.meshes.push(mesh);
    return mesh;
  }

  _fill(ps, data) {
    for (let i = 0; i < ps.n; i++) {
      const o = i * 15;
      data[o] = ps.pos[i * 3]; data[o + 1] = ps.pos[i * 3 + 1]; data[o + 2] = ps.pos[i * 3 + 2];
      data[o + 3] = ps.nrm[i * 3]; data[o + 4] = ps.nrm[i * 3 + 1]; data[o + 5] = ps.nrm[i * 3 + 2];
      data[o + 6] = ps.tan[i * 3]; data[o + 7] = ps.tan[i * 3 + 1]; data[o + 8] = ps.tan[i * 3 + 2];
      data[o + 9] = ps.attr[i * 4]; data[o + 10] = ps.attr[i * 4 + 1]; data[o + 11] = ps.attr[i * 4 + 2]; data[o + 12] = ps.attr[i * 4 + 3];
      data[o + 13] = ps.extra[i * 2]; data[o + 14] = ps.extra[i * 2 + 1];
    }
  }

  /** Atualiza posições/normais de uma malha dinâmica (capa). */
  updateMesh(mesh, ps) {
    this._fill(ps, mesh.data);
    const gl = this.gl;
    gl.bindBuffer(gl.ARRAY_BUFFER, mesh.buf);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, mesh.data, 0, ps.n * 15);
  }

  setupParticles(max = 3000) {
    const gl = this.gl;
    this.pmax = max;
    this.pdata = new Float32Array(max * 10);
    this.pvao = gl.createVertexArray();
    gl.bindVertexArray(this.pvao);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    this.pbuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.pbuf);
    gl.bufferData(gl.ARRAY_BUFFER, this.pdata.byteLength, gl.DYNAMIC_DRAW);
    const at = (loc, size, off) => { gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 40, off * 4); gl.vertexAttribDivisor(loc, 1); };
    at(1, 4, 0); at(2, 4, 4); at(3, 2, 8);
    gl.bindVertexArray(null);
  }

  resize(scale = 1) {
    const dpr = Math.min(window.devicePixelRatio || 1, 3) * scale;
    const w = Math.round(window.innerWidth * dpr), h = Math.round(window.innerHeight * dpr);
    if (this.canvas.width !== w || this.canvas.height !== h) { this.canvas.width = w; this.canvas.height = h; }
    this.canvas.style.width = window.innerWidth + 'px'; this.canvas.style.height = window.innerHeight + 'px';
    this.W = w; this.H = h; this.dpr = dpr;
  }

  _common(u, f) {
    const gl = this.gl;
    gl.uniformMatrix4fv(u.uVP, false, f.vp);
    gl.uniform2f(u.uViewport, this.W, this.H);
    gl.uniform1f(u.uPxScale, f.pxScale);
    gl.uniform1f(u.uAtlasCols, this.atlas.cols);
    gl.uniform1f(u.uAtlasRows, this.atlas.rows);
  }

  /** Desenha um quadro. f = parâmetros da cena (câmera, luzes, névoa...). */
  frame(f) {
    const gl = this.gl, { p, u } = this.prog;
    gl.useProgram(p);
    this._common(u, f);
    gl.uniformMatrix4fv(u.uLightVP, false, f.lightVP);
    gl.uniform3fv(u.uCam, f.cam);
    gl.uniform3fv(u.uFocus, f.focus);
    gl.uniform1f(u.uGlyph, f.glyphScale);
    gl.uniform1f(u.uExposure, f.exposure || 10);
    gl.uniform1f(u.uTime, f.time);
    gl.uniform1f(u.uShadowSize, f.shadowSize);
    gl.uniform3fv(u.uMoonDir, f.moonDir); gl.uniform3fv(u.uMoonCol, f.moonCol);
    gl.uniform3fv(u.uSky, f.sky); gl.uniform3fv(u.uGround, f.ground);
    gl.uniform3fv(u.uRimDir, f.rimDir || [0, 0.3, -1]); gl.uniform3fv(u.uRimCol, f.rimCol || [0, 0, 0]);
    const lp = new Float32Array(16), lc = new Float32Array(16);
    f.lights.slice(0, MAX_LIGHTS).forEach((l, i) => { lp.set([l.pos[0], l.pos[1], l.pos[2], l.radius], i * 4); lc.set([l.col[0] * l.value, l.col[1] * l.value, l.col[2] * l.value, 1], i * 4); });
    gl.uniform4fv(u.uLightPos, lp); gl.uniform4fv(u.uLightCol, lc);
    gl.uniform1i(u.uNumLights, Math.min(MAX_LIGHTS, f.lights.length));
    if (!this._matSet) {
      gl.uniform3fv(u.uMatColor, new Float32Array(MATERIALS.flatMap(m => m.c)));
      gl.uniform3fv(u.uMatProps, new Float32Array(MATERIALS.flatMap(m => [m.spec || 0, m.emissive || 0, m.gloss || 24])));
      gl.uniform4iv(u.uRamp, new Int32Array(this.atlas.rampTable()));
      gl.uniform4iv(u.uRim, new Int32Array(['─', '━', '─', '═'].map(c => this.atlas.get(c))));
      gl.uniform4iv(u.uVeg, new Int32Array(VEG.map(c => this.atlas.get(c))));
      gl.uniform4iv(u.uGlint, new Int32Array(GLINT.map(c => this.atlas.get(c))));
      this._matSet = true;
    }
    gl.uniform4f(u.uFog, f.fog[0], f.fog[1], f.fog[2], f.fog[3]);
    gl.uniform4f(u.uWind, f.wind[0], f.wind[1], f.wind[2], 0);
    gl.uniform3fv(u.uPlayer, f.focus);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.tex); gl.uniform1i(u.uAtlas, 0);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, null);
    gl.uniform1i(u.uShadow, 1);
    let drawn = 0;
    const draw = (mesh, M) => {
      gl.uniformMatrix4fv(u.uBones, false, mesh.boneData || (mesh.boneData = flatBones(mesh.bones)));
      gl.bindVertexArray(mesh.vao);
      if (!mesh.chunks) { gl.drawArraysInstanced(gl.TRIANGLE_STRIP, 0, 4, mesh.n); drawn += mesh.n; return; }
      // só os blocos dentro do volume de visão (da câmera ou da luz)
      gl.bindBuffer(gl.ARRAY_BUFFER, mesh.buf);
      for (const c of mesh.chunks) {
        if (!boxVisible(M, c.box, 0.6)) continue;
        const o = c.start * 60;
        gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 60, o); gl.vertexAttribPointer(2, 3, gl.FLOAT, false, 60, o + 12);
        gl.vertexAttribPointer(3, 3, gl.FLOAT, false, 60, o + 24); gl.vertexAttribPointer(4, 4, gl.FLOAT, false, 60, o + 36);
        gl.vertexAttribPointer(5, 2, gl.FLOAT, false, 60, o + 52);
        gl.drawArraysInstanced(gl.TRIANGLE_STRIP, 0, 4, c.count);
        drawn += c.count;
      }
    };
    // 1) sombra do luar
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.shadowFB);
    gl.viewport(0, 0, this.shadowSize, this.shadowSize);
    gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LESS); gl.depthMask(true); gl.colorMask(false, false, false, false);
    gl.clear(gl.DEPTH_BUFFER_BIT);
    gl.disable(gl.BLEND);
    gl.uniform1i(u.uPass, 2);
    if (f.shadows) for (const m of this.meshes) if (m.visible && m.castShadow) draw(m, f.lightVP);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, this.W, this.H);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, this.shadowTex);
    // 2) oclusão invisível
    gl.clearColor(f.clear[0], f.clear[1], f.clear[2], 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.uniform1i(u.uPass, 1);
    for (const m of this.meshes) if (m.visible && m.occlude) draw(m, f.vp);
    // 3) caracteres
    gl.colorMask(true, true, true, true);
    gl.depthMask(false); gl.depthFunc(gl.LEQUAL);
    gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    gl.uniform1i(u.uPass, 0);
    gl.uniform1f(u.uBias, f.bias);
    drawn = 0;
    for (const m of this.meshes) if (m.visible) draw(m, f.vp);
    this.stats.glyphs = drawn;
    // 4) partículas
    if (f.particles && f.particles.count) {
      const P = this.pprog;
      gl.useProgram(P.p);
      this._common(P.u, f);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.tex); gl.uniform1i(P.u.uAtlas, 0);
      gl.bindVertexArray(this.pvao);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.pbuf);
      const ps = f.particles;
      gl.uniform4fv(P.u.uLightPos, lp); gl.uniform4fv(P.u.uLightCol, lc);
      gl.uniform1i(P.u.uNumLights, Math.min(MAX_LIGHTS, f.lights.length));
      gl.uniform3f(P.u.uAmbP, 0.55, 0.58, 0.72);
      gl.uniform1i(P.u.uLit, 1);
      // névoa/cinzas: alfa normal; fogo/brasas: aditivo
      gl.bufferSubData(gl.ARRAY_BUFFER, 0, ps.data, 0, ps.count * 10);
      gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
      gl.drawArraysInstanced(gl.TRIANGLE_STRIP, 0, 4, ps.normalCount);
      if (ps.count > ps.normalCount) {
        gl.uniform1i(P.u.uLit, 0);
        gl.blendFunc(gl.ONE, gl.ONE);
        gl.vertexAttribPointer(1, 4, gl.FLOAT, false, 40, ps.normalCount * 40);
        gl.vertexAttribPointer(2, 4, gl.FLOAT, false, 40, ps.normalCount * 40 + 16);
        gl.vertexAttribPointer(3, 2, gl.FLOAT, false, 40, ps.normalCount * 40 + 32);
        gl.drawArraysInstanced(gl.TRIANGLE_STRIP, 0, 4, ps.count - ps.normalCount);
        gl.vertexAttribPointer(1, 4, gl.FLOAT, false, 40, 0);
        gl.vertexAttribPointer(2, 4, gl.FLOAT, false, 40, 16);
        gl.vertexAttribPointer(3, 2, gl.FLOAT, false, 40, 32);
      }
      this.stats.particles = ps.count;
    }
    gl.depthMask(true);
    gl.bindVertexArray(null);
  }
}

/** Caixa (min/max no mundo) toca o volume de visão da matriz M? */
function boxVisible(M, b, pad) {
  let l = 0, r = 0, d = 0, t = 0, nn = 0, ff = 0;
  for (let i = 0; i < 8; i++) {
    const x = (i & 1 ? b[3] + pad : b[0] - pad), y = (i & 2 ? b[4] + pad : b[1] - pad), z = (i & 4 ? b[5] + pad : b[2] - pad);
    const cx = M[0] * x + M[4] * y + M[8] * z + M[12], cy = M[1] * x + M[5] * y + M[9] * z + M[13];
    const cz = M[2] * x + M[6] * y + M[10] * z + M[14], cw = M[3] * x + M[7] * y + M[11] * z + M[15];
    if (cx < -cw) l++; if (cx > cw) r++; if (cy < -cw) d++; if (cy > cw) t++; if (cz < -cw) nn++; if (cz > cw) ff++;
  }
  return !(l === 8 || r === 8 || d === 8 || t === 8 || nn === 8 || ff === 8);
}

export function flatBones(bones) {
  const d = new Float32Array(MAX_BONES * 16);
  for (let i = 0; i < MAX_BONES; i++) d.set(bones[i] || bones[0], i * 16);
  return d;
}
export { MAX_BONES };
