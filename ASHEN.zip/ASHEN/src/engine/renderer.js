// ASHEN — Renderizador
// Canvas principal, densidade de pixels, escala interna, conversão mundo→dispositivo,
// lista de desenho ordenada por profundidade e culling.

import { CONFIG } from '../config.js';

export class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    this.renderScale = 1;
    this.cssW = 1; this.cssH = 1; this.dpr = 1;
    this.W = 1; this.H = 1;   // pixels do dispositivo (backing store)
    this.S = 1;               // pixels do dispositivo por unidade de mundo
    this.version = 0;         // muda quando S muda → caches são refeitos
    this.ox = 0; this.oy = 0; // deslocamento da câmera (pixels inteiros)
    this.view = { x0: 0, y0: 0, x1: 1, y1: 1 }; // retângulo visível em unidades projetadas
    this.items = [];
    this.stats = { drawn: 0, culled: 0, items: 0 };
    this.tilt = CONFIG.TILT;
  }

  /** Recalcula tamanhos. Retorna true se a escala mudou. */
  resize(renderScale = this.renderScale) {
    this.renderScale = renderScale;
    const cssW = Math.max(1, Math.round(window.innerWidth));
    const cssH = Math.max(1, Math.round(window.innerHeight));
    const dpr = Math.min(window.devicePixelRatio || 1, 3);
    const P = dpr * renderScale;
    const W = Math.round(cssW * P), H = Math.round(cssH * P);
    if (this.canvas.width !== W || this.canvas.height !== H) {
      this.canvas.width = W; this.canvas.height = H;
    }
    this.canvas.style.width = cssW + 'px';
    this.canvas.style.height = cssH + 'px';
    // Em retrato usamos a largura como referência para não encolher demais o mundo.
    const ref = cssH <= cssW ? cssH : Math.min(cssH, cssW * 1.15);
    const Z = ref / (CONFIG.VIEW_ROWS * CONFIG.CELL_H);
    // Quantiza para evitar refazer caches por variações de 1px (barra do navegador).
    const S = Math.max(0.25, Math.round(Z * P * 40) / 40);
    const changed = Math.abs(S - this.S) > 1e-6;
    Object.assign(this, { cssW, cssH, dpr, W, H, S, P });
    if (changed) this.version++;
    this.ctx.imageSmoothingEnabled = true;
    return changed;
  }

  /** Configura a câmera para o quadro. cam.x, cam.y em mundo. */
  begin(cam) {
    this.ox = Math.round(this.W / 2 - cam.x * this.S);
    this.oy = Math.round(this.H / 2 - cam.y * this.tilt * this.S + cam.lift * this.S);
    const S = this.S;
    this.view.x0 = -this.ox / S; this.view.x1 = (this.W - this.ox) / S;
    this.view.y0 = -this.oy / S; this.view.y1 = (this.H - this.oy) / S;
    this.items.length = 0;
    this.stats.drawn = 0; this.stats.culled = 0;
  }

  // Mundo (x,y no chão, z altura) → pixels do dispositivo.
  dx(x) { return x * this.S + this.ox; }
  dy(y, z = 0) { return (y * this.tilt - z) * this.S + this.oy; }

  /** Pixels CSS da tela → mundo (no plano do chão). */
  screenToWorld(cssX, cssY) {
    const px = cssX * this.P, py = cssY * this.P;
    return { x: (px - this.ox) / this.S, y: (py - this.oy) / this.S / this.tilt };
  }

  /** Teste de visibilidade com retângulo em unidades projetadas (x, y*tilt - z). */
  visible(x0, y0, x1, y1, margin = 40) {
    const v = this.view;
    return x1 >= v.x0 - margin && x0 <= v.x1 + margin && y1 >= v.y0 - margin && y0 <= v.y1 + margin;
  }

  /** Adiciona item à lista ordenada. item: {depth, bounds:[x0,y0,x1,y1], draw(ctx, r)} */
  submit(item) {
    const b = item.bounds;
    if (b && !this.visible(b[0], b[1], b[2], b[3])) { this.stats.culled++; return false; }
    this.items.push(item);
    return true;
  }

  flush() {
    const items = this.items;
    // Ordenação estável por profundidade (y dos pés no mundo).
    items.sort((a, b) => (a.depth - b.depth) || ((a.order || 0) - (b.order || 0)));
    this.stats.items = items.length;
    const ctx = this.ctx;
    for (let i = 0; i < items.length; i++) { items[i].draw(ctx, this); this.stats.drawn++; }
    items.length = 0;
  }

  /** Desenha um sprite em cache com a âncora no ponto do mundo. Pixels inteiros = nitidez. */
  blit(sprite, x, y, z = 0, alpha = 1) {
    const ctx = this.ctx;
    const px = Math.round(this.dx(x) - sprite.ax), py = Math.round(this.dy(y, z) - sprite.ay);
    if (alpha < 1) { ctx.globalAlpha = alpha; ctx.drawImage(sprite.canvas, px, py); ctx.globalAlpha = 1; }
    else ctx.drawImage(sprite.canvas, px, py);
  }

  /** Retângulo em pixels do dispositivo ocupado por um sprite. */
  spriteRect(sprite, x, y, z = 0) {
    const px = this.dx(x) - sprite.ax, py = this.dy(y, z) - sprite.ay;
    return [px, py, px + sprite.w, py + sprite.h];
  }
}
