// ASHEN 3D — O Palácio da Vigília: intacto e vazio, preso fora do tempo.
// Quatro cômodos: Grande Salão (entrada), Capela da Rainha (oeste), Sala do Tesouro (leste)
// e Sala do Trono (norte). Fica longe de tudo no espaço do mundo (x ≈ 320).

import * as S from './sdf.js';
import { MAT } from './glyphs.js';
import { noise3, rng } from './math3d.js';

export const PO = { x: 320, z: 0 };
const X = x => PO.x + x;
export const ROOMS = {
  hall: { x0: -5, z0: -6, x1: 5, z1: 8 },
  chapel: { x0: -14, z0: -4, x1: -5, z1: 4 },
  treasure: { x0: 5, z0: -4, x1: 14, z1: 4 },
  throne: { x0: -6, z0: -20, x1: 6, z1: -6 },
};
export const THRONE = { x: X(0), z: -17.4, seat: 0.62, dais: 0.42 };
export const PALACE_ENTRY = { x: X(0), z: 5.6 };
export const PALACE_BOUNDS = { x0: X(-13.6), z0: -19.6, x1: X(13.6), z1: 7.6 };
export function roomAt(x, z) { const lx = x - PO.x; for (const [k, r] of Object.entries(ROOMS)) if (lx > r.x0 && lx < r.x1 && z > r.z0 && z < r.z1) return k; return null; }

// paredes: [x0, z0, x1, z1, altura] (locais); as portas são vãos entre segmentos
const T = 0.3;
const WALLS = [
  // salão: sul (baixa, com o portal fechado), leste/oeste internas com vão, norte interna com vão
  [-5, 8, 5, 8, 1.0],
  [-5, -6, -5, -0.9, 2.6], [-5, 0.9, -5, 8, 3.6],
  [5, -6, 5, -0.9, 2.6], [5, 0.9, 5, 8, 3.6],
  [-5, -6, -1.2, -6, 2.6], [1.2, -6, 5, -6, 2.6],
  // capela
  [-14, -4, -14, 4, 3.6], [-14, -4, -5, -4, 3.6], [-14, 4, -5, 4, 1.0],
  // tesouro
  [14, -4, 14, 4, 3.6], [5, -4, 14, -4, 3.6], [5, 4, 14, 4, 1.0],
  // trono
  [-6, -20, 6, -20, 4.2], [-6, -20, -6, -6, 4.2], [6, -20, 6, -6, 4.2], [-6, -6, -5, -6, 2.6], [5, -6, 6, -6, 2.6],
];
const HALL_PILLARS = [-4, -1, 2, 5].flatMap(z => [[-3.2, z], [3.2, z]]);
const THRONE_PILLARS = [-9, -12.5, -16].flatMap(z => [[-4.3, z], [4.3, z]]);
const PILES = [[7.5, -2.5, 0.7], [10.5, -2.8, 0.9], [12.6, -1, 0.6], [12.5, 2.4, 0.75], [8.3, 2.6, 0.55]];
const PEWS = [-1.8, 0, 1.8].flatMap(z => [[-10.5, z], [-8.3, z]]);

const boxW = ([x0, z0, x1, z1, h]) => (x, y, z) => {
  const cx = X((x0 + x1) / 2), cz = (z0 + z1) / 2, hx = Math.abs(x1 - x0) / 2 + T / 2, hz = Math.abs(z1 - z0) / 2 + T / 2;
  return Math.max(Math.abs(x - cx) - hx, Math.abs(z - cz) - hz, Math.abs(y - h / 2) - h / 2);
};
export const PALACE_COLLIDERS = [
  ...WALLS.map(([x0, z0, x1, z1]) => ({ type: 'box', x0: X(Math.min(x0, x1)) - T / 2 - 0.02, z0: Math.min(z0, z1) - T / 2 - 0.02, x1: X(Math.max(x0, x1)) + T / 2 + 0.02, z1: Math.max(z0, z1) + T / 2 + 0.02 })),
  ...[...HALL_PILLARS, ...THRONE_PILLARS].map(([x, z]) => ({ type: 'circle', x: X(x), z, r: 0.42 })),
  { type: 'box', x0: X(-1.7), z0: -19.6, x1: X(1.7), z1: -16.35 },                       // estrado e trono
  { type: 'box', x0: X(-13.8), z0: -1.3, x1: X(-12.4), z1: 1.3 },                          // altar
  ...PEWS.map(([x, z]) => ({ type: 'box', x0: X(x - 0.9), z0: z - 0.25, x1: X(x + 0.9), z1: z + 0.25 })),
  ...PILES.map(([x, z, r]) => ({ type: 'circle', x: X(x), z, r: r * 0.9 })),
];

export function palaceParts() {
  const P = [], add = o => P.push(o);
  const R = rng(321);
  // piso de mármore xadrez, tapetes vermelhos
  const inRoom = (x, z) => { const lx = x - PO.x; return Object.values(ROOMS).some(r => lx > r.x0 - 0.2 && lx < r.x1 + 0.2 && z > r.z0 - 0.2 && z < r.z1 + 0.2); };
  add({ name: 'piso', f: (x, y, z) => (inRoom(x, z) ? Math.max(y, -0.06 - y) : 1), min: [X(-14.3), -0.08, -20.3], max: [X(14.3), 0.02, 8.3], mat: MAT.MARBLE, spacing: 0.075, flow: [1, 0, 0],
    keep: (p, n) => n[1] > 0.5,
    detail: (p) => {
      const lx = p[0] - PO.x;
      if ((Math.abs(lx) < 1.0 && p[2] > -16 && p[2] < 8) || (p[2] > -0.9 && p[2] < 0.9 && Math.abs(lx) > 5 && Math.abs(lx) < 12.5)) return Math.abs(Math.abs(lx) - 0.92) < 0.06 || Math.abs(Math.abs(p[2]) - 0.82) < 0.06 && Math.abs(lx) > 5 ? { mat: MAT.GOLD } : { mat: MAT.CLOTH };
      const ck = (Math.floor(lx / 0.8) + Math.floor(p[2] / 0.8)) & 1;
      if (((lx / 0.8) % 1 + 1) % 1 < 0.06 || ((p[2] / 0.8) % 1 + 1) % 1 < 0.06) return { mat: MAT.GOLD, glyph: '·', size: 0.7 };
      return ck ? { mat: MAT.STONE } : (noise3(p[0] * 3, 1, p[2] * 3) > 0.7 ? { mat: MAT.BONE } : null);
    } });
  // paredes: mármore embaixo, faixa dourada, painéis
  add({ name: 'paredes', f: S.union(...WALLS.map(boxW)), min: [X(-14.4), -0.02, -20.4], max: [X(14.4), 4.3, 8.4], mat: MAT.MARBLE, spacing: 0.06, flow: [0, 1, 0],
    detail: (p, n) => {
      if (Math.abs(p[1] - 2.3) < 0.07 || Math.abs(p[1] - 0.15) < 0.12) return { mat: MAT.GOLD };
      const u = Math.abs(n[0]) > 0.5 ? p[2] : p[0];
      if (p[1] > 0.4 && p[1] < 2.15 && Math.abs(((u / 1.6) % 1 + 1) % 1 - 0.5) > 0.44) return { mat: MAT.GOLD, glyph: '│', size: 0.8 };
      if (p[1] > 2.4) return { mat: MAT.ROYAL };
      return null;
    } });
  // colunas com base e capitel dourado
  for (const [px, pz] of [...HALL_PILLARS, ...THRONE_PILLARS]) {
    const cx = X(px), h = pz < -6 ? 4.2 : 3.6;
    const col = (x, y, z) => { const a = Math.atan2(z - pz, x - cx); return Math.max(Math.hypot(x - cx, z - pz) - 0.3 - 0.015 * Math.cos(a * 16), -y, y - h); };
    const base = S.xf(S.box(0.42, 0.12, 0.42, 0.02), [cx, 0.12, pz]), cap = S.xf(S.box(0.42, 0.14, 0.42, 0.02), [cx, h - 0.14, pz]);
    add({ name: 'coluna', f: S.union(col, base, cap), min: [cx - 0.5, -0.02, pz - 0.5], max: [cx + 0.5, h + 0.02, pz + 0.5], mat: MAT.MARBLE, spacing: 0.04, flow: [0, 1, 0],
      detail: (p) => (p[1] < 0.26 || p[1] > h - 0.3 ? { mat: MAT.GOLD } : null) });
  }
  // lustres do salão (velas acesas que nunca derretem)
  for (const lz of [-1, 4]) {
    const ring = S.xf(S.torus(0.75, 0.04), [X(0), 3.1, lz]), chain = S.capsule([X(0), 3.1, lz], [X(0), 3.8, lz], 0.025);
    add({ name: 'lustre', f: S.union(ring, chain), min: [X(-0.9), 3.0, lz - 0.9], max: [X(0.9), 3.85, lz + 0.9], mat: MAT.GOLD, spacing: 0.02, flow: [1, 0, 0],
      decals: [...Array(10)].map((_, i) => { const a = i * 0.628; return { p: [X(Math.cos(a) * 0.75), 3.22, lz + Math.sin(a) * 0.75], n: [0, 1, 0], glyph: '火', mat: MAT.EMBER, size: 0.1, flags: 2 }; }) });
  }
  // estandartes com 王 nas paredes do salão
  for (const [bx, bz, nx] of [[-4.82, 3.5, 1], [4.82, 3.5, -1], [-4.82, 6.5, 1], [4.82, 6.5, -1]]) {
    add({ name: 'estandarte', f: (x, y, z) => Math.max(Math.abs(x - X(bx)) - 0.02, Math.abs(z - bz) - 0.45, Math.abs(y - 2.2) - 1.0 + Math.max(0, 0.25 - Math.abs(z - bz)) * (y < 1.3 ? 1.5 : 0)), min: [X(bx) - 0.06, 1.0, bz - 0.5], max: [X(bx) + 0.06, 3.25, bz + 0.5], mat: MAT.CLOTH, spacing: 0.03, flow: [0, 1, 0],
      decals: [{ p: [X(bx + nx * 0.03), 2.4, bz], n: [nx, 0, 0], glyph: '王', mat: MAT.GOLD, size: 0.36, clear: 0.24 }] });
  }
  // portal de entrada (fechado) na parede sul baixa
  add({ name: 'portal', f: S.xf(S.box(1.2, 1.6, 0.12), [X(0), 1.6, 8.2]), min: [X(-1.3), 0, 8.0], max: [X(1.3), 3.3, 8.4], mat: MAT.WOOD, spacing: 0.04, flow: [0, 1, 0], detail: (p) => (Math.abs(p[0] - PO.x) < 0.03 || (p[1] % 0.6) < 0.06 ? { mat: MAT.GOLD } : null) });
  // ── Sala do trono: estrado em degraus, trono alto, braseiros ──
  const { x: tx, z: tz } = THRONE;
  add({ name: 'estrado', f: S.union(S.xf(S.box(1.8, 0.21, 1.6, 0.01), [tx, 0.21, tz - 0.4]), S.xf(S.box(2.3, 0.1, 1.9, 0.01), [tx, 0.1, tz - 0.3])), min: [tx - 2.4, -0.02, tz - 2.3], max: [tx + 2.4, 0.45, tz + 1.7], mat: MAT.MARBLE, spacing: 0.04, flow: [1, 0, 0],
    detail: (p) => (Math.abs(p[1] - 0.2) < 0.02 || Math.abs(p[1] - 0.42) < 0.02 ? { mat: MAT.GOLD } : (Math.abs(p[0] - tx) < 0.7 ? { mat: MAT.CLOTH } : null)) });
  const seat = S.xf(S.box(0.48, 0.1, 0.42, 0.02), [tx, 0.58 + 0.0, tz]);
  const back = S.xf(S.box(0.5, 1.15, 0.1, 0.03), [tx, 1.6, tz - 0.42]);
  const crest = (x, y, z) => Math.max(Math.abs(z - (tz - 0.42)) - 0.08, Math.hypot(x - tx, y - 2.8) - 0.55, 2.5 - y);
  const arms = S.union(S.xf(S.box(0.07, 0.2, 0.42, 0.02), [tx - 0.52, 0.85, tz]), S.xf(S.box(0.07, 0.2, 0.42, 0.02), [tx + 0.52, 0.85, tz]));
  const legs = S.union(...[-1, 1].flatMap(sx => [-1, 1].map(sz => S.xf(S.box(0.06, 0.12, 0.06), [tx + sx * 0.42, 0.54, tz + sz * 0.36]))));
  add({ name: 'trono', f: S.union(seat, back, crest, arms, legs), min: [tx - 0.7, 0.4, tz - 0.6], max: [tx + 0.7, 3.4, tz + 0.5], mat: MAT.GOLD, spacing: 0.025, flow: [0, 1, 0],
    detail: (p, n) => (p[1] > 0.66 && p[1] < 2.5 && Math.abs(p[0] - tx) < 0.4 && n[2] > 0.5 ? { mat: MAT.ROYAL } : (p[1] > 0.6 && p[1] < 0.7 && n[1] > 0.5 ? { mat: MAT.ROYAL } : null)),
    decals: [{ p: [tx, 2.85, tz - 0.32], n: [0, 0, 1], glyph: '王', mat: MAT.EMBER, size: 0.4, flags: 2, clear: 0.26 }, { p: [tx, 1.9, tz - 0.31], n: [0, 0, 1], glyph: '誓', mat: MAT.GOLD, size: 0.28, clear: 0.2 }] });
  for (const s of [-1, 1]) {
    const bx = tx + s * 2.6, bz = tz + 1.9;
    add({ name: 'braseiro', f: S.union(S.intersect(S.shell(S.xf(S.sphere(0.35), [bx, 1.15, bz]), 0.03), S.below(1.12)), S.capsule([bx, 0, bz], [bx, 0.85, bz], 0.06)), min: [bx - 0.4, -0.02, bz - 0.4], max: [bx + 0.4, 1.2, bz + 0.4], mat: MAT.GOLD, spacing: 0.025, flow: [0, 1, 0] });
  }
  // ── Capela: altar com coroa de flores de ferro, bancos, vitrais acesos ──
  add({ name: 'altar', f: S.xf(S.box(0.6, 0.5, 1.2, 0.02), [X(-13.1), 0.5, 0]), min: [X(-13.8), -0.02, -1.3], max: [X(-12.4), 1.05, 1.3], mat: MAT.MARBLE, spacing: 0.035, flow: [0, 1, 0],
    detail: (p) => (p[1] > 0.95 ? { mat: MAT.LINEN } : null), decals: [{ p: [X(-12.48), 0.55, 0], n: [1, 0, 0], glyph: '✠', mat: MAT.GOLD, size: 0.42, clear: 0.3 }] });
  add({ name: 'coroa de ferro', f: S.xf(S.torus(0.2, 0.04), [X(-13.1), 1.08, 0]), min: [X(-13.4), 1.0, -0.3], max: [X(-12.8), 1.16, 0.3], mat: MAT.IRON, spacing: 0.012, flow: [1, 0, 0], detail: () => (R() < 0.4 ? { mat: MAT.FLOWER_R } : null) });
  for (const [px, pz] of PEWS) add({ name: 'banco', f: S.union(S.xf(S.box(0.85, 0.03, 0.2), [X(px), 0.44, pz]), S.xf(S.box(0.85, 0.22, 0.03), [X(px), 0.68, pz + 0.19]), S.xf(S.box(0.03, 0.22, 0.2), [X(px - 0.8), 0.22, pz]), S.xf(S.box(0.03, 0.22, 0.2), [X(px + 0.8), 0.22, pz])), min: [X(px - 0.9), -0.02, pz - 0.25], max: [X(px + 0.9), 0.92, pz + 0.25], mat: MAT.WOOD, spacing: 0.03, flow: [1, 0, 0] });
  add({ name: 'vitrais', f: (x, y, z) => Math.max(Math.abs(z + 3.85) - 0.03, Math.abs(((x - PO.x + 40) % 2.2) - 1.1) - 0.35, Math.abs(y - 2.2) - 0.9), min: [X(-13.6), 1.2, -3.95], max: [X(-5.4), 3.2, -3.75], mat: MAT.SPIRIT, spacing: 0.06, flow: [0, 1, 0],
    detail: (p) => ({ mat: [MAT.SPIRIT, MAT.FLOWER_B, MAT.EMBER, MAT.FLOWER_R][(Math.abs(Math.floor(p[1] * 3) + Math.floor(p[0] * 2)) | 0) % 4], flags: 2 }) });
  // ── Tesouro: montes de ouro, baús abertos, cálices, coroas ──
  PILES.forEach(([px, pz, r], i) => {
    add({ name: 'ouro', f: (x, y, z) => Math.hypot((x - X(px)) / r, y / (r * 0.6), (z - pz) / r) - 1 + 0.08 * noise3(x * 9, y * 9, z * 9 + i), min: [X(px) - r - 0.1, -0.02, pz - r - 0.1], max: [X(px) + r + 0.1, r * 0.7, pz + r + 0.1], mat: MAT.GOLD, spacing: 0.03, flow: [1, 0, 0],
      detail: () => (R() < 0.12 ? { mat: MAT.GOLD, glyph: ['✦', '*', '◆'][(R() * 3) | 0] } : R() < 0.04 ? { mat: MAT.FLOWER_R, glyph: '◆' } : null) });
  });
  for (const [cx, cz, rot] of [[7.2, 3.1, 0.3], [13.2, -3.1, -0.5]]) {
    add({ name: 'baú do tesouro', f: S.xf(S.subtract(S.box(0.45, 0.25, 0.3, 0.02), S.xf(S.box(0.4, 0.25, 0.25), [0, 0.15, 0])), [X(cx), 0.25, cz], [0, rot, 0]), min: [X(cx) - 0.6, -0.02, cz - 0.6], max: [X(cx) + 0.6, 0.55, cz + 0.6], mat: MAT.WOOD, spacing: 0.025, flow: [1, 0, 0], detail: (p) => (Math.abs(p[1] - 0.45) < 0.04 ? { mat: MAT.GOLD } : null) });
    add({ name: 'moedas', f: S.xf(S.ellipsoid(0.4, 0.08, 0.26), [X(cx), 0.42, cz]), min: [X(cx) - 0.5, 0.3, cz - 0.4], max: [X(cx) + 0.5, 0.55, cz + 0.4], mat: MAT.GOLD, spacing: 0.025, flow: [1, 0, 0] });
  }
  for (const [gx, gz] of [[9.2, 0.8], [11.6, 0.4], [6.4, -0.6]]) add({ name: 'cálice', f: S.union(S.intersect(S.shell(S.xf(S.sphere(0.12), [X(gx), 0.55, gz]), 0.012), S.below(0.55)), S.capsule([X(gx), 0, gz], [X(gx), 0.44, gz], 0.025), S.xf(S.cylinder(0.08, 0.01), [X(gx), 0.01, gz])), min: [X(gx) - 0.15, -0.02, gz - 0.15], max: [X(gx) + 0.15, 0.58, gz + 0.15], mat: MAT.GOLD, spacing: 0.012, flow: [0, 1, 0] });
  return P;
}

export const PALACE_LIGHTS = [
  { name: 'lustre 1', pos: [X(0), 3.0, -1], col: [1.0, 0.72, 0.42], radius: 9, base: 1.5, flicker: 0.08, area: 'palace' },
  { name: 'lustre 2', pos: [X(0), 3.0, 4], col: [1.0, 0.72, 0.42], radius: 9, base: 1.5, flicker: 0.08, area: 'palace' },
  { name: 'vitrais', pos: [X(-9.5), 2.4, -2.5], col: [0.6, 0.5, 1.0], radius: 8, base: 1.1, flicker: 0.05, area: 'palace' },
  { name: 'ouro', pos: [X(9.8), 1.5, 0], col: [1.0, 0.82, 0.4], radius: 7, base: 1.2, flicker: 0.1, area: 'palace' },
  { name: 'braseiro 1', pos: [X(-2.6), 1.6, THRONE.z + 1.9], col: [1.0, 0.55, 0.25], radius: 7.5, base: 1.6, flicker: 0.3, area: 'palace' },
  { name: 'braseiro 2', pos: [X(2.6), 1.6, THRONE.z + 1.9], col: [1.0, 0.55, 0.25], radius: 7.5, base: 1.6, flicker: 0.3, area: 'palace' },
];
export const BRAZIERS3 = [[X(-2.6), 1.17, THRONE.z + 1.9], [X(2.6), 1.17, THRONE.z + 1.9]];
