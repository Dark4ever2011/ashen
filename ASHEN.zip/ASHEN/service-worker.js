// ASHEN — Service Worker: funciona offline depois do primeiro carregamento.
// Ao publicar uma versão nova, aumente CACHE (ex.: ashen-v0.1.1) para os jogadores receberem a atualização.
const CACHE = 'ashen-v0.1.1';
const CORE = [
  './', './index.html', './manifest.json', './styles/main.css',
  './assets/fonts/DejaVuSansMono.ttf', './assets/icons/icon-192.png', './assets/icons/icon-512.png', './assets/icons/maskable-512.png',
  './src/main.js', './src/config.js',
  './src/engine/typography.js', './src/engine/canvas.js', './src/engine/palette.js', './src/engine/sprite.js', './src/engine/renderer.js',
  './src/engine/camera.js', './src/engine/physics.js', './src/engine/input.js', './src/engine/animation.js', './src/engine/lighting.js',
  './src/engine/particles.js', './src/engine/atmosphere.js', './src/engine/perf.js',
  './src/art/knight.js', './src/art/cape.js', './src/art/props.js', './src/art/architecture.js',
  './src/entities/knight-rig.js', './src/entities/player.js',
  './src/world/terrain.js', './src/world/objects.js', './src/world/maps.js', './src/world/world.js',
  './src/ui/hud.js', './src/ui/menus.js', './src/ui/controls.js', './src/ui/settings.js', './src/ui/logo.js',
  './src/systems/save.js',
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

// Rede primeiro: sempre pega a versão publicada mais recente; sem internet, usa a cópia guardada.
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  e.respondWith(fetch(req, { cache: 'no-cache' }).then(res => {
    if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); }
    return res;
  }).catch(() => caches.match(req, { ignoreSearch: true }).then(hit => hit || caches.match('./index.html'))));
});
