# Gera os ícones PWA (opcional — os PNGs já vêm prontos em assets/icons).
from PIL import Image, ImageDraw, ImageFont
import sys
CJK = '/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc'
MONO = 'assets/fonts/DejaVuSansMono.ttf'
def icon(size, maskable=False):
    im = Image.new('RGB', (size, size), (11, 10, 13))
    d = ImageDraw.Draw(im)
    # brilho de brasa
    for r in range(size // 2, 0, -2):
        a = int(46 * (1 - r / (size / 2)) ** 2)
        d.ellipse([size/2 - r, size*0.56 - r, size/2 + r, size*0.56 + r], fill=(11 + a, 10 + a // 3, 13))
    pad = size * (0.16 if maskable else 0.06)
    # moldura tipográfica
    f = ImageFont.truetype(MONO, int(size * 0.045))
    n = int((size - 2 * pad) / (size * 0.045 * 0.6))
    top = '╔' + '═' * (n - 2) + '╗'; bot = '╚' + '═' * (n - 2) + '╝'
    d.text((pad, pad), top, font=f, fill=(150, 112, 48))
    d.text((pad, size - pad - size * 0.055), bot, font=f, fill=(150, 112, 48))
    for y in range(int(pad + size * 0.05), int(size - pad - size * 0.05), int(size * 0.05)):
        d.text((pad, y), '║', font=f, fill=(150, 112, 48)); d.text((size - pad - size * 0.03, y), '║', font=f, fill=(150, 112, 48))
    k = ImageFont.truetype(CJK, int(size * (0.44 if maskable else 0.52)))
    d.text((size / 2, size * 0.47), '誓', font=k, fill=(214, 166, 82), anchor='mm')
    t = ImageFont.truetype(MONO, int(size * 0.085))
    d.text((size / 2, size * (0.79 if maskable else 0.83)), 'ASHEN', font=t, fill=(212, 203, 185), anchor='mm')
    return im
for s in (192, 512):
    icon(s).save(f'assets/icons/icon-{s}.png')
icon(512, True).save('assets/icons/maskable-512.png')
print('ok')
