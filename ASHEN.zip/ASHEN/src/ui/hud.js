// ASHEN — HUD: título da região, aviso de interação, mensagens (máquina de escrever),
// avisos rápidos e painel de desempenho.

const $ = id => document.getElementById(id);

export class Hud {
  constructor() {
    this.el = { region: $('region'), kicker: $('region-kicker'), title: $('region-title'), sub: $('region-sub'),
      prompt: $('prompt'), promptKey: $('prompt-key'), promptText: $('prompt-text'),
      msg: $('message'), msgTitle: $('message-title'), msgText: $('message-text'), msgOk: $('message-ok'),
      toast: $('toast'), perf: $('perf') };
    this.msgOpen = false;
    this.full = ''; this.shown = 0; this.msgAt = null;
    this.toastT = 0;
    this.el.msgOk.addEventListener('click', e => { e.stopPropagation(); this.advance(); });
    this.el.msg.addEventListener('pointerdown', e => e.stopPropagation());
  }

  showRegion(map) {
    const e = this.el;
    e.kicker.textContent = map.region.toUpperCase();
    e.title.textContent = map.title;
    e.sub.textContent = map.subtitle || '';
    e.region.classList.remove('hidden');
    e.region.style.animation = 'none'; void e.region.offsetWidth; e.region.style.animation = '';
    clearTimeout(this._rt);
    this._rt = setTimeout(() => e.region.classList.add('hidden'), 5600);
  }

  setPrompt(text, key, touch) {
    const e = this.el;
    if (!text || this.msgOpen) { e.prompt.classList.add('hidden'); return; }
    e.prompt.classList.remove('hidden');
    e.prompt.classList.toggle('touch', !!touch);
    if (e.promptText.textContent !== text) e.promptText.textContent = text;
    e.promptKey.textContent = key;
  }

  message(text, title = '', at = null) {
    const e = this.el;
    this.full = text; this.shown = 0; this.msgOpen = true; this.msgAt = at;
    e.msgTitle.textContent = title;
    e.msgText.textContent = '';
    e.msg.classList.remove('hidden');
    e.prompt.classList.add('hidden');
  }

  /** Completa o texto ou fecha. */
  advance() {
    if (!this.msgOpen) return false;
    if (this.shown < this.full.length) { this.shown = this.full.length; this.el.msgText.textContent = this.full; return true; }
    this.close();
    return true;
  }

  close() { this.msgOpen = false; this.el.msg.classList.add('hidden'); }

  /** Aviso rápido: entra na fila de notificações (empilham, não se sobrepõem). */
  toast(text, ms = 3200) { this.notify({ kind: 'info', text, ms }); }
  /** Fila de avisos no topo: até 3 visíveis, o resto espera; repetidos se juntam (ouro soma). */
  notify(n) {
    if (!this.nq) { this.nq = []; this.nv = []; this.nbox = document.createElement('div'); this.nbox.id = 'notes'; document.body.appendChild(this.nbox); }
    const same = [...this.nv, ...this.nq].find(o => o.kind === n.kind && (n.kind === 'gold' || o.text === n.text) && (!o.el || !o.out));
    if (same) {
      if (n.kind === 'gold') { same.amount += n.amount; same.text = `+${same.amount} ◈ ouro`; } same.ms = Math.max(same.ms, n.ms || 2600);
      if (same.el) { same.el.querySelector('.t').textContent = same.text; same.left = Math.max(same.left, (n.ms || 2600) / 1000); same.el.classList.remove('bump'); void same.el.offsetWidth; same.el.classList.add('bump'); }
      return;
    }
    if (n.kind === 'gold') n.text = `+${n.amount} ◈ ouro`;
    this.nq.push({ ms: 2600, ...n });
    this._pumpNotes();
  }
  _pumpNotes() {
    while (this.nv.length < 3 && this.nq.length) {
      const n = this.nq.shift(), el = document.createElement('div');
      el.className = 'note ' + n.kind;
      el.innerHTML = (n.kanji ? `<span class="k">${n.kanji}</span>` : '') + `<div>${n.title ? `<small>${n.title}</small>` : ''}<span class="t"></span></div>`;
      el.querySelector('.t').textContent = n.text;
      this.nbox.appendChild(el); n.el = el; n.left = n.ms / 1000; this.nv.push(n);
    }
  }
  _tickNotes(dt) {
    if (!this.nv) return;
    for (const n of this.nv) {
      n.left -= dt;
      if (n.left <= 0 && !n.out) { n.out = true; n.el.classList.add('out'); setTimeout(() => { n.el.remove(); this.nv = this.nv.filter(x => x !== n); this._pumpNotes(); }, 200); }
    }
  }
  /** Barras com dano atrasado (estilo Souls): a parte clara segura um instante e depois desce;
   *  golpes seguidos renovam a espera; cura move tudo na hora. */
  bar(id, k) {
    const B = (this.bars || (this.bars = {}))[id] || (this.bars[id] = { k, lag: k, hold: 0, el: document.getElementById(id) });
    k = Math.max(0, Math.min(1, k));
    if (k < B.k - 1e-4) B.hold = 0.55;
    if (k > B.k + 1e-4) { B.lag = Math.max(B.lag, k); if (k - B.k > 0.02 && id === 'hp-bar') { B.el.classList.remove('heal'); void B.el.offsetWidth; B.el.classList.add('heal'); } }
    if (B.lag < k) B.lag = k;
    B.k = k;
  }
  _tickBars(dt) {
    for (const B of Object.values(this.bars || {})) {
      B.hold -= dt;
      if (B.hold <= 0 && B.lag > B.k) B.lag = Math.max(B.k, B.lag - Math.max(0.22, (B.lag - B.k) * 2.5) * dt);
      if (B.ks !== B.k) { B.el.firstElementChild.style.transform = `scaleX(${B.k})`; B.ks = B.k; }
      if (B.ls !== B.lag) { B.el.querySelector('b').style.transform = `scaleX(${B.lag})`; B.ls = B.lag; }
    }
  }
  /** Barra do chefe (qualquer chefe). Ao aparecer de novo, começa cheia sem animação. */
  bossHp(k) { this.bar('boss-bar-fill', k); }

  update(dt, player) {
    this._tickNotes(dt); this._tickBars(dt);
    if (this.msgOpen) {
      if (this.shown < this.full.length) {
        this.shown = Math.min(this.full.length, this.shown + dt * 70);
        this.el.msgText.textContent = this.full.slice(0, Math.floor(this.shown));
      }
      // Fecha sozinho se o cavaleiro se afastar.
      if (this.msgAt && Math.hypot(player.x - this.msgAt.x, player.z - this.msgAt.z) > 2.8) this.close();
    }
  }

  /** Flash de tela curto: 'hurt' (vermelho nas bordas), 'parry' (dourado), 'crit' (branco), 'dodge' (rastro azul + ESQUIVA). */
  flash(kind) {
    let f = this.fl; if (!f) { f = this.fl = document.createElement('div'); f.id = 'screen-flash'; document.body.appendChild(f); }
    f.className = ''; void f.offsetWidth; f.className = 'on ' + kind;
    if (kind === 'parry' || kind === 'dodge') this.pop(kind === 'parry' ? 'APARADO' : 'ESQUIVA', kind);
  }
  /** Palavra rápida no centro (aparar, esquiva). */
  pop(text, kind) {
    let p = this.pp; if (!p) { p = this.pp = document.createElement('div'); p.id = 'pop-word'; document.body.appendChild(p); }
    p.textContent = text; p.className = ''; void p.offsetWidth; p.className = 'on ' + kind;
  }
  /** Contador do sangramento do samurai: ◆◆◇. */
  pips(n, need) {
    let p = this.bp; if (!p) { p = this.bp = document.createElement('div'); p.id = 'bleed-pips'; document.body.appendChild(p); }
    p.textContent = '◆'.repeat(n) + '◇'.repeat(Math.max(0, need - n)); p.className = ''; void p.offsetWidth; p.className = 'on' + (n >= need ? ' full' : '');
  }
  showPerf(on) { this.el.perf.classList.toggle('hidden', !on); }
  perfText(t) { this.el.perf.textContent = t; }
}
