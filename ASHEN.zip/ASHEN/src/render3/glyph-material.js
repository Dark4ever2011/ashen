// ASHEN — Caracteres gravados no material 3D (Fase 2).
//
// Os caracteres não são mais uma grade na tela: cada superfície 3D tem uma grade de caracteres no
// PRÓPRIO espaço do objeto (triplanar nas construções/pedras/árvores; coordenadas de repouso nos corpos,
// então os caracteres andam com a armadura; UV da grade nos tecidos, então seguem as dobras).
// O traço vira relevo (normal perturbada pela derivada do traço) e brilho especular nas bordas:
// quente na chama, frio na lua — a luz é a do Three.js.

import * as THREE from 'three';
import { MATERIALS } from '../game/glyphs.js';
import { charWidth } from '../engine/typography.js';

/** Textura das rampas: linha = material+1, 8 colunas (0 = mais leve … 7 = mais denso). */
export function rampTexture(atlas) {
  const data = new Uint8Array(8 * 256 * 4);
  const put = (y, ramp, emissive) => {
    const r = emissive ? ramp.slice() : ramp.slice().reverse();
    for (let x = 0; x < 8; x++) {
      const ch = r[x], o = (y * 8 + x) * 4;
      if (!ch || ch === ' ') continue;
      const g = atlas.get(ch);
      data[o] = g & 255; data[o + 1] = g >> 8; data[o + 2] = charWidth(ch.codePointAt(0)) === 2 ? 255 : 0; data[o + 3] = 255;
    }
  };
  MATERIALS.forEach((m, i) => put(i + 1, m.ramp, m.emissive));
  const t = new THREE.DataTexture(data, 8, 256, THREE.RGBAFormat, THREE.UnsignedByteType);
  t.minFilter = t.magFilter = THREE.NearestFilter; t.needsUpdate = true;
  return t;
}

export function atlasTexture(atlas) {
  const tex = new THREE.CanvasTexture(atlas.canvas);
  tex.colorSpace = THREE.NoColorSpace; tex.generateMipmaps = true;
  tex.minFilter = THREE.LinearMipmapLinearFilter; tex.magFilter = THREE.LinearFilter;
  tex.anisotropy = 4;
  return tex;
}

/** GLSL: amostra o caractere numa coordenada contínua q (1 unidade = 1 célula; x atravessa, y sobe). */
export const GLYPH_GLSL = `
uniform sampler2D tAtlas, tRamp;
uniform float uAtlasCols, uAtlasRows, uGlyphFade0, uGlyphFade1;
float ashenHash(vec2 c) { return fract(sin(dot(c, vec2(12.9898, 78.233))) * 43758.5453); }
// glyph < 0: escolhe na rampa do material pela célula (variação estável); >= 0: caractere fixo
float ashenGlyph(vec2 q, float code, float glyph) {
  vec2 cell = floor(q), lc = q - cell;
  float g = glyph, wide = 0.0;
  if (g < 0.0) {
    float h = ashenHash(cell + code * 7.13);
    float k = 7.0 - floor(h * h * 5.99);                         // quase sempre os traços mais cheios
    vec4 r = texelFetch(tRamp, ivec2(int(k), int(code)), 0);
    if (r.a < 0.5) return 0.0;
    g = r.r * 255.0 + r.g * 255.0 * 256.0; wide = r.b;
  }
  float sx = wide > 0.5 ? 0.86 : 0.56, sy = 0.86;               // recorte justo: o traço encosta na borda
  vec2 a = vec2(0.5 + (lc.x - 0.5) * sx, 0.5 + (lc.y - 0.5) * sy);
  vec2 cg = vec2(mod(g, uAtlasCols), floor(g / uAtlasCols));
  vec2 auv = vec2((cg.x + a.x) / uAtlasCols, 1.0 - (cg.y + 1.0 - a.y) / uAtlasRows);
  vec2 s = vec2(sx / uAtlasCols, sy / uAtlasRows);
  return textureGrad(tAtlas, auv, dFdx(q) * s, dFdy(q) * s).a;
}
// grade de caracteres projetada pela face dominante (triplanar), célula cs metros
vec2 ashenTriQ(vec3 p, vec3 n, float cs) {
  vec3 a = abs(n); vec2 uv;
  if (a.y > a.x && a.y > a.z) uv = vec2(p.x, -p.z * sign(n.y));
  else if (a.x > a.z) uv = vec2(-p.z * sign(n.x), p.y);
  else uv = vec2(p.x * sign(n.z), p.y);
  return uv / vec2(cs * 0.62, cs);
}
// relevo: normal perturbada pela derivada da altura (mesma ideia do bump do Three)
vec3 ashenBump(vec3 pos, vec3 n, vec2 dH, float fd) {
  vec3 sx = dFdx(pos), sy = dFdy(pos);
  vec3 r1 = cross(sy, n), r2 = cross(n, sx);
  float det = dot(sx, r1) * fd;
  vec3 gr = sign(det) * (dH.x * r1 + dH.y * r2);
  return normalize(abs(det) * n - gr);
}`;

/** Bloco que troca a iluminação Phong para usar brilho por material e por traço. */
export const PHONG_LIGHTS = `
BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = gGloss;
material.specularStrength = specularStrength;`;
