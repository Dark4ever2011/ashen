// ASHEN 3D — Cenas animadas no próprio mundo de caracteres.
// Uma cena = planos de câmera (olho e alvo interpolados), legendas, eventos e escurecimentos.
// Pode ser pulada. Enquanto roda, o jogo não lê os controles.

const sm = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };
const lerp3 = (a, b, k) => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
const $ = id => document.getElementById(id);

export class Cinema {
  constructor() { this.cur = null; $('cine-skip').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); this.skip(); }); }
  get active() { return !!this.cur; }
  play(scene) {
    this.cur = { ...scene, t: 0, fired: new Set() };
    $('cine').classList.remove('hidden'); document.body.classList.add('cine');
    $('cine-title').textContent = ''; $('cine-text').textContent = '';
  }
  skip() { if (!this.cur) return; const c = this.cur; for (const e of c.events || []) if (!c.fired.has(e)) { c.fired.add(e); e.fn(true); } this.end(); }
  end() { const c = this.cur; this.cur = null; $('cine').classList.add('hidden'); document.body.classList.remove('cine'); $('cine-black').style.opacity = 0; c && c.onEnd && c.onEnd(); }
  /** Avança e devolve { eye, target, shake } (ou null se acabou). */
  update(dt) {
    const c = this.cur;
    if (!c) return null;
    c.t += dt;
    for (const e of c.events || []) if (!c.fired.has(e) && c.t >= e.t) { c.fired.add(e); e.fn(false); }
    if (c.t >= c.dur) { this.end(); return null; }
    let shot = c.shots[0];
    for (const s of c.shots) if (c.t >= s.t0) shot = s;
    const k = sm((c.t - shot.t0) / (shot.t1 - shot.t0));
    const cap = (c.captions || []).find(q => c.t >= q.t0 && c.t < q.t1);
    const text = cap ? cap.text : '';
    const el = $('cine-text');
    if (el.dataset.full !== text) { el.dataset.full = text; el.textContent = ''; el.dataset.shown = 0; }
    if (text) { const n = Math.min(text.length, (+el.dataset.shown || 0) + dt * 38); el.dataset.shown = n; el.textContent = text.slice(0, Math.floor(n)); }
    el.style.opacity = cap ? Math.min(1, (c.t - cap.t0) * 2, (cap.t1 - c.t) * 2) : 0;
    const title = (c.titles || []).find(q => c.t >= q.t0 && c.t < q.t1);
    $('cine-title').textContent = title ? title.text : '';
    $('cine-title').style.opacity = title ? Math.min(1, (c.t - title.t0) * 1.5, (title.t1 - c.t) * 1.5) : 0;
    let black = 0;
    for (const b of c.black || []) if (c.t >= b.t0 && c.t < b.t1) black = Math.max(black, b.a(c.t));
    $('cine-black').style.opacity = black;
    const shake = (c.shakes || []).reduce((a, s) => (c.t >= s.t0 && c.t < s.t1 ? Math.max(a, s.amp * (1 - (c.t - s.t0) / (s.t1 - s.t0))) : a), 0);
    return { eye: lerp3(shot.eye0, shot.eye1, k), target: lerp3(shot.tgt0, shot.tgt1, k), shake };
  }
}

/** Abertura: a queda do reino e o despertar do cavaleiro junto ao braseiro. */
export function openingScene(S, W, hooks) {
  const L = S.opening, bz = W.BRAZIER, fz = W.FALLEN, tomb = W.ROYAL_TOMB;
  const kn = [bz.x + 0.9, 0, bz.z + 1.1];
  return {
    dur: 42,
    shots: [
      { t0: 0, t1: 7, eye0: [9, 12, 7], eye1: [6, 11.5, 4.5], tgt0: [1.4, 8.5, -9.6], tgt1: [1.8, 9.5, -9.6] },          // fortaleza
      { t0: 7, t1: 14, eye0: [-7, 5, 4], eye1: [6, 4.5, 3.5], tgt0: [-3, 3, -4.4], tgt1: [2, 3.2, -4.4] },          // muralhas e portão
      { t0: 14, t1: 21, eye0: [tomb.x + 3, 2.2, tomb.z + 4], eye1: [tomb.x + 1.5, 1.4, tomb.z + 2.6], tgt0: [tomb.x, 0.4, tomb.z], tgt1: [tomb.x, 0.3, tomb.z + 0.6] },   // túmulo vazio
      { t0: 21, t1: 28, eye0: [fz.x - 1.5, 1.6, fz.z + 3.2], eye1: [fz.x - 0.6, 1.2, fz.z + 2.2], tgt0: [fz.x, 0.7, fz.z], tgt1: [fz.x, 0.6, fz.z] },      // cavaleiro caído
      { t0: 28, t1: 42, eye0: [kn[0] + 2.4, 2.6, kn[2] + 3.4], eye1: [kn[0] + 1.2, 1.5, kn[2] + 3.0], tgt0: [kn[0], 0.3, kn[2]], tgt1: [kn[0], 1.0, kn[2]] },  // despertar
    ],
    captions: L.map((text, i) => ({ t0: [1, 8, 15, 22, 29, 34.5][i], t1: [6.5, 13.5, 20.5, 27.5, 34, 39.5][i], text })),
    titles: [{ t0: 39.5, t1: 42, text: 'ASHEN · THE LAST OATH' }],
    black: [{ t0: 0, t1: 2, a: t => 1 - t / 2 }, { t0: 6.2, t1: 7.6, a: t => 1 - Math.abs(t - 6.9) / 0.7 }, { t0: 13.3, t1: 14.6, a: t => 1 - Math.abs(t - 13.95) / 0.65 }, { t0: 20.3, t1: 21.6, a: t => 1 - Math.abs(t - 20.95) / 0.65 }, { t0: 27.3, t1: 28.6, a: t => 1 - Math.abs(t - 27.95) / 0.65 }],
    events: [{ t: 28, fn: (skip) => hooks.lieDown(skip) }, { t: 34, fn: (skip) => hooks.wake(skip) }],
    onEnd: hooks.done,
  };
}

/** O rei sai do túmulo: tremor, garras na borda, o corpo se ergue, o grito. */
export function bossIntroScene(S, W, hooks) {
  const t = W.ROYAL_TOMB;
  return {
    dur: 10.5,
    shots: [
      { t0: 0, t1: 3.2, eye0: [t.x + 2.6, 1.0, t.z + 3.6], eye1: [t.x + 2.0, 0.8, t.z + 3.0], tgt0: [t.x, 0.2, t.z + 0.8], tgt1: [t.x, 0.3, t.z + 0.9] },
      { t0: 3.2, t1: 7.2, eye0: [t.x + 1.8, 0.7, t.z + 3.4], eye1: [t.x + 2.4, 0.9, t.z + 4.6], tgt0: [t.x, 0.6, t.z + 0.9], tgt1: [t.x, 2.0, t.z + 0.9] },
      { t0: 7.2, t1: 10.5, eye0: [t.x + 1.2, 1.3, t.z + 4.2], eye1: [t.x + 0.8, 1.6, t.z + 4.6], tgt0: [t.x, 2.0, t.z + 0.9], tgt1: [t.x, 2.1, t.z + 0.9] },
    ],
    captions: [{ t0: 0.4, t1: 3.2, text: S.bossIntro[0] }, { t0: 3.6, t1: 6.8, text: S.bossIntro[1] }],
    titles: [{ t0: 7.6, t1: 10.5, text: 'O PRIMEIRO REI, DESENTERRADO' }],
    shakes: [{ t0: 0, t1: 3.2, amp: 0.05 }, { t0: 7.2, t1: 9.2, amp: 0.12 }],
    events: [{ t: 0, fn: (skip) => hooks.quake(skip) }, { t: 3.2, fn: (skip) => hooks.rise(skip) }, { t: 7.2, fn: (skip) => hooks.roar(skip) }],
    onEnd: hooks.done,
  };
}
