// ASHEN — Renderizador Three.js (Fase 2: caracteres no espaço 3D).
//
// Regra do visual: tudo é 3D de verdade e os caracteres são GRAVADOS nos materiais — não existe mais grade
// colada na tela. Construções, pedras e árvores: grade de caracteres triplanar no mundo. Personagens: grade
// nas coordenadas de repouso do corpo (os caracteres andam com a armadura). Tecidos: grade no próprio pano
// (segue as dobras). O traço é relevo (normal perturbada) e pega brilho especular nas bordas com a luz real
// (quente no fogo, frio na lua). Longe e na névoa, os caracteres somem sozinhos (densidade na tela + névoa).
// O CHÃO continua 100% sólido, sem caracteres.
//
// Geometria contínua (sem discos):
//   • malhas sólidas (SolidGeom) e cascas geradas dos pontos (hullFromPoints) para objetos sem corpo sólido;
//   • chão e água: grade contínua montada dos pontos;
//   • tecidos (capa, tabardo, estandartes): malha da própria simulação, com a bainha rasgada recortada;
//   • grama: lâminas 3D;
//   • só sobram quadrinhos para caracteres FIXOS (kanji gravados 誓 王, brasões, brasas, lâmina azul) —
//     desenhados com o caractere recortado, em relevo — e para as partículas (cada uma é um caractere).
//
// Mesma interface do GlyphRenderer antigo: o jogo (combate, saves, mapas) não muda.

import * as THREE from 'three';
import { MATERIALS, MAT } from '../game/glyphs.js';
import { VSTRIDE, hullFromPoints } from '../game/solid.js';
import { GLYPH_GLSL, PHONG_LIGHTS, rampTexture, atlasTexture } from './glyph-material.js';
import { loadTemplate, instantiate, playState, DEFAULT_HEIGHT } from './glb-models.js';
import { AsciiPass } from './ascii-pass.js';

const MAX_BONES = 18, MAX_LIGHTS = 6;
const NMAT = MATERIALS.length;
const IDENT = new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
const GROUND_MATS = new Set([MAT.GROUND, MAT.GRAVEL, MAT.SAND, MAT.SNOW]);
const FLOOR_MATS = new Set([MAT.STONE, MAT.WOOD, MAT.MARBLE, MAT.GRAVEL, MAT.PLASTER]);
const FLOWERS = new Set([MAT.FLOWER, MAT.FLOWER_R, MAT.FLOWER_Y, MAT.FLOWER_W, MAT.FLOWER_B, MAT.PETAL_P]);
const EMISSIVE = new Set(MATERIALS.map((m, i) => (m.emissive ? i : -1)).filter(i => i >= 0));

const SCLASS = new Float32Array(NMAT);
{
  const set = (k, ids) => { for (const i of ids) if (i != null) SCLASS[i] = k; };
  set(1, [MAT.STONE, MAT.MARBLE]); set(2, [MAT.WOOD]); set(3, [MAT.STEEL, MAT.SILVER, MAT.GOLD, MAT.BLADE, MAT.IRON, MAT.MAIL, MAT.BRONZE, MAT.BLUE]);
  set(5, [MAT.CLOTH, MAT.CLOTH_IN, MAT.ROYAL, MAT.LINEN, MAT.WOOL, MAT.LEATHER]); set(7, [MAT.THATCH]); set(9, [MAT.RIVER, MAT.WATER]);
}
const MATCOL = MATERIALS.map(m => new THREE.Vector3(...m.c));
const MATSPEC = new Float32Array(MATERIALS.map(m => m.spec || 0));
const MATGLOSS = new Float32Array(MATERIALS.map(m => m.gloss || 10));

// ───────────────────────── trechos de shader ─────────────────────────
const COMMON_V = `
uniform mat4 uBones[${MAX_BONES}];
uniform float uTime;
uniform vec4 uWind;
uniform vec3 uFocus;
varying vec2 vNDC; varying float vDcam; varying float vActor;
vec3 ashenSway(vec3 wp, float seed) {
  float amt = pow(clamp((wp.y - uFocus.y - 0.8) / 4.5, 0.0, 1.0), 2.0);
  float ph = uTime * 1.25 + wp.x * 0.6 + wp.z * 0.45;
  vec2 sw = uWind.xy * uWind.z * (0.55 + 0.45 * sin(ph)) * 0.22 + vec2(sin(uTime * 3.7 + seed), cos(uTime * 3.1 + seed)) * 0.02;
  return wp + vec3(sw.x, -0.02 * length(sw), sw.y) * amt;
}`;
const COMMON_F = `
varying vec2 vNDC; varying float vDcam; varying float vActor;
uniform vec2 uPlayerNDC; uniform float uPlayerDist, uAspect, uFade, uBump;
uniform vec4 uActors[8];   // pés dos personagens: xz, raio, altura do chão
// sombra de contato (oclusão sob os pés): escurece o chão em volta de cada personagem
float ashenContact(vec3 wp) {
  float ao = 1.0;
  for (int i = 0; i < 8; i++) {
    vec4 a = uActors[i]; if (a.z <= 0.0) continue;
    float d = length(wp.xz - a.xy), hgt = max(0.0, wp.y - a.w);
    ao *= 1.0 - 0.62 * (1.0 - smoothstep(a.z * 0.25, a.z, d)) * (1.0 - smoothstep(0.0, 0.35, hgt));
  }
  return ao;
}
uniform float uMatSpec[${NMAT}];
uniform float uMatGloss[${NMAT}];
float gGloss = 10.0, gSpec = 0.0, gInk = 0.0, gK = 0.0;
uniform vec3 uSkyC, uGroundC, uMoonC, uMoonD;
// luz "pintada": céu/chão + lua, sem sombra nem luzes pontuais (essas entram pela cor na composição)
vec3 ashenLight(vec3 n) { return mix(uGroundC, uSkyC, n.y * 0.5 + 0.5) + uMoonC * max(dot(n, uMoonD), 0.0); }
float ashenBayer(vec2 fc) {
  vec2 p = mod(floor(fc), 4.0); float i = p.x + p.y * 4.0;
  float b = i < 1.0 ? 0.0 : i < 2.0 ? 8.0 : i < 3.0 ? 2.0 : i < 4.0 ? 10.0 : i < 5.0 ? 12.0 : i < 6.0 ? 4.0 : i < 7.0 ? 14.0 : i < 8.0 ? 6.0 :
            i < 9.0 ? 3.0 : i < 10.0 ? 11.0 : i < 11.0 ? 1.0 : i < 12.0 ? 9.0 : i < 13.0 ? 15.0 : i < 14.0 ? 7.0 : i < 15.0 ? 13.0 : 5.0;
  return (b + 0.5) / 16.0;
}
uniform float uNoFade;
void ashenFade(bool solidFloor) {
  if (uNoFade > 0.5) return;
  float bz = ashenBayer(gl_FragCoord.xy);
  if (uFade < 0.999 && bz > uFade) discard;
  if (vActor > 0.5 || solidFloor) return;
  if (vDcam < 2.8 && bz > smoothstep(1.3, 2.8, vDcam)) discard;
  if (vDcam < uPlayerDist - 0.7) {
    float k = smoothstep(0.2, 0.48, length((vNDC - uPlayerNDC) * vec2(uAspect, 1.0)));
    if (bz > max(k, 0.1)) discard;
  }
}
// quanto o caractere aparece: some quando a célula fica menor que ~3 px (longe) e na distância
float ashenVis(vec2 q) {
  float d = max(length(dFdx(q)), length(dFdy(q)));
  return (1.0 - smoothstep(0.22, 0.42, d)) * (1.0 - smoothstep(uGlyphFade0, uGlyphFade1, vDcam));
}`;
const PROJ_TAIL = `#include <project_vertex>
  vNDC = gl_Position.xy / gl_Position.w; vDcam = -mvPosition.z;`;

// ── sólidos (construções, corpos, chão, água, tecidos) ──
const SOLID_V = `
attribute float aMat; attribute vec3 aTint; attribute vec4 aW; attribute vec2 aUV;
uniform float uSinkR;
varying vec3 vWPos; varying vec3 vTint; varying vec4 vW; varying float vMat; varying vec3 vWN; varying vec3 vRest; varying vec3 vRestN; varying vec2 vUV2;
void ashenInst(out vec3 P, out vec3 N) {
  P = position; N = normal; vRest = position; vRestN = normal; vUV2 = aUV;
  if (aMat >= 0.0 && aW.z > 0.5) { mat4 B = uBones[int(aW.y + 0.5)]; P = (B * vec4(P, 1.0)).xyz; N = normalize(mat3(B) * N); }
  if (aMat < -1.5 && aMat > -2.5) { float d = max(abs(P.x - uFocus.x), abs(P.z - uFocus.z)); P.y -= 2.5 * (1.0 - smoothstep(uSinkR * 0.8, uSinkR, d)) + 0.15; }
  if (aMat >= 0.0 && aW.w > 0.5) P = ashenSway(P, 0.0);
  vWPos = P; vWN = N; vTint = aTint; vW = aW; vMat = aMat;
  vActor = (aMat >= 0.0 && aW.z > 0.5) ? 1.0 : 0.0;
}`;
const SOLID_F = `
varying vec3 vWPos; varying vec3 vTint; varying vec4 vW; varying float vMat; varying vec3 vWN; varying vec3 vRest; varying vec3 vRestN; varying vec2 vUV2;
uniform vec3 uMatColor[${NMAT}];
uniform float uSClass[${NMAT}];
uniform vec3 uFocusF;
uniform float uWet, uWL, uCloth, uMatBack, uGlyphCell;
uniform vec2 uClothSize;
uniform sampler2D tClothMask;
float hs(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vn2(vec2 p) { vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hs(i), hs(i + vec2(1, 0)), f.x), mix(hs(i + vec2(0, 1)), hs(i + vec2(1, 1)), f.x), f.y); }
float fbm(vec2 p) { float a = 0.5, s = 0.0; for (int i = 0; i < 3; i++) { s += a * vn2(p); p = p * 2.03 + 7.1; a *= 0.5; } return s; }
vec2 tri(vec3 p, vec3 n) { vec3 a = abs(n); return a.y > a.x && a.y > a.z ? p.xz : (a.x > a.z ? p.zy : p.xy); }
// cor do material + dados do caractere (código, coordenada da grade)
vec3 ashenBase(out float code, out vec2 q, out bool solidFloor) {
  vec3 n = normalize(vWN); vec2 xz = vWPos.xz; vec3 base; solidFloor = false; q = vec2(0.0);
  if (vMat < -2.5) {                                   // chão montado a partir dos pontos (pátios, vale, interiores)
    code = 0.0; solidFloor = true;
    float fine = vn2(xz * 6.0), mid = vn2(xz * 1.3);
    // terra com grão: torrões, pedrinhas e rachaduras finas (vira relevo pelo mesmo bump dos caracteres)
    float grain = vn2(xz * 19.0) * 0.55 + vn2(xz * 47.0) * 0.3 + vn2(xz * 113.0) * 0.15;
    vec2 pc = xz * 9.0; vec2 pi = floor(pc), pf = fract(pc) - 0.5;
    float pebble = step(0.82, hs(pi)) * smoothstep(0.32, 0.16, length(pf + (vec2(hs(pi + 3.1), hs(pi + 7.7)) - 0.5) * 0.4));
    float crack = smoothstep(0.035, 0.0, abs(vn2(xz * 3.3) - 0.5)) * 0.6;
    gInk = clamp(grain * 0.8 + pebble * 0.7 - crack, 0.0, 1.0); gK = 0.55; gSpec = 0.04 + 0.5 * uWet; gGloss = 14.0 + 40.0 * uWet;
    vec3 c = vTint * 0.62 * (0.86 + 0.16 * fine) * (0.92 + 0.14 * mid);
    c *= 0.72 + 0.42 * grain; c = mix(c, c * 1.35 + 0.02, pebble * 0.6); c *= 1.0 - crack * 0.5;
    return c * ashenContact(vWPos) * (1.0 - 0.35 * uWet);
  }
  if (vMat < -0.5) {                                   // terreno: bioma + manchas + trilhas + rocha nas encostas
    code = 0.0; solidFloor = true;
    float slope = 1.0 - n.y, big = fbm(xz * 0.07), mid = vn2(xz * 0.9), fine = vn2(xz * 7.0);
    vec3 soil = mix(vec3(0.2, 0.16, 0.12), vec3(0.27, 0.21, 0.15), fbm(xz * 0.35));
    float grassK = smoothstep(0.16, 0.4, big + (mid - 0.5) * 0.3);
    vec3 grass = vTint * (0.7 + 0.32 * mid);
    base = mix(soil, grass, grassK) * (0.86 + 0.18 * fine) * 0.8;
    float tr = abs(fbm(xz * 0.006 + 3.3) - 0.5);
    base = mix(base, vec3(0.3, 0.25, 0.18) * (0.85 + 0.25 * fine), smoothstep(0.016, 0.006, tr) * smoothstep(0.35, 0.15, slope) * 0.85);
    float rockK = clamp(max(vW.x, smoothstep(0.38, 0.62, slope + (mid - 0.5) * 0.2)), 0.0, 1.0);
    vec2 rp = tri(vWPos, n) * 0.55;
    base = mix(base, vec3(0.34, 0.33, 0.35) * (0.72 + 0.32 * fbm(rp * 2.0)), rockK);
    base = mix(base, vec3(0.7, 0.62, 0.45), vW.y);
    base = mix(base, vec3(0.86, 0.9, 0.96) * (0.92 + 0.08 * fine), vW.z);
    base = mix(base, vec3(0.16, 0.13, 0.1) * (0.8 + 0.3 * mid), vW.w);
    if (vWPos.y < uWL + 0.1) base *= 0.55;
    if (abs(vWPos.y - uWL) < 0.02) { base = vTint * 0.8; code = ${MAT.RIVER + 1}.0; solidFloor = false; }   // lago: no ASCII vira água espelhada
    float grainT = vn2(xz * 19.0) * 0.55 + vn2(xz * 47.0) * 0.3 + vn2(xz * 113.0) * 0.15;
    gInk = grainT; gK = 0.5; gSpec = 0.04 + 0.5 * uWet; gGloss = 14.0 + 40.0 * uWet;
    base *= 0.78 + 0.36 * grainT;
    return base * ashenContact(vWPos) * (1.0 - 0.35 * uWet);
  }
  int m = int(vMat + 0.5);
  if (uCloth > 0.5) {                                   // tecido: frente/verso, bainha recortada, grade no pano
    if (texture2D(tClothMask, vUV2).a < 0.5) discard;
    if (!gl_FrontFacing) m = int(uMatBack + 0.5);
    q = vUV2 * uClothSize / vec2(uGlyphCell * 0.62, uGlyphCell);
  }
  base = uMatColor[m] * vTint;
  float cls = uSClass[m];
  vec2 t = tri(vWPos, n);
  float fine = vn2(t * 9.0);
  if (cls > 0.5 && cls < 1.5) {
    bool flat_ = abs(n.y) > 0.7;
    vec2 qq = flat_ ? t / 0.7 : vec2(t.x / 0.62, t.y / 0.31);
    qq.x += flat_ ? 0.0 : floor(qq.y) * 0.5;
    vec2 fq = fract(qq);
    float mortar = min(min(fq.x, 1.0 - fq.x), min(fq.y, 1.0 - fq.y));
    base *= (0.78 + 0.32 * hs(floor(qq))) * (0.85 + 0.25 * fine) * mix(0.45, 1.0, smoothstep(0.01, 0.05, mortar));
  } else if (cls > 1.5 && cls < 2.5) {
    vec2 qq = vec2(t.x * 5.0, t.y * 0.6);
    base *= (0.75 + 0.3 * hs(vec2(floor(qq.x), 1.0))) * (0.82 + 0.22 * (sin(t.y * 18.0 + vn2(t * vec2(2.0, 14.0)) * 6.0) * 0.5 + 0.5));
  } else base *= 0.88 + 0.2 * fine;
  // tamanho da célula de caractere (m): corpos e metal finos; alvenaria e madeira maiores
  float cs = vActor > 0.5 ? 0.034 : cls > 0.5 && cls < 1.5 ? 0.085 : cls > 1.5 && cls < 2.5 ? 0.07 : cls > 2.5 && cls < 3.5 ? 0.045 : cls > 8.5 ? 0.09 : 0.06;
  if (uCloth < 0.5) q = vActor > 0.5 ? ashenTriQ(vRest, normalize(vRestN), cs) : ashenTriQ(vWPos, n, cs);
  bool water = cls > 8.5;
  solidFloor = !water && vActor < 0.5 && uCloth < 0.5 && n.y > 0.8 && vWPos.y < uFocusF.y + 0.25;
  code = solidFloor ? 0.0 : float(m) + 1.0;
  if (solidFloor) base *= ashenContact(vWPos);
  gSpec = uMatSpec[m]; gGloss = max(4.0, uMatGloss[m]);
  return base;
}`;

// ── grama 3D ──
const GRASS_V = `
attribute vec3 iRoot;   // raiz
attribute vec4 iBlade;  // altura, ângulo natural, largura, tipo (0 talo, 1 cabeça de flor, 2 folha de planta)
attribute vec4 iCol;    // cor, código
attribute float iSeed;
uniform vec3 uPlayer;
uniform vec4 uTrail[8];
uniform vec4 uActors[8];
varying vec3 vCol; varying vec2 vGQ; varying float vGCode; varying float vHead;
uniform vec2 uViewport; uniform float uLineW;
uniform vec3 uSkyC, uMoonC;
uniform sampler2D tShadow; uniform vec4 uSh; uniform vec2 uShS;
uniform vec4 uLP[6]; uniform vec3 uLC[6];
vec3 gS0, gS1;
// sombra "pintada": máscara vista de cima, projetada na direção da lua (muros, árvores, personagens)
float ashenShadowAt(vec3 p) {
  vec2 uv = (vec2(p.x - uShS.x * p.y, p.z - uShS.y * p.y) - uSh.xy) / uSh.z * 0.5 + 0.5;
  if (uv.x < 0.0 || uv.y < 0.0 || uv.x > 1.0 || uv.y > 1.0) return 1.0;
  float o = 1.5 / 512.0, s = 0.0;
  s += step(0.5 / 255.0, texture2D(tShadow, uv).a); s += step(0.5 / 255.0, texture2D(tShadow, uv + vec2(o, 0.0)).a);
  s += step(0.5 / 255.0, texture2D(tShadow, uv + vec2(0.0, o)).a); s += step(0.5 / 255.0, texture2D(tShadow, uv - vec2(o, o)).a);
  return 1.0 - 0.62 * s / 4.0;
}
// tocha, fogueira, lustre: poças de luz quente (só cor)
vec3 ashenPools(vec3 p) { vec3 I = vec3(0.0); for (int i = 0; i < 6; i++) { float r = uLP[i].w; if (r <= 0.0) continue; float a = clamp(1.0 - distance(p, uLP[i].xyz) / r, 0.0, 1.0); I += uLC[i] * a * a; } return I; }
float gHash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float gNoise(vec2 p) { vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(gHash(i), gHash(i + vec2(1, 0)), f.x), mix(gHash(i + vec2(0, 1)), gHash(i + vec2(1, 1)), f.x), f.y); }
// sombra das nuvens que passam pela grama
float ashenCloud(vec2 p) { vec2 q = p * 0.05 + uWind.xy * uTime * 0.05 + vec2(uTime * 0.012, 0.0); float n = gNoise(q) * 0.65 + gNoise(q * 2.3 + 7.0) * 0.35; return mix(0.42, 1.0, smoothstep(0.38, 0.62, n)); }
void ashenInst(out vec3 P, out vec3 N) {
  vec3 root = iRoot; float h = iBlade.x, nat = iBlade.y, kind = iBlade.w;
#ifdef ASHEN_ASCII
  h *= 0.85;                                    // traços curtos, como na referência
#endif
  vec2 wd = uWind.xy; float ws = uWind.z;
  float g1 = sin(dot(root.xz, wd) * 0.55 - uTime * 1.6);
  float g2 = sin(dot(root.xz, vec2(-wd.y, wd.x)) * 0.31 + uTime * 0.53 + g1 * 0.6);
  float gust = 0.5 + 0.32 * g1 + 0.18 * g2;
  float fl = sin(uTime * (4.5 + fract(iSeed * 0.131) * 4.0) + iSeed) * 0.2 + sin(uTime * 11.3 + iSeed * 2.1) * 0.06;
  vec2 bend = wd * ws * (gust + fl) * (kind > 1.5 ? 0.35 : 1.0) + vec2(cos(nat), sin(nat)) * 0.22;
  vec2 pd = root.xz - uPlayer.xz; float pdl = length(pd);
  if (pdl < 0.75) bend += pd / max(pdl, 0.05) * (0.75 - pdl) * 2.4;
  float flatK = 0.0;
  for (int i = 0; i < 8; i++) {
    vec2 dt = root.xz - uTrail[i].xy; float dd = length(dt), age = uTime - uTrail[i].z;
    if (dd < 0.32 && age > 0.0) { float k = (1.0 - dd / 0.32) * exp(-age / 3.5); bend += dt / max(dd, 0.04) * k * 1.3; flatK = max(flatK, k); }
  }
  float bl = length(bend); if (bl > 1.5) bend *= 1.5 / bl;
  float t = position.y;                       // 0 na raiz → 1 na ponta
  if (kind > 0.5 && kind < 1.5) t = 0.82 + 0.18 * t;  // cabeça de flor: só o alto
  float k = pow(t, 1.6), droop = min(length(bend), 1.3);
  vec3 c = root + vec3(0.0, h * t * (1.0 - 0.3 * droop * droop * t) * (1.0 - 0.75 * flatK), 0.0) + vec3(bend.x, 0.0, bend.y) * h * k * 0.8;
  float a = nat + 1.5708;
  vec3 side = vec3(cos(a), 0.0, sin(a));
  float w = iBlade.z * (kind > 0.5 && kind < 1.5 ? 1.0 : (1.0 - 0.85 * position.y));
  P = c + side * position.x * w;
  N = normalize(vec3(bend.x * 0.6, 1.0, bend.y * 0.6));
  float rootK = kind > 0.5 && kind < 1.5 ? 1.0 : mix(0.22, 1.1, pow(position.y, 0.8));   // base do talo escura (oclusão)
  float aoA = 1.0;
  for (int i = 0; i < 8; i++) { vec4 a = uActors[i]; if (a.z <= 0.0) continue; aoA *= 1.0 - 0.5 * (1.0 - smoothstep(a.z * 0.3, a.z * 1.2, length(root.xz - a.xy))) * (1.0 - position.y * 0.6); }
  vCol = iCol.rgb * rootK * aoA;
  vGCode = floor(iCol.a * 255.0 + 0.5); vActor = 0.0;
  vGQ = vec2(position.x * 0.5 + 0.5, t * h / max(iBlade.z * 1.7, 0.012));
  vHead = kind > 0.5 && kind < 1.5 ? 1.0 : 0.0;
  if (vHead > 0.5) { vGQ = vec2(position.x * 0.5 + 0.5, position.y); P = c + side * position.x * w * 0.62 + vec3(0.0, (position.y - 0.5) * w * 1.6, 0.0); }
#ifdef ASHEN_ASCII
  // tapete de traços: linha central (a largura em pixels entra depois da projeção), verde-musgo/floresta
  float t2 = min(1.0, t + 0.1), k2 = pow(t2, 1.6);
  gS0 = c; gS1 = root + vec3(0.0, h * t2 * (1.0 - 0.3 * droop * droop * t2) * (1.0 - 0.75 * flatK), 0.0) + vec3(bend.x, 0.0, bend.y) * h * k2 * 0.8;
  float hsd = fract(iSeed * 0.6180339), hs2 = fract(iSeed * 0.3713);
  // verde apagado e frio (referência): pouca saturação, alguns traços mais claros
  vec3 g0 = mix(vec3(0.1, 0.22, 0.14), vec3(0.22, 0.42, 0.26), hsd * hsd);
  g0 = mix(g0, vec3(0.12, 0.3, 0.24), step(0.7, hs2));
  g0 = mix(g0, vec3(0.26, 0.28, 0.16), step(0.95, hs2) * step(0.5, hsd));
  float cl = ashenCloud(root.xz);
  // "movimento pela cor": a rajada que passa clareia a grama
  float gustC = 0.85 + 0.3 * smoothstep(0.55, 0.95, gust);
  vec3 lightC = (uSkyC * 1.8 + uMoonC * 1.05) * ashenShadowAt(root) * cl * gustC + ashenPools(root) * 1.1;
  vCol = g0 * mix(0.3, 1.25, pow(position.y, 0.85)) * aoA * lightC * (step(0.93, fract(iSeed * 0.913)) * 0.6 + 1.0);
  if (vHead > 0.5) {                                                           // flor pálida: caractere virado para a câmera
    vec3 cr = vec3(viewMatrix[0][0], viewMatrix[1][0], viewMatrix[2][0]), cu = vec3(viewMatrix[0][1], viewMatrix[1][1], viewMatrix[2][1]);
    float fs = 0.032 + 0.02 * hsd;
    P = c + cr * position.x * fs * 0.62 + cu * (position.y - 0.5) * fs;
    vCol = mix(vec3(0.92, 0.93, 0.86), vec3(0.95, 0.75, 0.6), step(0.92, hs2)) * (0.5 + 0.4 * hsd) * cl * mix(0.5, 1.0, ashenShadowAt(root)) + ashenPools(root);
  } else P = c;
#endif
}`;
const GRASS_F = 'varying vec3 vCol; varying vec2 vGQ; varying float vGCode; varying float vHead;';

// ── caracteres fixos (decalques) ──
const SPRITE_V = `
attribute vec3 iPos; attribute vec3 iNrm; attribute vec3 iTan;
attribute vec4 iInfo;   // osso, flags, tamanho, glifo (-1 = rampa)
attribute vec4 iCol;    // cor, código
varying vec3 vCol; varying vec2 vCorner; varying float vEmis; varying float vGlyph; varying float vCode;
void ashenInst(out vec3 P, out vec3 N) {
  mat4 B = uBones[int(iInfo.x + 0.5)];
  vec3 wp = (B * vec4(iPos, 1.0)).xyz, wn = normalize(mat3(B) * iNrm), wt = mat3(B) * iTan;
  wt = wt - wn * dot(wt, wn);
  if (dot(wt, wt) < 1e-6) wt = abs(wn.y) < 0.9 ? cross(vec3(0.0, 1.0, 0.0), wn) : cross(wn, vec3(1.0, 0.0, 0.0));
  wt = normalize(wt); vec3 bt = cross(wn, wt);
  // o caractere fica de pé na superfície: "cima" = a tangente
  float s = iInfo.z * 0.6;
  P = wp + wn * 0.004 + (bt * position.x * 0.62 + wt * position.y) * s;
  N = wn;
  vCorner = position.xy; vCol = iCol.rgb; vCode = iCol.a; vGlyph = iInfo.w;
  vEmis = mod(floor(iInfo.y / 2.0), 2.0) > 0.5 ? 1.0 : 0.0;
  vActor = iInfo.x > 0.5 ? 1.0 : 0.0;
}`;
const SPRITE_F = 'varying vec3 vCol; varying vec2 vCorner; varying float vEmis; varying float vGlyph; varying float vCode;';

/** Aplica os trechos de shader num material do Three (e no material de profundidade da sombra). */
function patch(mat, kind, U, depth = false) {
  mat.onBeforeCompile = (sh) => {
    Object.assign(sh.uniforms, U);
    const head = COMMON_V + (kind === 'sprite' ? SPRITE_V : kind === 'solid' ? SOLID_V : GRASS_V);
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\n' + head);
    if (!depth) sh.vertexShader = sh.vertexShader.replace('#include <beginnormal_vertex>', 'vec3 aP, aN; ashenInst(aP, aN);\n#define ASHEN_N\nvec3 objectNormal = aN;');
    sh.vertexShader = sh.vertexShader.replace('#include <begin_vertex>', '#ifndef ASHEN_N\nvec3 aP, aN; ashenInst(aP, aN);\n#endif\nvec3 transformed = aP;');
    sh.vertexShader = sh.vertexShader.replace('#include <project_vertex>', kind === 'grass' ? PROJ_TAIL + `
#ifdef ASHEN_ASCII
  if (vHead < 0.5) {
    vec4 a0 = projectionMatrix * viewMatrix * vec4(gS0, 1.0), a1 = projectionMatrix * viewMatrix * vec4(gS1, 1.0);
    vec2 dd = (a1.xy / a1.w - a0.xy / a0.w) * uViewport;
    dd = length(dd) > 1e-4 ? normalize(dd) : vec2(0.0, 1.0);
    gl_Position.xy += vec2(-dd.y, dd.x) * position.x * uLineW * (1.0 - 0.55 * position.y) / uViewport * 2.0 * gl_Position.w;
  }
#endif` : PROJ_TAIL);
    const fh = GLYPH_GLSL + COMMON_F + (kind === 'sprite' ? SPRITE_F : kind === 'solid' ? SOLID_F : GRASS_F);
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\n' + fh);
    if (depth) {
      if (kind === 'sprite') sh.fragmentShader = sh.fragmentShader.replace('void main() {', 'void main() {\n if (ashenGlyph(vCorner * 0.5 + 0.5, vCode, vGlyph) < 0.4) discard;');
      if (kind === 'solid') sh.fragmentShader = sh.fragmentShader.replace('void main() {', 'void main() {\n if (uCloth > 0.5 && texture2D(tClothMask, vUV2).a < 0.5) discard;');
      return;
    }
    let color;
    if (kind === 'solid') color = `
      float gCode; vec2 gQ; bool gFloor;
      vec3 gBase = ashenBase(gCode, gQ, gFloor);
      ashenFade(gFloor);
      if (gCode > 0.5) { gK = ashenVis(gQ); if (gK > 0.001) gInk = ashenGlyph(gQ, gCode, -1.0); }
      diffuseColor.rgb *= gBase * mix(1.0, mix(0.5, 1.16, gInk), gK);
#ifdef ASHEN_ASCII
      diffuseColor.rgb *= ashenLight(normalize(vWN));
#endif`;
    else if (kind === 'grass') color = `
      ashenFade(false);
      gK = ashenVis(vGQ) * 0.85; if (gK > 0.001 || vHead > 0.5) gInk = ashenGlyph(vGQ, vGCode, -1.0);
      if (vHead > 0.5) { if (gInk < 0.35) discard; gK = 1.0; }   // flor: a corola tem o formato do caractere
      diffuseColor.rgb *= vCol * mix(1.0, mix(0.55, 1.2, gInk), gK);`;
    else color = `
      gInk = ashenGlyph(vCorner * 0.5 + 0.5, vCode, vGlyph);
      if (gInk < 0.4) discard;
      ashenFade(false);
      gK = 1.0; gSpec = 0.6; gGloss = 30.0;
      diffuseColor.rgb *= vCol;
#ifdef ASHEN_ASCII
      diffuseColor.rgb *= ashenLight(vec3(0.0, 1.0, 0.0)) * (1.0 + vEmis * 2.0);
#endif`;
    sh.fragmentShader = sh.fragmentShader.replace('#include <color_fragment>', color);
    if (kind !== 'grass') {
      sh.fragmentShader = sh.fragmentShader.replace('#include <specularmap_fragment>', `
        float gEdge = clamp(length(vec2(dFdx(gInk), dFdy(gInk))) * 1.4, 0.0, 1.0);
        float specularStrength = gSpec * (0.18 + (0.55 * gInk + 1.3 * gEdge) * gK);`);
      sh.fragmentShader = sh.fragmentShader.replace('#include <lights_phong_fragment>', PHONG_LIGHTS);
      if (kind === 'sprite') sh.fragmentShader = sh.fragmentShader.replace('#include <emissivemap_fragment>', 'totalEmissiveRadiance += vCol * vEmis * 1.6;');
    } else sh.fragmentShader = sh.fragmentShader.replace('#include <normal_fragment_begin>', '#include <normal_fragment_begin>\nnormal = normalize(vNormal);')
      .replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\n#ifdef ASHEN_ASCII\ntotalEmissiveRadiance += diffuseColor.rgb * 0.22;\n#endif');
    // código do material no alfa (o modo ASCII lê do alvo dos objetos)
    if (kind === 'solid') sh.fragmentShader = sh.fragmentShader.replace('#include <dithering_fragment>', '#include <dithering_fragment>\ngl_FragColor.a = (gCode + (gCode > 0.5 && (vActor > 0.5 || uCloth > 0.5) ? 100.0 : 0.0)) / 255.0;');
    if (kind === 'sprite') sh.fragmentShader = sh.fragmentShader.replace('#include <dithering_fragment>', '#include <dithering_fragment>\ngl_FragColor.a = vCode / 255.0;');
    // relevo: o traço levanta, o espaço entre os traços afunda
    sh.fragmentShader = sh.fragmentShader.replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
      if (gK > 0.001) normal = ashenBump(-vViewPosition, normal, vec2(dFdx(gInk), dFdy(gInk)) * uBump * gK, faceDirection);`);
  };
  mat.customProgramCacheKey = () => 'ashen2-' + kind + (depth ? '-d' : '');
}

// ── modelos .glb: o esqueleto e a textura do arquivo ficam; entram os caracteres gravados ──
const GLB_V = 'varying vec3 vRest; varying vec3 vRestN; varying vec2 vNDC; varying float vDcam; varying float vActor;';
const GLB_F = 'varying vec3 vRest; varying vec3 vRestN; uniform float uCode, uUnit, uSpecK, uGlossK;';
function patchGlb(mat, U) {
  mat.onBeforeCompile = (sh) => {
    Object.assign(sh.uniforms, U);
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\n' + GLB_V)
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvRest = position; vRestN = normal; vActor = 1.0;')
      .replace('#include <project_vertex>', PROJ_TAIL);
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\n' + GLYPH_GLSL + COMMON_F + GLB_F)
      .replace('#include <color_fragment>', `#include <color_fragment>
        ashenFade(false);
        vec2 gQ = ashenTriQ(vRest * uUnit, normalize(vRestN), 0.034);
        gK = ashenVis(gQ); if (gK > 0.001) gInk = ashenGlyph(gQ, uCode, -1.0);
        diffuseColor.rgb *= mix(1.0, mix(0.5, 1.16, gInk), gK);
        gSpec = uSpecK; gGloss = uGlossK;`)
      .replace('#include <specularmap_fragment>', `float gEdge = clamp(length(vec2(dFdx(gInk), dFdy(gInk))) * 1.4, 0.0, 1.0);
        float specularStrength = gSpec * (0.18 + (0.55 * gInk + 1.3 * gEdge) * gK);`)
      .replace('#include <lights_phong_fragment>', PHONG_LIGHTS)
      .replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
        if (gK > 0.001) normal = ashenBump(-vViewPosition, normal, vec2(dFdx(gInk), dFdy(gInk)) * uBump * gK, faceDirection);`)
      .replace('#include <dithering_fragment>', '#include <dithering_fragment>\ngl_FragColor.a = (uCode + 100.0) / 255.0;');
  };
  mat.customProgramCacheKey = () => 'ashen2-glb';
}
/** Qual família de caracteres combina com um material do .glb (pelo nome; senão pela cor/metal). */
function glbCode(m) {
  const n = (m.name || '').toLowerCase();
  const by = [[/steel|metal|iron|armou?r|plate|helm|mail|chain|sword|blade|a[çc]o|ferro|armadura/, MAT.STEEL], [/gold|ouro|brass|bronze/, MAT.GOLD], [/silver|prata/, MAT.SILVER],
    [/cape|cloak|cloth|fabric|robe|tunic|capa|tecido|manto/, MAT.CLOTH], [/leather|belt|boot|couro|cinto/, MAT.LEATHER], [/skin|body|face|pele|corpo/, MAT.SKIN],
    [/hair|cabelo|beard/, MAT.HAIR], [/wood|madeira/, MAT.WOOD], [/bone|skull|osso/, MAT.BONE], [/stone|pedra|rock/, MAT.STONE]];
  for (const [re, id] of by) if (re.test(n)) return id;
  const c = m.color || new THREE.Color(0.5, 0.5, 0.5), hsl = {}; c.getHSL(hsl);
  if ((m.metalness || 0) > 0.5) return hsl.s > 0.35 && hsl.h > 0.08 && hsl.h < 0.17 ? MAT.GOLD : MAT.STEEL;
  if (hsl.s > 0.35 && (hsl.h < 0.04 || hsl.h > 0.9)) return MAT.CLOTH;
  if (hsl.s > 0.2 && hsl.h < 0.12 && hsl.l > 0.45) return MAT.SKIN;
  if (hsl.h < 0.14 && hsl.l < 0.45) return MAT.LEATHER;
  return MAT.STEEL;
}

export class ThreeRenderer {
  constructor(canvas, atlas, { mode = 'gravado' } = {}) {
    const r = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, stencil: false, powerPreference: 'high-performance' });
    if (!r.capabilities.isWebGL2) throw new Error('WebGL2 indisponível');
    THREE.ColorManagement.enabled = false;
    r.outputColorSpace = THREE.LinearSRGBColorSpace;
    r.toneMapping = THREE.NoToneMapping;
    r.shadowMap.enabled = true; r.shadowMap.type = THREE.PCFShadowMap; r.shadowMap.autoUpdate = false;
    r.sortObjects = true;
    this.three = r; this.canvas = canvas; this.atlas = atlas;
    this.engine = 'three';
    this.ascii = mode === 'ascii';
    if (this.ascii) this.engine = 'ascii';
    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2(0x000000, 0.02);
    this.camera = new THREE.PerspectiveCamera(30, 1, 0.5, 100);
    this.camera.matrixAutoUpdate = false; this.camera.matrixWorldAutoUpdate = false;
    this.moon = new THREE.DirectionalLight(0xffffff, 1);
    this.moon.castShadow = true;
    this.moon.shadow.mapSize.set(2048, 2048);
    this.moon.shadow.bias = -0.0008; this.moon.shadow.normalBias = 0.03;
    this.moon.shadow.camera.near = 1; this.moon.shadow.camera.far = 70;
    this.scene.add(this.moon, this.moon.target);
    this.rim = new THREE.DirectionalLight(0xffffff, 0.3); this.scene.add(this.rim, this.rim.target);
    this.hemi = new THREE.HemisphereLight(0xffffff, 0x000000, 1); this.scene.add(this.hemi);
    this.points = [];
    for (let i = 0; i < MAX_LIGHTS; i++) { const l = new THREE.PointLight(0xffaa66, 0, 6, 1.2); this.points.push(l); this.scene.add(l); }
    this.atlasTex = atlasTexture(atlas);
    this.G = {
      uSkyC: { value: new THREE.Color() }, uGroundC: { value: new THREE.Color() }, uMoonC: { value: new THREE.Color() }, uMoonD: { value: new THREE.Vector3(0, 1, 0) },
      uNoFade: { value: 0 }, tShadow: { value: null }, uSh: { value: new THREE.Vector4(0, 0, 32, 0) }, uShS: { value: new THREE.Vector2() },
      uLP: { value: Array.from({ length: 6 }, () => new THREE.Vector4()) }, uLC: { value: Array.from({ length: 6 }, () => new THREE.Vector3()) },
      uTime: { value: 0 }, uWind: { value: new THREE.Vector4() }, uFocus: { value: new THREE.Vector3() }, uFocusF: { value: new THREE.Vector3() },
      uPlayer: { value: new THREE.Vector3() }, uTrail: { value: Array.from({ length: 8 }, () => new THREE.Vector4(-100, -100, -100, 0)) },
      uPlayerNDC: { value: new THREE.Vector2() }, uPlayerDist: { value: 0 }, uAspect: { value: 1 },
      uSinkR: { value: 60 }, uMatColor: { value: MATCOL }, uSClass: { value: SCLASS }, uMatSpec: { value: MATSPEC }, uMatGloss: { value: MATGLOSS },
      uWet: { value: 0 }, uWL: { value: -1000 }, uBump: { value: 1.6 }, uActors: { value: Array.from({ length: 8 }, () => new THREE.Vector4(0, 0, 0, 0)) },
      tAtlas: { value: this.atlasTex }, tRamp: { value: rampTexture(atlas) }, uAtlasCols: { value: atlas.cols }, uAtlasRows: { value: atlas.rows },
      uGlyphFade0: { value: 18 }, uGlyphFade1: { value: 46 },
      uViewport: { value: new THREE.Vector2(1, 1) }, uLineW: { value: 1.2 },
      uCloth: { value: 0 }, uMatBack: { value: 0 }, uGlyphCell: { value: 0.05 }, uClothSize: { value: new THREE.Vector2(1, 1) }, tClothMask: { value: null },
    };
    this.identBones = { value: (() => { const d = new Float32Array(MAX_BONES * 16); for (let i = 0; i < MAX_BONES; i++) d.set(IDENT, i * 16); return d; })() };
    this.quad = new THREE.PlaneGeometry(2, 2);
    this.bladeGeo = (() => {
      const g = new THREE.BufferGeometry(), seg = mode === 'ascii' ? 2 : 4, pos = [], idx = [];   // traço ASCII: 2 segmentos bastam
      for (let i = 0; i <= seg; i++) { const t = i / seg; pos.push(-1, t, 0, 1, t, 0); }
      for (let i = 0; i < seg; i++) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
      g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setIndex(idx);
      g.setAttribute('normal', new THREE.Float32BufferAttribute(new Array(pos.length).fill(0).map((_, i) => (i % 3 === 1 ? 1 : 0)), 3));
      return g;
    })();
    this.meshes = []; this.solids = [];
    this.lodNear = 4.5; this.lodMin = 0.2; this.densK = 0.75; this.pcf = 1; this.solidQ = 1; this.sinkR = 60;
    this.grassMul = 1.5; this.reflEvery = 1;
    this.stats = { glyphs: 0, particles: 0, tris: 0, calls: 0 };
    this.area = null;
    this.templates = new Map();
    this.cellCss = 6;
    if (this.ascii) {
      this.G.uGlyphFade0.value = -2; this.G.uGlyphFade1.value = -1;          // sem gravação: os caracteres saem da composição
      this.asciiPass = new AsciiPass(r, atlas, this.atlasTex);
      r.shadowMap.enabled = false;                                             // sombras: máscara pintada, não mapa de sombra
      this.shMask = new THREE.WebGLRenderTarget(512, 512, { type: THREE.UnsignedByteType, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: true, colorSpace: THREE.NoColorSpace });
      this.shCam = new THREE.Camera(); this.shN = 0; this.shEvery = 4;
      this.G.tShadow.value = this.shMask.texture;
      this.worldCell = 0.2; this.grassBudget = 120000;
      for (const l of [this.moon, this.rim, this.hemi, ...this.points]) l.layers.enableAll();
      this._setupMotes();
    }      // nome → modelo .glb carregado (ou null: não existe)
  }

  _mat(kind, U, opts = {}) {
    // ASCII: nada de luz por pixel — material sem iluminação; a luz/sombra é simulada pela cor
    const Cls = this.ascii ? THREE.MeshBasicMaterial : kind === 'grass' ? THREE.MeshLambertMaterial : THREE.MeshPhongMaterial;
    const extra = this.ascii || kind === 'grass' ? {} : { specular: 0xffffff, shininess: 20 };
    const m = new Cls({ side: kind === 'grass' || U.uCloth ? THREE.DoubleSide : THREE.FrontSide, ...extra, ...opts });
    patch(m, kind, { ...this.G, ...U });
    if (this.ascii) { m.defines = { ...(m.defines || {}), ASHEN_ASCII: '' }; }
    return m;
  }
  _depth(kind, U) {
    const m = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, side: U.uCloth ? THREE.DoubleSide : THREE.FrontSide });
    patch(m, kind, { ...this.G, ...U }, true);
    return m;
  }

  // ───────────── sólidos ─────────────
  _solidGeo(geom) {
    this._gpu = this._gpu || new Map();
    let gpu = this._gpu.get(geom);
    if (gpu) return gpu;
    const v = geom.v, nv = geom.nv;
    const pos = new Float32Array(nv * 3), nrm = new Float32Array(nv * 3), mat = new Float32Array(nv), tint = new Float32Array(nv * 3), w = new Float32Array(nv * 4);
    for (let i = 0; i < nv; i++) {
      const o = i * VSTRIDE;
      pos[i * 3] = v[o]; pos[i * 3 + 1] = v[o + 1]; pos[i * 3 + 2] = v[o + 2];
      nrm[i * 3] = v[o + 3]; nrm[i * 3 + 1] = v[o + 4]; nrm[i * 3 + 2] = v[o + 5];
      mat[i] = v[o + 6]; tint[i * 3] = v[o + 7]; tint[i * 3 + 1] = v[o + 8]; tint[i * 3 + 2] = v[o + 9];
      w[i * 4] = v[o + 10]; w[i * 4 + 1] = v[o + 11]; w[i * 4 + 2] = v[o + 12]; w[i * 4 + 3] = v[o + 13];
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('normal', new THREE.BufferAttribute(nrm, 3));
    g.setAttribute('aMat', new THREE.BufferAttribute(mat, 1)); g.setAttribute('aTint', new THREE.BufferAttribute(tint, 3)); g.setAttribute('aW', new THREE.BufferAttribute(w, 4));
    g.setIndex(new THREE.BufferAttribute(geom.idx.subarray(0, geom.ni), 1));
    g.computeBoundingSphere();
    if (geom.far) g.boundingSphere.radius += 3;
    gpu = { g, refs: 0, tris: geom.ni / 3, skinned: !!geom.skinned };
    this._gpu.set(geom, gpu);
    return gpu;
  }
  addSolid(geom, { chunk = 16, castShadow = true, parent = null } = {}) {
    if (!geom || !geom.nv || !geom.ni) return null;
    const gpu = this._solidGeo(geom);
    gpu.refs++;
    const U = { uBones: parent ? (parent._uBones || (parent._uBones = { value: null })) : this.identBones, uFade: { value: 1 } };
    const m = this._mat('solid', U, { polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 2 });
    const obj = new THREE.Mesh(gpu.g, m);
    obj.castShadow = castShadow; obj.receiveShadow = true;
    obj.customDepthMaterial = this._depth('solid', U);
    obj.frustumCulled = !gpu.skinned;
    obj.matrixAutoUpdate = false;
    this.scene.add(obj);
    const s = { obj, U, gpu, visible: true, castShadow, parent, area: null, skinned: gpu.skinned, tris: gpu.tris };
    this.solids.push(s);
    return s;
  }
  removeSolid(s) {
    if (!s) return;
    const i = this.solids.indexOf(s); if (i >= 0) this.solids.splice(i, 1);
    this.scene.remove(s.obj); s.obj.material.dispose(); s.obj.customDepthMaterial.dispose();
    if (--s.gpu.refs <= 0) { s.gpu.g.dispose(); for (const [k, v] of this._gpu) if (v === s.gpu) this._gpu.delete(k); }
  }

  // ───────────── conjuntos de pontos → geometria contínua ─────────────
  addMesh(ps, { dynamic = false, bones = null, occlude = true, chunk = 0 } = {}) {
    const mesh = { n: ps.n, dynamic, bones: bones || [IDENT], visible: true, castShadow: occlude, occlude, area: null, parts: [], boneData: null };
    mesh._uBones = { value: null };
    mesh.modelName = ps.modelName || null;
    if (ps.cloth) { this._clothPart(mesh, ps.cloth); this.meshes.push(mesh); return mesh; }
    // corpo contínuo: o sólido que já vem com os pontos ou uma casca gerada deles (objetos pequenos)
    let solid = ps.solid && ps.solid.nv ? ps.solid : null;
    if (!solid && !dynamic && ps.n >= 40) {
      if (ps._hull === undefined) {
        let mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9];
        for (let i = 0; i < ps.n; i++) for (let a = 0; a < 3; a++) { const v = ps.pos[i * 3 + a]; if (v < mn[a]) mn[a] = v; if (v > mx[a]) mx[a] = v; }
        const span = Math.max(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]);
        let veg = 0, water = 0; for (let i = 0; i < ps.n; i++) { const f = ps.attr[i * 4 + 3] | 0; if (f & 8) veg++; if (f & 256) water++; }
        ps._hull = null;
        if (span < 7 && veg < ps.n * 0.5 && !water) { try { const h = hullFromPoints(ps, { res: 0.02 }); if (h && h.nv) ps._hull = h; } catch (e) { console.warn('[ASHEN] casca', e); } }
      }
      solid = ps._hull;
    }
    const blades = [], ground = [], water = [], sprites = [], loose = [];
    for (let i = 0; i < ps.n; i++) {
      const fl = ps.attr[i * 4 + 3] | 0, mat = ps.attr[i * 4] | 0, bone = ps.attr[i * 4 + 2] | 0, glyph = ps.attr[i * 4 + 1];
      if (fl & 8) { blades.push(i); continue; }
      if (fl & 256) { water.push(i); continue; }
      if (mat === MAT.DARK && bone === 0 && ps.nrm[i * 3 + 1] > 0.8 && ps.pos[i * 3 + 1] < 0.12) continue;
      if (!dynamic && bone === 0 && (GROUND_MATS.has(mat) || (FLOOR_MATS.has(mat) && ps.nrm[i * 3 + 1] > 0.85 && ps.pos[i * 3 + 1] < 0.3))) { ground.push(i); continue; }
      if (glyph >= 0 || (fl & 2) || EMISSIVE.has(mat)) { sprites.push(i); continue; }
      if (!solid) loose.push(i);
    }
    const ck = chunk > 0 ? Math.max(6, chunk * 2.4) : 0;
    if (ground.length) this._groundSheet(mesh, ps, ground, ck || 8);
    if (water.length) { this._groundSheet(mesh, ps, water, ck || 8, MAT.RIVER); let y = 0; for (const i of water) y += ps.pos[i * 3 + 1]; mesh.waterY = y / water.length; }
    if (blades.length) this._grassParts(mesh, ps, blades, ck || 8);
    // pontos sem corpo (folhagem solta, conjuntos grandes sem sólido): viram caracteres fixos de pé na superfície
    const sp = sprites.concat(loose);
    if (sp.length) this._spriteParts(mesh, ps, sp, ck);
    this.meshes.push(mesh);
    if (solid) mesh.solid = this.addSolid(solid, { parent: mesh, chunk: 16, castShadow: occlude });
    const tpl = mesh.modelName && this.templates.get(mesh.modelName);
    if (tpl) this._attachTpl(mesh, tpl);
    return mesh;
  }

  _groupByChunk(ps, list, ck) {
    if (!ck) return [list];
    const map = new Map();
    for (const i of list) { const k = Math.floor(ps.pos[i * 3] / ck) * 100000 + Math.floor(ps.pos[i * 3 + 2] / ck); let a = map.get(k); if (!a) map.set(k, a = []); a.push(i); }
    const out = [...map.values()];
    for (const a of out) for (let i = a.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [a[i], a[j]] = [a[j], a[i]]; }
    return out;
  }

  _fillSprite(ps, list, arr) {
    const { P, N, T, I, C } = arr;
    list.forEach((i, k) => {
      P[k * 3] = ps.pos[i * 3]; P[k * 3 + 1] = ps.pos[i * 3 + 1]; P[k * 3 + 2] = ps.pos[i * 3 + 2];
      N[k * 3] = ps.nrm[i * 3]; N[k * 3 + 1] = ps.nrm[i * 3 + 1]; N[k * 3 + 2] = ps.nrm[i * 3 + 2];
      T[k * 3] = ps.tan[i * 3]; T[k * 3 + 1] = ps.tan[i * 3 + 1]; T[k * 3 + 2] = ps.tan[i * 3 + 2];
      const mat = ps.attr[i * 4] | 0, fl = ps.attr[i * 4 + 3] | 0, raw = ps.extra[i * 2];
      let size = raw, ao = 1;
      if (fl & 64) { size = Math.floor(raw) / 2000; ao = (raw % 1) / 0.99; }
      const c = (MATERIALS[mat] || MATERIALS[0]).c, a = 0.45 + 0.55 * ao;
      I[k * 4] = ps.attr[i * 4 + 2]; I[k * 4 + 1] = EMISSIVE.has(mat) ? fl | 2 : fl; I[k * 4 + 2] = size; I[k * 4 + 3] = ps.attr[i * 4 + 1];
      C[k * 4] = c[0] * a; C[k * 4 + 1] = c[1] * a; C[k * 4 + 2] = c[2] * a; C[k * 4 + 3] = mat + 1;
    });
  }

  _spriteParts(mesh, ps, list, ck) {
    for (const part of this._groupByChunk(ps, list, ck)) {
      const n = part.length;
      const arr = { P: new Float32Array(n * 3), N: new Float32Array(n * 3), T: new Float32Array(n * 3), I: new Float32Array(n * 4), C: new Float32Array(n * 4) };
      this._fillSprite(ps, part, arr);
      const g = new THREE.InstancedBufferGeometry();
      g.index = this.quad.index; g.setAttribute('position', this.quad.getAttribute('position')); g.setAttribute('normal', this.quad.getAttribute('normal'));
      const u = mesh.dynamic ? THREE.DynamicDrawUsage : THREE.StaticDrawUsage;
      const at = (k, a, s) => { const b = new THREE.InstancedBufferAttribute(a, s); b.setUsage(u); g.setAttribute(k, b); };
      at('iPos', arr.P, 3); at('iNrm', arr.N, 3); at('iTan', arr.T, 3); at('iInfo', arr.I, 4); at('iCol', arr.C, 4);
      g.instanceCount = n;
      const U = { uBones: mesh._uBones, uFade: { value: 1 } };
      const m = this._mat('sprite', U);
      const obj = new THREE.Mesh(g, m);
      obj.matrixAutoUpdate = false;
      let box = null;
      if (ck) {
        box = new THREE.Box3(); const v = new THREE.Vector3();
        for (let k = 0; k < n; k++) box.expandByPoint(v.set(arr.P[k * 3], arr.P[k * 3 + 1], arr.P[k * 3 + 2]));
        g.boundingSphere = box.getBoundingSphere(new THREE.Sphere()); g.boundingSphere.radius += 1;
      } else obj.frustumCulled = false;
      obj.castShadow = false; obj.receiveShadow = true;
      this.scene.add(obj);
      mesh.parts.push({ obj, U, n, list: part, arr, kind: 'sprite', chunked: !!ck, box });
    }
  }

  /** Tecido: a grade da simulação vira malha; a bainha rasgada e os furos saem de uma máscara. */
  _clothPart(mesh, cl) {
    const { cols, rows } = cl, nv = cols * rows;
    const pos = new Float32Array(nv * 3), nrm = new Float32Array(nv * 3), uv = new Float32Array(nv * 2), idx = [];
    for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) { const k = j * cols + i; uv[k * 2] = i / (cols - 1); uv[k * 2 + 1] = j / (rows - 1); }
    for (let j = 0; j < rows - 1; j++) for (let i = 0; i < cols - 1; i++) { const a = j * cols + i; idx.push(a, a + 1, a + cols, a + 1, a + cols + 1, a + cols); }
    const g = new THREE.BufferGeometry();
    const P = new THREE.BufferAttribute(pos, 3), N = new THREE.BufferAttribute(nrm, 3);
    P.setUsage(THREE.DynamicDrawUsage); N.setUsage(THREE.DynamicDrawUsage);
    g.setAttribute('position', P); g.setAttribute('normal', N); g.setAttribute('aUV', new THREE.BufferAttribute(uv, 2));
    g.setAttribute('aMat', new THREE.BufferAttribute(new Float32Array(nv).fill(cl.mats[0]), 1));
    g.setAttribute('aTint', new THREE.BufferAttribute(new Float32Array(nv * 3).fill(1), 3)); g.setAttribute('aW', new THREE.BufferAttribute(new Float32Array(nv * 4), 4));
    g.setIndex(idx);
    // máscara da bainha (64×64): 1 onde há pano
    const S = 64, md = new Uint8Array(S * S * 4);
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
      const u = (x + 0.5) / S, v = (y + 0.5) / S, hem = cl.hem(u);
      const on = v <= hem && !(cl.hole && cl.hole(u, v, hem));
      md[(y * S + x) * 4 + 3] = on ? 255 : 0;
    }
    const mask = new THREE.DataTexture(md, S, S, THREE.RGBAFormat); mask.magFilter = THREE.LinearFilter; mask.minFilter = THREE.LinearFilter; mask.needsUpdate = true;
    const U = { uBones: this.identBones, uFade: { value: 1 }, uCloth: { value: 1 }, uMatBack: { value: cl.mats[1] }, uGlyphCell: { value: 0.045 }, uClothSize: { value: new THREE.Vector2(cl.w, cl.h) }, tClothMask: { value: mask } };
    const m = this._mat('solid', U);
    const obj = new THREE.Mesh(g, m);
    obj.frustumCulled = false; obj.matrixAutoUpdate = false; obj.castShadow = true; obj.receiveShadow = true;
    obj.customDepthMaterial = this._depth('solid', U);
    this.scene.add(obj);
    mesh.cloth = cl;
    mesh.parts.push({ obj, U, n: (cols - 1) * (rows - 1) * 2, kind: 'cloth', mask });
    this._clothSync(mesh);
    // brasão bordado (estandartes): caractere fixo preso ao pano
    if (cl.emblem) mesh.emblemIdx = true;
  }
  _clothSync(mesh) {
    const cl = mesh.cloth, p = mesh.parts[0], g = p.obj.geometry, P = g.attributes.position.array, N = g.attributes.normal.array;
    for (let k = 0; k < cl.p.length; k++) {
      const a = cl.p[k], n = cl.nrm[k] || [0, 0, 1];
      P[k * 3] = a[0]; P[k * 3 + 1] = a[1]; P[k * 3 + 2] = a[2];
      N[k * 3] = n[0]; N[k * 3 + 1] = n[1]; N[k * 3 + 2] = n[2];
    }
    g.attributes.position.needsUpdate = true; g.attributes.normal.needsUpdate = true;
  }

  /** Chão contínuo: os pontos do chão são rasterizados numa grade (altura e cor médias por célula),
   *  os buracos são preenchidos e a grade vira uma malha sólida — sem caracteres, como pede a regra. */
  _groundSheet(mesh, ps, list, ck, matOverride = -3) {
    const res = 0.2;
    let x0 = 1e9, z0 = 1e9, x1 = -1e9, z1 = -1e9;
    for (const i of list) { const x = ps.pos[i * 3], z = ps.pos[i * 3 + 2]; if (x < x0) x0 = x; if (x > x1) x1 = x; if (z < z0) z0 = z; if (z > z1) z1 = z; }
    x0 -= res * 2; z0 -= res * 2;
    const nx = Math.ceil((x1 - x0) / res) + 3, nz = Math.ceil((z1 - z0) / res) + 3;
    if (nx * nz > 9e6) return;
    const cnt = new Float32Array(nx * nz), Y = new Float32Array(nx * nz), C = new Float32Array(nx * nz * 3);
    for (const i of list) {
      const ix = Math.floor((ps.pos[i * 3] - x0) / res), iz = Math.floor((ps.pos[i * 3 + 2] - z0) / res), c = ix + iz * nx;
      const mat = ps.attr[i * 4] | 0, fl = ps.attr[i * 4 + 3] | 0, raw = ps.extra[i * 2];
      const ao = fl & 64 ? (raw % 1) / 0.99 : 1, col = (MATERIALS[mat] || MATERIALS[MAT.GROUND]).c, a = 0.55 + 0.45 * ao;
      cnt[c]++; Y[c] += ps.pos[i * 3 + 1]; C[c * 3] += col[0] * a; C[c * 3 + 1] += col[1] * a; C[c * 3 + 2] += col[2] * a;
    }
    for (let c = 0; c < nx * nz; c++) if (cnt[c]) { Y[c] /= cnt[c]; C[c * 3] /= cnt[c]; C[c * 3 + 1] /= cnt[c]; C[c * 3 + 2] /= cnt[c]; cnt[c] = 1; }
    // fecha os buracos (2 passadas: cada célula vazia com vizinhos cheios pega a média deles)
    for (let pass = 0; pass < 3; pass++) {
      const add = [];
      for (let z = 1; z < nz - 1; z++) for (let x = 1; x < nx - 1; x++) {
        const c = x + z * nx; if (cnt[c]) continue;
        let k = 0, y = 0, r = 0, g = 0, b = 0;
        for (const d of [-1, 1, -nx, nx, -1 - nx, 1 - nx, -1 + nx, 1 + nx]) if (cnt[c + d] === 1) { k++; y += Y[c + d]; r += C[(c + d) * 3]; g += C[(c + d) * 3 + 1]; b += C[(c + d) * 3 + 2]; }
        if (k >= (pass === 0 ? 2 : 3)) add.push([c, y / k, r / k, g / k, b / k]);
      }
      for (const [c, y, r, g, b] of add) { cnt[c] = 1; Y[c] = y; C[c * 3] = r; C[c * 3 + 1] = g; C[c * 3 + 2] = b; }
    }
    // vértice em cada canto = média das células que o tocam
    const vid = new Int32Array((nx + 1) * (nz + 1)).fill(-1);
    const pos = [], nrm = [], tint = [];
    const corner = (x, z) => {
      const k = x + z * (nx + 1); if (vid[k] >= 0) return vid[k];
      let n = 0, y = 0, r = 0, g = 0, b = 0;
      for (const [dx, dz] of [[-1, -1], [0, -1], [-1, 0], [0, 0]]) { const cx = x + dx, cz = z + dz; if (cx < 0 || cz < 0 || cx >= nx || cz >= nz) continue; const c = cx + cz * nx; if (!cnt[c]) continue; n++; y += Y[c]; r += C[c * 3]; g += C[c * 3 + 1]; b += C[c * 3 + 2]; }
      vid[k] = pos.length / 3; pos.push(x0 + x * res, y / n - 0.006, z0 + z * res); nrm.push(0, 1, 0); tint.push(r / n, g / n, b / n);
      return vid[k];
    };
    const buckets = new Map();
    for (let z = 0; z < nz; z++) for (let x = 0; x < nx; x++) {
      if (!cnt[x + z * nx]) continue;
      const a = corner(x, z), b = corner(x + 1, z), c = corner(x, z + 1), d = corner(x + 1, z + 1);
      const key = Math.floor((x0 + x * res) / ck) * 100000 + Math.floor((z0 + z * res) / ck);
      let arr = buckets.get(key); if (!arr) buckets.set(key, arr = []);
      arr.push(a, c, b, b, c, d);
    }
    // normais pela grade
    const nv = pos.length / 3, N = new Float32Array(nv * 3);
    for (const arr of buckets.values()) for (let t = 0; t < arr.length; t += 3) {
      const A = arr[t] * 3, B = arr[t + 1] * 3, Cc = arr[t + 2] * 3;
      const ux = pos[B] - pos[A], uy = pos[B + 1] - pos[A + 1], uz = pos[B + 2] - pos[A + 2], wx = pos[Cc] - pos[A], wy = pos[Cc + 1] - pos[A + 1], wz = pos[Cc + 2] - pos[A + 2];
      const fx = uy * wz - uz * wy, fy = uz * wx - ux * wz, fz = ux * wy - uy * wx;
      for (const q of [A, B, Cc]) { N[q] += fx; N[q + 1] += fy; N[q + 2] += fz; }
    }
    for (let i = 0; i < nv; i++) { const l = Math.hypot(N[i * 3], N[i * 3 + 1], N[i * 3 + 2]) || 1; let ny = N[i * 3 + 1] / l; const sgn = ny < 0 ? -1 : 1; N[i * 3] *= sgn / l; N[i * 3 + 1] = Math.abs(ny); N[i * 3 + 2] *= sgn / l; }
    const P = new Float32Array(pos), T = new Float32Array(matOverride >= 0 ? tint.map(() => 1) : tint), Mt = new Float32Array(nv).fill(matOverride), W = new Float32Array(nv * 4);
    // os blocos compartilham os mesmos atributos (um buffer só na GPU); cada um tem seu índice
    const A = { position: new THREE.BufferAttribute(P, 3), normal: new THREE.BufferAttribute(N, 3), aMat: new THREE.BufferAttribute(Mt, 1), aTint: new THREE.BufferAttribute(T, 3), aW: new THREE.BufferAttribute(W, 4) };
    for (const arr of buckets.values()) {
      const g = new THREE.BufferGeometry();
      for (const [k, v] of Object.entries(A)) g.setAttribute(k, v);
      g.setIndex(new THREE.Uint32BufferAttribute(arr, 1));
      const box = new THREE.Box3(), v = new THREE.Vector3();
      for (const q of arr) box.expandByPoint(v.set(P[q * 3], P[q * 3 + 1], P[q * 3 + 2]));
      g.boundingBox = box; g.boundingSphere = box.getBoundingSphere(new THREE.Sphere());
      const U = { uBones: this.identBones, uFade: { value: 1 } };
      const m = this._mat('solid', U, { polygonOffset: true, polygonOffsetFactor: 2, polygonOffsetUnits: 4 });
      const obj = new THREE.Mesh(g, m);
      obj.matrixAutoUpdate = false; obj.receiveShadow = true; obj.castShadow = false;
      this.scene.add(obj);
      mesh.parts.push({ obj, U, n: arr.length / 3, kind: 'sheet', chunked: true, box });
    }
  }

  /** Talos → lâminas 3D. Um talo = pontos seguidos com a mesma raiz; os de "ponta" (f ≥ 1) são cabeças de flor. */
  _grassParts(mesh, ps, list, ck) {
    const blades = [];
    let i0 = 0;
    const same = (a, b) => ps.pos[a * 3] === ps.pos[b * 3] && ps.pos[a * 3 + 2] === ps.pos[b * 3 + 2] && ps.extra[a * 2 + 1] === ps.extra[b * 2 + 1];
    const R = (() => { let s = 12345; return () => ((s = (s * 16807) % 2147483647) / 2147483647); })();
    const emit = (a, b) => {
      const idx = list.slice(a, b);
      const heads = idx.filter(i => ps.tan[i * 3] >= 0.99), stem = idx.filter(i => ps.tan[i * 3] < 0.99);
      const fl = ps.attr[idx[0] * 4 + 3] | 0, plant = !!(fl & 32);
      if (stem.length) {
        const i = stem[0], mat = ps.attr[i * 4] | 0, h = Math.max(...stem.map(q => ps.tan[q * 3 + 1])) * (plant ? 1.0 : 1);
        const size = ps.extra[i * 2];
        blades.push({ x: ps.pos[i * 3], y: ps.pos[i * 3 + 1], z: ps.pos[i * 3 + 2], h: plant ? h * 0.9 + 0.04 : h, nat: ps.tan[i * 3 + 2], w: plant ? 0.05 + size * 0.2 : 0.012 + size * 0.06, kind: plant ? 2 : 0, mat, seed: ps.extra[i * 2 + 1] });
      }
      for (const i of heads) blades.push({ x: ps.pos[i * 3], y: ps.pos[i * 3 + 1], z: ps.pos[i * 3 + 2], h: ps.tan[i * 3 + 1], nat: ps.tan[i * 3 + 2], w: 0.05 * (ps.extra[i * 2] / 0.075), kind: 1, mat: ps.attr[i * 4] | 0, seed: ps.extra[i * 2 + 1] });
    };
    for (let k = 1; k <= list.length; k++) if (k === list.length || !same(list[k], list[i0])) { emit(i0, k); i0 = k; }
    // grama densa: cada talo ganha vizinhos (mesma touceira) — quantos depende da qualidade
    const extra = [];
    const mul = this.grassMul;
    for (const b of blades) {
      if (b.kind !== 0) continue;
      let c = mul - 1;
      while (c > 0) {
        if (c < 1 && R() > c) break;
        const a = R() * 6.283, r = this.ascii ? 0.03 + R() * 0.34 : 0.04 + R() * 0.12;
        const dot = this.ascii && R() < 0.05;                    // pontinhos brancos espalhados (referência)
        extra.push({ ...b, x: b.x + Math.cos(a) * r, z: b.z + Math.sin(a) * r, h: dot ? 0.05 + R() * 0.12 : b.h * (0.7 + R() * 0.5), nat: b.nat + (R() - 0.5) * 1.4, seed: b.seed + 17.3 * c, kind: dot ? 1 : 0, w: dot ? 0.03 : b.w, mat: dot ? MAT.FLOWER_W : b.mat });
        c -= 1;
      }
    }
    const all = blades.concat(extra);
    // blocos espaciais
    const map = new Map();
    for (const b of all) { const k = Math.floor(b.x / ck) * 100000 + Math.floor(b.z / ck); let a = map.get(k); if (!a) map.set(k, a = []); a.push(b); }
    for (const part of map.values()) {
      for (let i = part.length - 1; i > 0; i--) { const j = (R() * (i + 1)) | 0; [part[i], part[j]] = [part[j], part[i]]; }
      const n = part.length, Ro = new Float32Array(n * 3), Bl = new Float32Array(n * 4), Co = new Float32Array(n * 4), Se = new Float32Array(n);
      const box = new THREE.Box3(), v = new THREE.Vector3();
      part.forEach((b, k) => {
        Ro[k * 3] = b.x; Ro[k * 3 + 1] = b.y; Ro[k * 3 + 2] = b.z;
        Bl[k * 4] = b.h; Bl[k * 4 + 1] = b.nat; Bl[k * 4 + 2] = b.w; Bl[k * 4 + 3] = b.kind;
        let c = (MATERIALS[b.mat] || MATERIALS[MAT.GRASS]).c; const tone = 0.85 + 0.3 * ((b.seed * 0.618) % 1);
        if (FLOWERS.has(b.mat)) {                     // dark fantasy: flores secas e escuras, nada de neon
          const l = c[0] * 0.3 + c[1] * 0.59 + c[2] * 0.11, d = 0.42 + 0.18 * ((b.seed * 0.377) % 1);
          c = [(l + (c[0] - l) * 0.42) * d + 0.03, (l + (c[1] - l) * 0.42) * d * 0.92 + 0.02, (l + (c[2] - l) * 0.42) * d * 0.8 + 0.01];
        }
        Co[k * 4] = c[0] * tone; Co[k * 4 + 1] = c[1] * tone; Co[k * 4 + 2] = c[2] * tone; Co[k * 4 + 3] = (b.mat + 1) / 255;
        Se[k] = b.seed;
        box.expandByPoint(v.set(b.x, b.y, b.z)); box.expandByPoint(v.set(b.x, b.y + b.h, b.z));
      });
      const g = new THREE.InstancedBufferGeometry();
      g.index = this.bladeGeo.index; g.setAttribute('position', this.bladeGeo.getAttribute('position')); g.setAttribute('normal', this.bladeGeo.getAttribute('normal'));
      g.setAttribute('iRoot', new THREE.InstancedBufferAttribute(Ro, 3)); g.setAttribute('iBlade', new THREE.InstancedBufferAttribute(Bl, 4));
      g.setAttribute('iCol', new THREE.InstancedBufferAttribute(Co, 4)); g.setAttribute('iSeed', new THREE.InstancedBufferAttribute(Se, 1));
      g.instanceCount = n;
      box.expandByScalar(0.6);
      g.boundingBox = box; g.boundingSphere = box.getBoundingSphere(new THREE.Sphere());
      const U = { uFade: { value: 1 } };
      const m = this._mat('grass', U);
      const obj = new THREE.Mesh(g, m);
      obj.matrixAutoUpdate = false; obj.receiveShadow = true; obj.castShadow = false;
      if (this.ascii) obj.layers.set(1);           // tapete de traços: desenhado direto na tela, depois da composição
      this.scene.add(obj);
      mesh.parts.push({ obj, U, n, kind: 'grass', chunked: true, box });
    }
    mesh.blades = all.length;
  }

  // ───────────── modelos .glb (Fase 3) ─────────────
  /** Procura assets/models/<nome>.glb para cada nome; os que existem passam a desenhar todas as malhas daquele personagem. */
  async loadModels(names) {
    const found = [];
    await Promise.all(names.map(async n => {
      const tpl = await loadTemplate(n).catch(() => null);
      this.templates.set(n, tpl);
      if (!tpl) return;
      found.push(n);
      for (const m of this.meshes) if (m.modelName === n && !m.model) this._attachTpl(m, tpl);
    }));
    return found;
  }
  _glbMaterial(src) {
    const code = glbCode(src), M = MATERIALS[code];
    const m = new (this.ascii ? THREE.MeshBasicMaterial : THREE.MeshPhongMaterial)({ map: src.map || null, color: src.color ? src.color.clone() : new THREE.Color(1, 1, 1), normalMap: src.normalMap || null,
      emissive: src.emissive ? src.emissive.clone() : new THREE.Color(0, 0, 0), emissiveMap: src.emissiveMap || null, ...(this.ascii ? {} : { specular: 0xffffff, shininess: 20 }),
      transparent: !!src.transparent, opacity: src.opacity == null ? 1 : src.opacity, alphaTest: src.alphaTest || 0, side: src.side });
    if (m.map) m.map.colorSpace = THREE.NoColorSpace;
    const U = { ...this.G, uFade: { value: 1 }, uCode: { value: code + 1 }, uUnit: { value: 1 },
      uSpecK: { value: Math.max(M.spec || 0, (src.metalness || 0) * (1 - (src.roughness == null ? 0.5 : src.roughness)) * 1.4) }, uGlossK: { value: Math.max(6, M.gloss || 14) } };
    patchGlb(m, U);
    if (this.ascii) { for (const k of ['emissive', 'emissiveMap', 'normalMap', 'specular', 'shininess']) delete m[k]; }
    m.userData.U = U;
    return m;
  }
  _attachTpl(mesh, tpl) {
    if (mesh.noModel) return;
    const model = instantiate(tpl, src => this._glbMaterial(src));
    mesh.model = model;
    model.holder.visible = false;
    this.scene.add(model.holder);
  }
  /** Compat.: prende um modelo já pronto a uma malha. */
  attachModel(mesh, model) { mesh.model = model; model.holder.matrixAutoUpdate = false; this.scene.add(model.holder); }

  _driveModel(m, on, f) {
    const md = m.model, H = md.holder;
    H.visible = m._modelOn;
    if (!m._modelOn) return;
    const W = m.modelMatrix, dt = Math.min(0.1, f.dt || 1 / 60);
    // altura: a do corpo atual (cabeça → pés pelos ossos), medida uma vez, no espaço do modelo do jogo
    if (!md.hLocal) {
      const b = m.boneData, sc = Math.hypot(W[0], W[1], W[2]) || 1;
      let h = 0, lo = 1e9, hi = -1e9, used = 0;
      if (b) for (let i = 1; i < 18; i++) { const o = i * 16; if (b[o + 12] === 0 && b[o + 13] === 0 && b[o + 14] === 0) continue; used++; lo = Math.min(lo, b[o + 13]); hi = Math.max(hi, b[o + 13]); }
      if (used >= 12) h = (hi - lo) * 1.16;                      // esqueleto humano: cabeça → pés
      const def = DEFAULT_HEIGHT[m.modelName];
      md.hLocal = def ? def / sc : h > 0.3 && h < 12 ? h / sc : 1.78 / 0.955;
    }
    this._m4 = this._m4 || new THREE.Matrix4();
    H.matrix.fromArray(W).multiply(this._m4.makeScale(md.hLocal, md.hLocal, md.hLocal));
    H.matrixWorldNeedsUpdate = true;
    // velocidade (para parado/andar/correr quando o jogo não diz o estado)
    const x = W[12], z = W[14];
    if (md.last) { const v = Math.hypot(x - md.last[0], z - md.last[1]) / Math.max(dt, 1e-3); md.speed += (Math.min(v, 12) - md.speed) * Math.min(1, dt * 8); }
    md.last = [x, z];
    playState(md, m.animState || (md.speed > 3.2 ? 'run' : md.speed > 0.25 ? 'walk' : 'idle'));
    md.mixer.update(dt);
    // morrendo: some pontilhado como o corpo antigo; escala da grade de caracteres em metros
    const fade = !m.lodDraw && m.drawCount != null && m.n ? Math.min(1, m.drawCount / m.n) : 1;
    for (const o of md.meshes) {
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      const unit = new THREE.Vector3().setFromMatrixScale(o.matrixWorld).x || 1;
      for (const mt of mats) if (mt.userData.U) { mt.userData.U.uFade.value = fade; mt.userData.U.uUnit.value = unit; }
    }
  }

  removeMesh(mesh) {
    if (mesh.model) { this.scene.remove(mesh.model.holder); mesh.model = null; }
    const i = this.meshes.indexOf(mesh); if (i >= 0) this.meshes.splice(i, 1);
    for (const p of mesh.parts) {
      this.scene.remove(p.obj); p.obj.material.dispose(); if (p.obj.customDepthMaterial) p.obj.customDepthMaterial.dispose();
      if (p.kind === 'sprite' || p.kind === 'grass') for (const k of Object.keys(p.obj.geometry.attributes)) if (k.startsWith('i')) p.obj.geometry.deleteAttribute(k);
      if (p.kind !== 'sheet') p.obj.geometry.dispose(); else p.obj.geometry.index && p.obj.geometry.dispose();
      if (p.mask) p.mask.dispose();
    }
    mesh.parts = [];
    if (mesh.solid) { this.removeSolid(mesh.solid); mesh.solid = null; }
  }

  /** Malha dinâmica: tecidos reenviam a grade; caracteres fixos reenviam posição. */
  updateMesh(mesh, ps) {
    if (mesh.cloth) { this._clothSync(mesh); return; }
    for (const p of mesh.parts) {
      if (p.kind !== 'sprite') continue;
      this._fillSprite(ps, p.list, p.arr);
      const g = p.obj.geometry;
      for (const k of ['iPos', 'iNrm', 'iTan']) g.attributes[k].needsUpdate = true;
    }
  }

  // ───────────── partículas: cada uma é um caractere solto no ar ─────────────
  setupParticles(max = 3000) {
    this.pmax = max;
    const mk = this._mkParticles = (additive, cap = max) => {
      const data = new Float32Array(cap * 10);
      const ib = new THREE.InstancedInterleavedBuffer(data, 10, 1); ib.setUsage(THREE.DynamicDrawUsage);
      const g = new THREE.InstancedBufferGeometry();
      g.index = this.quad.index; g.setAttribute('position', this.quad.getAttribute('position'));
      g.setAttribute('iPos', new THREE.InterleavedBufferAttribute(ib, 4, 0)); g.setAttribute('iCol', new THREE.InterleavedBufferAttribute(ib, 4, 4)); g.setAttribute('iG', new THREE.InterleavedBufferAttribute(ib, 2, 8));
      g.instanceCount = 0;
      const vs = `
attribute vec4 iPos; attribute vec4 iCol; attribute vec2 iG;
varying vec4 vC; varying vec2 vA;
uniform float uAtlasCols, uAtlasRows;
#include <fog_pars_vertex>
void main() {
  vec4 mvPosition = modelViewMatrix * vec4(iPos.xyz, 1.0);
  float cs = cos(iG.y), sn = sin(iG.y);
  vec2 q = position.xy * iPos.w * 0.5;
  mvPosition.xy += vec2(cs * q.x - sn * q.y, sn * q.x + cs * q.y);
  gl_Position = projectionMatrix * mvPosition;
  vec2 cell = vec2(mod(iG.x, uAtlasCols), floor(iG.x / uAtlasCols));
  vA = (cell + (position.xy * vec2(0.5, -0.5) + 0.5)) / vec2(uAtlasCols, uAtlasRows);
  vA.y = 1.0 - vA.y;
  vC = iCol;
  #include <fog_vertex>
}`;
      const fs = `
varying vec4 vC; varying vec2 vA;
uniform sampler2D tAtlas;
#include <fog_pars_fragment>
void main() {
  float a = texture2D(tAtlas, vA).a * vC.a;
  if (a < 0.02) discard;
  vec3 pc = vC.rgb;
  ${!additive && this.ascii ? 'float pl = dot(pc, vec3(0.3, 0.59, 0.11)); pc = mix(pc, vec3(0.78, 0.88, 1.0) * (0.35 + 1.2 * pl), 0.6);   // chuva, névoa, magia: branco/azul-gelo' : ''}
  gl_FragColor = vec4(pc * a${additive ? ' * 1.5' : ''}, a);
  #include <fog_fragment>
}`;
      const mat = new THREE.ShaderMaterial({ vertexShader: vs, fragmentShader: fs, depthWrite: false, transparent: true, fog: true,
        uniforms: THREE.UniformsUtils.merge([THREE.UniformsLib.fog, { tAtlas: { value: null }, uAtlasCols: { value: this.atlas.cols }, uAtlasRows: { value: this.atlas.rows } }]),
        blending: THREE.CustomBlending, blendEquation: THREE.AddEquation, blendSrc: THREE.OneFactor, blendDst: additive ? THREE.OneFactor : THREE.OneMinusSrcAlphaFactor });
      mat.uniforms.tAtlas.value = this.atlasTex;
      const o = new THREE.Mesh(g, mat); o.frustumCulled = false; o.renderOrder = 10;
      if (this.ascii) o.layers.set(1);
      this.scene.add(o);
      return { data, ib, g, o };
    };
    this.pNorm = mk(false); this.pAdd = mk(true);
    if (this.ascii) this.motes = { ...mk(true, 220), n: 220, st: null };
  }

  resize(scale = 1) {
    const dpr = Math.min(window.devicePixelRatio || 1, 3) * scale;
    const w = Math.round(window.innerWidth * dpr), h = Math.round(window.innerHeight * dpr);
    this.three.setPixelRatio(1);
    this.three.setSize(w, h, false);
    this.canvas.style.width = window.innerWidth + 'px'; this.canvas.style.height = window.innerHeight + 'px';
    this.W = w; this.H = h; this.dpr = dpr;
    if (this.ascii) { this._cpx = 0; this.asciiPass.setSize(w, h, this.cellCss * dpr); this.G.uViewport.value.set(w, h); this.G.uLineW.value = Math.max(1, 0.8 * dpr); }
  }
  setCell() { /* ASCII: o tamanho do caractere é fixo no mundo (worldCell) e vem da distância da câmera */ }
  /** Brasas e folhas laranja soltas no ar (só no visual ASCII), em volta da câmera, levadas pelo vento. */
  _setupMotes() { this._moteGlyphs = ['·', '•', ',', '‹', '›', '\'', '°'].map(c => this.atlas.get(c)); }
  _updateMotes(f, dt) {
    const M = this.motes; if (!M) return;
    const fx = f.focus[0], fz = f.focus[2], fy = f.focus[1];
    if (!M.st) { M.st = []; for (let i = 0; i < M.n; i++) M.st.push({ x: fx + (Math.random() - 0.5) * 26, y: fy + Math.random() * 3.2, z: fz + (Math.random() - 0.5) * 22, ph: Math.random() * 6.28, g: this._moteGlyphs[(Math.random() * this._moteGlyphs.length) | 0], leaf: Math.random() < 0.35 }); }
    const d = M.data, w = f.wind || [0, 0, 0], night = this.area === 'dungeon' || this.area === 'house' || this.area === 'church' || this.area === 'palace' ? 0 : 1;
    let n = 0;
    for (const m of M.st) {
      m.ph += dt;
      m.x += (w[0] * 0.6 + Math.sin(m.ph * 0.7) * 0.15) * dt; m.z += (w[2] * 0.6 + Math.cos(m.ph * 0.5) * 0.12) * dt; m.y += (m.leaf ? -0.12 : 0.06) * dt + Math.sin(m.ph * 1.3) * 0.004;
      if (m.x - fx > 13) m.x -= 26; if (fx - m.x > 13) m.x += 26; if (m.z - fz > 11) m.z -= 22; if (fz - m.z > 11) m.z += 22;
      if (m.y < fy + 0.05) m.y = fy + 3.2; if (m.y > fy + 3.4) m.y = fy + 0.1;
      if (!night) continue;
      const tw = 0.55 + 0.45 * Math.sin(m.ph * 2.3), o = n * 10;
      d[o] = m.x; d[o + 1] = m.y; d[o + 2] = m.z; d[o + 3] = m.leaf ? 0.09 : 0.06;
      d[o + 4] = 1.0; d[o + 5] = m.leaf ? 0.42 : 0.5; d[o + 6] = 0.12; d[o + 7] = (m.leaf ? 0.55 : 0.75) * tw;
      d[o + 8] = m.g; d[o + 9] = m.ph * (m.leaf ? 0.8 : 0); n++;
    }
    M.ib.needsUpdate = true; M.g.instanceCount = n; M.o.visible = n > 0;
  }
  _setCellOld() { /* a grade de tela não existe mais (Fase 2): os caracteres vivem nos materiais 3D */ }

  frame(f) {
    const r = this.three, G = this.G, cam = this.camera;
    if (!this.W) this.resize(1);
    cam.projectionMatrix.fromArray(f.proj); cam.projectionMatrixInverse.copy(cam.projectionMatrix).invert();
    cam.matrixWorldInverse.fromArray(f.view); cam.matrixWorld.copy(cam.matrixWorldInverse).invert();
    G.uTime.value = f.time; G.uWind.value.set(f.wind[0], f.wind[1], f.wind[2], 0);
    G.uFocus.value.fromArray(f.focus); G.uFocusF.value.fromArray(f.focus); G.uPlayer.value.fromArray(f.focus);
    G.uSinkR.value = this.sinkR; G.uWet.value = f.wet || 0; G.uWL.value = f.waterLevel != null ? f.waterLevel : -1000;
    const trail = f.trail || [];
    for (let i = 0; i < 8; i++) { const t = trail[i]; G.uTrail.value[i].set(t ? t[0] : -100, t ? t[1] : -100, t ? t[2] : -100, 0); }
    const pc = new THREE.Vector3(f.focus[0], f.focus[1] + 0.9, f.focus[2]);
    G.uPlayerDist.value = pc.distanceTo(new THREE.Vector3().fromArray(f.cam));
    pc.project(cam); G.uPlayerNDC.value.set(pc.x, pc.y); G.uAspect.value = this.W / this.H;
    const K = Math.PI;
    this.hemi.color.setRGB(f.sky[0], f.sky[1], f.sky[2]).multiplyScalar(2.2); this.hemi.groundColor.setRGB(f.ground[0], f.ground[1], f.ground[2]).multiplyScalar(2.2);
    this.moon.color.setRGB(f.moonCol[0], f.moonCol[1], f.moonCol[2]); this.moon.intensity = 0.85 * K;
    const half = 0.55 / (f.shadowSize || 0.05);
    const lc = new THREE.Vector3(f.focus[0], f.focus[1], f.focus[2] - 1);
    this.moon.target.position.copy(lc); this.moon.position.copy(lc).addScaledVector(new THREE.Vector3().fromArray(f.moonDir), 25);
    this.moon.target.updateMatrixWorld(); this.moon.updateMatrixWorld();
    const sc = this.moon.shadow.camera;
    if (sc.right !== half) { sc.left = -half; sc.right = half; sc.top = half; sc.bottom = -half; sc.updateProjectionMatrix(); }
    this.moon.castShadow = f.shadows !== false;
    this.rim.color.setRGB(...(f.rimCol || [0, 0, 0])); this.rim.intensity = 0.8 * K;
    this.rim.position.copy(lc).addScaledVector(new THREE.Vector3().fromArray(f.rimDir || [0, 0.3, -1]), 20); this.rim.target.position.copy(lc);
    this.rim.target.updateMatrixWorld(); this.rim.updateMatrixWorld();
    const lights = f.lights || [];
    for (let i = 0; i < MAX_LIGHTS; i++) {
      const L = this.points[i], l = lights[i];
      if (!l) { L.intensity = 0; continue; }
      L.position.set(l.pos[0], l.pos[1], l.pos[2]); L.distance = l.radius * 1.35; L.decay = 1.2;
      L.color.setRGB(l.col[0], l.col[1], l.col[2]); L.intensity = (l.value != null ? l.value : 1) * 1.7 * K;
      L.updateMatrixWorld();
    }
    this.scene.fog.color.setRGB(f.fog[0], f.fog[1], f.fog[2]);
    this.scene.fog.density = Math.sqrt(Math.max(0, f.fog[3])) * 0.16;
    r.setClearColor(new THREE.Color(f.clear[0], f.clear[1], f.clear[2]), 1);
    if (this.ascii) { this.scene.fog.color.setRGB(0, 0, 0); this.scene.fog.density = 0.0; }
    let drawn = 0, tris = 0;
    const fx = f.focus[0], fz = f.focus[2];
    const gk = this.ascii ? Math.min(1, this.grassBudget / Math.max(1, this._grassLast || 1)) : 1; let grassSum = 0;   // teto de traços por preset
    for (const m of this.meshes) {
      const on = m.visible && (!m.area || m.area === this.area);
      m._uBones.value = m.boneData || (m.boneData = flatBones(m.bones));
      m._modelOn = !!(m.model && m.modelMatrix && on && !m.noModel);
      if (m.model) this._driveModel(m, on, f);
      for (const p of m.parts) {
        p.obj.visible = on && !m._modelOn;
        if (!on) continue;
        if (p.kind === 'sheet' || p.kind === 'cloth') { tris += p.n; continue; }
        if (p.kind === 'grass' || (p.kind === 'sprite' && p.chunked)) {
          const b = p.box, dx = Math.max(b.min.x - fx, 0, fx - b.max.x), dz = Math.max(b.min.z - fz, 0, fz - b.max.z);
          const dd = Math.hypot(dx, dz), near = p.kind === 'grass' ? (this.ascii ? 6.5 : 9) : this.lodNear * 2.5;
          const frac = dd < near ? 1 : Math.max(p.kind === 'grass' ? (this.ascii ? 0.06 : 0.12) : this.lodMin, Math.min(1, Math.pow(near / dd, 1.6))) * Math.min(1, this.densK + 0.25);
          p.obj.geometry.instanceCount = Math.max(1, Math.round(p.n * Math.min(1, frac) * (p.kind === 'grass' && dd > 3 ? gk : 1)));
          if (p.kind === 'grass') grassSum += Math.round(p.n * Math.min(1, frac));
        }
        drawn += p.obj.geometry.instanceCount || 0;
      }
    }
    // pés dos personagens visíveis (osso da bacia) → sombra de contato
    const A = G.uActors.value; let na = 0;
    for (const s of this.solids) {
      if (na >= 8 || !s.skinned || !s.parent) continue;
      const P = s.parent, on = P.visible && (!P.area || P.area === this.area); if (!on) continue;
      const b = P._uBones.value; if (!b) continue;
      const x = b[16 + 12], y = b[16 + 13], z = b[16 + 14];
      if (Math.abs(x - fx) > 30 || Math.abs(z - fz) > 30) continue;
      const gy = P === this._playerMesh ? f.focus[1] : y - 0.95;
      A[na++].set(x, z, 0.55, gy);
    }
    for (let i = na; i < 8; i++) A[i].set(0, 0, 0, 0);
    this._grassLast = grassSum;
    for (const s of this.solids) {
      const P = s.parent, on = P ? P.visible && (!P.area || P.area === this.area) : s.visible && (!s.area || s.area === this.area);
      s.obj.visible = on && !(P && P._modelOn); s.obj.castShadow = s.castShadow;
      if (!on) continue;
      if (P && s.skinned) s.U.uFade.value = !P.lodDraw && P.drawCount != null && P.n ? Math.min(1, P.drawCount / P.n) : 1;
      tris += s.tris;
    }
    let pc2 = 0;
    if (f.particles && f.particles.count && this.pNorm) {
      const ps = f.particles, nn = Math.min(ps.normalCount, this.pmax), na = Math.min(ps.count - ps.normalCount, this.pmax);
      this.pNorm.data.set(ps.data.subarray(0, nn * 10)); this.pNorm.ib.needsUpdate = true; this.pNorm.g.instanceCount = nn;
      this.pAdd.data.set(ps.data.subarray(ps.normalCount * 10, (ps.normalCount + na) * 10)); this.pAdd.ib.needsUpdate = true; this.pAdd.g.instanceCount = na;
      pc2 = nn + na;
    } else if (this.pNorm) { this.pNorm.g.instanceCount = 0; this.pAdd.g.instanceCount = 0; }
    if (this.pNorm) { this.pNorm.o.visible = this.pNorm.g.instanceCount > 0; this.pAdd.o.visible = this.pAdd.g.instanceCount > 0; }
    r.info.autoReset = false; r.info.reset();
    r.shadowMap.needsUpdate = f.shadowRefresh !== false;
    if (this.ascii) {
      // luz pintada (cores do céu/chão/lua do jogo) e poças de luz das chamas
      G.uSkyC.value.setRGB(f.sky[0], f.sky[1], f.sky[2]).multiplyScalar(2.6); G.uGroundC.value.setRGB(f.ground[0], f.ground[1], f.ground[2]).multiplyScalar(2.2);
      G.uMoonC.value.setRGB(f.moonCol[0], f.moonCol[1], f.moonCol[2]).multiplyScalar(0.85); G.uMoonD.value.fromArray(f.moonDir).normalize();
      const LL = f.lights || [];
      for (let i = 0; i < 6; i++) { const l = LL[i], v = l ? (l.value != null ? l.value : 1) : 0; G.uLP.value[i].set(l ? l.pos[0] : 0, l ? l.pos[1] : 0, l ? l.pos[2] : 0, l ? l.radius * 1.25 : 0); G.uLC.value[i].set(l ? l.col[0] * v : 0, l ? l.col[1] * v : 0, l ? l.col[2] * v : 0); }
      // máscara de sombras vista de cima, projetada na direção da lua (a cada N quadros)
      const md = f.moonDir, my = Math.max(0.3, md[1]), shx = md[0] / my, shz = md[2] / my, half = 46;
      if (this.shN++ % this.shEvery === 0) {
        const cx = Math.round(f.focus[0] / 2) * 2, cz = Math.round(f.focus[2] / 2) * 2, fy = f.focus[1];
        const C = this.shCam; C.projectionMatrix.set(1 / half, -shx / half, 0, -cx / half, 0, -shz / half, 1 / half, -cz / half, 0, -1 / 40, 0, fy / 40 + 0.2, 0, 0, 0, 1);
        C.projectionMatrixInverse.copy(C.projectionMatrix).invert(); C.layers.set(0);
        G.uSh.value.set(cx, cz, half, 0); G.uShS.value.set(shx, shz); G.uNoFade.value = 1;
        r.setClearColor(0x000000, 0); r.setRenderTarget(this.shMask); r.render(this.scene, C);
        G.uNoFade.value = 0;
      }
      // tamanho do caractere preso ao mundo: o zoom só aproxima/afasta (mesma quantidade de caracteres)
      const D = Math.hypot(f.cam[0] - f.focus[0], f.cam[1] - f.focus[1] - 0.9, f.cam[2] - f.focus[2]) || 10;
      const pxm = this.H * f.proj[5] / (2 * D), cpx = Math.round(this.worldCell * pxm * 4) / 4;
      if (Math.abs(cpx - (this._cpx || 0)) > 0.01) { this._cpx = cpx; this.asciiPass.setSize(this.W, this.H, Math.max(6, cpx)); }
      this._updateMotes(f, Math.min(0.1, f.dt || 1 / 60));
      const A = this.asciiPass, P = cam.projectionMatrix.clone();
      // 1) objetos (sem grama nem partículas) no alvo da grade: a projeção cobre a grade inteira
      const [gx, gy] = A.gridScale(this.W, this.H), sx = 1 / gx, sy = 1 / gy;
      const M = new THREE.Matrix4().set(sx, 0, 0, sx - 1, 0, sy, 0, sy - 1, 0, 0, 1, 0, 0, 0, 0, 1);
      cam.projectionMatrix.premultiply(M); cam.projectionMatrixInverse.copy(cam.projectionMatrix).invert();
      cam.layers.set(0);
      r.setClearColor(0x000000, 0);
      r.setRenderTarget(A.objRT); r.render(this.scene, cam);
      A.setFrame(cam, f.lights || [], f.time);
      // 1b) reflexo: o mundo espelhado no plano da água (só objetos acima dela), a cada N quadros
      let wy = f.reflWater !== undefined ? f.reflWater : f.waterLevel != null && this.area === 'ow' ? f.waterLevel : null;
      if (wy == null) for (const m of this.meshes) if (m.waterY != null && m.visible && (!m.area || m.area === this.area)) { wy = m.waterY; break; }
      A.setWater(wy, f, this.three.info);
      this._reflN = (this._reflN || 0) + 1;
      if (wy != null && this._reflN % (this.reflEvery || 1) === 0) {
        const S = this.scene;
        S.matrixAutoUpdate = false; S.matrix.set(1, 0, 0, 0, 0, -1, 0, 2 * wy, 0, 0, 1, 0, 0, 0, 0, 1); S.matrixWorldNeedsUpdate = true;
        r.clippingPlanes = [new THREE.Plane(new THREE.Vector3(0, -1, 0), wy - 0.04)];   // só o que está acima da água (a própria água fica de fora)
        const sh = r.shadowMap.enabled; r.shadowMap.enabled = false;
        r.setRenderTarget(A.reflRT); r.render(S, cam);
        r.shadowMap.enabled = sh; r.clippingPlanes = [];
        S.matrix.identity(); S.matrixWorldNeedsUpdate = true; S.updateMatrixWorld(true);
      }
      cam.projectionMatrix.copy(P); cam.projectionMatrixInverse.copy(P).invert();
      // 2) caracteres sobre preto (grava a profundidade dos objetos)
      r.setRenderTarget(null); r.setClearColor(0x000000, 1); r.autoClear = true; A.render();
      // 3) grama em traços + partículas + brasas, por cima, respeitando a profundidade dos objetos
      r.autoClear = false; r.shadowMap.needsUpdate = false;
      if (!this._dbgNoGrass) { cam.layers.set(1); r.render(this.scene, cam); cam.layers.set(0); }
      r.autoClear = true;
    } else {
      r.setRenderTarget(null);
      r.render(this.scene, cam);
    }
    this.stats.glyphs = drawn; this.stats.particles = pc2; this.stats.tris = tris; this.stats.calls = r.info.render.calls; this.stats.instances = drawn;
  }
}

/** Junta as matrizes dos ossos num bloco só (mesmo formato do renderizador antigo). */
export function flatBones(bones, out) {
  const d = out && out.length === MAX_BONES * 16 ? out : new Float32Array(MAX_BONES * 16);
  for (let i = 0; i < MAX_BONES; i++) d.set(bones[i] || bones[0], i * 16);
  return d;
}
