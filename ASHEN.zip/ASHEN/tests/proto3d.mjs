// Protótipo 3D: carrega, mede tempo de construção, captura parado e andando (toque real).
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const url = process.argv[2] || 'http://localhost:8123/prototipo3d.html', out = process.argv[3] || '/tmp/p3';
const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await browser.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 2.625, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
const logs = [];
page.on('console', m => logs.push(`[${m.type()}] ${m.text()}`));
page.on('pageerror', e => logs.push(`[pageerror] ${e.message}`));
const t0 = Date.now();
await page.goto(url);
try { await page.waitForFunction(() => window.__ASHEN3D && window.__ASHEN3D.ready, null, { timeout: 120000 }); }
catch (e) { console.log('NÃO CARREGOU', await page.textContent('#p3-err')); }
const loadS = ((Date.now() - t0) / 1000).toFixed(1);
await page.waitForTimeout(2500);
await page.screenshot({ path: `${out}-parado.png` });
const cdp = await ctx.newCDPSession(page);
const touch = (type, pts) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: pts.map((p, i) => ({ x: p[0], y: p[1], id: i })) });
await touch('touchStart', [[150, 300]]); await touch('touchMove', [[210, 300]]);
await page.waitForTimeout(1200);
await page.screenshot({ path: `${out}-andando.png` });
await touch('touchMove', [[150, 240]]);
await page.waitForTimeout(1500);
await page.evaluate(() => { const p = window.__ASHEN3D.player; p.x = 0.3; p.z = -3.2; p.yaw = Math.PI; window.__ASHEN3D.cam.x = 0.3; window.__ASHEN3D.cam.z = -3.2; });
await page.waitForTimeout(1200);
await touch('touchEnd', []);
await page.waitForTimeout(600);
await page.screenshot({ path: `${out}-norte.png` });
const st = await page.evaluate(() => { const g = window.__ASHEN3D; return g && g.ready ? { x: +g.player.x.toFixed(2), z: +g.player.z.toFixed(2), counts: g.counts, perf: document.getElementById('p3-perf').textContent } : null; });
console.log('carregou em', loadS, 's', JSON.stringify(st));
console.log(logs.slice(0, 15).join('\n') || '(sem logs)');
await browser.close();
