// ASHEN — Fábrica de canvas fora da tela.
// Usa OffscreenCanvas quando o navegador suporta E quando ele enxerga as fontes do documento
// (testado em typography.loadFonts). Caso contrário, usa <canvas> comum (também acelerado).

let useOffscreen = false;

export function setOffscreenAllowed(v) { useOffscreen = !!v && typeof OffscreenCanvas !== 'undefined'; }
export function offscreenInUse() { return useOffscreen; }

export function makeCanvas(w, h) {
  w = Math.max(1, Math.ceil(w));
  h = Math.max(1, Math.ceil(h));
  if (useOffscreen) {
    try { return new OffscreenCanvas(w, h); } catch (e) { /* cai para <canvas> */ }
  }
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}

/** Bytes aproximados de um canvas (RGBA). */
export function canvasBytes(c) { return c ? c.width * c.height * 4 : 0; }
