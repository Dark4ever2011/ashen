// ASHEN — Animação
// Clipes quadro a quadro, animador com transição suave entre clipes,
// fase dirigida por distância (passos não "deslizam"), utilidades de curvas e ruído.

export class Clip {
  constructor(name, frames, fps, loop = true) { this.name = name; this.frames = frames; this.fps = fps; this.loop = loop; }
}

export class Animator {
  constructor(clips) {
    this.clips = clips;
    this.clip = null;
    this.time = 0;
    this.phase = 0;        // 0..1 dentro do ciclo
    this.prev = null;      // clipe anterior (transição)
    this.blend = 1;        // 0 = só anterior, 1 = só atual
    this.blendTime = 0.22;
  }
  play(name, { reset = false, blend = 0.22 } = {}) {
    const c = this.clips[name];
    if (!c || (this.clip === c && !reset)) return;
    if (this.clip && blend > 0) { this.prev = this.clip; this.prevPhase = this.phase; this.blend = 0; this.blendTime = blend; }
    else { this.prev = null; this.blend = 1; }
    this.clip = c;
    if (reset || !this.prev) { this.time = 0; this.phase = 0; }
  }
  /** Avança por tempo. */
  update(dt) {
    if (!this.clip) return;
    this.time += dt;
    const len = this.clip.frames / this.clip.fps;
    this.phase = this.clip.loop ? (this.time / len) % 1 : Math.min(1, this.time / len);
    if (this.blend < 1) { this.blend = Math.min(1, this.blend + dt / this.blendTime); if (this.blend >= 1) this.prev = null; }
  }
  /** Avança por distância percorrida (ciclos de caminhada). */
  advance(distance, stride) {
    this.phase = (this.phase + distance / stride) % 1;
    if (this.blend < 1) this.blend = Math.min(1, this.blend + 1 / 60 / this.blendTime);
  }
  frame() { return this.clip ? Math.floor(this.phase * this.clip.frames) % this.clip.frames : 0; }
  get done() { return this.clip && !this.clip.loop && this.phase >= 1; }
}

export const ease = {
  inOut: t => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2,
  out: t => 1 - (1 - t) * (1 - t),
  smooth: t => t * t * (3 - 2 * t),
};

export const lerp = (a, b, t) => a + (b - a) * t;
export const clamp = (v, a, b) => v < a ? a : v > b ? b : v;

// Ruído de valor 1D/2D determinístico (sem dependências).
function hash(n) { n = (n << 13) ^ n; return 1 - ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824; }
export function hash2(x, y, seed = 0) {
  let h = (x | 0) * 374761393 + (y | 0) * 668265263 + seed * 1442695041;
  h = (h ^ (h >>> 13)) * 1274126177;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
}
export function noise1(x, seed = 0) {
  const i = Math.floor(x), f = x - i, u = f * f * (3 - 2 * f);
  return lerp(hash(i + seed * 131), hash(i + 1 + seed * 131), u);
}
export function noise2(x, y, seed = 0) {
  const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const a = hash2(xi, yi, seed), b = hash2(xi + 1, yi, seed), c = hash2(xi, yi + 1, seed), d = hash2(xi + 1, yi + 1, seed);
  return lerp(lerp(a, b, u), lerp(c, d, u), v);
}
/** Ruído fractal 0..1 */
export function fbm(x, y, seed = 0, oct = 4) {
  let s = 0, a = 0.5, f = 1, n = 0;
  for (let i = 0; i < oct; i++) { s += noise2(x * f, y * f, seed + i * 17) * a; n += a; a *= 0.5; f *= 2.03; }
  return s / n;
}
/** Ruído periódico (tileável) com período px,py em unidades da grade. */
export function noise2p(x, y, px, py, seed = 0) {
  const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const m = (a, p) => ((a % p) + p) % p;
  const a = hash2(m(xi, px), m(yi, py), seed), b = hash2(m(xi + 1, px), m(yi, py), seed);
  const c = hash2(m(xi, px), m(yi + 1, py), seed), d = hash2(m(xi + 1, px), m(yi + 1, py), seed);
  return lerp(lerp(a, b, u), lerp(c, d, u), v);
}

/** Gerador pseudoaleatório com semente (mulberry32). */
export function rng(seed) {
  let a = seed >>> 0;
  return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}

/** Mola amortecida (para capa, balanço, câmera). */
export class Spring {
  constructor(k = 60, d = 9) { this.k = k; this.d = d; this.x = 0; this.v = 0; }
  update(target, dt) { const a = (target - this.x) * this.k - this.v * this.d; this.v += a * dt; this.x += this.v * dt; return this.x; }
}
