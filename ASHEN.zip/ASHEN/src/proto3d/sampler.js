// ASHEN 3D — Distribuição orgânica de caracteres sobre superfícies SDF.
// 1) varre uma grade 3D e projeta na superfície, 2) espalha com jitter tangencial,
// 3) afina com Poisson-disk (distância mínima) → pontos sem padrão de grade,
// 4) mede curvatura para achar arestas/vincos e a direção do traço,
// 5) chama o "detalhe" da peça (rebites, gravuras, frisos) para glifos fixos.

import { rng } from './math3d.js';

export class PointSet {
  constructor(cap = 4096) { this.n = 0; this._alloc(cap); }
  _alloc(cap) {
    const g = (k, old) => { const a = new Float32Array(cap * k); if (old) a.set(old.subarray(0, this.n * k)); return a; };
    this.pos = g(3, this.pos); this.nrm = g(3, this.nrm); this.tan = g(3, this.tan);
    this.attr = g(4, this.attr); // mat, glyph (-1 = rampa), osso, flags (1 aresta, 2 emissivo, 4 contorno-forte)
    this.extra = g(2, this.extra); // tamanho, semente
    this.cap = cap;
  }
  push(p, n, t, mat, glyph, bone, flags, size, seed) {
    if (this.n >= this.cap) this._alloc(this.cap * 2);
    const i = this.n++;
    this.pos.set(p, i * 3); this.nrm.set(n, i * 3); this.tan.set(t, i * 3);
    this.attr[i * 4] = mat; this.attr[i * 4 + 1] = glyph; this.attr[i * 4 + 2] = bone; this.attr[i * 4 + 3] = flags;
    this.extra[i * 2] = size; this.extra[i * 2 + 1] = seed;
  }
  append(o) { for (let i = 0; i < o.n; i++) this.push(o.pos.subarray(i * 3, i * 3 + 3), o.nrm.subarray(i * 3, i * 3 + 3), o.tan.subarray(i * 3, i * 3 + 3), o.attr[i * 4], o.attr[i * 4 + 1], o.attr[i * 4 + 2], o.attr[i * 4 + 3], o.extra[i * 2], o.extra[i * 2 + 1]); }
}

function grad(f, x, y, z, e) {
  const gx = f(x + e, y, z) - f(x - e, y, z), gy = f(x, y + e, z) - f(x, y - e, z), gz = f(x, y, z + e) - f(x, y, z - e);
  const l = Math.hypot(gx, gy, gz) || 1;
  return [gx / l, gy / l, gz / l];
}

function tangentBasis(n) {
  const a = Math.abs(n[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0];
  let t = [a[1] * n[2] - a[2] * n[1], a[2] * n[0] - a[0] * n[2], a[0] * n[1] - a[1] * n[0]];
  const l = Math.hypot(t[0], t[1], t[2]); t = [t[0] / l, t[1] / l, t[2] / l];
  const b = [n[1] * t[2] - n[2] * t[1], n[2] * t[0] - n[0] * t[2], n[0] * t[1] - n[1] * t[0]];
  return [t, b];
}

/**
 * part = { f, min:[x,y,z], max:[x,y,z], mat, spacing, flow:[x,y,z] (direção dos traços),
 *          bone, detail(p,n) → {glyph, mat, flags} | null, size, seed, keep(p,n) → bool }
 */
export function samplePart(part, glyphIndex) {
  const out = new PointSet(2048);
  const f = part.f, s = part.spacing, R = rng(part.seed || 1);
  const g = s * 0.62, e = s * 0.12;
  const [x0, y0, z0] = part.min, [x1, y1, z1] = part.max;
  const hash = new Map();
  const cellKey = (x, y, z) => (Math.floor(x / s) * 73856093) ^ (Math.floor(y / s) * 19349663) ^ (Math.floor(z / s) * 83492791);
  const minD = s * 0.86, minD2 = minD * minD;
  const accepted = [];
  const tryAccept = (p) => {
    const cx = Math.floor(p[0] / s), cy = Math.floor(p[1] / s), cz = Math.floor(p[2] / s);
    for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) for (let k = -1; k <= 1; k++) {
      const list = hash.get(((cx + i) * 73856093) ^ ((cy + j) * 19349663) ^ ((cz + k) * 83492791));
      if (!list) continue;
      for (const q of list) { const dx = q[0] - p[0], dy = q[1] - p[1], dz = q[2] - p[2]; if (dx * dx + dy * dy + dz * dz < minD2) return false; }
    }
    const key = cellKey(p[0], p[1], p[2]);
    let list = hash.get(key); if (!list) { list = []; hash.set(key, list); }
    list.push(p);
    return true;
  };
  const cands = [];
  const C = g * 6, cr = C * 0.87 + g;
  for (let cx = x0; cx <= x1; cx += C) for (let cy = y0; cy <= y1; cy += C) for (let cz = z0; cz <= z1; cz += C) {
    if (Math.abs(f(cx + C / 2, cy + C / 2, cz + C / 2)) > cr) continue;   // célula grossa vazia
  for (let x = cx; x < Math.min(cx + C, x1 + g); x += g) for (let y = cy; y < Math.min(cy + C, y1 + g); y += g) for (let z = cz; z < Math.min(cz + C, z1 + g); z += g) {
    const d = f(x, y, z);
    if (Math.abs(d) > g * 0.9) continue;
    // jitter dentro da célula para quebrar qualquer alinhamento
    let px = x + (R() - 0.5) * g, py = y + (R() - 0.5) * g, pz = z + (R() - 0.5) * g;
    for (let it = 0; it < 3; it++) {
      const dd = f(px, py, pz);
      const n = grad(f, px, py, pz, e);
      px -= n[0] * dd; py -= n[1] * dd; pz -= n[2] * dd;
    }
    if (Math.abs(f(px, py, pz)) > s * 0.08) continue;
    cands.push([px, py, pz, R()]);
  }
  }
  // ordem aleatória → afinamento Poisson sem direção preferencial
  cands.sort((a, b) => a[3] - b[3]);
  for (const c of cands) if (tryAccept(c)) accepted.push(c);
  const flow = part.flow || [0, 1, 0];
  for (const p of accepted) {
    const n = grad(f, p[0], p[1], p[2], e);
    if (part.keep && !part.keep(p, n)) continue;
    // curvatura: variação da normal em duas direções tangentes
    const [t1, t2] = tangentBasis(n);
    const k = s * 0.7;
    const na = grad(f, p[0] + t1[0] * k, p[1] + t1[1] * k, p[2] + t1[2] * k, e);
    const nb = grad(f, p[0] - t1[0] * k, p[1] - t1[1] * k, p[2] - t1[2] * k, e);
    const nc = grad(f, p[0] + t2[0] * k, p[1] + t2[1] * k, p[2] + t2[2] * k, e);
    const nd = grad(f, p[0] - t2[0] * k, p[1] - t2[1] * k, p[2] - t2[2] * k, e);
    const v1 = 1 - (na[0] * nb[0] + na[1] * nb[1] + na[2] * nb[2]);
    const v2 = 1 - (nc[0] * nd[0] + nc[1] * nd[1] + nc[2] * nd[2]);
    const curv = Math.max(v1, v2);
    let tan, flags = 0;
    if (curv > 0.35) {
      // aresta: o traço corre AO LONGO do vinco (direção de menor variação)
      tan = v1 > v2 ? t2 : t1;
      flags |= 1;
    } else {
      const fl = part.flowFn ? part.flowFn(p, n) : flow;
      const fd = fl[0] * n[0] + fl[1] * n[1] + fl[2] * n[2];
      tan = [fl[0] - n[0] * fd, fl[1] - n[1] * fd, fl[2] - n[2] * fd];
      const l = Math.hypot(tan[0], tan[1], tan[2]);
      tan = l > 1e-3 ? [tan[0] / l, tan[1] / l, tan[2] / l] : t1;
    }
    let mat = part.mat, glyph = -1;
    const det = part.detail ? part.detail(p, n, curv) : null;
    if (det) {
      if (det.mat !== undefined) mat = det.mat;
      if (det.glyph) glyph = glyphIndex(det.glyph);
      if (det.flags) flags |= det.flags;
      if (det.skip) continue;
    }
    let size = (part.size || 1) * (det && det.size ? det.size : 1);
    if (part.aoF) {
      // oclusão: quanto as placas vizinhas (e a própria forma) fecham o espaço acima do ponto
      let occ = 0, w = 1;
      for (const h of [0.008, 0.016, 0.028, 0.045, 0.07]) {
        const d = part.aoF(p[0] + n[0] * h, p[1] + n[1] * h, p[2] + n[2] * h);
        occ += Math.max(0, h - d) * w; w *= 0.7;
      }
      const ao = Math.max(0.08, Math.min(1, 1 - occ * 11));
      size = Math.round(size * 2000) + ao * 0.99;   // tamanho e oclusão no mesmo float (flag 64)
      flags |= 64;
    }
    out.push([p[0], p[1], p[2]], n, tan, mat, glyph, part.bone || 0, flags | (part.pointFlags || 0), size, p[3] * 1000);
  }
  return out;
}

/**
 * Constrói várias peças sem travar a tela (cede um quadro a cada ~30 ms).
 * Cada peça pode ter "decals": caracteres fixos posicionados à mão (emblemas, rebites, olhos),
 * que abrem espaço na superfície em volta deles.
 */
export async function buildParts(list, atlas, { sizeMul = 1.85, seed = 1, onProgress, spacingMul = 1 } = {}) {
  const all = new PointSet(20000);
  let t0 = performance.now();
  for (let i = 0; i < list.length; i++) {
    const part = list[i];
    part.seed = seed + i * 31;
    part.spacing *= spacingMul;
    part.size = part.spacing * sizeMul * (part.size || 1);
    const decals = part.decals || [];
    const user = part.detail;
    part.detail = (p, n, c) => {
      for (const d of decals) { const r = d.clear || d.size * 0.65; if ((p[0] - d.p[0]) ** 2 + (p[1] - d.p[1]) ** 2 + (p[2] - d.p[2]) ** 2 < r * r) return { skip: true }; }
      return user ? user(p, n, c) : null;
    };
    all.append(samplePart(part, ch => atlas.get(ch)));
    for (const d of decals) {
      const l = Math.hypot(d.n[0], d.n[1], d.n[2]);
      all.push(d.p, [d.n[0] / l, d.n[1] / l, d.n[2] / l], [1, 0, 0], d.mat, atlas.get(d.glyph), part.bone || 0, (d.flags || 0) | 4, d.size, i * 7 + 3);
    }
    onProgress && onProgress((i + 1) / list.length, part.name);
    if (performance.now() - t0 > 30) { await new Promise(r => requestAnimationFrame(r)); t0 = performance.now(); }
  }
  return all;
}

/**
 * Densidade por zoom: reordena os pontos em níveis encaixados (cada nível é uma amostragem
 * uniforme e sem aglomerados). Desenhar só os primeiros N pontos = versão mais esparsa do mesmo
 * modelo; o renderizador aumenta os caracteres na proporção. Emblemas e arestas entram primeiro.
 * Retorna { ps, levels: [fim do nível 0, fim do nível 1, total] }.
 */
export function lodOrder(ps, seed = 5) {
  const n = ps.n, R = (s => () => { s = s * 16807 % 2147483647; return s / 2147483647; })(seed);
  const sizeOf = i => { const f = ps.attr[i * 4 + 3]; const x = ps.extra[i * 2]; return (f & 64) ? Math.floor(x) / 2000 : x; };
  const order = Array.from({ length: n }, (_, i) => i).map(i => [i, ((ps.attr[i * 4 + 3] & 4) ? -2 : (ps.attr[i * 4 + 3] & 1) ? -1 : 0) + R()]);
  order.sort((a, b) => a[1] - b[1]);
  const level = new Int8Array(n).fill(2);
  const C = 0.05;
  for (const [L, k] of [[0, 0.95], [1, 0.66]]) {
    const grid = new Map();
    const key = (b, x, y, z) => b * 1e9 + (x + 500) * 1e6 + (y + 500) * 1e3 + (z + 500);
    const put = (i) => { const k2 = key(ps.attr[i * 4 + 2], Math.floor(ps.pos[i * 3] / C), Math.floor(ps.pos[i * 3 + 1] / C), Math.floor(ps.pos[i * 3 + 2] / C)); if (!grid.has(k2)) grid.set(k2, []); grid.get(k2).push(i); };
    for (const [i] of order) if (level[i] < L) put(i);          // níveis mais grossos já ocupam o espaço
    for (const [i] of order) {
      if (level[i] < L) continue;
      const b = ps.attr[i * 4 + 2], px = ps.pos[i * 3], py = ps.pos[i * 3 + 1], pz = ps.pos[i * 3 + 2];
      const cx = Math.floor(px / C), cy = Math.floor(py / C), cz = Math.floor(pz / C);
      const r = sizeOf(i) * k;
      let ok = !!(ps.attr[i * 4 + 3] & 4);
      if (!ok) {
        ok = true;
        for (let a = -1; a <= 1 && ok; a++) for (let c = -1; c <= 1 && ok; c++) for (let d = -1; d <= 1 && ok; d++) {
          const list = grid.get(key(b, cx + a, cy + c, cz + d));
          if (list) for (const j of list) { const dx = ps.pos[j * 3] - px, dy = ps.pos[j * 3 + 1] - py, dz = ps.pos[j * 3 + 2] - pz; if (dx * dx + dy * dy + dz * dz < r * r) { ok = false; break; } }
        }
      }
      if (ok) { level[i] = L; put(i); }
    }
  }
  const out = new PointSet(n + 8), levels = [0, 0, n];
  for (const L of [0, 1, 2]) {
    for (const [i] of order) if (level[i] === L) {
      out.push(ps.pos.subarray(i * 3, i * 3 + 3), ps.nrm.subarray(i * 3, i * 3 + 3), ps.tan.subarray(i * 3, i * 3 + 3), ps.attr[i * 4], ps.attr[i * 4 + 1], ps.attr[i * 4 + 2], ps.attr[i * 4 + 3], ps.extra[i * 2], ps.extra[i * 2 + 1]);
    }
    if (L < 2) levels[L] = out.n;
  }
  return { ps: out, levels };
}
