// ASHEN 3D — Chefe: o Primeiro Rei, desenterrado.
// O rei que quebrou o juramento não pôde morrer de verdade: a Chama que ele roubou o mantém de pé.
// Morto-vivo alto e esquálido, costelas à mostra, garras longas, coroa partida com 王, manto real
// em farrapos e chamas espectrais violeta. Mesmo esqueleto de 17 ossos do cavaleiro (outra anatomia).

import { m4, v3, noise3 } from './math3d.js';
import { MAT } from './glyphs.js';
import * as S from './sdf.js';

const B = { WORLD: 0, PELVIS: 1, CHEST: 2, HEAD: 3, UA_L: 4, FA_L: 5, HAND_L: 6, UA_R: 7, FA_R: 8, HAND_R: 9, TH_L: 10, SH_L: 11, FT_L: 12, TH_R: 13, SH_R: 14, FT_R: 15, CROWN: 16 };
const L = { thigh: 0.5, shin: 0.48, upper: 0.42, fore: 0.4 };
export const BSCALE = 1.12;                  // ~2,4 m curvado
export const BOSS_NAME = 'O Primeiro Rei, Desenterrado';
export const BOSS_HP = 640;
const slab = (y0, y1) => (x, y, z) => Math.max(y0 - y, y - y1);

/** Peças do corpo (no espaço de cada osso). */
export function bossParts() {
  const P = [];
  const add = o => P.push(o);
  const bony = (c) => c > 0.3 ? { mat: MAT.BONE } : null;
  const rot = (p) => noise3(p[0] * 30, p[1] * 30, p[2] * 30) > 0.68 ? { mat: MAT.DARK } : null;   // carne apodrecida
  // ── tronco esquálido: caixa torácica com costelas, ventre afundado, coluna saliente ──
  const torso = S.smooth(0.05, S.xf(S.ellipsoid(0.17, 0.22, 0.12), [0, 0.24, 0]), S.xf(S.ellipsoid(0.12, 0.12, 0.085), [0, 0.02, -0.01]));
  const ribs = S.intersect(S.union(...[0, 1, 2, 3, 4].map(i => S.xf(S.torus(0.155 - i * 0.008, 0.011), [0, 0.32 - i * 0.055, 0.01], [0.15, 0, 0]))), (x, y, z) => -z + 0.01);
  const spine = S.union(...[0, 1, 2, 3, 4, 5].map(i => S.xf(S.sphere(0.022), [0, 0.38 - i * 0.07, -0.11])));
  const collar = S.union(S.capsule([-0.2, 0.42, 0.0], [0.2, 0.42, 0.0], 0.03), S.xf(S.sphere(0.06), [0.21, 0.4, -0.01]), S.xf(S.sphere(0.06), [-0.21, 0.4, -0.01]));
  const neck = S.capsule([0, 0.42, 0.0], [0, 0.55, 0.04], 0.04);
  add({ name: 'tronco', bone: B.CHEST, f: S.union(S.smooth(0.03, torso, spine, collar, neck), ribs), min: [-0.3, -0.12, -0.18], max: [0.3, 0.6, 0.18], mat: MAT.FLESH, spacing: 0.02, flow: [1, 0, 0],
    detail: (p, n, c) => {
      if (Math.abs(Math.hypot(p[0], (p[2] - 0.01) / 1) - 0.15) < 0.02 && p[2] > 0 && p[1] > 0.08 && p[1] < 0.36) return { mat: MAT.BONE };
      return bony(c) || rot(p);
    } });
  // ── pélvis ossuda e tanga de farrapos ──
  add({ name: 'quadril', bone: B.PELVIS, f: S.smooth(0.03, S.xf(S.ellipsoid(0.15, 0.09, 0.1), [0, 0.0, 0]), S.xf(S.sphere(0.045), [0.13, -0.02, 0.02]), S.xf(S.sphere(0.045), [-0.13, -0.02, 0.02])), min: [-0.2, -0.12, -0.14], max: [0.2, 0.12, 0.14], mat: MAT.FLESH, spacing: 0.02, flow: [1, 0, 0], detail: (p, n, c) => bony(c) || rot(p) });
  const rags = S.intersect(S.shell(S.roundCone([0, 0.05, 0], [0, -0.45, 0], 0.16, 0.2), 0.006), (x, y, z) => Math.max(y - 0.06, -0.48 - y - 0.12 * Math.abs(Math.sin(x * 23 + z * 17))));
  add({ name: 'farrapos', bone: B.PELVIS, f: rags, min: [-0.24, -0.62, -0.24], max: [0.24, 0.08, 0.24], mat: MAT.ROYAL, spacing: 0.024, flow: [0, 1, 0], keep: (p) => Math.abs(Math.sin(Math.atan2(p[2], p[0]) * 5)) > 0.25 });
  // ── crânio: órbitas fundas com brilho espectral, mandíbula caída, cabelos ralos, coroa partida ──
  const skull = S.subtract(S.smooth(0.03, S.xf(S.ellipsoid(0.1, 0.115, 0.115), [0, 0.13, 0]), S.xf(S.ellipsoid(0.075, 0.05, 0.08), [0, 0.06, 0.03])),
    S.union(S.xf(S.sphere(0.03), [0.04, 0.12, 0.1]), S.xf(S.sphere(0.03), [-0.04, 0.12, 0.1])));
  const jaw = S.xf(S.ellipsoid(0.065, 0.035, 0.075), [0, 0.0, 0.04], [0.45, 0, 0]);
  add({ name: 'crânio', bone: B.HEAD, f: S.union(skull, jaw), min: [-0.13, -0.08, -0.14], max: [0.13, 0.26, 0.15], mat: MAT.FLESH, spacing: 0.012, flow: [0, 1, 0],
    detail: (p, n, c) => {
      if (p[2] > 0.07 && p[1] > 0.02 && p[1] < 0.05 && Math.abs(p[0]) < 0.05) return { mat: MAT.BONE, glyph: 'ʌ' };    // dentes
      if (p[1] > 0.17 && noise3(p[0] * 50, p[1] * 50, p[2] * 50) > 0.6) return { mat: MAT.DARK, glyph: '⁞' };        // cabelo ralo
      return bony(c);
    },
    decals: [-1, 1].map(s => ({ p: [s * 0.04, 0.12, 0.105], n: [0, 0, 1], glyph: '•', mat: MAT.SPIRIT, size: 0.035, flags: 2 })) });
  const band = S.intersect(S.shell(S.xf(S.ellipsoid(0.112, 0.4, 0.122), [0, 0.2, 0]), 0.006), slab(0.17, 0.2));
  const spikes = S.union(...[-1.2, -0.6, 0, 0.6, 1.2, 2.4].map((a, i) => { const h = i === 1 || i === 4 ? 0.025 : 0.065; return S.roundCone([Math.sin(a) * 0.11, 0.19, Math.cos(a) * 0.12], [Math.sin(a) * 0.115, 0.2 + h, Math.cos(a) * 0.125], 0.012, 0.003); }));
  add({ name: 'coroa', bone: B.HEAD, f: S.union(band, spikes), min: [-0.14, 0.15, -0.15], max: [0.14, 0.3, 0.15], mat: MAT.GOLD, spacing: 0.009, flow: [1, 0, 0],
    decals: [{ p: [0, 0.185, 0.124], n: [0, 0, 1], glyph: '王', mat: MAT.GOLD, size: 0.045, clear: 0.02 }] });
  // ── braços longos e garras ──
  for (const [ua, fa, hd, side] of [[B.UA_L, B.FA_L, B.HAND_L, 1], [B.UA_R, B.FA_R, B.HAND_R, -1]]) {
    add({ name: 'braço', bone: ua, f: S.smooth(0.02, S.roundCone([0, 0, 0], [0, -0.4, 0], 0.045, 0.032), S.xf(S.sphere(0.04), [0, -0.4, 0])), min: [-0.07, -0.45, -0.07], max: [0.07, 0.05, 0.07], mat: MAT.FLESH, spacing: 0.016, flow: [0, 1, 0], detail: (p, n, c) => bony(c) || rot(p) });
    add({ name: 'antebraço', bone: fa, f: S.roundCone([0, 0, 0], [0, -0.38, 0], 0.034, 0.024), min: [-0.06, -0.41, -0.06], max: [0.06, 0.04, 0.06], mat: MAT.FLESH, spacing: 0.015, flow: [0, 1, 0], detail: (p, n, c) => bony(c) || rot(p) });
    const palm = S.xf(S.ellipsoid(0.04, 0.05, 0.022), [0, -0.05, 0]);
    const claws = S.union(...[-0.03, -0.01, 0.01, 0.03].map((x, i) => S.roundCone([x, -0.08, 0.005], [x * 1.3, -0.2 - (i === 1 || i === 2 ? 0.03 : 0), 0.04], 0.009, 0.002)), S.roundCone([-side * 0.04, -0.04, 0.01], [-side * 0.07, -0.12, 0.05], 0.009, 0.002));
    add({ name: 'garra', bone: hd, f: S.smooth(0.01, palm, claws), min: [-0.09, -0.25, -0.04], max: [0.09, 0.02, 0.08], mat: MAT.FLESH, spacing: 0.008, flow: [0, 1, 0],
      detail: (p) => (p[1] < -0.14 ? { mat: MAT.BONE } : null) });
  }
  // ── pernas magras, joelhos nodosos, pés longos ──
  for (const [th, sh, ft] of [[B.TH_L, B.SH_L, B.FT_L], [B.TH_R, B.SH_R, B.FT_R]]) {
    add({ name: 'coxa', bone: th, f: S.roundCone([0, 0, 0], [0, -0.5, 0], 0.06, 0.04), min: [-0.08, -0.53, -0.08], max: [0.08, 0.06, 0.08], mat: MAT.FLESH, spacing: 0.018, flow: [0, 1, 0], detail: (p, n, c) => bony(c) || rot(p) });
    add({ name: 'canela', bone: sh, f: S.smooth(0.02, S.xf(S.sphere(0.05), [0, 0, 0.01]), S.roundCone([0, -0.02, 0], [0, -0.47, 0], 0.036, 0.026)), min: [-0.07, -0.5, -0.07], max: [0.07, 0.06, 0.08], mat: MAT.FLESH, spacing: 0.016, flow: [0, 1, 0], detail: (p, n, c) => bony(c) || rot(p) });
    add({ name: 'pé', bone: ft, f: S.union(S.xf(S.ellipsoid(0.045, 0.03, 0.12), [0, -0.035, 0.06]), ...[-0.03, 0, 0.03].map(x => S.roundCone([x, -0.04, 0.15], [x, -0.06, 0.22], 0.012, 0.004))), min: [-0.07, -0.08, -0.08], max: [0.07, 0.02, 0.25], mat: MAT.FLESH, spacing: 0.013, flow: [1, 0, 0], detail: (p) => (p[2] > 0.18 ? { mat: MAT.BONE } : null) });
  }
  return P;
}

// ─────────────── Pose ───────────────
const frame = (origin, yAxis, fwd) => {
  const y = v3.norm(yAxis);
  let x = v3.norm(v3.cross(y, fwd));
  if (!isFinite(x[0])) x = [1, 0, 0];
  const z = v3.cross(x, y);
  const m = m4.ident();
  m[0] = x[0]; m[1] = x[1]; m[2] = x[2]; m[4] = y[0]; m[5] = y[1]; m[6] = y[2]; m[8] = z[0]; m[9] = z[1]; m[10] = z[2];
  m[12] = origin[0]; m[13] = origin[1]; m[14] = origin[2];
  return m;
};
function ik(a, target, l1, l2, pole) {
  let d = v3.sub(target, a), dist = v3.len(d);
  const max = (l1 + l2) * 0.999;
  if (dist > max) { d = v3.mul(d, max / dist); dist = max; }
  const dir = v3.mul(d, 1 / dist);
  const x = (l1 * l1 - l2 * l2 + dist * dist) / (2 * dist), h = Math.sqrt(Math.max(0, l1 * l1 - x * x));
  const pv = v3.norm(v3.sub(pole, v3.mul(dir, v3.dot(pole, dir))));
  return { knee: v3.add(v3.add(a, v3.mul(dir, x)), v3.mul(pv, h)), end: v3.add(a, d) };
}
const sm = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };
function keys(list, t) {
  for (let i = 0; i < list.length - 1; i++) {
    const [t0, a] = list[i], [t1, b] = list[i + 1];
    if (t <= t1) { const k = sm((t - t0) / (t1 - t0)); return Array.isArray(a) ? a.map((v, j) => v + (b[j] - v) * k) : a + (b - a) * k; }
  }
  return list[list.length - 1][1];
}
const REST_R = [-0.32, -0.42, 0.18], REST_L = [0.32, -0.42, 0.14];
/** Ações: mãos (no espaço do peito), giro, inclinação, agachamento; janelas de golpe (hit). */
export const ACTIONS = {
  swipe: { dur: 1.15, dmg: 22, reach: 2.0, hits: [[0.47, 0.6, 'R']],
    R: [[0, REST_R], [0.38, [-0.6, 0.38, -0.28]], [0.55, [0.32, 0.08, 0.62]], [0.72, [0.45, -0.25, 0.3]], [1, REST_R]], L: [[0, REST_L], [1, REST_L]],
    twist: [[0, 0], [0.38, 0.65], [0.56, -0.55], [1, 0]], lean: [[0, 0], [0.38, -0.1], [0.56, 0.25], [1, 0]], crouch: [[0, 0], [0.55, 0.08], [1, 0]], step: [[0, 0], [0.5, 0.0], [0.6, 0.35], [1, 0.35]] },
  swipe2: { dur: 1.7, dmg: 18, reach: 1.9, hits: [[0.27, 0.38, 'L'], [0.62, 0.74, 'R']],
    L: [[0, REST_L], [0.18, [0.6, 0.38, -0.25]], [0.33, [-0.32, 0.08, 0.6]], [0.48, [-0.4, -0.2, 0.3]], [0.8, REST_L], [1, REST_L]],
    R: [[0, REST_R], [0.45, REST_R], [0.56, [-0.6, 0.38, -0.25]], [0.69, [0.32, 0.08, 0.6]], [0.82, [0.42, -0.25, 0.3]], [1, REST_R]],
    twist: [[0, 0], [0.18, -0.6], [0.34, 0.5], [0.56, 0.6], [0.7, -0.55], [1, 0]], lean: [[0, 0], [0.3, 0.2], [0.5, 0], [0.7, 0.25], [1, 0]], crouch: [[0, 0], [1, 0]], step: [[0, 0], [0.3, 0.25], [0.7, 0.55], [1, 0.55]] },
  slam: { dur: 1.75, dmg: 36, reach: 2.4, aoe: true, hits: [[0.62, 0.68, 'AOE']],
    R: [[0, REST_R], [0.45, [-0.25, 0.8, -0.05]], [0.62, [-0.22, -0.72, 0.62]], [0.85, [-0.25, -0.65, 0.55]], [1, REST_R]],
    L: [[0, REST_L], [0.45, [0.25, 0.8, -0.05]], [0.62, [0.22, -0.72, 0.62]], [0.85, [0.25, -0.65, 0.55]], [1, REST_L]],
    twist: [[0, 0], [1, 0]], lean: [[0, 0], [0.45, -0.45], [0.62, 0.75], [0.85, 0.7], [1, 0]], crouch: [[0, 0], [0.45, -0.05], [0.62, 0.32], [0.85, 0.28], [1, 0]], step: [[0, 0], [0.55, 0.0], [0.63, 0.45], [1, 0.45]] },
  roar: { dur: 2.0, hits: [],
    R: [[0, REST_R], [0.3, [-0.6, 0.3, 0.2]], [0.8, [-0.62, 0.32, 0.2]], [1, REST_R]], L: [[0, REST_L], [0.3, [0.6, 0.3, 0.2]], [0.8, [0.62, 0.32, 0.2]], [1, REST_L]],
    twist: [[0, 0], [1, 0]], lean: [[0, 0], [0.3, -0.55], [0.8, -0.5], [1, 0]], crouch: [[0, 0], [1, 0]], step: [[0, 0], [1, 0]] },
  stagger: { dur: 1.9, hits: [],
    R: [[0, REST_R], [0.2, [-0.3, -0.6, 0.35]], [0.85, [-0.3, -0.62, 0.35]], [1, REST_R]], L: [[0, REST_L], [0.2, [0.3, -0.6, 0.35]], [0.85, [0.3, -0.62, 0.35]], [1, REST_L]],
    twist: [[0, 0], [1, 0]], lean: [[0, 0], [0.2, 0.6], [0.85, 0.6], [1, 0]], crouch: [[0, 0], [0.2, 0.4], [0.85, 0.4], [1, 0]], step: [[0, 0], [1, 0]] },
};

/**
 * st = { phase, blend (andando), t (tempo), act (nome da ação ou null), at (0..1), rise (0..1: saindo da cova), dead (0..1), hurt (0..1) }
 * Retorna 17 matrizes no espaço do modelo.
 */
export function poseBoss(st) {
  const b = st.blend || 0, T = st.t || 0, ph = (st.phase || 0) * Math.PI * 2;
  const A = st.act ? ACTIONS[st.act] : null, at = st.at || 0;
  const aw = A ? sm(Math.min(at / 0.1, (1 - at) / 0.12)) : 0;
  const rise = st.rise == null ? 1 : st.rise, dead = st.dead || 0, hurt = st.hurt || 0;
  const breathe = Math.sin(T * 1.7) * 0.5 + Math.sin(T * 0.6) * 0.5;
  const bones = new Array(17);
  bones[0] = m4.ident();
  // sobe da cova: o corpo emerge do chão, primeiro as mãos agarrando a borda
  const emerge = -1.6 * (1 - sm(rise / 0.75));
  const limp = Math.max(0, Math.sin(ph)) * 0.05 * b;                    // manca da perna direita
  const crouch = (A ? keys(A.crouch, at) : 0) * aw + 0.4 * sm((dead - 0.1) / 0.4) + 0.06 * hurt;
  const twist = (A ? keys(A.twist, at) : 0) * aw;
  const lean = 0.42 + 0.06 * breathe + 0.1 * b + (A ? keys(A.lean, at) : 0) * aw + 0.9 * sm((dead - 0.45) / 0.5) - 0.25 * hurt;
  const pelvis = m4.mul(m4.mul(m4.translate(0.05 * Math.sin(ph) * b, 0.93 - 0.04 * Math.abs(Math.cos(ph)) * b - limp - crouch + emerge, 0), m4.rotY(0.15 * Math.sin(ph) * b + twist * 0.3)), m4.rotZ(0.08 * Math.sin(ph) * b));
  bones[1] = pelvis;
  const chest = m4.mul(m4.mul(m4.mul(pelvis, m4.translate(0, 0.14, 0)), m4.rotY(twist * 0.7 - 0.15 * Math.sin(ph) * b)), m4.mul(m4.rotX(lean), m4.rotZ(0.06 * Math.sin(T * 0.9))));
  bones[2] = chest;
  const headLift = A && st.act === 'roar' ? keys([[0, 0], [0.3, -0.9], [0.8, -0.85], [1, 0]], at) : 0;
  bones[3] = m4.mul(chest, m4.mul(m4.mul(m4.translate(0, 0.52, 0.06), m4.rotX(-lean * 0.8 + headLift - 0.1 + 0.6 * sm((dead - 0.2) / 0.4))), m4.rotZ(0.12 * Math.sin(T * 0.7) + 0.3 * hurt)));
  // pernas
  const half = 0.28 * b;
  for (const [side, th, ph0] of [[1, 10, 0], [-1, 13, 0.5]]) {
    const p = ((st.phase || 0) + ph0) % 1, swing = p < 0.5, q = swing ? p / 0.5 : (p - 0.5) / 0.5;
    const drag = side < 0 ? 0.55 : 1;
    let z = (swing ? -Math.cos(q * Math.PI) : Math.cos(q * Math.PI)) * half * drag;
    const ly = swing ? Math.sin(q * Math.PI) * 0.09 * b * drag : 0;
    const stepF = (A ? keys(A.step, at) : 0) * aw;
    z += side < 0 ? stepF * 0.6 : -stepF * 0.15;
    const hip = m4.point(pelvis, [side * 0.12, -0.04, 0]);
    const kneelD = sm((dead - 0.1) / 0.4);
    const ankle = [side * 0.17, 0.08 + ly + Math.min(0, emerge + 0.9) * 0, z + 0.02 - kneelD * 0.35 + emerge * 0];
    const { knee, end } = ik(hip, [ankle[0], Math.min(ankle[1], hip[1] - 0.2), ankle[2]], L.thigh, L.shin, [side * 0.25, 0, 1]);
    bones[th] = frame(hip, v3.sub(hip, knee), [0, 0, 1]);
    bones[th + 1] = frame(knee, v3.sub(knee, end), [0, 0, 1]);
    bones[th + 2] = m4.mul(m4.translate(end[0], end[1], end[2]), m4.rotX(swing ? -0.3 * Math.sin(q * Math.PI) * b : 0));
  }
  // braços: pendem, balançam soltos ao andar; as ações levam as garras
  const shL = m4.point(chest, [0.21, 0.4, -0.01]), shR = m4.point(chest, [-0.21, 0.4, -0.01]);
  const dangle = (side) => [side * 0.32, -0.42, 0.16 + 0.14 * Math.sin(ph + (side > 0 ? Math.PI : 0)) * b + 0.03 * breathe];
  let rT = dangle(-1), lT = dangle(1);
  if (A) { rT = v3.lerp(rT, keys(A.R, at), aw); lT = v3.lerp(lT, keys(A.L, at), aw); }
  if (rise < 1) { const k = 1 - sm((rise - 0.35) / 0.5); rT = v3.lerp(rT, [-0.35, 0.55, 0.45], k); lT = v3.lerp(lT, [0.35, 0.6, 0.4], k); }
  for (const [sh, tgt, ua, side] of [[shL, lT, 4, 1], [shR, rT, 7, -1]]) {
    const hand = m4.point(chest, tgt);
    const { knee: el, end } = ik(sh, hand, L.upper, L.fore + 0.05, [side * 0.5, -0.3, -1]);
    bones[ua] = frame(sh, v3.sub(sh, el), [0, 0, 1]);
    bones[ua + 1] = frame(el, v3.sub(el, end), [0, 0, 1]);
    bones[ua + 2] = frame(end, v3.sub(el, end), [0, 0, 1]);
  }
  bones[16] = bones[3];
  // morte: tomba para a frente sobre os joelhos
  if (dead > 0.45) { const k = sm((dead - 0.45) / 0.5); const R = m4.mul(m4.mul(m4.translate(0, 0.05, 0.4), m4.rotX(1.2 * k)), m4.translate(0, -0.05, -0.4)); for (let i = 1; i < 17; i++) bones[i] = m4.mul(R, bones[i]); }
  return bones;
}

// ─────────────── Comportamento ───────────────
export class Boss {
  constructor(home) {
    this.home = home;                 // { x, z } — o túmulo real
    this.reset();
  }
  reset() {
    Object.assign(this, { x: this.home.x, z: this.home.z + 0.9, yaw: 0, hp: BOSS_HP, phase: 0, blend: 0, t: 0, act: null, at: 0, cool: 1.5,
      rise: 0, dead: 0, hurt: 0, state: 'buried', phase2: false, hitDone: new Set(), stagger: 0, speed: 0 });
  }
  get alive() { return this.state !== 'buried' && this.state !== 'dead'; }
  start(act) { this.act = act; this.at = 0; this.hitDone.clear(); }
  /** Retorna eventos: [{ type: 'hit', dmg, from:[x,z] } | { type: 'slam', x, z } | { type: 'roar' }]. */
  update(dt, player, canHit) {
    const ev = [];
    this.t += dt;
    this.hurt = Math.max(0, this.hurt - dt * 4);
    if (this.state === 'rising') { this.rise = Math.min(1, this.rise + dt / 3.2); if (this.rise >= 1) { this.state = 'fight'; this.start('roar'); ev.push({ type: 'roar' }); } return ev; }
    if (this.state === 'dying') { this.dead = Math.min(1, this.dead + dt / 3.4); if (this.dead >= 1) this.state = 'dead'; return ev; }
    if (this.state !== 'fight') return ev;
    const dx = player.x - this.x, dz = player.z - this.z, d = Math.hypot(dx, dz);
    const want = Math.atan2(dx, dz);
    const fast = this.phase2 ? 1.25 : 1;
    if (this.act) {
      const A = ACTIONS[this.act];
      const prev = this.at;
      this.at += dt * fast / A.dur;
      // gira devagar durante o golpe (dá para esquivar para o lado)
      const turnK = this.at < 0.35 ? 2.2 : 0.4;
      this.yaw += Math.max(-turnK * dt, Math.min(turnK * dt, Math.atan2(Math.sin(want - this.yaw), Math.cos(want - this.yaw))));
      // avanço do corpo no golpe
      const s0 = keys(A.step, prev), s1 = keys(A.step, Math.min(1, this.at));
      this.x += Math.sin(this.yaw) * (s1 - s0) * BSCALE; this.z += Math.cos(this.yaw) * (s1 - s0) * BSCALE;
      for (const [h0, h1, hand] of A.hits) {
        const key = h0 + hand;
        if (prev < h0 - 0.06 && this.at >= h0 - 0.06 && !A.aoe) ev.push({ type: 'swing' });
        if (this.at >= h0 && prev <= h1 && !this.hitDone.has(key) && canHit) {
          if (A.aoe) {
            const cx = this.x + Math.sin(this.yaw) * 1.3, cz = this.z + Math.cos(this.yaw) * 1.3;
            ev.push({ type: 'slam', x: cx, z: cz });
            if (Math.hypot(player.x - cx, player.z - cz) < A.reach) ev.push({ type: 'hit', dmg: A.dmg * fast, from: [this.x, this.z] });
            this.hitDone.add(key);
          } else {
            const ang = Math.abs(Math.atan2(Math.sin(want - this.yaw), Math.cos(want - this.yaw)));
            if (d < A.reach * BSCALE * 0.85 && ang < 1.2) { ev.push({ type: 'hit', dmg: A.dmg * fast, from: [this.x, this.z] }); this.hitDone.add(key); }
          }
        }
      }
      if (this.at >= 1) { this.act = null; this.cool = (this.phase2 ? 0.45 : 0.9) + Math.random() * 0.7; }
      this.blend += (0 - this.blend) * Math.min(1, dt * 6);
      return ev;
    }
    // persegue arrastando os pés; escolhe um golpe quando perto
    this.cool -= dt;
    const turn = 2.4 * fast;
    this.yaw += Math.max(-turn * dt, Math.min(turn * dt, Math.atan2(Math.sin(want - this.yaw), Math.cos(want - this.yaw))));
    if (d > 2.1 * BSCALE) {
      const sp = 0.95 * fast;
      this.x += Math.sin(this.yaw) * sp * dt; this.z += Math.cos(this.yaw) * sp * dt;
      this.phase = (this.phase + sp * dt / 1.6) % 1;
      this.blend += (1 - this.blend) * Math.min(1, dt * 4);
    } else this.blend += (0 - this.blend) * Math.min(1, dt * 5);
    if (this.cool <= 0 && d < 2.6 * BSCALE) {
      const r = Math.random();
      this.start(d > 1.9 * BSCALE ? 'slam' : r < 0.45 ? 'swipe' : r < 0.78 ? 'swipe2' : 'slam');
    }
    if (!this.phase2 && this.hp < BOSS_HP * 0.5) { this.phase2 = true; this.start('roar'); ev.push({ type: 'roar', phase2: true }); }
    return ev;
  }
  /** Recebe dano; retorna true se morreu. */
  damage(n) {
    if (!this.alive || this.state === 'dying') return false;
    this.hp = Math.max(0, this.hp - n);
    this.hurt = 1;
    if (this.hp <= 0) { this.state = 'dying'; this.act = null; return true; }
    return false;
  }
  doStagger() { if (this.state === 'fight') this.start('stagger'); }
}
