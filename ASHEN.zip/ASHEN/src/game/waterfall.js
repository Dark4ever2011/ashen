// ASHEN — Cachoeiras do Reino Partido (v0.25): cada uma tem o seu penhasco esculpido no relevo (ow.js · FALLS).
// Cortina larga de caracteres (azul do céu no alto → branco embaixo), espuma e respingos no poço, nuvem de névoa
// branca na base, brilhos piscando; pedras escuras arredondadas e moitas de musgo em volta; reflexo na água e rumor.

import { heightAt, OW_WL, FALLS } from './ow.js';
import { SolidGeom, rock } from './solid.js';
import { PointSet } from './sampler.js';
import { MAT } from './glyphs.js';

const noise2 = (x, z) => 0.5 + 0.25 * Math.sin(x * 1.7 + z * 0.9) + 0.25 * Math.sin(x * 0.6 - z * 2.3);

export function initWaterfalls(g) {
  if (!g.R.addWaterfall) return;
  g.falls = FALLS.map(F => {
    const tx = F.x - F.dx * 0.8, tz = F.z - F.dz * 0.8, bx = F.x + F.dx * 3.2, bz = F.z + F.dz * 3.2;
    const obj = g.R.addWaterfall({ top: [tx, heightAt(tx, tz) + 0.2, tz], bottom: [bx, OW_WL + 0.02, bz], width: F.W * 1.15 });
    return { ...F, bx, bz, obj };
  }).filter(f => f.obj);
  // pedras e musgo em volta (montados junto com o resto do mundo aberto)
  (g.owExtras = g.owExtras || []).push(async () => {
    const solid = new SolidGeom(4096), cols = [];
    let sd = 77; const R = () => ((sd = (sd * 16807) % 2147483647) / 2147483647);
    const put = (x, z, rad, mat, moss, top = 0.78) => {
      const y = heightAt(x, z);
      rock(solid, x, Math.max(y, OW_WL - 0.4) - rad * 0.25, z, rad, x * 0.37 + z, noise2, mat, moss, top);
      if (rad > 0.7 && y > OW_WL - 0.5) cols.push({ type: 'circle', x, z, r: rad * 1.05 });
    };
    for (const F of FALLS) {
      const side = (a, b) => [F.x + F.dx * a - F.dz * b, F.z + F.dz * a + F.dx * b];
      // o paredão do penhasco: pedras escuras empilhadas na face (atrás da cortina também), do poço até a beira
      const top = heightAt(F.x - F.dx * 3, F.z - F.dz * 3);
      for (let y = OW_WL + 1; y < top - 0.5; y += 2.1) for (let b = -F.W * 1.25; b <= F.W * 1.25; b += 2.3) {
        const [x, z] = side(-0.6 - R() * 0.8 - (y - OW_WL) * 0.04, b + (R() - 0.5) * 1.2), rad = 1.3 + R() * 1.1;
        rock(solid, x, y + (R() - 0.5) * 0.8, z, rad, x * 0.37 + y, noise2, MAT.STONE, R() < 0.35 ? MAT.MOSS : MAT.STONE, 0.9);
      }
      // pé do paredão e beira do poço
      for (let i = 0; i < 9; i++) { const s = R() < 0.5 ? -1 : 1, [x, z] = side(0.6 + R() * 2.5, s * (F.W * (0.45 + R() * 0.9))); put(x, z, 1.1 + R() * 1.5, MAT.STONE, MAT.MOSS); }
      // no alto, dos dois lados da cortina
      for (let i = 0; i < 6; i++) { const s = i % 2 ? -1 : 1, [x, z] = side(-1.2 - R() * 3, s * (F.W * (0.5 + R() * 0.6))); put(x, z, 1.0 + R() * 1.3, MAT.STONE, MAT.MOSS); }
      // em volta do poço
      for (let i = 0; i < 10; i++) { const a = R() * Math.PI * 2, r = 9.5 + R() * 3; put(F.px + Math.cos(a) * r, F.pz + Math.sin(a) * r, 0.6 + R() * 1.2, MAT.STONE, MAT.MOSS); }
      // moitas de musgo verde
      for (let i = 0; i < 10; i++) { const a = R() * Math.PI * 2, r = 8 + R() * 6, x = F.px + Math.cos(a) * r, z = F.pz + Math.sin(a) * r; put(x, z, 0.6 + R() * 0.8, MAT.LEAF_G, MAT.MOSS, 0.65); }
      for (let i = 0; i < 6; i++) { const s = R() < 0.5 ? -1 : 1, [x, z] = side(-0.5 - R() * 2, s * (F.W * (0.3 + R() * 0.8))); put(x, z, 0.5 + R() * 0.7, MAT.LEAF_G, MAT.MOSS, 0.65); }
    }
    const ps = new PointSet(16); ps.solid = solid;
    const m = g.R.addMesh(ps, { chunk: 8 }); m.area = 'ow';
    return cols;
  });
}
export function waterfallStep(g, dt) {
  if (!g.falls) return;
  const p = g.player, inOW = g.area === 'ow';
  let near = 1e9;
  for (const f of g.falls) {
    const d = Math.hypot(p.x - f.x, p.z - f.z);
    f.obj.visible = inOW && d < 150;
    if (inOW) near = Math.min(near, d);
  }
  // rumor contínuo: rajadas curtas de ruído grave, mais fortes quanto mais perto
  g._fallT = (g._fallT || 0) - dt;
  if (near < 80 && g._fallT <= 0) { g._fallT = 0.22; g.audio && g.audio.play('falls', Math.min(1, Math.pow(1 - near / 80, 1.5) * 1.3)); }
}
