// ASHEN — HUD: título da região, aviso de interação, mensagens (máquina de escrever),
// avisos rápidos e painel de desempenho.

const $ = id => document.getElementById(id);

export class Hud {
  constructor() {
    this.el = { region: $('region'), kicker: $('region-kicker'), title: $('region-title'), sub: $('region-sub'),
      prompt: $('prompt'), promptKey: $('prompt-key'), promptText: $('prompt-text'),
      msg: $('message'), msgTitle: $('message-title'), msgText: $('message-text'), msgOk: $('message-ok'),
      toast: $('toast'), perf: $('perf') };
    this.msgOpen = false;
    this.full = ''; this.shown = 0; this.msgAt = null;
    this.toastT = 0;
    this.el.msgOk.addEventListener('click', e => { e.stopPropagation(); this.advance(); });
    this.el.msg.addEventListener('pointerdown', e => e.stopPropagation());
  }

  showRegion(map) {
    const e = this.el;
    e.kicker.textContent = map.region.toUpperCase();
    e.title.textContent = map.title;
    e.sub.textContent = map.subtitle || '';
    e.region.classList.remove('hidden');
    e.region.style.animation = 'none'; void e.region.offsetWidth; e.region.style.animation = '';
    clearTimeout(this._rt);
    this._rt = setTimeout(() => e.region.classList.add('hidden'), 5600);
  }

  setPrompt(text, key, touch) {
    const e = this.el;
    if (!text || this.msgOpen) { e.prompt.classList.add('hidden'); return; }
    e.prompt.classList.remove('hidden');
    e.prompt.classList.toggle('touch', !!touch);
    if (e.promptText.textContent !== text) e.promptText.textContent = text;
    e.promptKey.textContent = key;
  }

  message(text, title = '', at = null) {
    const e = this.el;
    this.full = text; this.shown = 0; this.msgOpen = true; this.msgAt = at;
    e.msgTitle.textContent = title;
    e.msgText.textContent = '';
    e.msg.classList.remove('hidden');
    e.prompt.classList.add('hidden');
  }

  /** Completa o texto ou fecha. */
  advance() {
    if (!this.msgOpen) return false;
    if (this.shown < this.full.length) { this.shown = this.full.length; this.el.msgText.textContent = this.full; return true; }
    this.close();
    return true;
  }

  close() { this.msgOpen = false; this.el.msg.classList.add('hidden'); }

  toast(text, ms = 3200) {
    const e = this.el.toast;
    e.textContent = text;
    e.classList.remove('hidden');
    clearTimeout(this._tt);
    this._tt = setTimeout(() => e.classList.add('hidden'), ms);
  }

  update(dt, player) {
    if (this.msgOpen) {
      if (this.shown < this.full.length) {
        this.shown = Math.min(this.full.length, this.shown + dt * 70);
        this.el.msgText.textContent = this.full.slice(0, Math.floor(this.shown));
      }
      // Fecha sozinho se o cavaleiro se afastar.
      if (this.msgAt && Math.hypot(player.x - this.msgAt.x, player.z - this.msgAt.z) > 2.8) this.close();
    }
  }

  showPerf(on) { this.el.perf.classList.toggle('hidden', !on); }
  perfText(t) { this.el.perf.textContent = t; }
}
