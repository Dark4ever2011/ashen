// Zoom: perto (pinça máxima), médio e padrão — frente e 3/4.
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const page = await (await browser.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 2.625, isMobile: true, hasTouch: true })).newPage();
page.on('pageerror', e => console.log('[pageerror]', e.message));
await page.goto('http://localhost:8123/prototipo3d.html');
await page.waitForFunction(() => window.__ASHEN3D && window.__ASHEN3D.ready, null, { timeout: 120000 });
await page.evaluate(() => { const g = window.__ASHEN3D; const p = g.player; p.x = 1.6; p.z = 1.5; g.cam.x = 1.6; g.cam.z = 1.5; });
for (const [name, dist, yaw] of [['perto-frente', 3.1, 0.27], ['perto-34', 3.1, 0.95], ['medio', 4.5, 0.6], ['padrao', 6.5, 0.6]]) {
  await page.evaluate(([d, y]) => { const g = window.__ASHEN3D; g.CAM.dist = d; g.player.yaw = y; }, [dist, yaw]);
  await page.waitForTimeout(1800);
  await page.screenshot({ path: `/tmp/z-${name}.png` });
  console.log(name, await page.evaluate(() => { const m = window.__ASHEN3D.knightMesh; return m.drawCount + '/' + m.n + ' ×' + m.sizeMul.toFixed(2); }));
}
await browser.close();
