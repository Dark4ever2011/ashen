// ASHEN — Controles na tela (toque) e proteção contra gestos do navegador.
// Botões: joystick, correr (segurar), atacar (combo de 3 golpes), interagir, menu.

const $ = id => document.getElementById(id);

export function setupControls(game) {
  const input = game.input;
  const touchEl = $('touch');
  input.attachStick($('stick-zone'), $('stick-base'), $('stick-knob'));
  input.attachButton($('btn-run'), 'run');
  input.attachButton($('btn-interact'), 'interact');
  input.attachButton($('btn-atk'), 'attack');
  $('btn-menu').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); game.menu.toggle(); });
  $('btn-menu-desk').addEventListener('click', () => game.menu.toggle());

  const showTouch = on => {
    touchEl.classList.toggle('hidden', !on);
    document.body.classList.toggle('touch-ui', on);
    $('btn-menu-desk').classList.toggle('hidden', on);
  };
  const isTouch = matchMedia('(pointer: coarse)').matches || navigator.maxTouchPoints > 0;
  showTouch(isTouch);
  // Alterna automaticamente conforme o último dispositivo usado.
  window.addEventListener('pointerdown', e => { if (e.pointerType === 'touch') showTouch(true); else if (e.pointerType === 'mouse') showTouch(false); }, { capture: true });
  window.addEventListener('keydown', () => { if (!matchMedia('(pointer: coarse)').matches) showTouch(false); }, { capture: true });

  // Gestos do navegador: zoom por pinça, toque duplo, menu de contexto, rolagem e "puxar para atualizar".
  const stop = e => { if (e.cancelable) e.preventDefault(); };
  document.addEventListener('touchmove', e => { if (!e.target.closest || !e.target.closest('#menu .scroll')) stop(e); }, { passive: false });
  document.addEventListener('gesturestart', stop, { passive: false });
  document.addEventListener('dblclick', stop, { passive: false });
  document.addEventListener('contextmenu', stop);
  // Botão/gesto "voltar" do Android abre o menu em vez de sair (só fora de iframes).
  try {
    if (window.top === window.self && history.pushState) {
      history.pushState({ ashen: 1 }, '');
      window.addEventListener('popstate', () => { history.pushState({ ashen: 1 }, ''); if (!game.menu.open) game.menu.show(); });
    }
  } catch (e) { /* sandbox: ignora */ }
}

export function updateInteractButton(focus) {
  const b = $('btn-interact');
  b.classList.toggle('ready', !!focus);
  b.classList.toggle('idle', !focus);
}
