// ASHEN — A história (original, inspirada no tom de fantasia sombria de "Elden Ring":
// um mundo partido, um juramento quebrado, guerreiros caídos chamados de volta e reis que não morrem).

export const STORY = {
  opening: [
    'Antes das cinzas, havia a Chama — e um juramento que a mantinha acesa para todos.',
    'O Primeiro Rei jurou guardá-la. Quebrou a palavra… e tomou a Chama para si.',
    'A Chama se partiu em mil brasas. O reino ardeu — e a morte deixou de vir buscar os mortos.',
    'A Ordem do Juramento caiu defendendo estes portões. Seus cavaleiros, sem chama, foram chamados de Apagados.',
    'Mas uma brasa ainda reconhece o 誓 gravado no seu peito.',
    'Ergue-te, Apagado. O último juramento ainda não foi cumprido.',
  ],
  bossIntro: ['A terra do túmulo real se abre…', 'O rei que roubou a Chama não pode morrer.'],
  bossDefeated: 'O PRIMEIRO REI RETORNA ÀS CINZAS',
  bossDefeatedText: 'Da coroa partida rola uma brasa viva, quente como um coração. O portão estremece: uma das trancas cedeu.',
  death: 'O JURAMENTO SE APAGA',
  shield: 'Escudo do Juramento — o aço guarda o calor de quem o empunhou. Troque a mão esquerda entre tocha e escudo.',
  flask: 'Frasco de Brasa — um gole devolve a força. Os frascos se renovam ao descansar junto à chama.',
};
