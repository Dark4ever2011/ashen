// ASHEN 3D — Região II: chave e portão, a vila viva (conversas), o desmaio, as ruínas, os mortos,
// a cena do que aconteceu, a igreja com Ser Caedmon, as casas, a atadura, a aranha e o amuleto.

import { m4, v3 } from './math3d.js';
import { PointSet } from './sampler.js';
import { flatBones } from './renderer3d.js';
import { poseKnight, poseFallen, COMBO, swordSegment } from './knight3d.js';
import { Ghoul, GSCALE, lyingBones } from './npc3d.js';
import { gateScene, faintScene, ruinScene } from './cinema.js';
import { hurtPlayer, DMG_TABLE } from './gameplay.js';
import { TALKS, VILLAGERS, KNIGHT_TALK, VALLEY } from './story2.js';
import { Dialog, SPIDER } from '../ui/dialog.js';
import * as V from './region2.js';
import * as W from './world3d.js';
import { MAT } from './glyphs.js';

const $ = id => document.getElementById(id);
const I = m4.ident();
const sm = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };
const snd = (g, n, k) => g.audio && g.audio.play(n, k);
const GZ = W.WALL_Z + 0.6;
const KS = 0.955;
const OUT_GHOULS = [[-2.6, -3.2, 2.4], [3.0, -6.4, -2.0], [-3.2, -9.6, 1.0], [2.2, -14.6, 3.0]];
const SKELS = [[-1.8, -4.2, 0.5], [2.2, -10.4, 2], [-4.6, -7.4, 1.2], [4.8, -0.6, -0.5], [0.8, -19.8, 3], [-1.2, -21, 0.3]];
const PEOPLE_AT = { bram: [3.4, -1.2, -1.3, 'man', 1], oswin: [-2.2, 2.7, 2.6, 'man', 0.97], maren: [-3.5, -6.7, 1.57, 'woman', 1], ilsa: [-3.9, -10.9, 1.4, 'woman', 0.97], pip: [0, -6.6, 0, 'man', 0.62] };

export function initVillage(g, sets, atlas, saved) {
  const R = g.R, s = saved || {};
  g.vs = Object.assign({ phase: 'lush', talked: [], killed: [], searched: [], bandageHouse: -1, hasBandage: false, amulet: false, visited: false }, s.v2 || {});
  g.hasKey = !!s.hasKey; g.gateOpen = !!s.gateOpen; g.keyTaken = !!s.hasKey || !!s.gateOpen;
  g.luck = g.vs.amulet ? 0.05 : 0;
  g.dialog = new Dialog(g.audio);
  // portão (grade móvel)
  g.portK = g.gateOpen ? 1 : 0; g.portTarget = g.portK;
  g.portMesh = R.addMesh(sets.portcullis, { bones: [I, m4.translate(0, g.portK * 3.1, 0)] }); g.portMesh.area = 'r1';
  // chave no chão (aparece na Brasa do Rei depois da vitória)
  const kp = new PointSet(16);
  kp.push([0, 0, 0], [0, 0, 1], [1, 0, 0], MAT.GOLD, atlas.get('鍵'), 1, 2 | 4, 0.3, 1);
  for (let i = 0; i < 6; i++) { const a = i * 1.047; kp.push([Math.cos(a) * 0.24, Math.sin(a * 2) * 0.05, Math.sin(a) * 0.24], [0, 1, 0], [1, 0, 0], MAT.EMBER, atlas.get('·'), 1, 2 | 4, 0.06, i + 2); }
  g.keyMesh = R.addMesh(kp, { occlude: false, bones: [I, I] }); g.keyMesh.visible = false; g.keyMesh.area = 'r1';
  // vale
  const mk = (ps, area, o = {}) => { const m = R.addMesh(ps, o); m.area = area; return m; };
  g.v2 = {
    ground: mk(sets.ground2, 'r2', { occlude: false, chunk: 3 }),
    lushVeg: mk(sets.vegLush, 'r2', { occlude: false, chunk: 3 }),
    deadVeg: mk(sets.vegDead, 'r2', { occlude: false, chunk: 3 }),
    lush: mk(sets.valleyLush, 'r2', { chunk: 2.5 }),
    ruin: mk(sets.valleyRuin, 'r2', { chunk: 2.5 }),
    room: mk(sets.room, 'house'), nave: mk(sets.nave, 'church'),
  };
  g.v2.skels = SKELS.map(([x, z, yaw], i) => mk(sets.skeleton, 'r2', { bones: lyingBones(V.O.x + x, z, yaw, i) }));
  // aldeões
  g.people = VILLAGERS.map(id => {
    const [x, z, yaw, kind, sc] = PEOPLE_AT[id];
    const mesh = mk(kind === 'woman' ? sets.woman : sets.man, 'r2', { dynamic: false });
    return { id, x: V.O.x + x, z, yaw, home: { x: V.O.x + x, z, yaw }, sc, mesh, st: { blend: 0, phase: Math.random(), breath: Math.random(), time: 0, atk: -1, combo: 0, roll: -1, hurt: 0, dead: 0, heal: -1, swap: -1, block: 0, offhand: 'none', look: 0, accel: 0, turn: 0, run: 0 }, ang: 0 };
  });
  // mortos: 4 na vila + 1 dentro da casa visitada
  g.ghouls = OUT_GHOULS.map(([x, z, yaw], i) => new Ghoul('o' + i, V.O.x + x, z, yaw));
  for (const gh of g.ghouls) if (g.vs.killed.includes(gh.id)) { gh.state = 'dead'; gh.dead = 1; }
  g.roomGhoul = new Ghoul('h', V.ROOM.x - 1.0, V.ROOM.z - 0.5, 0);
  g.ghoulMeshes = [...g.ghouls, g.roomGhoul].map((gh, i) => mk(sets.ghoul, i < 4 ? 'r2' : 'house'));
  // Ser Caedmon, sentado contra o altar
  g.caedmon = mk(sets.knight, 'church', { bones: seatedBones(0) });
  // luzes e fogos do vale
  g.v2.lights = V.LIGHTS2.map(l => ({ ...l, value: l.base, level: 1 }));
  g.lights.push(...g.v2.lights);
  g.v2.fire = g.fx.addFire([V.FIRE.x, 0.15, V.FIRE.z], 0.2, 110, 0.1); g.v2.fire.area = 'r2';
  g.v2.candle = g.fx.addFire([V.ROOM.x - 0.6, 0.93, V.ROOM.z - 1.45], 0.015, 10); g.v2.candle.area = 'house';
  g.v2.altar = [-0.9, -0.55, 0.55, 0.9].map(vx => { const f = g.fx.addFire([V.NAVE.x + vx, 1.3 + Math.abs(vx) * 0.05, V.NAVE.z - 4.55], 0.015, 9); f.area = 'church'; return f; });
  g.curHouse = -1;
  applyPhase(g);
  setArea(g, s.area === 'r2' ? 'r2' : 'r1');
}

function seatedBones(t) {
  const W0 = m4.mul(m4.mul(m4.translate(V.KNIGHT_SEAT.x, 0, V.KNIGHT_SEAT.z), m4.rotY(-0.25)), m4.scale(KS, KS, KS));
  const pose = poseFallen();
  // respira com dificuldade: o peito sobe e a cabeça balança devagar
  const br = Math.sin(t * 1.6) * 0.5 + 0.5;
  pose[2] = m4.mul(pose[2], m4.rotX(-0.04 * br));
  pose[3] = m4.mul(pose[3], m4.mul(m4.rotX(-0.06 * br - 0.25), m4.rotZ(0.04 * Math.sin(t * 0.4))));
  const b = pose.map(m => m4.mul(W0, m)); b[0] = I;
  return b;
}

/** Mostra a vila viva ou as ruínas, conforme a fase. */
function applyPhase(g) {
  const lush = g.vs.phase === 'lush', v = g.v2;
  v.lush.visible = v.lushVeg.visible = lush;
  v.ruin.visible = v.deadVeg.visible = !lush;
  for (const m of v.skels) m.visible = !lush;
  for (const p of g.people) p.mesh.visible = lush;
  for (const l of v.lights) if (l.lush) l.level = lush ? 1 : 0;
}

/** Troca de lugar: mostra só as malhas daquele lugar. */
export function setArea(g, area) {
  g.area = area; g.R.area = area; g.fx.area = area;
  g.indoor = area === 'house' || area === 'church';
}

/** Escurece, muda de lugar, clareia. */
function travel(g, area, x, z, yaw, after) {
  if (g.traveling) return;
  g.traveling = true; $('fade').classList.add('on');
  setTimeout(() => {
    try {
      setArea(g, area);
      const p = g.player;
      Object.assign(p, { x, z, yaw, vx: 0, vz: 0, speed: 0, atk: -1, roll: -1 });
      g.cam.x = x; g.cam.z = z; g.teleported();
      after && after();
    } catch (e) { console.error('[ASHEN] viagem:', e); }
    setTimeout(() => { $('fade').classList.remove('on'); g.traveling = false; }, 120);
  }, 470);
}

export function areaColliders(g) {
  if (g.area === 'r2') return [V.COLLIDERS2, V.BOUNDS2];
  if (g.area === 'house') return [V.ROOM_COLLIDERS, V.ROOM_BOUNDS];
  if (g.area === 'church') return [V.NAVE_COLLIDERS, V.NAVE_BOUNDS];
  return null;
}
/** Colisores que se movem (aldeões e mortos). */
export function dynamicColliders(g) {
  const out = [];
  if (g.area === 'r2' && g.vs.phase === 'lush') for (const p of g.people) out.push({ x: p.x, z: p.z, r: 0.3 * p.sc });
  return out;
}

// ─────────────── Interações ───────────────
const near = (p, x, z, r) => { const d = Math.hypot(p.x - x, p.z - z); return d < r ? d : null; };
export function villageFocus(p, g) {
  const vs = g.vs, list = [];
  const add = (it, x, z, r) => { const d = near(p, x, z, r); if (d != null) list.push({ ...it, x, z, d }); };
  if (g.area === 'r1') {
    if (g.keyMesh.visible) return null;
    return null;
  }
  if (g.area === 'r2') {
    add({ id: 'v:fire', title: 'Fogueira de Orvalho', prompt: 'descansar na fogueira' }, V.FIRE.x, V.FIRE.z, 1.5);
    if (vs.phase === 'lush') for (const q of g.people) add({ id: 'v:talk:' + q.id, prompt: 'conversar' + (vs.talked.includes(q.id) ? ' de novo' : '') }, q.x, q.z, 1.7);
    V.HOUSES.forEach(h => add({ id: 'v:house:' + h.i, prompt: canEnterHouses(g) ? 'entrar na casa' : 'examinar a porta' }, h.doorOut.x, h.doorOut.z, 1.2));
    add({ id: 'v:church', prompt: churchOpen(g) ? 'entrar na igreja' : 'examinar o portal' }, V.CHURCH_DOOR.x, V.CHURCH_DOOR.z, 1.6);
  } else if (g.area === 'house') {
    add({ id: 'v:basket', prompt: 'vasculhar o cesto' }, V.BASKET.x, V.BASKET.z, 1.1);
  } else if (g.area === 'church') {
    add({ id: 'v:knight', prompt: 'falar com o cavaleiro' }, V.KNIGHT_SEAT.x, V.KNIGHT_SEAT.z + 0.5, 1.5);
  }
  list.sort((a, b) => a.d - b.d);
  return list[0] || null;
}
const canEnterHouses = g => g.vs.phase === 'quest' || g.vs.phase === 'done';
const churchOpen = g => ['church', 'quest', 'done'].includes(g.vs.phase);
const outAlive = g => g.ghouls.filter(x => x.state !== 'dead' && x.state !== 'dying').length;

/** Retorna true se tratou a interação. */
export function villageInteract(g, it) {
  const vs = g.vs, hud = g.hud;
  if (it.id === 'gate') {
    if (g.gateOpen) { hud.message(VALLEY.gateOpen, it.title, it); return true; }
    if (g.hasKey) { playGate(g); return true; }
    return false;
  }
  if (!it.id.startsWith('v:')) return false;
  const [, kind, arg] = it.id.split(':');
  if (kind === 'fire') { g.restAt('village'); hud.message(VALLEY.fireText, it.title, it); g.save(); hud.toast('Você descansa: vida e frascos renovados. Progresso salvo.'); return true; }
  if (kind === 'talk') {
    const q = g.people.find(x => x.id === arg);
    q.talking = true;
    g.dialog.start(TALKS[arg].map(([w, t]) => [w, t]), () => {
      q.talking = false;
      if (!vs.talked.includes(arg)) vs.talked.push(arg);
      g.save();
      const left = VILLAGERS.filter(v => !vs.talked.includes(v)).length;
      if (left === 0) setTimeout(() => startFaint(g), 900);
      else g.hud.toast(`Falta conversar com ${left} morador${left > 1 ? 'es' : ''}.`, 2200);
    });
    return true;
  }
  if (kind === 'house') {
    const h = V.HOUSES[+arg];
    if (vs.phase === 'lush') { hud.message('Ninguém atende. Lá de dentro vem cheiro de pão quente.', 'Casa', it); return true; }
    if (!canEnterHouses(g)) { hud.message(VALLEY.door, 'Casa em ruínas', it); return true; }
    snd(g, 'door');
    travel(g, 'house', V.ROOM.x, V.ROOM.z + 1.6, Math.PI, () => enterHouse(g, h.i));
    return true;
  }
  if (kind === 'church') {
    if (vs.phase === 'lush') { hud.message(VALLEY.churchLocked, 'Igreja de Orvalho', it); return true; }
    if (!churchOpen(g)) { hud.message(VALLEY.churchBarred, 'Igreja de Orvalho', it); return true; }
    snd(g, 'door');
    travel(g, 'church', V.NAVE.x, V.NAVE.z + 4.6, Math.PI);
    return true;
  }
  if (kind === 'basket') {
    const i = g.curHouse;
    if (vs.searched.includes(i)) { hud.message(VALLEY.basketTaken, 'Cesto de panos', it); return true; }
    vs.searched.push(i);
    if (i === vs.bandageHouse && !vs.hasBandage) { vs.hasBandage = true; g.save(); jumpscare(g, () => { hud.message(VALLEY.bandage, 'Atadura de Linho', null); hud.toast(VALLEY.questDone, 4000); }); }
    else { hud.message(VALLEY.basketEmpty, 'Cesto de panos', it); g.save(); }
    return true;
  }
  if (kind === 'knight') { talkKnight(g); return true; }
  return false;
}

function talkKnight(g) {
  const vs = g.vs;
  if (vs.phase === 'church') {
    g.dialog.start(KNIGHT_TALK.first, () => {
      vs.phase = 'quest'; vs.bandageHouse = Math.floor(Math.random() * 4); g.save();
      g.hud.toast(VALLEY.quest, 4500);
    });
  } else if (vs.phase === 'quest' && vs.hasBandage) {
    g.dialog.start(KNIGHT_TALK.done, () => {
      vs.phase = 'done'; vs.amulet = true; g.luck = 0.05; g.save(); snd(g, 'pickup');
      g.hud.message(VALLEY.amulet, 'Trevo de Ferro', null);
    });
  } else g.dialog.start(vs.phase === 'done' ? KNIGHT_TALK.after : KNIGHT_TALK.waiting, null);
}

function enterHouse(g, i) {
  g.curHouse = i;
  const gh = g.roomGhoul;
  gh.reset();
  if (g.vs.killed.includes('h' + i)) { gh.state = 'dead'; gh.dead = 1; }
  else { gh.state = 'fight'; gh.cool = 1.8; }
  g.region2Banner && g.region2Banner('Casa abandonada');
}

function jumpscare(g, after) {
  const el = $('spider');
  $('spider-art').textContent = SPIDER;
  el.classList.remove('hidden', 'go'); void el.offsetWidth; el.classList.add('go');
  snd(g, 'spider'); g.shake = 0.25;
  if (g.settings.haptics && navigator.vibrate) { try { navigator.vibrate([90, 40, 160]); } catch (e) { /* ok */ } }
  g.scared = 1.2;
  setTimeout(() => { el.classList.add('hidden'); el.classList.remove('go'); after && after(); }, 1150);
}

// ─────────────── Cenas ───────────────
function playGate(g) {
  const p = g.player;
  Object.assign(p, { x: 0.4, z: GZ + 1.3, yaw: Math.PI, atk: -1, speed: 0 }); g.teleported(); g.cam.x = p.x; g.cam.z = p.z;
  g.cinema.play(gateScene(GZ, {
    key: () => snd(g, 'key'),
    raise: (skip) => { g.portTarget = 1; if (skip) g.portK = 1; else snd(g, 'gate'); },
    done: () => { g.portTarget = 1; g.portK = Math.max(g.portK, 0.999); g.gateOpen = true; g.hasKey = false; g.save(); g.hud.toast('O Portão do Rei está aberto. O vale espera do outro lado.', 3800); },
  }));
}

function startFaint(g) {
  const p = g.player, at = { x: p.x, z: p.z };
  g.fainting = true; snd(g, 'faint');
  g.cinema.play(faintScene(VALLEY, at, V.ENTRY, { x: V.WELL.x, z: V.WELL.z }, {
    fall: () => { p.dead = 0.05; },
    swap: () => {
      g.vs.phase = 'ruin'; applyPhase(g);
      Object.assign(p, { x: V.ENTRY.x + 0.4, z: V.ENTRY.z - 0.6, yaw: Math.PI, dead: 1 }); g.cam.x = p.x; g.cam.z = p.z; g.teleported();
      g.lastRest = 'village'; g.save();
    },
    done: () => { g.fainting = false; p.dead = 1; p.wake = 1; g.hud.showRegion({ region: V.R2.region, title: 'Ruínas de Orvalho', subtitle: '灰の村' }); },
  }));
}

function playRuinStory(g) {
  g.cinema.play(ruinScene(VALLEY, V, {
    bell: () => snd(g, 'bell'),
    done: () => { g.vs.phase = 'church'; g.save(); g.hud.toast('A igreja ao norte. Alguém ainda respira lá dentro.', 4000); },
  }));
}

// ─────────────── A cada passo ───────────────
export function villageStep(g, dt) {
  const p = g.player, vs = g.vs;
  // desmaio: o cavaleiro cai de joelhos
  if (g.fainting && p.dead > 0 && p.dead < 1) p.dead = Math.min(1, p.dead + dt / 1.6);
  // a chave aparece na Brasa do Rei
  if (g.bossDefeated && g.shrine && !g.keyTaken && !g.cinema.active) {
    if (!g.keyMesh.visible) { g.keyMesh.visible = true; g.keyAt = { x: g.shrine.x + 0.9, z: g.shrine.z + 0.2 }; }
    if (g.area === 'r1' && p.dead <= 0 && Math.hypot(p.x - g.keyAt.x, p.z - g.keyAt.z) < 0.8) {
      g.keyMesh.visible = false; g.keyTaken = true; g.hasKey = true; snd(g, 'pickup'); g.fx.burst([g.keyAt.x, 0.7, g.keyAt.z], 40);
      g.hud.message(VALLEY.key, 'Chave do Portão do Rei', null); g.save();
    }
  }
  if (g.cinema.active || g.traveling) return;
  // atravessar o portão / voltar pelo arco do vale
  if (g.area === 'r1' && g.gateOpen && Math.abs(p.x) < 1.05 && p.z < GZ + 0.55 && p.dead <= 0) {
    travel(g, 'r2', V.ENTRY.x, V.ENTRY.z, Math.PI, () => {
      const first = !vs.visited; vs.visited = true; g.save();
      g.hud.showRegion(vs.phase === 'lush' ? V.R2 : { region: V.R2.region, title: 'Ruínas de Orvalho', subtitle: '灰の村' });
      if (first) setTimeout(() => g.hud.toast('Uma fogueira junto ao arco: descanse nela para salvar no vale.', 4200), 5800);
    });
    return;
  }
  if (g.area === 'r2' && p.z > V.ENTRY.z + 1.9 && Math.abs(p.x - V.O.x) < 1.5) { travel(g, 'r1', 0, GZ + 1.4, 0, () => g.hud.showRegion({ region: 'I · Reino das Cinzas', title: 'O Portão do Rei', subtitle: '灰の王国' })); return; }
  if (g.area === 'house' && p.z > V.ROOM.z + V.ROOM.hd + 0.3) { const h = V.HOUSES[g.curHouse]; snd(g, 'door'); travel(g, 'r2', h.doorOut.x + h.door * 0.3, h.doorOut.z, h.door > 0 ? Math.PI / 2 : -Math.PI / 2); return; }
  if (g.area === 'church' && p.z > V.NAVE.z + V.NAVE.hd + 0.35) { snd(g, 'door'); travel(g, 'r2', V.CHURCH_DOOR.x, V.CHURCH_DOOR.z + 0.6, 0); return; }
  // mortos
  const active = g.area === 'r2' && vs.phase !== 'lush' ? g.ghouls : g.area === 'house' ? [g.roomGhoul] : [];
  combatVillage(g, dt, active);
  if (vs.phase === 'ruin' && outAlive(g) === 0 && !g.cinema.active) {
    g.ruinT = (g.ruinT || 0) + dt;
    if (g.ruinT > 2.2) { g.ruinT = 0; playRuinStory(g); }
  }
  // aldeões: olham para o cavaleiro; Pip corre em volta do poço
  if (g.area === 'r2' && vs.phase === 'lush') for (const q of g.people) {
    const d = Math.hypot(p.x - q.x, p.z - q.z);
    let moving = false;
    if (q.id === 'pip' && d > 2.6 && !q.talking) {
      q.ang = (q.ang || 0) + dt * 0.42;
      const tx = V.WELL.x + Math.cos(q.ang) * 2.1, tz = V.WELL.z + Math.sin(q.ang) * 2.1;
      q.yaw = Math.atan2(tx - q.x, tz - q.z); q.x = tx; q.z = tz; moving = true;
    } else if (d < 3.2 || q.talking) {
      const want = Math.atan2(p.x - q.x, p.z - q.z);
      q.yaw += Math.max(-3 * dt, Math.min(3 * dt, Math.atan2(Math.sin(want - q.yaw), Math.cos(want - q.yaw))));
    } else q.yaw += Math.atan2(Math.sin(q.home.yaw - q.yaw), Math.cos(q.home.yaw - q.yaw)) * Math.min(1, dt);
    const st = q.st;
    st.blend += ((moving ? 1 : 0) - st.blend) * Math.min(1, dt * 5);
    if (moving) st.phase = (st.phase + 0.9 * dt / (1.2 * q.sc)) % 1;
    st.breath = (st.breath + dt / 3.6) % 1; st.time = g.t;
  }
}

function combatVillage(g, dt, list) {
  const p = g.player;
  // a lâmina acerta os mortos (uma vez por golpe)
  if (p.atk >= 0 && g.knightBones) {
    const C = COMBO[p.combo];
    if (p.atk > C.hit[0] - 0.03 && p.atk < C.hit[1] + 0.04) {
      const [a, b] = swordSegment(g.knightBones);
      const pts = [0.2, 0.45, 0.7, 0.95].map(k => v3.lerp(a, b, k));
      for (const gh of list) {
        if (!gh.alive || p.hitSet.has(gh.id)) continue;
        for (const q of pts) if (Math.hypot(q[0] - gh.x, q[2] - gh.z) < 0.48 && q[1] < 1.9) {
          p.hitSet.add(gh.id);
          const crit = p.riposte > 0 ? 3 : 1; p.riposte = 0;
          const died = gh.damage(DMG_TABLE[p.combo] * crit);
          snd(g, crit > 1 ? 'crit' : 'hit');
          g.fx.sparks(q, crit > 1 ? 30 : 12, [0.85, 0.8, 0.7]);
          g.shake = Math.max(g.shake || 0, crit > 1 ? 0.1 : 0.04);
          if (died) { snd(g, 'claw', 0.6); if (!g.vs.killed.includes(gh.id === 'h' ? 'h' + g.curHouse : gh.id)) g.vs.killed.push(gh.id === 'h' ? 'h' + g.curHouse : gh.id); g.save(); }
          break;
        }
      }
    }
  }
  for (const gh of list) {
    if (gh.state === 'dead') continue;
    const ev = gh.update(dt, p, p.dead <= 0 && !g.cinema.active && !g.dialog.open, g.area === 'house' ? 12 : 6.5);
    for (const e of ev) {
      if (e.type === 'hit') hurtPlayer(g, e.dmg, e.from, gh);
      else if (e.type === 'swing') snd(g, 'claw', 0.7);
    }
    // não atravessam paredes nem o cavaleiro
    const cols = areaColliders(g);
    if (cols) for (const c of cols[0]) {
      if (c.type === 'circle') { const dx = gh.x - c.x, dz = gh.z - c.z, d = Math.hypot(dx, dz), rr = c.r + 0.3; if (d < rr && d > 1e-6) { gh.x = c.x + dx / d * rr; gh.z = c.z + dz / d * rr; } }
      else if (gh.x > c.x0 - 0.3 && gh.x < c.x1 + 0.3 && gh.z > c.z0 - 0.3 && gh.z < c.z1 + 0.3) {
        const ox = Math.min(gh.x - (c.x0 - 0.3), (c.x1 + 0.3) - gh.x), oz = Math.min(gh.z - (c.z0 - 0.3), (c.z1 + 0.3) - gh.z);
        if (ox < oz) gh.x = gh.x - (c.x0 - 0.3) < (c.x1 + 0.3) - gh.x ? c.x0 - 0.3 : c.x1 + 0.3; else gh.z = gh.z - (c.z0 - 0.3) < (c.z1 + 0.3) - gh.z ? c.z0 - 0.3 : c.z1 + 0.3;
      }
    }
    if (gh.alive) {
      const dx = p.x - gh.x, dz = p.z - gh.z, d = Math.hypot(dx, dz), rr = 0.62;
      if (d < rr && d > 1e-4) { p.x = gh.x + dx / d * rr; p.z = gh.z + dz / d * rr; }
    }
  }
}

/** Morreu no vale: os mortos voltam aos seus lugares. */
export function villageRespawn(g) {
  for (const gh of g.ghouls) if (gh.state !== 'dead') gh.reset();
  if (g.lastRest === 'village') { setArea(g, 'r2'); return { x: V.FIRE.x - 0.9, z: V.FIRE.z - 0.6 }; }
  setArea(g, 'r1');
  return null;
}

// ─────────────── Desenho ───────────────
export function villageRender(g, dt) {
  // grade do portão
  g.portK += Math.max(-dt, Math.min(dt / 5.4, g.portTarget - g.portK));
  g.portMesh.boneData = flatBones([I, m4.translate(0, sm(g.portK) * 3.1, 0)]);
  if (g.keyMesh.visible && g.keyAt) g.keyMesh.boneData = flatBones([I, m4.mul(m4.translate(g.keyAt.x, 0.6 + 0.08 * Math.sin(g.t * 2.5), g.keyAt.z), m4.rotY(g.t * 1.6))]);
  // aldeões
  if (g.area === 'r2' && g.vs.phase === 'lush') for (const q of g.people) {
    const Wm = m4.mul(m4.mul(m4.translate(q.x, 0, q.z), m4.rotY(q.yaw)), m4.scale(KS * q.sc, KS * q.sc, KS * q.sc));
    const b = poseKnight(q.st).map(m => m4.mul(Wm, m)); b[0] = I;
    q.mesh.boneData = flatBones(b);
  }
  // mortos
  const all = [...g.ghouls, g.roomGhoul];
  all.forEach((gh, i) => {
    const mesh = g.ghoulMeshes[i];
    const show = gh.state !== 'dead' && (i < 4 ? g.vs.phase !== 'lush' : true);
    mesh.visible = show;
    if (!show) return;
    const Wm = gh.matrix(), b = gh.pose().map(m => m4.mul(Wm, m)); b[0] = I;
    mesh.boneData = flatBones(b);
    mesh.drawCount = Math.round(mesh.n * (1 - sm((gh.dead - 0.45) / 0.55)));
    if (gh.dead > 0.45 && gh.dead < 1 && Math.random() < 0.5) g.fx.dirt(m4.point(b[2], [0, 0.2, 0]), 2, 0.8);
  });
  if (g.area === 'church') g.caedmon.boneData = flatBones(seatedBones(g.t));
}

export function villageSave(g) {
  const o = { v2: g.vs, hasKey: g.hasKey, gateOpen: g.gateOpen, area: g.area === 'r1' ? 'r1' : 'r2' };
  if (g.area === 'house') { const h = V.HOUSES[g.curHouse]; o.x = +(h.doorOut.x + h.door * 0.3).toFixed(2); o.z = +h.doorOut.z.toFixed(2); }
  if (g.area === 'church') { o.x = V.CHURCH_DOOR.x; o.z = V.CHURCH_DOOR.z + 0.6; }
  if (g.traveling) { o.area = g.area === 'r1' ? 'r1' : 'r2'; }
  return o;
}
