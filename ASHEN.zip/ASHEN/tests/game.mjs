// ASHEN 3D — teste do jogo: carrega (1ª vez e com cache), título, começa, anda, combo, braseiro, clima.
// Uso: node tests/game.mjs [url]  → capturas em /tmp/g-*.png
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const url = process.argv[2] || 'http://localhost:8123/';
const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await browser.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 2.625, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
const logs = [];
page.on('console', m => { if (m.type() !== 'log' || /ASHEN/.test(m.text())) logs.push(`[${m.type()}] ${m.text()}`); });
page.on('pageerror', e => logs.push(`[pageerror] ${e.message}`));
const load = async (label) => {
  const t0 = Date.now();
  await page.goto(url);
  try { await page.waitForFunction(() => window.__ASHEN && window.__ASHEN.ready, null, { timeout: 240000 }); }
  catch (e) { console.log('NÃO CARREGOU', await page.textContent('#load-text')); }
  console.log(label, ((Date.now() - t0) / 1000).toFixed(1), 's');
};
await load('1ª carga (esculpe e guarda):');
await page.evaluate(() => localStorage.setItem('ashen.save.v1', JSON.stringify({ introSeen: true })));
await load('2ª carga (do cache):');
await page.waitForTimeout(1500);
await page.screenshot({ path: '/tmp/g-titulo.png' });
await page.tap('#start');
await page.waitForTimeout(1600);
const g = (f, a) => page.evaluate(f, a);
await g(() => { window.__ASHEN.settings.showPerf = true; window.__ASHEN.applySettings(false); });
await page.screenshot({ path: '/tmp/g-inicio.png' });
const cdp = await ctx.newCDPSession(page);
const touch = (type, pts) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: pts.map((p, i) => ({ x: p[0], y: p[1], id: i })) });
await touch('touchStart', [[150, 300]]); await touch('touchMove', [[150, 240]]);
await page.waitForTimeout(1300);
await page.screenshot({ path: '/tmp/g-andando.png' });
await touch('touchEnd', []);
await page.waitForTimeout(600);
// combo de 3 golpes
for (let i = 0; i < 3; i++) { await page.tap('#btn-atk'); await page.waitForTimeout(260); }
const combo = await g(() => ({ atk: window.__ASHEN.player.atk.toFixed(2), combo: window.__ASHEN.player.combo }));
await page.screenshot({ path: '/tmp/g-combo.png' });
await page.waitForTimeout(1500);
// braseiro: teleporta perto e interage
await g(() => { const G = window.__ASHEN, p = G.player; p.x = -1.6 + 0.9; p.z = -0.25 + 0.9; G.cam.x = p.x; G.cam.z = p.z; G.teleported(); });
await page.waitForTimeout(500);
await page.tap('#btn-interact');
await page.waitForTimeout(1500);
const lit = await g(() => window.__ASHEN.brazierLit);
await page.screenshot({ path: '/tmp/g-braseiro.png' });
await page.tap('#message-ok').catch(() => {}); await page.tap('#message-ok').catch(() => {});
// tempestade forçada
await g(() => { const G = window.__ASHEN; G.weather.setMode('tempestade'); G.weather.rain = 1; G.weather.wet = 1; G.weather.nextBolt = 0; });
await page.waitForTimeout(2500);
await page.screenshot({ path: '/tmp/g-chuva.png' });
await g(() => { const G = window.__ASHEN; G.weather.bolt = { t: 0, peaks: [[0, 1]] }; });
await page.waitForTimeout(60);
await page.screenshot({ path: '/tmp/g-relampago.png' });
// portão e cavaleiro caído
await g(() => { const G = window.__ASHEN, p = G.player; G.weather.setMode('limpo'); G.weather.rain = 0; G.weather.wet = 0; p.x = 4.2; p.z = -2.2; p.yaw = 3.14; G.cam.x = 2.5; G.cam.z = -2.5; G.teleported(); });
await page.waitForTimeout(1800);
await page.screenshot({ path: '/tmp/g-portao.png' });
await g(() => { const G = window.__ASHEN, p = G.player; p.x = -8.5; p.z = 2.4; G.cam.x = -8.5; G.cam.z = 2.4; G.teleported(); });
await page.waitForTimeout(1800);
await page.screenshot({ path: '/tmp/g-cemiterio.png' });
const st = await g(() => ({ perf: document.getElementById('perf').textContent }));
console.log('combo', JSON.stringify(combo), '· braseiro aceso:', lit);
console.log(st.perf);
console.log(logs.slice(0, 20).join('\n') || '(sem erros)');
await browser.close();
