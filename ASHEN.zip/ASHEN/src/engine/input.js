// ASHEN — Entrada unificada
// Teclado (teclas configuráveis), mouse (clique para mover/interagir) e toque
// (joystick virtual flutuante + botões, múltiplos toques simultâneos).
// Toda a gameplay lê apenas `input.state` — mesma lógica para mobile e desktop.

export const DEFAULT_BINDINGS = {
  up: ['KeyW', 'ArrowUp'],
  down: ['KeyS', 'ArrowDown'],
  left: ['KeyA', 'ArrowLeft'],
  right: ['KeyD', 'ArrowRight'],
  run: ['ShiftLeft', 'ShiftRight'],
  attack: ['KeyJ', 'Space'],
  dodge: ['KeyK', 'ControlLeft'],
  block: ['KeyL', 'KeyB'],
  swap: ['KeyQ'],
  heal: ['KeyR'],
  interact: ['KeyE', 'Enter'],
  menu: ['Escape', 'KeyP'],
  debug: ['F3', 'Backquote'],
};

export const ACTION_LABELS = {
  up: 'Mover para cima', down: 'Mover para baixo', left: 'Mover para a esquerda', right: 'Mover para a direita',
  run: 'Correr (segurar)', attack: 'Atacar (combo)', dodge: 'Rolar / esquivar', block: 'Bloquear (segurar) / aparar', swap: 'Trocar tocha ⇄ escudo', heal: 'Beber frasco de cura', interact: 'Interagir', menu: 'Menu / pausa', debug: 'Painel de desempenho',
};

export class Input {
  constructor(target) {
    this.target = target;
    this.bindings = structuredClone(DEFAULT_BINDINGS);
    this.keys = new Set();
    this.held = {};        // ação → número de fontes segurando
    this.pressed = {};     // ação → apertou neste passo
    this.state = { mx: 0, my: 0, run: false, analog: false };
    this.stick = { active: false, id: null, ox: 0, oy: 0, x: 0, y: 0, vx: 0, vy: 0, radius: 56 };
    this.mouse = { down: false, x: 0, y: 0, moved: 0, clickX: 0, clickY: 0, click: false, has: false };
    this.lastDevice = 'keyboard';
    this.rebinding = null;
    this.listeners = [];
    this._bind();
  }

  setBindings(b) { if (b) for (const k in DEFAULT_BINDINGS) if (Array.isArray(b[k]) && b[k].length) this.bindings[k] = b[k].slice(0, 2); }

  actionForCode(code) {
    for (const a in this.bindings) if (this.bindings[a].includes(code)) return a;
    return null;
  }

  press(action) {
    this.held[action] = (this.held[action] || 0) + 1;
    this.pressed[action] = true;
    (this.pressedAt || (this.pressedAt = {}))[action] = performance.now();
  }
  release(action) { this.held[action] = Math.max(0, (this.held[action] || 0) - 1); }
  isHeld(a) { return (this.held[a] || 0) > 0; }
  /** Consome o "apertou" (uma vez por ação). */
  take(a) { const v = !!this.pressed[a]; this.pressed[a] = false; return v; }
  /** Buffer de comandos: o aperto fica guardado por ~0,3 s até a ação poder começar (não é consumido aqui). */
  want(a, win = 300) { if (!this.pressed[a]) return false; if (performance.now() - ((this.pressedAt && this.pressedAt[a]) || 0) > win) { this.pressed[a] = false; return false; } return true; }
  consume(a) { this.pressed[a] = false; }
  /** Mantém vivo um aperto guardado enquanto a ação atual ainda não acabou. */
  hold(a) { if (this.pressed[a] && this.pressedAt) this.pressedAt[a] = performance.now(); }

  /** Inicia captura de tecla para reconfigurar uma ação. */
  startRebind(action, slot, done) { this.rebinding = { action, slot, done }; }

  _on(el, ev, fn, opts) { el.addEventListener(ev, fn, opts); this.listeners.push([el, ev, fn, opts]); }

  _bind() {
    this._on(window, 'keydown', e => {
      if (this.rebinding) {
        e.preventDefault();
        const { action, slot, done } = this.rebinding;
        if (e.code !== 'Escape') {
          for (const a in this.bindings) this.bindings[a] = this.bindings[a].filter(c => c !== e.code);
          const list = this.bindings[action];
          list[slot] = e.code;
          this.bindings[action] = list.filter(Boolean);
        }
        this.rebinding = null;
        done && done(this.bindings);
        return;
      }
      const a = this.actionForCode(e.code);
      if (a) {
        e.preventDefault();
        if (!this.keys.has(e.code)) { this.keys.add(e.code); this.press(a); }
        this.lastDevice = 'keyboard';
      }
    });
    this._on(window, 'keyup', e => {
      if (this.keys.has(e.code)) {
        this.keys.delete(e.code);
        const a = this.actionForCode(e.code);
        if (a) this.release(a);
      }
    });
    this._on(window, 'blur', () => this.clearAll());
    document.addEventListener('visibilitychange', () => { if (document.hidden) this.clearAll(); });

    // Mouse no canvas: segurar = andar até o cursor; clique curto = mover/interagir.
    const t = this.target;
    this._on(t, 'pointerdown', e => {
      if (e.pointerType !== 'mouse') return;
      if (e.button === 0) {
        this.mouse.down = true; this.mouse.moved = 0;
        this.mouse.x = this.mouse.clickX = e.clientX; this.mouse.y = this.mouse.clickY = e.clientY;
        this.mouse.has = true;
        this.lastDevice = 'mouse';
        try { t.setPointerCapture(e.pointerId); } catch (err) { /* ok */ }
      }
    });
    this._on(t, 'pointermove', e => {
      if (e.pointerType !== 'mouse') return;
      this.mouse.moved += Math.abs(e.clientX - this.mouse.x) + Math.abs(e.clientY - this.mouse.y);
      this.mouse.x = e.clientX; this.mouse.y = e.clientY; this.mouse.has = true;
    });
    this._on(t, 'pointerup', e => {
      if (e.pointerType !== 'mouse' || e.button !== 0) return;
      if (this.mouse.down && this.mouse.moved < 12) this.mouse.click = true;
      this.mouse.down = false;
    });
    this._on(t, 'contextmenu', e => e.preventDefault());
  }

  /** Liga o joystick flutuante a uma zona da tela. */
  attachStick(zone, baseEl, knobEl) {
    this.stickEls = { zone, baseEl, knobEl };
    const s = this.stick;
    const start = e => {
      if (s.active || e.pointerType === 'mouse' && e.button !== 0) return;
      e.preventDefault();
      s.active = true; s.id = e.pointerId;
      s.ox = e.clientX; s.oy = e.clientY; s.x = e.clientX; s.y = e.clientY;
      s.radius = Math.max(44, Math.min(72, Math.min(window.innerWidth, window.innerHeight) * 0.14));
      try { zone.setPointerCapture(e.pointerId); } catch (err) { /* ok */ }
      this.lastDevice = 'touch';
      this._stickVisual();
    };
    const move = e => {
      if (!s.active || e.pointerId !== s.id) return;
      e.preventDefault();
      s.x = e.clientX; s.y = e.clientY;
      // Base segue o dedo quando ele passa do raio (joystick "arrastável").
      const dx = s.x - s.ox, dy = s.y - s.oy, d = Math.hypot(dx, dy), max = s.radius * 1.35;
      if (d > max) { s.ox += dx / d * (d - max); s.oy += dy / d * (d - max); }
      this._stickVisual();
    };
    const end = e => {
      if (e.pointerId !== s.id) return;
      s.active = false; s.id = null; s.vx = s.vy = 0;
      this._stickVisual();
    };
    this._on(zone, 'pointerdown', start, { passive: false });
    this._on(zone, 'pointermove', move, { passive: false });
    this._on(zone, 'pointerup', end);
    this._on(zone, 'pointercancel', end);
  }

  _stickVisual() {
    const s = this.stick, el = this.stickEls;
    if (!el) return;
    const dx = s.x - s.ox, dy = s.y - s.oy;
    const d = Math.hypot(dx, dy), r = s.radius;
    const k = d > r ? r / d : 1;
    const nx = dx * k / r, ny = dy * k / r;
    const mag = Math.min(1, d / r);
    const dead = 0.14;
    const m = mag < dead ? 0 : (mag - dead) / (1 - dead);
    s.vx = d > 0 ? dx / d * m : 0; s.vy = d > 0 ? dy / d * m : 0;
    if (s.active) {
      el.baseEl.style.transform = `translate(${s.ox}px, ${s.oy}px) translate(-50%,-50%)`;
      el.knobEl.style.transform = `translate(${s.ox + nx * r}px, ${s.oy + ny * r}px) translate(-50%,-50%)`;
      el.baseEl.style.width = el.baseEl.style.height = r * 2 + 'px';
      el.baseEl.classList.add('on'); el.knobEl.classList.add('on');
    } else {
      el.baseEl.classList.remove('on'); el.knobEl.classList.remove('on');
    }
  }

  /** Liga um botão de toque a uma ação (suporta vários dedos ao mesmo tempo). */
  attachButton(el, action) {
    const ids = new Set();
    const down = e => {
      e.preventDefault(); e.stopPropagation();
      if (ids.has(e.pointerId)) return;
      ids.add(e.pointerId);
      try { el.setPointerCapture(e.pointerId); } catch (err) { /* ok */ }
      this.press(action);                       // o comando primeiro; o visual depois (não atrasa nada)
      el.classList.add('down'); el.classList.remove('ping'); void el.offsetWidth; el.classList.add('ping');
      if (navigator.vibrate && this.haptics) { try { navigator.vibrate(8); } catch (err) { /* ok */ } }
      this.lastDevice = 'touch';
    };
    const up = e => {
      if (!ids.has(e.pointerId)) return;
      ids.delete(e.pointerId);
      if (!ids.size) el.classList.remove('down');
      this.release(action);
    };
    this._on(el, 'pointerdown', down, { passive: false });
    this._on(el, 'pointerup', up);
    this._on(el, 'pointercancel', up);
    this._on(el, 'lostpointercapture', up);
  }

  clearAll() {
    this.keys.clear();
    for (const a in this.held) this.held[a] = 0;
    this.stick.active = false; this.stick.vx = this.stick.vy = 0;
    this.mouse.down = false;
    this._stickVisual();
  }

  /** Consolida o estado de movimento para um passo de física. */
  poll() {
    let mx = 0, my = 0;
    if (this.isHeld('left')) mx -= 1;
    if (this.isHeld('right')) mx += 1;
    if (this.isHeld('up')) my -= 1;
    if (this.isHeld('down')) my += 1;
    let analog = false;
    if (this.stick.active && (this.stick.vx || this.stick.vy)) { mx = this.stick.vx; my = this.stick.vy; analog = true; }
    const len = Math.hypot(mx, my);
    if (len > 1) { mx /= len; my /= len; }
    this.state.mx = mx; this.state.my = my; this.state.analog = analog;
    this.state.run = this.isHeld('run');
    return this.state;
  }
}
