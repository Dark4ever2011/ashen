// ASHEN — Atmosfera
// Névoa feita de caracteres (░ ▒ ~ ·) em texturas tileáveis pré-renderizadas,
// deslizando com o vento em duas camadas; névoa de distância no topo da tela; vinheta.

import { makeCanvas } from './canvas.js';
import { GlyphPainter } from './typography.js';
import { noise2p } from './animation.js';

export class Atmosphere {
  constructor() {
    this.layers = [];
    this.version = -1;
    this.vignette = null;
    this.haze = null;
    this.density = 1;      // preset
    this.detail = 1;       // 1 = duas camadas
    this.wind = 14;
  }

  _buildLayer(S, opts) {
    const p = new GlyphPainter();
    const cw = opts.cw * S, ch = opts.ch * S;
    p.setCell(cw, ch);
    const cols = opts.cols, rows = opts.rows;
    const c = makeCanvas(cols * cw, rows * ch);
    const x = c.getContext('2d');
    const per = opts.period;
    for (let r = 0; r < rows; r++) for (let q = 0; q < cols; q++) {
      // Ruído periódico em duas escalas → bancos de névoa com bordas esfiapadas.
      const u = q / cols * per, v = r / rows * (per * rows / cols);
      let d = noise2p(u, v, per, Math.round(per * rows / cols), opts.seed) * 0.65
            + noise2p(u * 3, v * 3, per * 3, Math.round(per * 3 * rows / cols), opts.seed + 7) * 0.35;
      d = (d - opts.cut) / (1 - opts.cut);
      if (d <= 0) continue;
      let g;
      if (d < 0.22) { if ((q * 5 + r * 3) % 4) continue; g = (q + r) % 3 === 0 ? '·' : '˙'; }
      else if (d < 0.5) g = (q * 7 + r * 3) % 4 === 0 ? '~' : '░';
      else g = (q * 3 + r) % 6 === 0 ? '≈' : '░';
      const a = Math.min(1, 0.16 + d * 0.62);
      x.globalAlpha = a;
      p.paint(x, g, 1, q * cw, r * ch, opts.color);
    }
    p.end(x);
    x.globalAlpha = 1;
    return { canvas: c, w: c.width, h: c.height, ...opts };
  }

  build(r) {
    if (this.version === r.version && this.layers.length) {
      if (!this.vignette || this.vW !== r.W || this.vH !== r.H) this._buildScreen(r);
      return;
    }
    this.version = r.version;
    const S = r.S;
    this.layers = [
      this._buildLayer(S, { cw: 10, ch: 16, cols: 64, rows: 26, period: 6, cut: 0.42, seed: 11, color: '#a3acbd', speed: 1, alpha: 0.5, parallax: 1 }),
      this._buildLayer(S, { cw: 7, ch: 11, cols: 80, rows: 30, period: 8, cut: 0.5, seed: 29, color: '#c4cad6', speed: 1.7, alpha: 0.32, parallax: 1.06 }),
    ];
    this._buildScreen(r);
  }

  _buildScreen(r) {
    // Névoa de distância: só a faixa de cima da tela (o resto já recebe a vinheta no mapa de luz).
    this.vW = r.W; this.vH = r.H;
    this.hazeH = Math.ceil(r.H * 0.5);
    this.vignette = makeCanvas(4, 64);
    const x = this.vignette.getContext('2d');
    const h = x.createLinearGradient(0, 0, 0, 64);
    h.addColorStop(0, 'rgba(70,78,100,0.38)');
    h.addColorStop(0.6, 'rgba(60,66,86,0.1)');
    h.addColorStop(1, 'rgba(60,66,86,0)');
    x.fillStyle = h; x.fillRect(0, 0, 4, 64);
  }

  /** Névoa rasteira, ancorada no mundo, antes da luz (é iluminada pelo fogo). */
  drawMist(r, t, which = 0) {
    const L = this.layers[which];
    if (!L || this.density <= 0) return;
    if (which === 1 && this.detail < 1) return;
    const ctx = r.ctx;
    const drift = t * this.wind * L.speed * r.S;
    let offX = ((r.ox * L.parallax + drift) % L.w + L.w) % L.w;
    let offY = ((r.oy * L.parallax + t * 3 * r.S) % L.h + L.h) % L.h;
    ctx.globalAlpha = L.alpha * this.density;
    for (let y = offY - L.h; y < r.H; y += L.h)
      for (let x = offX - L.w; x < r.W; x += L.w)
        ctx.drawImage(L.canvas, Math.round(x), Math.round(y));
    ctx.globalAlpha = 1;
  }

  /** Névoa de distância e vinheta (depois da luz). */
  drawScreen(r) {
    if (this.vignette) r.ctx.drawImage(this.vignette, 0, 0, r.W, this.hazeH);
  }
}
