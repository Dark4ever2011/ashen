// ASHEN 3D — Cavaleiro de Aço Negro do Juramento
// Anatomia humana (~1,88 m, ~7,5 cabeças), armadura modelada em cascas com espessura.
// Cada peça vive no espaço do seu osso; a superfície vira milhares de caracteres.
// Ossos: 0 mundo, 1 pélvis, 2 peito, 3 cabeça, 4-6 braço esq., 7-9 braço dir.,
//        10-12 perna esq., 13-15 perna dir., 16 espada.
// O cavaleiro olha para +Z. Lado esquerdo dele = +X.

import { m4, v3 } from './math3d.js';
import { MAT } from './glyphs.js';
import * as S from './sdf.js';
import { PointSet } from './sampler.js';

export const BONE = { WORLD: 0, PELVIS: 1, CHEST: 2, HEAD: 3, UA_L: 4, FA_L: 5, HAND_L: 6, UA_R: 7, FA_R: 8, HAND_R: 9, TH_L: 10, SH_L: 11, FT_L: 12, TH_R: 13, SH_R: 14, FT_R: 15, SWORD: 16 };

const L = { thigh: 0.43, shin: 0.42, upper: 0.29, fore: 0.26 };
const slab = (y0, y1) => (x, y, z) => Math.max(y0 - y, y - y1);

/** Peças da armadura (tudo em metros, no espaço do osso). */
export function knightParts() {
  const P = [];
  const add = (o) => P.push(o);

  // ── Pélvis: lâminas da cintura (faldas), cinto e escarcelas ──
  const faulds = S.union(...[0, 1, 2].map(i => S.intersect(S.shell(S.xf(S.ellipsoid(0.165 + i * 0.012, 0.4, 0.125 + i * 0.01), [0, 0.05, 0.005]), 0.008), slab(0.05 - i * 0.055, 0.1 - i * 0.055))));
  add({ name: 'faldas', bone: BONE.PELVIS, f: faulds, min: [-0.2, -0.12, -0.16], max: [0.2, 0.12, 0.16], mat: MAT.STEEL, spacing: 0.024, flow: [1, 0, 0] });
  add({ name: 'cinto', bone: BONE.PELVIS, f: S.intersect(S.shell(S.xf(S.ellipsoid(0.17, 0.4, 0.13), [0, 0.1, 0.005]), 0.01), slab(0.1, 0.13)), min: [-0.2, 0.08, -0.16], max: [0.2, 0.15, 0.16], mat: MAT.LEATHER, spacing: 0.02, flow: [1, 0, 0],
    decals: [{ p: [0, 0.115, 0.142], n: [0, 0, 1], glyph: '◆', mat: MAT.GOLD, size: 0.045 }] });
  const tasset = S.union(...[0, 1, 2].map(i => S.xf(S.box(0.075 - i * 0.004, 0.032, 0.008, 0.006), [0.098, -0.07 - i * 0.05, 0.135 - i * 0.004], [-0.18, 0, -0.12])));
  add({ name: 'escarcelas', bone: BONE.PELVIS, f: S.mirrorX(tasset), min: [-0.2, -0.24, 0.08], max: [0.2, -0.02, 0.17], mat: MAT.STEEL, spacing: 0.02, flow: [1, 0, 0],
    detail: (p, n, c) => c > 0.35 && p[1] < -0.09 ? { mat: MAT.SILVER } : null });

  // ── Peito: couraça, gorjal, ombreiras em lâminas ──
  const chest = S.smooth(0.07, S.xf(S.ellipsoid(0.19, 0.2, 0.135), [0, 0.21, 0.012]), S.xf(S.ellipsoid(0.155, 0.13, 0.115), [0, 0.04, 0.008]));
  const keel = S.capsule([0, 0.05, 0.13], [0, 0.32, 0.14], 0.009);
  add({ name: 'couraça', bone: BONE.CHEST, f: S.smooth(0.02, chest, keel), min: [-0.22, -0.1, -0.16], max: [0.22, 0.42, 0.17], mat: MAT.STEEL, spacing: 0.026, flow: [0, 1, 0],
    decals: [{ p: [0, 0.225, 0.152], n: [0, 0.1, 1], glyph: '誓', mat: MAT.GOLD, size: 0.085, clear: 0.05 }],
    detail: (p) => Math.abs(p[0]) < 0.012 && p[2] > 0.1 ? { mat: MAT.SILVER, glyph: '│' } : null });
  add({ name: 'gorjal', bone: BONE.CHEST, f: S.union(S.xf(S.cylinder(0.072, 0.035, 0.012), [0, 0.42, 0]), S.xf(S.cylinder(0.105, 0.012, 0.01), [0, 0.385, 0])), min: [-0.12, 0.36, -0.12], max: [0.12, 0.47, 0.12], mat: MAT.STEEL, spacing: 0.018, flow: [1, 0, 0],
    detail: (p, n, c) => c > 0.3 ? { mat: MAT.SILVER } : null });
  const lame = i => S.intersect(S.intersect(S.shell(S.xf(S.sphere(0.135 - i * 0.008), [0.205 + i * 0.022, 0.355 - i * 0.055, 0]), 0.009), S.above(0.32 - i * 0.058)), (x) => 0.11 - x);
  const pauldron = S.union(lame(0), lame(1), lame(2));
  add({ name: 'ombreiras', bone: BONE.CHEST, f: S.mirrorX(pauldron), min: [-0.39, 0.16, -0.16], max: [0.39, 0.5, 0.16], mat: MAT.STEEL, spacing: 0.022, flow: [0, 0, 1],
    detail: (p, n, c) => c > 0.3 ? { mat: MAT.GOLD } : null,
    decals: [-1, 1].map(s => ({ p: [s * 0.26, 0.44, 0.075], n: [s * 0.4, 0.6, 0.6], glyph: '•', mat: MAT.SILVER, size: 0.03 }))
      .concat([-1, 1].map(s => ({ p: [s * 0.31, 0.35, 0.09], n: [s * 0.6, 0.3, 0.7], glyph: '•', mat: MAT.SILVER, size: 0.026 }))) });

  // ── Elmo fechado: calota, viseira estreita, crista, aro de ouro partido ──
  const bowl = S.smooth(0.05, S.xf(S.ellipsoid(0.112, 0.138, 0.128), [0, 0.165, 0]), S.xf(S.ellipsoid(0.098, 0.09, 0.112), [0, 0.075, 0.022]));
  const slit = S.xf(S.box(0.085, 0.0085, 0.06), [0, 0.165, 0.11]);
  const comb = S.intersect(S.box(0.009, 0.3, 0.3), S.xf(S.ellipsoid(0.13, 0.168, 0.145), [0, 0.17, -0.005]));
  add({ name: 'elmo', bone: BONE.HEAD, f: S.union(S.subtract(bowl, slit), comb), min: [-0.14, -0.02, -0.16], max: [0.14, 0.36, 0.16], mat: MAT.STEEL, spacing: 0.017, flow: [0, 1, 0],
    detail: (p, n) => {
      if (Math.abs(p[0]) < 0.011 && p[1] > 0.22) return { mat: MAT.SILVER };
      if (Math.abs(p[1] - 0.165) < 0.013 && p[2] > 0.06) return { mat: MAT.DARK };
      if (p[2] > 0.08 && p[1] < 0.12 && p[1] > 0.06 && (Math.round(p[0] * 60) % 2 === 0)) return { glyph: '∴', mat: MAT.SILVER, size: 0.8 };
      return null;
    },
    decals: [-1, 1].map(s => ({ p: [s * 0.036, 0.165, 0.112], n: [0, 0, 1], glyph: '•', mat: MAT.EMBER, size: 0.03, flags: 2 })) });
  add({ name: 'aro', bone: BONE.HEAD, f: S.intersect(S.shell(S.xf(S.ellipsoid(0.12, 0.4, 0.135), [0, 0.2, 0]), 0.007), slab(0.205, 0.228)), min: [-0.14, 0.19, -0.15], max: [0.14, 0.24, 0.15], mat: MAT.GOLD, spacing: 0.014, flow: [1, 0, 0],
    keep: (p) => !(Math.atan2(p[2], p[0]) > 0.25 && Math.atan2(p[2], p[0]) < 0.55), size: 1.2,
    decals: [-0.6, -0.3, 0, 0.3].map(a => ({ p: [Math.sin(a) * 0.12, 0.25, Math.cos(a) * 0.135], n: [Math.sin(a), 0.3, Math.cos(a)], glyph: 'Λ', mat: MAT.GOLD, size: 0.03 })) });

  // ── Braços (por lado) ──
  for (const [ua, fa, hd, side] of [[BONE.UA_L, BONE.FA_L, BONE.HAND_L, 1], [BONE.UA_R, BONE.FA_R, BONE.HAND_R, -1]]) {
    add({ name: 'braçal', bone: ua, f: S.roundCone([0, -0.03, 0], [0, -0.25, 0], 0.056, 0.048), min: [-0.08, -0.3, -0.08], max: [0.08, 0.04, 0.08], mat: MAT.STEEL, spacing: 0.022, flow: [0, 1, 0] });
    const couter = S.smooth(0.01, S.sphere(0.056), S.xf(S.ellipsoid(0.014, 0.07, 0.062), [side * 0.05, 0.0, -0.012]));
    add({ name: 'cotoveleira', bone: fa, f: couter, min: [-0.08, -0.08, -0.08], max: [0.08, 0.08, 0.08], mat: MAT.STEEL, spacing: 0.016, flow: [0, 1, 0],
      detail: (p, n, c) => c > 0.3 ? { mat: MAT.SILVER } : null });
    add({ name: 'antebraço', bone: fa, f: S.roundCone([0, -0.04, 0], [0, -0.235, 0], 0.05, 0.041), min: [-0.07, -0.29, -0.07], max: [0.07, 0.0, 0.07], mat: MAT.STEEL, spacing: 0.02, flow: [0, 1, 0] });
    const cuff = S.roundCone([0, 0.0, 0], [0, -0.05, 0], 0.046, 0.058);
    const palm = S.xf(S.box(0.042, 0.045, 0.024, 0.016), [0, -0.085, 0.006]);
    const fingers = S.capsule([-0.03, -0.12, 0.03], [0.03, -0.12, 0.03], 0.02);
    add({ name: 'manopla', bone: hd, f: S.smooth(0.015, cuff, palm, fingers), min: [-0.08, -0.16, -0.06], max: [0.08, 0.02, 0.07], mat: MAT.STEEL, spacing: 0.015, flow: [1, 0, 0],
      detail: (p, n, c) => c > 0.4 ? { mat: MAT.SILVER } : null });
  }

  // ── Pernas (por lado) ──
  for (const [th, sh, ft, side] of [[BONE.TH_L, BONE.SH_L, BONE.FT_L, 1], [BONE.TH_R, BONE.SH_R, BONE.FT_R, -1]]) {
    add({ name: 'coxote', bone: th, f: S.roundCone([0, -0.02, 0], [0, -0.38, 0.005], 0.082, 0.064), min: [-0.11, -0.44, -0.11], max: [0.11, 0.08, 0.11], mat: MAT.STEEL, spacing: 0.024, flow: [0, 1, 0] });
    const poleyn = S.smooth(0.012, S.xf(S.sphere(0.06), [0, 0, 0.022]), S.xf(S.ellipsoid(0.012, 0.07, 0.06), [side * 0.06, 0.0, 0.0]));
    add({ name: 'joelheira', bone: sh, f: poleyn, min: [-0.09, -0.08, -0.07], max: [0.09, 0.08, 0.1], mat: MAT.STEEL, spacing: 0.016, flow: [0, 1, 0],
      detail: (p, n, c) => c > 0.3 ? { mat: MAT.SILVER } : null,
      decals: [{ p: [0, 0.0, 0.083], n: [0, 0, 1], glyph: '◆', mat: MAT.SILVER, size: 0.03 }] });
    const greave = S.smooth(0.01, S.roundCone([0, -0.05, 0], [0, -0.39, 0], 0.057, 0.044), S.capsule([0, -0.08, 0.052], [0, -0.36, 0.041], 0.008));
    add({ name: 'greva', bone: sh, f: greave, min: [-0.08, -0.45, -0.08], max: [0.08, 0.0, 0.08], mat: MAT.STEEL, spacing: 0.021, flow: [0, 1, 0],
      detail: (p) => Math.abs(p[0]) < 0.01 && p[2] > 0.035 ? { mat: MAT.SILVER, glyph: '│' } : null });
    const sab = S.union(...[0, 1, 2, 3].map(i => S.xf(S.ellipsoid(0.052 - i * 0.002, 0.04, 0.05), [0, -0.035, 0.035 + i * 0.033])), S.xf(S.ellipsoid(0.05, 0.035, 0.05), [0, -0.035, 0.155]), S.xf(S.ellipsoid(0.05, 0.045, 0.05), [0, -0.03, -0.02]));
    add({ name: 'sabatons', bone: ft, f: S.intersect(sab, S.above(-0.075)), min: [-0.08, -0.08, -0.08], max: [0.08, 0.03, 0.22], mat: MAT.STEEL, spacing: 0.018, flow: [1, 0, 0],
      detail: (p, n, c) => c > 0.3 ? { mat: MAT.SILVER } : null });
  }

  // ── Montante: pomo, punho de couro, guarda, lâmina com sulco central ──
  const blade = (x, y, z) => {
    const t = (y - 0.12) / 1.08;
    const w = 0.031 * (1 - t * 0.45) * (t > 0.9 ? Math.max(0, (1 - t) / 0.1) : 1);
    const th = 0.0065 * (1 - Math.abs(x) / 0.035);
    return Math.max(Math.abs(x) - w, Math.abs(z) - th, 0.12 - y, y - 1.2);
  };
  add({ name: 'lâmina', bone: BONE.SWORD, f: blade, min: [-0.04, 0.1, -0.02], max: [0.04, 1.22, 0.02], mat: MAT.BLADE, spacing: 0.013, flow: [0, 1, 0],
    detail: (p) => Math.abs(p[0]) < 0.005 && p[1] < 0.95 ? { mat: MAT.STEEL, glyph: '│' } : null, size: 0.9 });
  add({ name: 'guarda', bone: BONE.SWORD, f: S.smooth(0.01, S.xf(S.box(0.15, 0.014, 0.018, 0.008), [0, 0.1, 0]), S.xf(S.sphere(0.024), [0.15, 0.1, 0]), S.xf(S.sphere(0.024), [-0.15, 0.1, 0])), min: [-0.19, 0.06, -0.04], max: [0.19, 0.14, 0.04], mat: MAT.GOLD, spacing: 0.012, flow: [1, 0, 0] });
  add({ name: 'punho', bone: BONE.SWORD, f: S.capsule([0, -0.15, 0], [0, 0.08, 0], 0.017), min: [-0.03, -0.18, -0.03], max: [0.03, 0.1, 0.03], mat: MAT.LEATHER, spacing: 0.011, flow: [1, 0.4, 0] });
  add({ name: 'pomo', bone: BONE.SWORD, f: S.xf(S.sphere(0.03), [0, -0.18, 0]), min: [-0.04, -0.22, -0.04], max: [0.04, -0.14, 0.04], mat: MAT.GOLD, spacing: 0.011, flow: [0, 1, 0] });
  return P;
}


// ─────────────── Pose: cinemática inversa e marcha ───────────────
const frame = (origin, yAxis, fwd) => {
  const y = v3.norm(yAxis);
  let x = v3.norm(v3.cross(y, fwd));
  if (!isFinite(x[0])) x = [1, 0, 0];
  const z = v3.cross(x, y);
  const m = m4.ident();
  m[0] = x[0]; m[1] = x[1]; m[2] = x[2]; m[4] = y[0]; m[5] = y[1]; m[6] = y[2]; m[8] = z[0]; m[9] = z[1]; m[10] = z[2];
  m[12] = origin[0]; m[13] = origin[1]; m[14] = origin[2];
  return m;
};

function ik(a, target, l1, l2, pole) {
  let d = v3.sub(target, a);
  let dist = v3.len(d);
  const max = (l1 + l2) * 0.999;
  if (dist > max) { d = v3.mul(d, max / dist); dist = max; }
  const dir = v3.mul(d, 1 / dist);
  const x = (l1 * l1 - l2 * l2 + dist * dist) / (2 * dist);
  const h = Math.sqrt(Math.max(0, l1 * l1 - x * x));
  let pv = v3.sub(pole, v3.mul(dir, v3.dot(pole, dir)));
  pv = v3.norm(pv);
  const knee = v3.add(v3.add(a, v3.mul(dir, x)), v3.mul(pv, h));
  return { knee, end: v3.add(a, d) };
}

/**
 * st = { phase (0..1), blend (0 parado .. 1 andando), run (0..1), breath (0..1) }
 * Retorna matrizes dos ossos no espaço do modelo.
 */
export function poseKnight(st) {
  const b = st.blend * st.blend * (3 - 2 * st.blend), run = st.run || 0;
  const ph = st.phase * Math.PI * 2;
  const br = Math.sin(st.breath * Math.PI * 2) * (1 - b);
  const bones = new Array(17);
  bones[0] = m4.ident();
  const bob = -(0.02 + 0.02 * run) * Math.cos(ph * 2) * b - 0.01 * b;
  const sway = 0.018 * Math.sin(ph) * b * (1 - run * 0.5);
  const lean = 0.05 * b + 0.16 * run * b;
  // pélvis
  const pelvis = m4.mul(m4.translate(sway, 0.97 + bob, 0), m4.rotY(0.12 * Math.sin(ph) * b));
  bones[1] = pelvis;
  const chest = m4.mul(m4.mul(m4.mul(pelvis, m4.translate(0, 0.15, 0)), m4.rotY(-0.2 * Math.sin(ph) * b)), m4.mul(m4.rotX(lean + br * 0.015), m4.translate(0, br * 0.004, 0)));
  bones[2] = chest;
  bones[3] = m4.mul(chest, m4.mul(m4.translate(0, 0.43, 0.005), m4.rotX(-lean * 0.6 + br * 0.01)));
  // pernas
  const half = (0.3 + 0.18 * run) * b, lift = (0.1 + 0.1 * run) * b;
  for (const [side, th, ph0] of [[1, 10, 0], [-1, 13, 0.5]]) {
    const p = (st.phase + ph0) % 1;
    const swing = p < 0.5, q = swing ? p / 0.5 : (p - 0.5) / 0.5;
    const z = swing ? -Math.cos(q * Math.PI) * half : Math.cos(q * Math.PI) * half;
    const ly = swing ? Math.sin(q * Math.PI) * lift : 0;
    const hip = m4.point(pelvis, [side * 0.096, -0.04, 0]);
    const ankle = [side * 0.11, 0.085 + ly, z + 0.01];
    const { knee, end } = ik(hip, ankle, L.thigh, L.shin, [0, 0, 1]);
    bones[th] = frame(hip, v3.sub(hip, knee), [0, 0, 1]);
    bones[th + 1] = frame(knee, v3.sub(knee, end), [0, 0, 1]);
    const toe = swing ? -0.25 * Math.sin(q * Math.PI) * b : 0;
    bones[th + 2] = m4.mul(m4.translate(end[0], end[1], end[2]), m4.rotX(toe));
  }
  // braços: parado = guarda com as duas mãos; andando = espada baixa na mão direita
  const shL = m4.point(chest, [0.205, 0.35, -0.01]), shR = m4.point(chest, [-0.205, 0.35, -0.01]);
  // espada
  const guardDir = v3.norm([0.12, 0.82, 0.56]);
  const guardGrip = m4.point(chest, [-0.02, -0.02, 0.3]);
  const walkDir = v3.norm([-0.12, -0.42, -0.9 + run * 0.2]);
  const walkHand = v3.add(m4.point(pelvis, [-0.27, -0.12, 0.06 + 0.05 * Math.sin(ph) * b]), [0, 0, 0]);
  const sDir = v3.norm(v3.lerp(guardDir, walkDir, b));
  const rHand = v3.lerp(v3.add(guardGrip, v3.mul(guardDir, 0.04)), walkHand, b);
  const lIdle = v3.add(guardGrip, v3.mul(guardDir, -0.08));
  const lWalk = m4.point(pelvis, [0.25, -0.12, 0.13 * Math.sin(ph + Math.PI) * (1 + run) - 0.02]);
  const lHand = v3.lerp(lIdle, lWalk, b);
  const arm = (sh, hand, ua, side, gripDir) => {
    const { knee: el, end } = ik(sh, hand, L.upper, L.fore + 0.04, [side * 0.4, -0.2, -1]);
    bones[ua] = frame(sh, v3.sub(sh, el), [0, 0, 1]);
    bones[ua + 1] = frame(el, v3.sub(el, end), [0, 0, 1]);
    const hy = gripDir ? v3.norm(v3.cross(gripDir, [side, 0, 0])) : v3.sub(el, end);
    bones[ua + 2] = frame(end, v3.sub(el, end), gripDir || [0, 0, 1]);
    void hy;
  };
  arm(shL, lHand, 4, 1, null);
  arm(shR, rHand, 7, -1, null);
  const swordOrigin = v3.sub(rHand, v3.mul(sDir, 0.02));
  bones[16] = frame(swordOrigin, sDir, [1, 0, 0]);
  return bones;
}

// ─────────────── Capa: tecido simulado (Verlet) ───────────────
export class Cape {
  constructor(atlas, cols = 9, rows = 14) {
    this.cols = cols; this.rows = rows;
    this.w = 0.52; this.h = 1.12;
    this.p = []; this.o = [];
    for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) { const q = [0, 1.48 - j * this.h / (rows - 1), -0.15]; this.p.push(q.slice()); this.o.push(q.slice()); }
    // amostras orgânicas no espaço (u,v) do tecido — duas faces (fora vinho, dentro forro)
    const R = (s => () => { s = s * 16807 % 2147483647; return s / 2147483647; })(91);
    this.samples = [];
    const minD = 0.03, pts = [];
    for (let k = 0; k < 2600; k++) {
      const u = R(), v = R();
      const hem = 0.92 - 0.1 * Math.abs(Math.sin(u * 23)) - 0.07 * (Math.sin(u * 61) > 0.6 ? 1 : 0);
      if (v > hem) continue;
      const x = u * this.w, y = v * this.h;
      if (pts.some(q => (q[0] - x) ** 2 + (q[1] - y) ** 2 < minD * minD)) continue;
      pts.push([x, y]);
      this.samples.push([u, v, R()]);
    }
    this.ps = new PointSet(this.samples.length * 2 + 8);
    this.glyphFold = atlas.get('§');
    this.t = 0;
  }
  /** Prende a borda superior aos ombros (matriz do peito no mundo) e simula. */
  update(dt, chestW, spheres, wind) {
    const { cols, rows, p, o } = this;
    this.t += dt;
    dt = Math.min(dt, 1 / 30);
    for (let i = 0; i < cols; i++) {
      const u = i / (cols - 1);
      const local = [(u - 0.5) * this.w * (0.75 + 0.25 * Math.abs(u - 0.5) * 2), 0.36 - Math.abs(u - 0.5) * 0.05, -0.13 - Math.abs(u - 0.5) * 0.04];
      const w = m4.point(chestW, local);
      p[i] = w; o[i] = w.slice();
    }
    if (!this.inited) {             // nasce pendurada atrás das costas, já no lugar
      this.inited = true;
      for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) {
        const u = i / (cols - 1);
        const w = m4.point(chestW, [(u - 0.5) * this.w, 0.36 - j * this.h / (rows - 1), -0.2 - j * 0.02]);
        p[j * cols + i] = w; o[j * cols + i] = w.slice();
      }
    }
    const fwd = v3.norm([chestW[8], 0, chestW[10]]), c0 = [chestW[12], 0, chestW[14]];
    const g = -9.8 * dt * dt;
    for (let k = cols; k < p.length; k++) {
      const a = p[k], b = o[k];
      const vx = (a[0] - b[0]) * 0.985, vy = (a[1] - b[1]) * 0.985, vz = (a[2] - b[2]) * 0.985;
      const j = Math.floor(k / cols), f = j / (rows - 1);
      const wx = wind[0] * dt * dt * (0.5 + f) * (1 + 0.6 * Math.sin(this.t * 2.1 + k)), wz = wind[2] * dt * dt * (0.5 + f);
      o[k] = a.slice();
      p[k] = [a[0] + vx + wx, a[1] + vy + g, a[2] + vz + wz];
    }
    const rest = this.w / (cols - 1), restV = this.h / (rows - 1);
    for (let it = 0; it < 6; it++) {
      for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) {
        const k = j * cols + i;
        if (i < cols - 1) this._link(k, k + 1, rest, j === 0);
        if (j < rows - 1) this._link(k, k + cols, restV, j === 0);
      }
      for (let k = cols; k < p.length; k++) {
        for (const s of spheres) {
          const d = v3.sub(p[k], s.c), l = v3.len(d);
          if (l < s.r) p[k] = v3.add(s.c, v3.mul(d, s.r / (l || 1)));
        }
        if (p[k][1] < 0.03) p[k][1] = 0.03;
        // não atravessa o corpo: fica atrás do plano do peito
        const d = (p[k][0] - c0[0]) * fwd[0] + (p[k][2] - c0[2]) * fwd[2];
        if (d > -0.13) { const m = d + 0.13; p[k] = [p[k][0] - fwd[0] * m, p[k][1], p[k][2] - fwd[2] * m]; }
      }
    }
    this._emit();
  }
  _link(a, b, rest, pinA) {
    const P = this.p, d = v3.sub(P[b], P[a]), l = v3.len(d) || 1e-6, diff = (l - rest) / l;
    if (pinA && a < this.cols) { if (b >= this.cols) P[b] = v3.sub(P[b], v3.mul(d, diff)); return; }
    const h = v3.mul(d, diff * 0.5);
    P[a] = v3.add(P[a], h); P[b] = v3.sub(P[b], h);
  }
  _at(u, v) {
    const { cols, rows, p } = this;
    const fx = u * (cols - 1), fy = v * (rows - 1);
    const i = Math.min(cols - 2, Math.floor(fx)), j = Math.min(rows - 2, Math.floor(fy));
    const tx = fx - i, ty = fy - j;
    const A = p[j * cols + i], B = p[j * cols + i + 1], C = p[(j + 1) * cols + i], D = p[(j + 1) * cols + i + 1];
    return v3.lerp(v3.lerp(A, B, tx), v3.lerp(C, D, tx), ty);
  }
  _emit() {
    const ps = this.ps; ps.n = 0;
    const e = 0.02;
    for (const [u, v, r] of this.samples) {
      const P = this._at(u, v);
      const du = v3.sub(this._at(Math.min(1, u + e), v), this._at(Math.max(0, u - e), v));
      const dv = v3.sub(this._at(u, Math.min(1, v + e)), this._at(u, Math.max(0, v - e)));
      const n = v3.norm(v3.cross(du, dv)); // face externa (costas do cavaleiro)
      const t = v3.norm(dv);
      const fold = Math.sin(u * Math.PI * 7 + v * 2) > 0.85;
      ps.push(P, n, t, 3, fold ? this.glyphFold : -1, 0, 0, 0.055, r * 1000);
      ps.push(P, [-n[0], -n[1], -n[2]], t, 14, -1, 0, 0, 0.05, r * 1000 + 1);
    }
    return ps;
  }
}
