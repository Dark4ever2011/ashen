// ASHEN — Aviso de golpe (telegrafia): todo inimigo chama tell() no instante em que começa a armar um ataque.
// O jogo registra o que fazer (brilho nos olhos/arma + som curto), sem os inimigos conhecerem o jogo.
let hook = null;
export function setTellHook(fn) { hook = fn; }
export function tell(e, kind = 'light', h = 1.4) { if (hook) hook(e, kind, h); }
