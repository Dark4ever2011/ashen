// ASHEN — The Last Oath · ponto de entrada
// Laço: requestAnimationFrame + delta time; física em passo fixo (60 Hz) com interpolação;
// limite de quadros configurável (o Galaxy A56 tem tela de 120 Hz — 60 é o padrão).

import { CONFIG } from './config.js';
import { loadFonts, fontStatus } from './engine/typography.js';
import { setOffscreenAllowed, offscreenInUse } from './engine/canvas.js';
import { Renderer } from './engine/renderer.js';
import { Camera } from './engine/camera.js';
import { Input } from './engine/input.js';
import { Atmosphere } from './engine/atmosphere.js';
import { Perf } from './engine/perf.js';
import { World } from './world/world.js';
import { ASHEN_GATE } from './world/maps.js';
import { Player } from './entities/player.js';
import { Hud } from './ui/hud.js';
import { Menu } from './ui/menus.js';
import { setupControls, updateInteractButton } from './ui/controls.js';
import { DEFAULT_SETTINGS, effective } from './ui/settings.js';
import { buildLogo } from './ui/logo.js';
import { Save } from './systems/save.js';

const $ = id => document.getElementById(id);
const STEP = 1 / CONFIG.PHYSICS_HZ;
const nextFrame = () => new Promise(r => requestAnimationFrame(() => r()));
const smooth = t => t * t * (3 - 2 * t);
const KIND_TITLE = { gate: 'Portão do Rei', grave: 'Lápide', fallen: 'Cavaleiro caído', pillar: 'Colunata em ruínas', brazier: 'Chama do Último Juramento' };

const game = window.__ASHEN = {
  state: 'loading', time: 0, quality: { castShadows: 'all' },
  settings: null, renderer: null, input: null, world: null, player: null, camera: null,
  atmosphere: null, perf: null, hud: null, menu: null, focus: null, rotateDismissed: false,
};

function setLoad(p, text) {
  $('bar').firstElementChild.style.width = Math.round(p * 100) + '%';
  if (text) $('load-text').textContent = text;
}

async function boot() {
  $('logo').innerHTML = buildLogo();
  setLoad(0.05, 'carregando a fonte tipográfica…');
  await loadFonts();
  setOffscreenAllowed(fontStatus.offscreenFonts);

  game.settings = { ...DEFAULT_SETTINGS, ...(Save.loadSettings() || {}) };
  const canvas = $('screen');
  game.renderer = new Renderer(canvas);
  game.input = new Input(canvas);
  if (game.settings.bindings) game.input.setBindings(game.settings.bindings);
  game.hud = new Hud();
  game.menu = new Menu(game);
  game.perf = new Perf();
  game.perf.onSuggest = ({ first, last }) => {
    if (game.settings.preset !== 'DESEMPENHO') game.hud.toast(`O desempenho caiu de ${first} para ${last} FPS (aquecimento?). Se preferir, use EQUILIBRADA no menu.`, 7000);
  };

  setLoad(0.12, 'erguendo o Reino das Cinzas…');
  const saved = Save.loadGame();
  game.world = new World(ASHEN_GATE, { brazierLit: !!(saved && saved.brazierLit) });
  const sp = saved && Number.isFinite(saved.x) ? saved : ASHEN_GATE.spawn;
  game.player = new Player(sp.x, sp.y);
  game.camera = new Camera();
  game.camera.setBounds(ASHEN_GATE.camera);
  game.atmosphere = new Atmosphere();
  applySettings(false);
  game.camera.snap(game.player.x, game.player.y + framingOffset(game.player.y));

  // Pré-renderiza sprites e o chão visível, mostrando progresso.
  const r = game.renderer;
  let done = false;
  r.begin(game.camera.lerp(1));
  while (!done) {
    done = game.world.prepare(r, 9000, game.player);
    setLoad(0.15 + game.world.progress(r) * 0.7, 'gravando a pedra, o aço e as cinzas…');
    await nextFrame();
  }
  setLoad(0.9, 'levantando a névoa…');
  game.atmosphere.build(r);
  r.begin(game.camera.lerp(1));
  for (let i = 0; i < 12 && (i === 0 || game.world.terrain.pending > 0); i++) { game.world.terrain.draw(r, 6); await nextFrame(); }
  setLoad(1, '');
  $('load-text').textContent = '';

  setupControls(game);
  window.addEventListener('resize', onResize);
  window.visualViewport && window.visualViewport.addEventListener('resize', onResize);
  window.addEventListener('orientationchange', () => setTimeout(onResize, 200));
  document.addEventListener('visibilitychange', () => { if (document.hidden && game.state === 'play') game.save(); });
  $('rotate-ok').onclick = () => { game.rotateDismissed = true; checkRotate(); };

  game.state = 'title';
  document.body.classList.add('title');
  $('loading').classList.add('overlay');
  $('bar').classList.add('hidden');
  const start = $('start');
  start.classList.remove('hidden');
  const touch = matchMedia('(pointer: coarse)').matches;
  $('start-hint').textContent = touch
    ? 'Joystick à esquerda · segure » para correr · ◈ para interagir · ≡ menu'
    : 'WASD/setas para andar · Shift corre · E interage · clique para andar/interagir · Esc menu · F3 desempenho';
  start.onclick = () => beginPlay(touch);
  window.addEventListener('keydown', function k(e) { if (game.state === 'title' && (e.code === 'Enter' || e.code === 'Space')) { window.removeEventListener('keydown', k); beginPlay(false); } });
  requestAnimationFrame(frame);
}

function beginPlay(touch) {
  if (game.state !== 'title') return;
  if (touch) game.fullscreen();
  $('loading').classList.add('fade');
  setTimeout(() => $('loading').classList.add('hidden'), 950);
  game.state = 'play';
  document.body.classList.remove('title');
  game.input.clearAll();
  game.hud.showRegion(ASHEN_GATE);
  checkRotate();
}

function framingOffset(y) {
  const f = ASHEN_GATE.framing;
  const k = Math.max(0, Math.min(1, (f.y0 - y) / (f.y0 - f.y1)));
  return f.dy * smooth(k);
}

function applySettings(save = true) {
  const g = game, s = g.settings, eff = effective(s);
  const changed = g.renderer.resize(eff.renderScale);
  const w = g.world;
  w.lighting.res = eff.lightRes;
  w.lighting.glow = eff.glow;
  w.particles.ashTarget = eff.ash;
  w.particles.secondary = eff.secondary;
  g.atmosphere.detail = eff.fogDetail;
  g.atmosphere.density = eff.fogDensity;
  g.quality.castShadows = eff.castShadows;
  g.input.haptics = s.haptics;
  document.documentElement.style.setProperty('--ctrl', s.controlScale);
  g.hud.showPerf(s.showPerf);
  if (changed && g.state !== 'loading') g.atmosphere.build(g.renderer);
  if (save) Save.saveSettings(s);
}
game.applySettings = applySettings;

let resizeT = 0;
function onResize() {
  clearTimeout(resizeT);
  resizeT = setTimeout(() => { applySettings(false); game.atmosphere.build(game.renderer); checkRotate(); }, 120);
}

function checkRotate() {
  const portrait = window.innerHeight > window.innerWidth * 1.05;
  const touch = matchMedia('(pointer: coarse)').matches;
  $('rotate').classList.toggle('hidden', !(portrait && touch && game.state === 'play' && !game.rotateDismissed));
}

game.fullscreen = () => {
  try {
    const el = document.documentElement;
    const p = el.requestFullscreen ? el.requestFullscreen({ navigationUI: 'hide' }) : null;
    if (p && p.then) p.then(() => { try { screen.orientation.lock('landscape').catch(() => {}); } catch (e) { /* ok */ } }).catch(() => {});
  } catch (e) { /* sem tela cheia (iframe/sandbox) */ }
};

game.save = () => {
  const p = game.player, w = game.world;
  Save.saveGame({ x: Math.round(p.x), y: Math.round(p.y), brazierLit: !!w.state.brazierLit, region: ASHEN_GATE.id });
};
game.rest = () => {
  game.save();
  game.hud.toast('Você descansa. Progresso salvo junto à chama.');
};
game.respawn = () => {
  const b = game.world.props.find(p => p.kind === 'brazier');
  const x = b ? b.x + 70 : ASHEN_GATE.spawn.x, y = b ? b.y + 70 : ASHEN_GATE.spawn.y;
  Object.assign(game.player, { x, y, px: x, py: y, vx: 0, vy: 0, moveTarget: null });
  game.camera.snap(x, y + framingOffset(y));
};
game.resetProgress = () => { Save.clearGame(); game.hud.toast('Progresso apagado. Recarregue a página para recomeçar do início.'); };

function doInteract(prop) {
  const it = prop.interact;
  if (!it) return;
  if (it.run) it.run(game);
  else game.hud.message(it.text, KIND_TITLE[prop.kind] || '', { x: prop.x, y: prop.y });
}

// ─────────────── Atualização (passo fixo) ───────────────
let autosave = 0;
function step(dt) {
  const g = game, input = g.input, p = g.player, r = g.renderer;
  input.poll();
  if (input.take('menu')) { g.menu.toggle(); return; }
  if (input.take('debug')) { g.settings.showPerf = !g.settings.showPerf; applySettings(); }
  // Mouse: segurar anda até o cursor; soltar sobre um objeto anda até ele e interage.
  const m = input.mouse;
  if (m.down) {
    const w = r.screenToWorld(m.x, m.y);
    p.moveTarget = { x: w.x, y: w.y, stop: 12 };
  }
  if (m.click) {
    m.click = false;
    const w = r.screenToWorld(m.clickX, m.clickY);
    const target = g.world.pickAt(w.x, w.y);
    if (target) {
      const at = target.interact.at || target;
      const near = Math.hypot(p.x - at.x, p.y - at.y) < target.interact.r;
      if (near) doInteract(target);
      else p.moveTarget = { x: at.x, y: at.y + 40, stop: target.interact.r * 0.55, onArrive: () => doInteract(target) };
    } else p.moveTarget = { x: w.x, y: w.y, stop: 12 };
  }
  g.focus = g.world.findInteractable(p.x, p.y);
  if (input.take('interact')) {
    if (g.hud.msgOpen) g.hud.advance();
    else if (g.focus) doInteract(g.focus);
  }
  p.update(dt, input, g.world);
  g.world.update(dt, p);
  const vw = r.W / r.S, vh = r.H / r.S / r.tilt;
  g.camera.update(dt, { x: p.x, y: p.y + framingOffset(p.y), vx: p.rvx || 0, vy: p.rvy || 0 }, vw, vh);
  g.hud.update(dt, p);
  autosave += dt;
  if (autosave > 25) { autosave = 0; g.save(); }
}

function titleStep(dt) {
  game.world.update(dt, game.player);
  game.player.rig.updateCape(dt, game.player.view, 0, 0, 0, game.world.time, game.world.windNorm);
  game.player.breath = (game.player.breath + dt / 3.4) % 1;
}

// ─────────────── Desenho ───────────────
// Tempo médio (ms) de cada passe — aparece no painel de desempenho (F3 / menu).
const pass = game.passMs = {};
let tp = 0;
const mark = name => { if (game.syncPasses) game.renderer.ctx.getImageData(0, 0, 1, 1); const n = performance.now(); pass[name] = (pass[name] || 0) * 0.9 + (n - tp) * 0.1; tp = n; };

function render(alpha) {
  const g = game, r = g.renderer, w = g.world, p = g.player;
  const cam = g.camera.lerp(alpha);
  tp = performance.now();
  r.begin(cam);
  w.prepare(r, 5000, p); // streaming + reconstrução gradual após mudança de escala
  mark('cache');
  w.terrain.draw(r, 1);
  mark('chão');
  const pItem = p.drawItem(r, w.painters.get(1), alpha);
  mark('cavaleiro');
  w.drawShadows(r, p, g.quality);
  mark('sombras');
  w.submit(r, pItem, p, 1 / 60);
  r.flush();
  mark('objetos');
  w.particles.feedAsh(worldView(r));
  w.particles.draw(r, w.atlas, false);
  mark('partículas');
  g.atmosphere.drawMist(r, w.time, 0);
  g.atmosphere.drawMist(r, w.time, 1);
  mark('névoa');
  w.lighting.apply(r);
  w.lighting.applyGlow(r);
  mark('luz');
  w.particles.draw(r, w.atlas, true);
  g.atmosphere.drawScreen(r);
  mark('tela');
}

function worldView(r) {
  const v = r.view;
  return { x0: v.x0, x1: v.x1, y0: v.y0 / r.tilt, y1: v.y1 / r.tilt + 300 };
}

// ─────────────── Laço ───────────────
let last = 0, acc = 0, perfT = 0;
function frame(now) {
  requestAnimationFrame(frame);
  const cap = game.settings.fpsCap;
  if (cap && last && now - last < 1000 / cap - 2) return;
  const dt = last ? Math.min(0.1, (now - last) / 1000) : STEP;
  last = now;
  const t0 = performance.now();
  if (game.state === 'play' && !game.menu.open) {
    acc += dt;
    let n = 0;
    while (acc >= STEP && n < 5) { step(STEP); acc -= STEP; n++; }
    if (n >= 5) acc = 0;
  } else if (game.state === 'title') { titleStep(dt); acc = 0; }
  const t1 = performance.now();
  render(game.state === 'play' ? acc / STEP : 1);
  const t2 = performance.now();
  game.perf.frame(now, t1 - t0, t2 - t1);
  // HUD de interação
  const touch = game.input.lastDevice === 'touch';
  const f = game.focus;
  const label = f && f.interact ? (typeof f.interact.prompt === 'function' ? f.interact.prompt() : f.interact.prompt) : '';
  game.hud.setPrompt(game.state === 'play' && !game.menu.open ? label : '', keyLabel(game.input.bindings.interact[0]), touch);
  updateInteractButton(f);
  if (game.settings.showPerf && now - perfT > 250) { perfT = now; game.hud.perfText(perfText()); }
  const m = game.input.mouse;
  if (m.has && !m.down && now % 6 < 1) {
    const wpos = game.renderer.screenToWorld(m.x, m.y);
    game.renderer.canvas.style.cursor = game.world.pickAt(wpos.x, wpos.y) ? 'pointer' : 'crosshair';
  }
}

const keyLabel = c => (c || 'E').replace(/^Key/, '').replace('Enter', '⏎');

function perfText() {
  const g = game, r = g.renderer, w = g.world, rp = g.perf.report();
  const kb = (g.player.rig.cache.bytes() / 1048576).toFixed(1);
  return `FPS ${rp.fps}  (${rp.frameMs} ms)  limite ${g.settings.fpsCap || '∞'}
lógica ${rp.updateMs} ms · desenho ${rp.renderMs} ms
${g.settings.preset} · escala ${Math.round(r.renderScale * 100)}% · ${r.W}×${r.H}px · DPR ${r.dpr}
objetos ${r.stats.items} desenhados · ${r.stats.culled} fora da câmera
partículas ${w.particles.count} · chão ${w.terrain.cache.size} blocos (${w.terrain.built} gerados)
cavaleiro: ${g.player.rig.cache.map.size} quadros (${kb} MB) · ${g.player.view} · canvas do mundo ${w.canvasMB().toFixed(0)} MB
luz ${Math.round(w.lighting.res * 100)}% · ${offscreenInUse() ? 'OffscreenCanvas' : '<canvas>'}
passes ms: ${Object.entries(game.passMs).map(([k, v]) => `${k} ${v.toFixed(1)}`).join(' · ')}
${rp.samples.map(s => `${s.t}s:${s.fps}`).join(' ')}`;
}

// PWA: instala o service worker (ignorado em file:// e em iframes que não permitem).
function registerSW() {
  try {
    if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
      navigator.serviceWorker.register('./service-worker.js').catch(e => console.info('[ASHEN] SW indisponível:', e.message));
    }
  } catch (e) { /* ok */ }
}
registerSW();

boot().catch(err => {
  console.error(err);
  $('load-text').textContent = 'Erro ao iniciar: ' + err.message;
});
