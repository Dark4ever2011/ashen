// Tira screenshot de uma página local com Playwright. Uso:
// node tests/shot.mjs <url> <saida.png> [largura] [altura] [dpr] [esperaMs] [mobile]
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';

const [url, out, w = '1400', h = '1800', dpr = '1', wait = '1500', mobile = '0'] = process.argv.slice(2);
const browser = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await browser.newContext({ viewport: { width: +w, height: +h }, deviceScaleFactor: +dpr, isMobile: mobile === '1', hasTouch: mobile === '1' });
const page = await ctx.newPage();
const logs = [];
page.on('console', m => logs.push(`[${m.type()}] ${m.text()}`));
page.on('pageerror', e => logs.push(`[pageerror] ${e.message}`));
await page.goto(url, { waitUntil: 'load' });
await page.waitForTimeout(+wait);
await page.screenshot({ path: out, fullPage: true });
console.log(logs.join('\n') || '(sem logs)');
await browser.close();
