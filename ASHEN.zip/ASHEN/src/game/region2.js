// ASHEN 3D — Região II · Vale de Orvalho (do outro lado do Portão do Rei).
// O vale fica longe da Região I no espaço do mundo (x ≈ 140): os dois nunca aparecem juntos.
// Dois estados do mesmo lugar: a vila viva (lembrança, muita grama e flores) e a vila em ruínas
// (o presente). Os interiores (casa e nave da igreja) são cômodos separados, mais longe ainda.

import * as S from './sdf.js';
import { MAT } from './glyphs.js';
import { noise3, rng } from './math3d.js';
import { PointSet } from './sampler.js';
import { makeTree } from './trees3d.js';
import { pushFlower } from './veg3d.js';

export const O = { x: 140, z: 0 };                       // origem do vale
const wx = lx => O.x + lx;
export const R2 = { region: 'II · Vale de Orvalho', title: 'A Vila de Orvalho', subtitle: '露の村' };
export const BOUNDS2 = { x0: wx(-12), z0: -33, x1: wx(12), z1: 12.4 };
export const ENTRY = { x: wx(0), z: 10.2 };              // onde se chega pelo portão
export const FIRE = { x: wx(2.6), z: 8.6 };             // fogueira (ponto de salvamento da vila)
export const WELL = { x: wx(0), z: -6.6 };
export const CHURCH = { x: wx(0), z: -28.2, hw: 2.7, hd: 4.6 };
export const CHURCH_DOOR = { x: wx(0), z: CHURCH.z + CHURCH.hd + 0.7 };
/** 4 casas: centro, para que lado fica a porta (±x), giro do telhado. */
export const HOUSES = [
  { x: wx(-6.2), z: -1.8, door: 1 }, { x: wx(6.2), z: -3.4, door: -1 },
  { x: wx(-6.4), z: -11.4, door: 1 }, { x: wx(6.3), z: -12.6, door: -1 },
].map((h, i) => ({ ...h, i, hw: 1.7, hd: 1.5, doorX: h.x + h.door * 1.7, doorOut: { x: h.x + h.door * 2.35, z: h.z } }));
const PATH2 = [[0, 12.6], [0.6, 6], [-0.3, 0], [0.25, -7], [0, -14], [-0.5, -19], [0, CHURCH.z + CHURCH.hd + 0.2]].map(([x, z]) => [wx(x), z]);
const TREES2 = [[-9.5, 7, 41, 1.05], [9.8, 4.5, 42, 1.1], [-10.2, -6, 43, 1.0], [10.3, -8, 44, 1.15], [-9.6, -19, 45, 1.1], [9.5, -21, 46, 1.0], [-6.5, 9.5, 47, 0.9], [6.5, -24, 48, 0.95]]
  .map(([x, z, seed, size]) => ({ x: wx(x), z, seed, size }));
// interiores
export const ROOM = { x: 210, z: 0, hw: 2.5, hd: 2.0 };
export const NAVE = { x: 250, z: 0, hw: 3.0, hd: 5.2 };
export const KNIGHT_SEAT = { x: NAVE.x + 0.95, z: NAVE.z - 3.55 };
export const BASKET = { x: ROOM.x - 1.85, z: ROOM.z - 1.35 };
export const CHEST = { x: ROOM.x + 0.45, z: ROOM.z - 1.6 };

export const groundHeight2 = (x, z) => groundH(x, z);
const groundH = (x, z) => 0.04 * noise3(x * 0.7, 0, z * 0.7) + 0.02 * noise3(x * 2.3, 1, z * 2.3);
function pathDist(x, z) {
  let d = 1e9;
  for (let i = 0; i < PATH2.length - 1; i++) {
    const [ax, az] = PATH2[i], [bx, bz] = PATH2[i + 1], dx = bx - ax, dz = bz - az;
    const t = Math.max(0, Math.min(1, ((x - ax) * dx + (z - az) * dz) / (dx * dx + dz * dz)));
    d = Math.min(d, Math.hypot(x - ax - dx * t, z - az - dz * t));
  }
  return d;
}
const isPath2 = (x, z) => pathDist(x, z) < 0.85 + 0.15 * noise3(x * 2, 4, z * 2) || (Math.hypot(x - WELL.x, z - WELL.z) < 2.6);

// ─────────────── Colisores ───────────────
const boxC = (cx, cz, hw, hd) => ({ type: 'box', x0: cx - hw, z0: cz - hd, x1: cx + hw, z1: cz + hd });
export const COLLIDERS2 = [
  ...HOUSES.map(h => boxC(h.x, h.z, h.hw + 0.05, h.hd + 0.05)),
  boxC(CHURCH.x, CHURCH.z, CHURCH.hw + 0.1, CHURCH.hd + 0.1),
  { type: 'circle', x: CHURCH.x, z: CHURCH.z + CHURCH.hd - 0.4, r: 1.5 },             // torre
  { type: 'circle', x: WELL.x, z: WELL.z, r: 0.85 },
  { type: 'circle', x: FIRE.x, z: FIRE.z, r: 0.45 },
  ...TREES2.map(t => ({ type: 'circle', x: t.x, z: t.z, r: 0.32 * t.size })),
  boxC(wx(-2.2), 12.2, 0.55, 0.5), boxC(wx(2.2), 12.2, 0.55, 0.5),                  // pilares do arco
  { type: 'circle', x: wx(-3.2), z: 1.2, r: 0.55 }, { type: 'circle', x: wx(3.4), z: -8.6, r: 0.7 },   // feno / carroça
];
export const ROOM_COLLIDERS = [
  boxC(ROOM.x - 0.9, ROOM.z - 1.45, 0.75, 0.35),        // mesa
  boxC(ROOM.x + 1.6, ROOM.z - 1.2, 0.6, 0.95),          // cama
  { type: 'circle', x: BASKET.x, z: BASKET.z, r: 0.3 },
  { type: 'box', x0: CHEST.x - 0.45, z0: CHEST.z - 0.3, x1: CHEST.x + 0.45, z1: CHEST.z + 0.3 },
  boxC(ROOM.x - 1.25, ROOM.z + 2.05, 1.0, 0.15), boxC(ROOM.x + 1.25, ROOM.z + 2.05, 1.0, 0.15),   // parede da frente (vão da porta no meio)
];
export const ROOM_BOUNDS = { x0: ROOM.x - ROOM.hw + 0.3, z0: ROOM.z - ROOM.hd + 0.3, x1: ROOM.x + ROOM.hw - 0.3, z1: ROOM.z + ROOM.hd + 0.6 };
export const NAVE_COLLIDERS = [
  ...[-1, 1].flatMap(s => [-1.4, 0.4, 2.2].map(z => boxC(NAVE.x + s * 1.6, NAVE.z + z, 0.85, 0.22))),   // bancos
  boxC(NAVE.x, NAVE.z - 4.55, 1.2, 0.45),                // altar
  { type: 'circle', x: KNIGHT_SEAT.x, z: KNIGHT_SEAT.z, r: 0.5 },
  boxC(NAVE.x - 1.85, NAVE.z + 5.25, 1.2, 0.15), boxC(NAVE.x + 1.85, NAVE.z + 5.25, 1.2, 0.15),
];
export const NAVE_BOUNDS = { x0: NAVE.x - NAVE.hw + 0.3, z0: NAVE.z - NAVE.hd + 0.3, x1: NAVE.x + NAVE.hw - 0.3, z1: NAVE.z + NAVE.hd + 0.6 };

// ─────────────── Chão ───────────────
export function ground2Parts() {
  return [{
    name: 'chão do vale', f: (x, y, z) => y - groundH(x, z) + (isPath2(x, z) ? 0.012 : 0),
    min: [BOUNDS2.x0 - 1.5, -0.12, BOUNDS2.z0 - 1], max: [BOUNDS2.x1 + 1.5, 0.12, BOUNDS2.z1 + 1.2], mat: MAT.GROUND, spacing: 0.14, size: 0.42,
    flowFn: (p) => { const a = (Math.sin(p[0] * 91.7 + p[2] * 47.3) * 43758.5) % 6.28; return [Math.cos(a), 0, Math.sin(a)]; },
    detail: (p) => {
      if (isPath2(p[0], p[2])) return noise3(p[0] * 3, 2, p[2] * 3) > 0.62 ? { mat: MAT.GRAVEL } : { mat: MAT.GROUND, glyph: ['·', ':', '.'][(Math.abs(p[0] * 13 + p[2] * 7) | 0) % 3] };
      if (noise3(p[0] * 4.7, 2, p[2] * 4.7) > 0.74) return { mat: MAT.GRAVEL, glyph: ['°', '•', '·'][(Math.abs(p[2] * 29) | 0) % 3], size: 0.7 };
      if (noise3(p[0] * 3.3, 6, p[2] * 3.3) > 0.72) return { mat: MAT.GRASS2, glyph: [',', '\'', '"'][(Math.abs(p[0] * 31) | 0) % 3], size: 0.75 };
      return noise3(p[0] * 0.5, 7, p[2] * 0.5) > 0.4 ? { mat: MAT.MOSS, size: 0.8 } : null;
    },
  }];
}
export function avoidVeg2(x, z) {
  if (isPath2(x, z)) return true;
  for (const h of HOUSES) if (Math.abs(x - h.x) < h.hw + 0.25 && Math.abs(z - h.z) < h.hd + 0.25) return true;
  if (Math.abs(x - CHURCH.x) < CHURCH.hw + 0.4 && Math.abs(z - CHURCH.z) < CHURCH.hd + 1.6) return true;
  if (Math.hypot(x - FIRE.x, z - FIRE.z) < 1.0 || z > 11.6) return true;
  return COLLIDERS2.some(c => c.type === 'circle' && Math.hypot(x - c.x, z - c.z) < c.r + 0.05);
}

/** Campo: muita grama alta e muitas flores (vila viva) ou grama seca e rala (ruínas). */
export function buildMeadow({ lush, atlas, seed = 9 }) {
  const G = ch => atlas.get(ch);
  const R = rng(seed);
  const ps = new PointSet(90000);
  const area = [BOUNDS2.x0 - 1, BOUNDS2.z0 - 0.5, BOUNDS2.x1 + 1, BOUNDS2.z1];
  const count = lush ? 5200 : 1700;
  const flowerMats = [MAT.FLOWER_R, MAT.FLOWER_Y, MAT.FLOWER_W, MAT.FLOWER_B, MAT.PETAL_P, MAT.FLOWER_R, MAT.FLOWER_W];
  let tufts = 0, flowers = 0, tries = 0;
  while (tufts + flowers < count && tries++ < count * 25) {
    const x = area[0] + R() * (area[2] - area[0]), z = area[1] + R() * (area[3] - area[1]);
    const dens = noise3(x * 0.38, 3, z * 0.38) * 0.7 + noise3(x * 1.5, 9, z * 1.5) * 0.3;
    if (!lush && R() > Math.max(0, dens - 0.3) * 2) continue;
    if (lush && R() > 0.35 + dens) continue;
    if (avoidVeg2(x, z)) continue;
    const y = groundH(x, z);
    // flores: manchas de uma cor só, com hastes que balançam
    const patch = noise3(x * 0.6, 11, z * 0.6);
    if (lush && R() < 0.5) {
      const mat = flowerMats[Math.floor(patch * 17) % flowerMats.length];
      const n = 1 + ((R() * 3) | 0);
      for (let k = 0; k < n; k++) pushFlower(ps, G, x + (R() - 0.5) * 0.3, y, z + (R() - 0.5) * 0.3, R, mat, 1.15 + R() * 0.35, mat === MAT.FLOWER_Y ? MAT.LEATHER : MAT.FLOWER_Y);
      flowers++; continue;
    }
    if (!lush && R() < 0.12) {            // flor seca, cinza e osso
      const h = 0.25 + R() * 0.2, nat = R() * 6.28, sd = R() * 1000;
      for (let s = 0; s < 2; s++) ps.push([x, y, z], [0, 1, 0], [(s + 0.5) / 2.5, h, nat], MAT.GRASS3, -1, 0, 8, 0.07, sd + s);
      ps.push([x, y, z], [0, 1, 0], [1.0, h, nat], MAT.FLOWER, G('⁎'), 0, 8, 0.06, sd + 2);
      flowers++; continue;
    }
    // tufo de grama
    const blades = lush ? 4 + ((R() * 4) | 0) : 2 + ((R() * 3) | 0);
    const tall = lush ? 0.32 + dens * 0.45 + R() * 0.2 : 0.15 + dens * 0.25;
    const mat = lush ? (R() < 0.65 ? MAT.GRASS2 : MAT.GRASS) : (R() < 0.6 ? MAT.GRASS3 : MAT.GRASS);
    const lean = R() * 6.28;
    for (let b = 0; b < blades; b++) {
      const a = R() * 6.28, r = R() * 0.1, h = tall * (0.55 + R() * 0.55);
      const segs = h > 0.3 ? 3 : 2, bx = x + Math.cos(a) * r, bz = z + Math.sin(a) * r, nat = lean + (R() - 0.5) * 1.2, s = R() * 1000;
      for (let k = 0; k < segs; k++) ps.push([bx, y, bz], [0, 1, 0], [(k + 0.5) / segs, h, nat], mat, -1, 0, 8, 0.06 + h * 0.13, s + k * 0.37);
    }
    tufts++;
  }
  return ps;
}

// ─────────────── Peças comuns ───────────────
const plankDetail = (axis = 0, w = 0.22) => (p, n) => {
  const v = axis === 0 ? p[0] : p[2], f = ((v / w) % 1 + 1) % 1;
  if (f < 0.09 && n[1] > 0.6) return { mat: MAT.DARK, glyph: '│', size: 0.8 };
  return noise3(p[0] * 6, p[1] * 6, p[2] * 6) > 0.72 ? { mat: MAT.LEATHER } : null;
};
const timber = (h, wall) => (p, n) => {
  // enxaimel: vigas de madeira sobre o reboco
  const u = Math.abs(n[0]) > 0.6 ? p[2] : p[0];
  const fu = ((u / 1.1) % 1 + 1) % 1;
  if (fu < 0.08 || p[1] < 0.18 || Math.abs(p[1] - h) < 0.1 || Math.abs(p[1] - h * 0.5) < 0.05) return { mat: MAT.WOOD };
  if (Math.abs(fu - 0.5 - (p[1] / h - 0.5) * 0.4) < 0.04 && p[1] > h * 0.5) return { mat: MAT.WOOD };       // escoras diagonais
  return wall ? wall(p, n) : null;
};

/** Uma casa camponesa: enxaimel, telhado de palha, porta voltada para o caminho. */
export function houseParts(h, ruined) {
  const P = [], R = rng(500 + h.i * 7 + (ruined ? 100 : 0));
  const { x: cx, z: cz, hw, hd, door } = h;
  const H = 2.1;
  const doorF = (x, y, z) => Math.max(Math.abs(z - cz) - 0.45, y - 1.75, Math.abs(x - (cx + door * hw)) - 0.4);
  const winF = (x, y, z) => Math.min(Math.max(Math.abs(x - cx) - 0.32, Math.abs(y - 1.3) - 0.28, Math.abs(Math.abs(z - cz) - hd) - 0.3),
    Math.max(Math.abs(z - cz - 0.9 * (h.i % 2 ? 1 : -1)) - 0.3, Math.abs(y - 1.3) - 0.28, Math.abs(x - (cx - door * hw)) - 0.3));
  let walls = S.subtract(S.subtract(S.shell(S.xf(S.box(hw, H / 2, hd), [cx, H / 2, cz]), 0.08), doorF), winF);
  if (ruined) {
    // buracos queimados e um canto desabado
    const holes = (x, y, z) => 0.45 - noise3(x * 1.3 + h.i, y * 1.3, z * 1.3) * 0.9 - Math.max(0, y - 1.2) * 0.25;
    walls = S.subtract(walls, holes);
    const corner = (x, y, z) => Math.hypot(x - (cx - door * hw), y - H, z - (cz + hd * (h.i % 2 ? -1 : 1))) - 1.3;
    walls = S.subtract(walls, corner);
  }
  P.push({ name: 'casa', f: walls, min: [cx - hw - 0.15, -0.05, cz - hd - 0.15], max: [cx + hw + 0.15, H + 0.1, cz + hd + 0.15], mat: MAT.PLASTER, spacing: 0.055, flow: [0, 1, 0],
    keep: (p, n) => n[1] < 0.7,
    detail: timber(H, ruined ? (p) => (noise3(p[0] * 1.8, p[1] * 1.8, p[2] * 1.8) > 0.58 ? { mat: MAT.DARK, glyph: ['·', ',', '\''][(Math.abs(p[1] * 31) | 0) % 3] } : null) : null) });
  // telhado de duas águas (cumeeira ao longo de z), beiral generoso
  const roofF = (x, y, z) => {
    const dx = Math.abs(x - cx), slope = (y - H) + (dx - hw - 0.35) * 0.95;
    return Math.max(Math.abs(slope) - 0.09, Math.abs(z - cz) - hd - 0.35, H - 0.2 - y);
  };
  if (!ruined) {
    P.push({ name: 'telhado de palha', f: roofF, min: [cx - hw - 0.5, H - 0.3, cz - hd - 0.45], max: [cx + hw + 0.5, H + 2.1, cz + hd + 0.45], mat: MAT.THATCH, spacing: 0.06, flow: [0, 1, 0],
      detail: (p) => (Math.abs(p[0] - cx) < 0.12 ? { mat: MAT.WOOD } : (noise3(p[0] * 4, p[1] * 4, p[2] * 4) > 0.7 ? { mat: MAT.MOSS } : null)) });
    // porta de tábuas e janelas acesas
    const dX = cx + door * hw;
    P.push({ name: 'porta', f: S.xf(S.box(0.04, 0.86, 0.42), [dX + door * 0.02, 0.87, cz]), min: [dX - 0.1, 0, cz - 0.5], max: [dX + 0.1, 1.8, cz + 0.5], mat: MAT.WOOD, spacing: 0.035, flow: [0, 1, 0],
      detail: (p) => (Math.abs(((p[2] - cz) / 0.14 % 1 + 1) % 1) < 0.12 ? { mat: MAT.DARK, glyph: '│' } : (Math.abs(p[1] - 0.9) < 0.04 && Math.abs(p[2] - cz - 0.3) < 0.04 ? { mat: MAT.IRON } : null)) });
    P.push({ name: 'janelas acesas', f: (x, y, z) => winF(x, y, z) + 0.06, min: [cx - hw - 0.1, 0.9, cz - hd - 0.1], max: [cx + hw + 0.1, 1.7, cz + hd + 0.1], mat: MAT.EMBER, spacing: 0.05, flow: [0, 1, 0],
      keep: (p) => Math.abs(Math.abs(p[0] - cx) - hw) < 0.1 || Math.abs(Math.abs(p[2] - cz) - hd) < 0.1, detail: () => ({ mat: MAT.EMBER, glyph: ['¦', '|', '#'][(R() * 3) | 0] }) });
    // chaminé de pedra
    const chx = cx - door * (hw - 0.4), chz = cz - hd + 0.5;
    P.push({ name: 'chaminé', f: S.xf(S.box(0.25, 1.6, 0.25), [chx, 1.6, chz]), min: [chx - 0.3, 0, chz - 0.3], max: [chx + 0.3, 3.3, chz + 0.3], mat: MAT.STONE, spacing: 0.045, flow: [1, 0, 0],
      detail: (p, n) => ((p[1] / 0.25 % 1) < 0.15 ? { mat: MAT.DARK, glyph: '─' } : null) });
  } else {
    // caibros carbonizados e restos de palha
    const rafters = S.union(...[-1, -0.35, 0.3, 0.95].map(k => (x, y, z) => {
      const zz = cz + k * hd, broken = (k * 7 + h.i) % 2 > 1 ? 0.45 : 0;
      return Math.max(Math.abs(z - zz) - 0.06, Math.abs((y - H) + (Math.abs(x - cx) - hw - 0.35) * 0.95) - 0.06, Math.abs(x - cx) - hw - 0.3 + broken * (x > cx ? 1 : 0) * 2, H - 0.2 - y);
    }));
    P.push({ name: 'caibros queimados', f: rafters, min: [cx - hw - 0.5, H - 0.3, cz - hd - 0.1], max: [cx + hw + 0.5, H + 2.1, cz + hd + 0.1], mat: MAT.DARK, spacing: 0.04, flow: [1, 0, 0],
      detail: (p) => (noise3(p[0] * 5, p[1] * 5, p[2] * 5) > 0.6 ? { mat: MAT.WOOD } : (R() < 0.04 ? { mat: MAT.EMBER, glyph: '·' } : null)) });
    P.push({ name: 'palha caída', f: (x, y, z) => Math.max(roofF(x, y, z), 0.4 - noise3(x * 1.5, y * 1.5, z * 1.5 + 3)), min: [cx - hw - 0.5, H - 0.3, cz - hd - 0.45], max: [cx + hw + 0.5, H + 2.1, cz + hd + 0.45], mat: MAT.THATCH, spacing: 0.07, flow: [0, 1, 0],
      detail: () => ({ mat: R() < 0.5 ? MAT.DARK : MAT.THATCH }) });
    // escombros no chão e a porta arrebentada
    P.push({ name: 'escombros', f: (x, y, z) => Math.hypot((x - cx + door * 0.5) / 1.1, y / 0.3, (z - cz) / 1.0) - 1 + 0.4 * noise3(x * 3, y * 3, z * 3), min: [cx - hw, -0.05, cz - hd], max: [cx + hw, 0.5, cz + hd], mat: MAT.DARK, spacing: 0.05, flow: [1, 0, 0],
      detail: (p) => (noise3(p[0] * 4, 1, p[2] * 4) > 0.55 ? { mat: MAT.WOOD } : null) });
    const dX = cx + door * (hw + 0.55);
    P.push({ name: 'porta caída', f: S.xf(S.box(0.42, 0.03, 0.86, 0.01), [dX, 0.05, cz + 0.3], [0, 0.3, 0.1]), min: [dX - 0.6, -0.05, cz - 0.8], max: [dX + 0.6, 0.25, cz + 1.4], mat: MAT.WOOD, spacing: 0.035, flow: [0, 0, 1], detail: plankDetail(0, 0.16) });
  }
  return P;
}

function wellParts(ruined) {
  const { x, z } = WELL, P = [];
  const ring = (px, py, pz) => Math.max(Math.abs(Math.hypot(px - x, pz - z) - 0.72) - 0.14, Math.abs(py - 0.38) - 0.38);
  P.push({ name: 'poço', f: ring, min: [x - 0.95, -0.02, z - 0.95], max: [x + 0.95, 0.8, z + 0.95], mat: MAT.STONE, spacing: 0.04, flow: [1, 0, 0],
    detail: (p) => ((p[1] / 0.2 % 1) < 0.14 ? { mat: MAT.DARK, glyph: '─' } : (noise3(p[0] * 6, p[1] * 6, p[2] * 6) > 0.68 ? { mat: MAT.MOSS } : null)) });
  P.push({ name: 'água do poço', f: (px, py, pz) => Math.max(Math.hypot(px - x, pz - z) - 0.58, Math.abs(py - 0.5) - 0.01), min: [x - 0.6, 0.45, z - 0.6], max: [x + 0.6, 0.55, z + 0.6], mat: ruined ? MAT.DARK : MAT.WATER, spacing: 0.06, flow: [1, 0, 0] });
  if (!ruined) {
    const posts = S.union(S.capsule([x - 0.78, 0.6, z], [x - 0.78, 2.0, z], 0.05), S.capsule([x + 0.78, 0.6, z], [x + 0.78, 2.0, z], 0.05), S.capsule([x - 0.85, 1.75, z], [x + 0.85, 1.75, z], 0.04));
    const roof = (px, py, pz) => Math.max(Math.abs((py - 2.25) + Math.abs(pz - z) * 0.7) - 0.05, Math.abs(px - x) - 1.0, Math.abs(pz - z) - 0.75);
    P.push({ name: 'sarilho', f: S.union(posts, roof), min: [x - 1.1, 0.5, z - 0.85], max: [x + 1.1, 2.4, z + 0.85], mat: MAT.WOOD, spacing: 0.035, flow: [0, 1, 0] });
    P.push({ name: 'balde', f: S.xf(S.cylinder(0.12, 0.12, 0.02), [x + 0.45, 0.9, z + 0.55]), min: [x + 0.3, 0.75, z + 0.4], max: [x + 0.6, 1.05, z + 0.7], mat: MAT.WOOD, spacing: 0.02, flow: [0, 1, 0], detail: (p) => (Math.abs(p[1] - 0.95) < 0.02 ? { mat: MAT.IRON } : null) });
  } else {
    P.push({ name: 'sarilho caído', f: S.union(S.capsule([x + 0.9, 0.05, z - 0.4], [x + 2.1, 0.08, z + 0.5], 0.05), S.capsule([x - 1.4, 0.05, z + 0.6], [x - 0.8, 0.5, z + 0.1], 0.05)), min: [x - 1.5, -0.05, z - 0.5], max: [x + 2.2, 0.6, z + 0.7], mat: MAT.DARK, spacing: 0.03, flow: [1, 0, 0] });
  }
  return P;
}

/** Entrada do vale: o outro lado do portão (arco em ruínas com 門) e a fogueira de descanso. */
function entranceParts() {
  const P = [];
  const z0 = 12.5;
  const pillar = s => S.xf(S.box(0.5, 1.9, 0.45), [wx(s * 2.2), 1.9, z0]);
  const arch = (x, y, z) => Math.max(Math.abs(Math.hypot(x - wx(0), y - 3.1) - 2.05) - 0.3, Math.abs(z - z0) - 0.4, 3.0 - y);
  P.push({ name: 'arco do vale', f: S.subtract(S.union(pillar(-1), pillar(1), arch), (x, y, z) => 0.55 - noise3(x * 0.9, y * 0.9, z * 0.9) - (y > 3.6 && x > wx(0.6) ? 0.4 : 0)), min: [wx(-2.9), -0.05, z0 - 0.5], max: [wx(2.9), 5.6, z0 + 0.5], mat: MAT.STONE, spacing: 0.06, flow: [1, 0, 0],
    detail: (p, n) => ((p[1] / 0.38 % 1) < 0.12 && n[2] > 0.5 ? { mat: MAT.DARK, glyph: '─' } : (noise3(p[0] * 2, p[1] * 2, 5) > 0.66 ? { mat: MAT.MOSS } : null)),
    decals: [{ p: [wx(0), 4.85, z0 - 0.42], n: [0, 0, -1], glyph: '門', mat: MAT.GOLD, size: 0.36, clear: 0.24 }] });
  const { x: fx, z: fz } = FIRE;
  const stones = S.union(...[0, 1, 2, 3, 4, 5, 6].map(i => { const a = i * 0.9; return S.xf(S.ellipsoid(0.12, 0.08, 0.1), [fx + Math.cos(a) * 0.38, 0.06, fz + Math.sin(a) * 0.38]); }));
  const logs = S.union(S.capsule([fx - 0.28, 0.08, fz - 0.15], [fx + 0.25, 0.18, fz + 0.1], 0.05), S.capsule([fx + 0.2, 0.08, fz - 0.25], [fx - 0.15, 0.2, fz + 0.22], 0.05), S.capsule([fx - 0.05, 0.08, fz + 0.3], [fx + 0.05, 0.22, fz - 0.28], 0.045));
  P.push({ name: 'fogueira', f: stones, min: [fx - 0.55, -0.02, fz - 0.55], max: [fx + 0.55, 0.2, fz + 0.55], mat: MAT.STONE, spacing: 0.025, flow: [1, 0, 0] });
  P.push({ name: 'lenha', f: logs, min: [fx - 0.4, 0, fz - 0.4], max: [fx + 0.4, 0.3, fz + 0.4], mat: MAT.WOOD, spacing: 0.02, flow: [1, 0, 0], detail: (p) => (p[1] < 0.13 ? { mat: MAT.EMBER, flags: 2 } : null) });
  return P;
}

/** Igreja de pedra: nave alta, portal ogival com rosácea ✠, torre do sino na frente. */
function churchParts() {
  const P = [], { x: cx, z: cz, hw, hd } = CHURCH;
  const H = 3.6, front = cz + hd;
  const doorF = (x, y, z) => Math.max(Math.min(Math.max(Math.abs(x - cx) - 0.62, y - 1.7), Math.hypot(x - cx, (y - 1.7) * 0.9) - 0.62), Math.abs(z - front) - 0.6);
  const winF = (x, y, z) => Math.max(Math.abs(((z - cz + 20) % 2.0) - 1.0) - 0.18, Math.abs(y - 2.2) - 0.65, Math.abs(Math.abs(x - cx) - hw) - 0.3, Math.abs(z - cz) - hd + 0.8);
  const nave = S.subtract(S.subtract(S.shell(S.xf(S.box(hw, H / 2, hd), [cx, H / 2, cz]), 0.18), doorF), winF);
  const butt = S.union(...[-1, 1].flatMap(s => [-3, -1, 1, 3].map(k => S.intersect(S.xf(S.box(0.2, 1.4, 0.25), [cx + s * (hw + 0.2), 1.4, cz + k * 1.1]), (x, y) => y - 2.8 + Math.abs(x - cx) * 0.3 - hw * 0.3))));
  P.push({ name: 'nave', f: S.union(nave, butt), min: [cx - hw - 0.5, -0.05, cz - hd - 0.3], max: [cx + hw + 0.5, H + 0.1, cz + hd + 0.3], mat: MAT.STONE, spacing: 0.06, flow: [1, 0, 0],
    keep: (p, n) => n[1] < 0.7,
    detail: (p, n) => {
      if ((p[1] / 0.4 % 1) < 0.1) return { mat: MAT.DARK, glyph: '─', size: 0.85 };
      if (Math.abs(p[2] - front) < 0.25 && Math.abs(p[0] - cx) < 0.9 && p[1] < 2.5) return { mat: MAT.BONE };
      return noise3(p[0] * 0.9, p[1] * 0.9, p[2] * 0.9) > 0.68 ? { mat: MAT.MOSS } : null;
    },
    decals: [{ p: [cx, 2.95, front + 0.2], n: [0, 0, 1], glyph: '✠', mat: MAT.GOLD, size: 0.5, clear: 0.34 }] });
  const roof = (x, y, z) => Math.max(Math.abs((y - H) + (Math.abs(x - cx) - hw - 0.3) * 1.25) - 0.1, Math.abs(z - cz) - hd - 0.25, H - 0.3 - y);
  P.push({ name: 'telhado da igreja', f: S.subtract(roof, (x, y, z) => Math.hypot(x - cx - 1, y - H - 1.5, z - cz + 1.5) - 1.1), min: [cx - hw - 0.5, H - 0.4, cz - hd - 0.35], max: [cx + hw + 0.5, H + 3.8, cz + hd + 0.35], mat: MAT.IRON, spacing: 0.07, flow: [0, 1, 0],
    detail: (p) => (((p[1] * 5) % 1) < 0.15 ? { mat: MAT.DARK, glyph: '═', size: 0.85 } : null) });
  // torre do sino
  const tz = front - 0.4, TH = 7.2;
  const tower = S.subtract(S.xf(S.box(0.95, TH / 2, 0.95), [cx, TH / 2, tz]), S.union(
    S.xf(S.box(0.5, 0.55, 1.2), [cx, 5.9, tz]), S.xf(S.box(1.2, 0.55, 0.5), [cx, 5.9, tz])));
  const spire = (x, y, z) => Math.max(Math.max(Math.abs(x - cx), Math.abs(z - tz)) - Math.max(0, (TH + 2.8 - y) * 0.36), TH - y, y - TH - 2.8);
  P.push({ name: 'torre do sino', f: S.union(S.subtract(tower, doorF), spire), min: [cx - 1.1, -0.05, tz - 1.1], max: [cx + 1.1, TH + 2.9, tz + 1.1], mat: MAT.STONE, spacing: 0.065, flow: [0, 1, 0],
    detail: (p) => (p[1] > TH ? { mat: MAT.IRON } : ((p[1] / 0.4 % 1) < 0.1 ? { mat: MAT.DARK, glyph: '─', size: 0.85 } : null)),
    decals: [{ p: [cx, TH + 3.0, tz], n: [0, 1, 0.3], glyph: '†', mat: MAT.IRON, size: 0.45 }] });
  P.push({ name: 'sino', f: S.intersect(S.shell(S.xf(S.ellipsoid(0.3, 0.38, 0.3), [cx, 5.9, tz]), 0.03), S.below(6.15)), min: [cx - 0.35, 5.4, tz - 0.35], max: [cx + 0.35, 6.3, tz + 0.35], mat: MAT.BRONZE, spacing: 0.025, flow: [0, 1, 0] });
  // portas de carvalho (fechadas)
  P.push({ name: 'portal', f: (x, y, z) => Math.max(doorF(x, y, z) + 0.02, Math.abs(z - front + 0.08) - 0.04), min: [cx - 0.7, 0, front - 0.2], max: [cx + 0.7, 2.4, front + 0.1], mat: MAT.WOOD, spacing: 0.035, flow: [0, 1, 0],
    detail: (p) => (Math.abs(p[0] - cx) < 0.02 ? { mat: MAT.DARK, glyph: '│' } : ((p[1] % 0.45) < 0.05 ? { mat: MAT.IRON } : null)) });
  return P;
}

/** Enfeites da vila viva: feno, barris, carroça, cerca, varal. Ou os destroços da vila morta. */
function propsParts(ruined) {
  const P = [];
  const hay = S.xf(S.ellipsoid(0.55, 0.45, 0.55), [wx(-3.2), 0.3, 1.2]);
  const cart = (x, z, rot, over) => S.xf(S.union(S.xf(S.box(0.9, 0.12, 0.5, 0.02), [0, 0.6, 0]), S.xf(S.torus(0.35, 0.05), [0.5, 0.38, 0.55], [Math.PI / 2, 0, 0]), S.xf(S.torus(0.35, 0.05), [0.5, 0.38, -0.55], [Math.PI / 2, 0, 0]), S.capsule([-0.9, 0.55, 0.15], [-1.9, 0.35, 0.15], 0.04), S.capsule([-0.9, 0.55, -0.15], [-1.9, 0.35, -0.15], 0.04)), [x, 0, z], [over ? 1.35 : 0, rot, 0]);
  if (!ruined) {
    P.push({ name: 'feno', f: S.smooth(0.15, hay, S.xf(S.ellipsoid(0.4, 0.35, 0.4), [wx(-2.6), 0.22, 1.7])), min: [wx(-3.9), -0.05, 0.4], max: [wx(-2.0), 0.85, 2.3], mat: MAT.THATCH, spacing: 0.045, flow: [0, 1, 0] });
    P.push({ name: 'carroça', f: cart(wx(3.4), -8.6, 0.3, false), min: [wx(1.0), -0.05, -9.8], max: [wx(4.8), 1.1, -7.4], mat: MAT.WOOD, spacing: 0.035, flow: [1, 0, 0], detail: plankDetail(0, 0.2) });
    for (const [bx, bz] of [[-4.4, -1.0], [-4.6, -0.4], [4.2, -12.0], [-4.3, -12.2]]) {
      const f = (x, y, z) => Math.max(Math.hypot(x - wx(bx), z - bz) - 0.26 - 0.04 * Math.sin(Math.PI * y / 0.8), Math.abs(y - 0.4) - 0.4);
      P.push({ name: 'barril', f, min: [wx(bx) - 0.35, -0.02, bz - 0.35], max: [wx(bx) + 0.35, 0.85, bz + 0.35], mat: MAT.WOOD, spacing: 0.03, flow: [0, 1, 0], detail: (p) => (Math.abs(p[1] - 0.15) < 0.03 || Math.abs(p[1] - 0.65) < 0.03 ? { mat: MAT.IRON } : null) });
    }
    // cerca baixa ao longo do caminho
    for (const s of [-1, 1]) {
      const fx = wx(s * 2.4);
      const f = (x, y, z) => Math.min(Math.max(Math.abs(((z + 50) % 1.2) - 0.6) - 0.05, Math.abs(x - fx) - 0.05, Math.abs(y - 0.45) - 0.45), Math.max(Math.abs(x - fx) - 0.035, Math.min(Math.abs(y - 0.35), Math.abs(y - 0.72)) - 0.035));
      P.push({ name: 'cerca', f: (x, y, z) => Math.max(f(x, y, z), Math.abs(z - 4.5) - 3.0), min: [fx - 0.1, -0.02, 1.4], max: [fx + 0.1, 0.95, 7.6], mat: MAT.WOOD, spacing: 0.03, flow: [0, 1, 0] });
    }
    // varal com panos coloridos entre duas casas
    const line = S.capsule([wx(-4.4), 1.6, -5.6], [wx(-4.4), 1.6, -7.8], 0.01);
    P.push({ name: 'varal', f: S.union(line, S.capsule([wx(-4.4), 0, -5.6], [wx(-4.4), 1.7, -5.6], 0.03), S.capsule([wx(-4.4), 0, -7.8], [wx(-4.4), 1.7, -7.8], 0.03)), min: [wx(-4.5), -0.02, -7.9], max: [wx(-4.3), 1.75, -5.5], mat: MAT.WOOD, spacing: 0.025, flow: [0, 1, 0] });
    [-6.0, -6.7, -7.4].forEach((z, i) => P.push({ name: 'pano', f: S.xf(S.box(0.01, 0.28, 0.25), [wx(-4.4), 1.3, z]), min: [wx(-4.45), 0.95, z - 0.3], max: [wx(-4.35), 1.62, z + 0.3], mat: [MAT.LINEN, MAT.WOOL, MAT.CLOTH][i], spacing: 0.03, flow: [0, 1, 0] }));
  } else {
    P.push({ name: 'feno queimado', f: S.xf(S.ellipsoid(0.6, 0.18, 0.6), [wx(-3.2), 0.08, 1.2]), min: [wx(-3.9), -0.05, 0.5], max: [wx(-2.5), 0.3, 1.9], mat: MAT.DARK, spacing: 0.045, flow: [1, 0, 0] });
    P.push({ name: 'carroça virada', f: cart(wx(3.4), -8.6, 0.9, true), min: [wx(1.0), -0.05, -10.2], max: [wx(5.2), 1.4, -7.0], mat: MAT.WOOD, spacing: 0.035, flow: [1, 0, 0], detail: (p) => (noise3(p[0] * 5, p[1] * 5, p[2] * 5) > 0.55 ? { mat: MAT.DARK } : null) });
    for (const [bx, bz] of [[-4.4, -1.0], [4.2, -12.0]]) {
      const f = (x, y, z) => Math.max(Math.hypot(x - wx(bx), z - bz) - 0.27, Math.abs(y - 0.2) - 0.2 - 0.15 * noise3(x * 9, 1, z * 9), -(Math.hypot(x - wx(bx), z - bz) - 0.22));
      P.push({ name: 'barril partido', f, min: [wx(bx) - 0.35, -0.02, bz - 0.35], max: [wx(bx) + 0.35, 0.6, bz + 0.35], mat: MAT.WOOD, spacing: 0.03, flow: [0, 1, 0] });
    }
    // marcas de sangue seco no chão perto da igreja
    for (let i = 0; i < 5; i++) {
      const sx = wx(-1 + i * 0.5), sz = -21 + (i % 2) * 0.6;
      P.push({ name: 'sangue', f: (x, y, z) => Math.max(Math.hypot((x - sx) / 0.35, (z - sz) / 0.2) - 1 + 0.4 * noise3(x * 6, 0, z * 6), Math.abs(y - 0.02) - 0.01), min: [sx - 0.45, 0, sz - 0.3], max: [sx + 0.45, 0.05, sz + 0.3], mat: MAT.BLOOD, spacing: 0.04, flow: [1, 0, 0] });
    }
  }
  return P;
}

/** Peças fixas do vale em cada estado (a igreja e a entrada entram nos dois). */
export function valleyParts(ruined) {
  return [...entranceParts(), ...churchParts(), ...wellParts(ruined), ...HOUSES.flatMap(h => houseParts(h, ruined)), ...propsParts(ruined)];
}
export function valleyTrees(ruined) {
  return TREES2.map((t, i) => makeTree(t.x, t.z, t.seed + (ruined ? 200 : 0), t.size, ruined ? 'dead' : (i % 3 === 2 ? 'autumn' : 'green')));
}

// ─────────────── Interiores ───────────────
/** Casa por dentro: tábuas, paredes de reboco, mesa, cama, lareira fria, cesto de panos. */
export function roomParts() {
  const P = [], { x: cx, z: cz, hw, hd } = ROOM;
  P.push({ name: 'assoalho', f: (x, y, z) => Math.max(y, -0.06 - y, Math.abs(x - cx) - hw - 0.1, Math.abs(z - cz) - hd - 0.3), min: [cx - hw - 0.2, -0.08, cz - hd - 0.4], max: [cx + hw + 0.2, 0.02, cz + hd + 0.4], mat: MAT.WOOD, spacing: 0.06, flow: [0, 0, 1],
    keep: (p, n) => n[1] > 0.5, detail: plankDetail(0, 0.24) });
  // paredes: fundo e esquerda altas, direita meia altura, frente baixa (a câmera vê por cima)
  const wall = (x0, z0, x1, z1, h) => (x, y, z) => Math.max(Math.abs(x - (x0 + x1) / 2) - Math.abs(x1 - x0) / 2 - 0.1, Math.abs(z - (z0 + z1) / 2) - Math.abs(z1 - z0) / 2 - 0.1, Math.abs(y - h / 2) - h / 2);
  const walls = S.union(wall(cx - hw, cz - hd, cx + hw, cz - hd, 2.5), wall(cx - hw, cz - hd, cx - hw, cz + hd, 2.5), wall(cx + hw, cz - hd, cx + hw, cz + hd, 1.0),
    S.subtract(wall(cx - hw, cz + hd, cx + hw, cz + hd, 0.55), (x) => Math.abs(x - cx) - 0.45));
  P.push({ name: 'paredes', f: walls, min: [cx - hw - 0.2, -0.02, cz - hd - 0.2], max: [cx + hw + 0.2, 2.6, cz + hd + 0.2], mat: MAT.PLASTER, spacing: 0.05, flow: [0, 1, 0],
    detail: timber(2.5, (p) => (noise3(p[0] * 2, p[1] * 2, p[2] * 2) > 0.62 ? { mat: MAT.DARK, glyph: '·' } : null)),
    decals: [{ p: [cx - hw + 0.12, 1.9, cz - hd + 0.15], n: [1, 0, 1], glyph: '#', mat: MAT.BONE, size: 0.4, flags: 0 }] });
  // mesa e banco
  const tx = cx - 0.9, tz = cz - 1.45;
  const table = S.union(S.xf(S.box(0.7, 0.04, 0.32, 0.01), [tx, 0.74, tz]), ...[[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([a, b]) => S.xf(S.box(0.04, 0.36, 0.04), [tx + a * 0.6, 0.36, tz + b * 0.25])),
    S.xf(S.box(0.6, 0.03, 0.12), [tx, 0.42, tz + 0.55]), S.xf(S.box(0.03, 0.2, 0.08), [tx - 0.5, 0.2, tz + 0.55]), S.xf(S.box(0.03, 0.2, 0.08), [tx + 0.5, 0.2, tz + 0.55]));
  P.push({ name: 'mesa', f: table, min: [tx - 0.8, -0.02, tz - 0.4], max: [tx + 0.8, 0.8, tz + 0.75], mat: MAT.WOOD, spacing: 0.025, flow: [1, 0, 0], detail: plankDetail(2, 0.16) });
  P.push({ name: 'vela', f: S.xf(S.cylinder(0.025, 0.06, 0.005), [tx + 0.3, 0.84, tz]), min: [tx + 0.25, 0.76, tz - 0.05], max: [tx + 0.35, 0.92, tz + 0.05], mat: MAT.BONE, spacing: 0.012, flow: [0, 1, 0] });
  P.push({ name: 'tigela', f: S.intersect(S.shell(S.xf(S.sphere(0.09), [tx - 0.25, 0.84, tz]), 0.01), S.below(0.84)), min: [tx - 0.36, 0.74, tz - 0.11], max: [tx - 0.14, 0.86, tz + 0.11], mat: MAT.WOOD, spacing: 0.014, flow: [1, 0, 0] });
  // cama de palha com cobertor
  const bx = cx + 1.6, bz = cz - 1.2;
  P.push({ name: 'cama', f: S.union(S.xf(S.box(0.5, 0.15, 0.9, 0.02), [bx, 0.22, bz]), S.xf(S.box(0.5, 0.3, 0.04), [bx, 0.3, bz - 0.88])), min: [bx - 0.6, -0.02, bz - 1.0], max: [bx + 0.6, 0.62, bz + 1.0], mat: MAT.WOOD, spacing: 0.03, flow: [0, 0, 1] });
  P.push({ name: 'colchão', f: S.xf(S.box(0.44, 0.07, 0.82, 0.05), [bx, 0.42, bz + 0.03]), min: [bx - 0.5, 0.32, bz - 0.85], max: [bx + 0.5, 0.52, bz + 0.9], mat: MAT.LINEN, spacing: 0.03, flow: [0, 0, 1],
    detail: (p) => (p[2] > bz + 0.1 ? { mat: MAT.WOOL } : null) });
  // lareira fria no canto
  const hx = cx - hw + 0.45, hz = cz - 0.2;
  P.push({ name: 'lareira', f: S.subtract(S.xf(S.box(0.35, 0.7, 0.55), [hx, 0.7, hz]), S.xf(S.box(0.3, 0.35, 0.35), [hx + 0.15, 0.35, hz])), min: [hx - 0.4, -0.02, hz - 0.6], max: [hx + 0.4, 1.45, hz + 0.6], mat: MAT.STONE, spacing: 0.035, flow: [1, 0, 0],
    detail: (p) => (p[1] < 0.1 && p[0] > hx ? { mat: MAT.DARK, glyph: '·' } : null) });
  // cesto de panos (onde pode estar a atadura)
  const { x: kx, z: kz } = BASKET;
  P.push({ name: 'cesto', f: S.subtract(S.xf(S.cylinder(0.24, 0.17, 0.02), [kx, 0.17, kz]), S.xf(S.cylinder(0.2, 0.2), [kx, 0.32, kz])), min: [kx - 0.3, -0.02, kz - 0.3], max: [kx + 0.3, 0.36, kz + 0.3], mat: MAT.THATCH, spacing: 0.02, flow: [1, 0, 0] });
  P.push({ name: 'panos', f: S.xf(S.ellipsoid(0.2, 0.08, 0.2), [kx, 0.3, kz]), min: [kx - 0.24, 0.2, kz - 0.24], max: [kx + 0.24, 0.4, kz + 0.24], mat: MAT.LINEN, spacing: 0.02, flow: [1, 0, 0], detail: (p) => (noise3(p[0] * 30, p[1] * 30, p[2] * 30) > 0.6 ? { mat: MAT.WOOL } : null) });
  // teias nos cantos
  for (const [ax, az] of [[cx - hw + 0.1, cz - hd + 0.1], [cx + hw - 0.1, cz - hd + 0.1]]) P.push({ name: 'teia', f: (x, y, z) => Math.max(Math.abs((x - ax) + (z - az) * (ax < cx ? -1 : 1)) - 0.01, Math.hypot(x - ax, y - 2.4, z - az) - 0.55), min: [ax - 0.55, 1.85, az - 0.05], max: [ax + 0.55, 2.5, az + 0.55], mat: MAT.BONE, spacing: 0.04, flow: [1, 1, 0], detail: () => ({ mat: MAT.BONE, glyph: ['·', '╲', '/', '·'][(Math.random() * 4) | 0] }) });
  return P;
}

/** Baú de madeira com cintas de ferro. Corpo no mundo; a tampa (osso 1) gira na dobradiça de trás. */
export function chestParts() {
  const { x: cx, z: cz } = CHEST;
  const straps = (p, n) => (Math.abs(Math.abs(p[0] - cx) - 0.28) < 0.035 || Math.abs(p[1] - 0.06) < 0.025 ? { mat: MAT.IRON } : (Math.abs(p[0] - cx) < 0.04 && Math.abs(p[1] - 0.4) < 0.06 && n[2] > 0.5 ? { mat: MAT.GOLD } : null));
  const body = S.subtract(S.xf(S.box(0.42, 0.22, 0.25, 0.015), [cx, 0.23, cz]), S.xf(S.box(0.38, 0.22, 0.21), [cx, 0.45, cz]));
  // tampa arredondada, no espaço da dobradiça (origem na borda de trás, em cima)
  const lid = S.intersect(S.xf(S.cylinder(0.25, 0.42, 0.01), [0, 0, 0.25], [0, 0, Math.PI / 2]), (x, y) => -y);
  return [
    { name: 'baú', f: body, min: [cx - 0.46, -0.02, cz - 0.3], max: [cx + 0.46, 0.46, cz + 0.3], mat: MAT.WOOD, spacing: 0.022, flow: [1, 0, 0], detail: (p, n) => straps(p, n) || plankDetail(0, 0.12)(p, n) },
    { name: 'tampa', bone: 1, f: lid, min: [-0.46, -0.02, -0.03], max: [0.46, 0.28, 0.53], mat: MAT.WOOD, spacing: 0.022, flow: [1, 0, 0],
      detail: (p) => (Math.abs(Math.abs(p[0]) - 0.28) < 0.035 ? { mat: MAT.IRON } : null) },
    { name: 'moedas', bone: 0, f: S.xf(S.ellipsoid(0.3, 0.05, 0.16), [cx, 0.3, cz]), min: [cx - 0.34, 0.24, cz - 0.2], max: [cx + 0.34, 0.37, cz + 0.2], mat: MAT.GOLD, spacing: 0.03, flow: [1, 0, 0] },
  ];
}
export const CHEST_HINGE = [CHEST.x, 0.45, CHEST.z - 0.25];

/** Nave da igreja: lajes, bancos tombados, altar com velas, o ✠ na parede do fundo. */
export function naveParts() {
  const P = [], { x: cx, z: cz, hw, hd } = NAVE;
  P.push({ name: 'lajes', f: (x, y, z) => Math.max(y, -0.06 - y, Math.abs(x - cx) - hw - 0.1, Math.abs(z - cz) - hd - 0.3), min: [cx - hw - 0.2, -0.08, cz - hd - 0.4], max: [cx + hw + 0.2, 0.02, cz + hd + 0.4], mat: MAT.GRAVEL, spacing: 0.06, flow: [1, 0, 0], keep: (p, n) => n[1] > 0.5,
    detail: (p) => { const fu = ((p[0] / 0.7) % 1 + 1) % 1, fv = ((p[2] / 0.6) % 1 + 1) % 1; return fu < 0.08 || fv < 0.08 ? { mat: MAT.DARK, glyph: fu < 0.08 ? '│' : '─', size: 0.8 } : (Math.abs(p[0] - cx) < 0.6 && p[2] > cz - 3.6 ? { mat: MAT.CLOTH } : null); } });
  const wall = (x0, z0, x1, z1, h) => (x, y, z) => Math.max(Math.abs(x - (x0 + x1) / 2) - Math.abs(x1 - x0) / 2 - 0.15, Math.abs(z - (z0 + z1) / 2) - Math.abs(z1 - z0) / 2 - 0.15, Math.abs(y - h / 2) - h / 2);
  const winF = (x, y, z) => Math.max(Math.abs(((z - cz + 20) % 2.2) - 1.1) - 0.22, Math.abs(y - 2.3) - 0.7);
  const walls = S.union(wall(cx - hw, cz - hd, cx + hw, cz - hd, 3.6), S.subtract(wall(cx - hw, cz - hd, cx - hw, cz + hd, 3.6), winF), wall(cx + hw, cz - hd, cx + hw, cz + hd, 1.2),
    S.subtract(wall(cx - hw, cz + hd, cx + hw, cz + hd, 0.6), (x) => Math.abs(x - cx) - 0.6));
  P.push({ name: 'paredes da nave', f: walls, min: [cx - hw - 0.25, -0.02, cz - hd - 0.25], max: [cx + hw + 0.25, 3.7, cz + hd + 0.25], mat: MAT.STONE, spacing: 0.06, flow: [1, 0, 0],
    detail: (p) => ((p[1] / 0.4 % 1) < 0.1 ? { mat: MAT.DARK, glyph: '─', size: 0.85 } : (noise3(p[0], p[1], p[2]) > 0.66 ? { mat: MAT.MOSS } : null)),
    decals: [{ p: [cx, 2.7, cz - hd + 0.17], n: [0, 0, 1], glyph: '✠', mat: MAT.GOLD, size: 0.9, clear: 0.6 }, { p: [cx - hw + 0.17, 2.3, cz - 1.1], n: [1, 0, 0], glyph: '誓', mat: MAT.GOLD, size: 0.4, clear: 0.3 }] });
  // vitrais (luz colorida fraca nas janelas da esquerda)
  P.push({ name: 'vitral', f: (x, y, z) => Math.max(winF(x, y, z) + 0.05, Math.abs(x - (cx - hw)) - 0.03), min: [cx - hw - 0.1, 1.5, cz - hd], max: [cx - hw + 0.1, 3.1, cz + hd], mat: MAT.SPIRIT, spacing: 0.06, flow: [0, 1, 0], detail: (p) => ({ mat: [MAT.SPIRIT, MAT.FLOWER_B, MAT.EMBER][(Math.abs(p[1] * 7 + p[2] * 3) | 0) % 3], flags: 2 }) });
  // bancos (alguns tombados)
  [-1, 1].forEach(s => [-1.4, 0.4, 2.2].forEach((z, i) => {
    const bx = cx + s * 1.6, bz = cz + z, over = (i + (s > 0 ? 1 : 0)) % 3 === 1;
    const pew = S.union(S.xf(S.box(0.8, 0.03, 0.16), [0, 0.44, 0]), S.xf(S.box(0.8, 0.2, 0.03), [0, 0.68, -0.15]), S.xf(S.box(0.03, 0.22, 0.16), [-0.75, 0.22, 0]), S.xf(S.box(0.03, 0.22, 0.16), [0.75, 0.22, 0]));
    P.push({ name: 'banco', f: S.xf(pew, [bx, over ? 0.16 : 0, bz], [over ? -1.4 : 0, (i - 1) * 0.08, 0]), min: [bx - 0.9, -0.02, bz - 0.7], max: [bx + 0.9, 0.95, bz + 0.7], mat: MAT.WOOD, spacing: 0.03, flow: [1, 0, 0], detail: plankDetail(2, 0.12) });
  }));
  // altar com toalha e velas
  const az = cz - 4.55;
  P.push({ name: 'altar', f: S.union(S.xf(S.box(1.2, 0.5, 0.45, 0.02), [cx, 0.5, az]), S.xf(S.box(1.6, 0.08, 0.8), [cx, 0.08, az + 0.2])), min: [cx - 1.7, -0.02, az - 0.6], max: [cx + 1.7, 1.05, az + 1.05], mat: MAT.STONE, spacing: 0.035, flow: [1, 0, 0],
    detail: (p, n) => (p[1] > 0.85 || (n[2] > 0.6 && p[1] > 0.6) ? { mat: MAT.LINEN } : null) });
  for (const vx of [-0.9, -0.55, 0.55, 0.9]) P.push({ name: 'vela', f: S.xf(S.cylinder(0.03, 0.09 + Math.abs(vx) * 0.05), [cx + vx, 1.09, az]), min: [cx + vx - 0.05, 1.0, az - 0.05], max: [cx + vx + 0.05, 1.3, az + 0.05], mat: MAT.BONE, spacing: 0.012, flow: [0, 1, 0] });
  // manchas de sangue até o cavaleiro
  for (let i = 0; i < 6; i++) { const sx = KNIGHT_SEAT.x + 0.2 - i * 0.12, sz = KNIGHT_SEAT.z + 0.6 + i * 0.7; P.push({ name: 'sangue', f: (x, y, z) => Math.max(Math.hypot((x - sx) / 0.2, (z - sz) / 0.14) - 1 + 0.4 * noise3(x * 9, 0, z * 9), Math.abs(y - 0.01) - 0.01), min: [sx - 0.25, -0.01, sz - 0.2], max: [sx + 0.25, 0.03, sz + 0.2], mat: MAT.BLOOD, spacing: 0.03, flow: [1, 0, 0] }); }
  return P;
}

/** Luzes do vale (a fogueira) e dos interiores (velas). */
export const LIGHTS2 = [
  { name: 'fogueira da vila', pos: [FIRE.x, 0.9, FIRE.z], col: [1.0, 0.55, 0.24], radius: 7, base: 1.5, flicker: 0.32, area: 'r2' },
  { name: 'janelas', pos: [wx(0), 2.0, -6.5], col: [1.0, 0.62, 0.3], radius: 11, base: 0.9, flicker: 0.1, area: 'r2', lush: true },
  { name: 'vela da casa', pos: [ROOM.x - 0.6, 1.2, ROOM.z - 1.45], col: [1.0, 0.62, 0.3], radius: 5.5, base: 1.4, flicker: 0.25, area: 'house' },
  { name: 'luar da casa', pos: [ROOM.x + 0.5, 3.5, ROOM.z + 1.0], col: [0.5, 0.58, 0.85], radius: 7, base: 0.9, flicker: 0.0, area: 'house' },
  { name: 'velas do altar', pos: [NAVE.x, 1.6, NAVE.z - 4.3], col: [1.0, 0.62, 0.3], radius: 7.5, base: 1.6, flicker: 0.25, area: 'church' },
  { name: 'vitrais', pos: [NAVE.x - 1.6, 2.6, NAVE.z], col: [0.55, 0.45, 0.95], radius: 6.5, base: 0.8, flicker: 0.05, area: 'church' },
];
