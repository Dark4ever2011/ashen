// ASHEN 3D — O Profano: mago que flutua numa igreja sem teto nas montanhas do norte.
// Três magias de longe, todas lentas e com aviso no chão:
//   1. Chamas Profanas: orbes roxos que nascem à volta dele e perseguem devagar;
//   2. Lança do Abismo: uma linha brilha no chão até você e espinhos irrompem por ela;
//   3. Chuva de Ossos: círculos marcam o chão à sua volta e, depois, ossos caem do céu.
// Quando chega perto demais, ele some e reaparece longe. Ao morrer, esfarela em cinza; no lugar
// surgem uma fogueira e um baú com a armadura nova (de acordo com a classe).

import { enemyState } from '../render3/glb-models.js';
import { tell } from './tell.js';
import { m4, v3, noise3 } from './math3d.js';
import { MAT } from './glyphs.js';
import * as S from './sdf.js';
import { PointSet } from './sampler.js';
import { flatBones } from './renderer3d.js';
import { COMBO, swordSegment } from './knight3d.js';
import { hurtPlayer, DMG_TABLE } from './gameplay.js';
import { registerHit, hitFlash } from './bleed.js';
import { SITES, heightAt } from './ow.js';

const $ = id => document.getElementById(id);
const snd = (g, n, k) => g.audio && g.audio.play(n, k);
const I = m4.ident();
export const PROFANO_HP = 900;
const C = SITES.church;
export const NAVE = { x: C.x, z: C.z - 2, hw: 7, hd: 13 };          // dentro da igreja
const runes = '呪魔死冥闇骨虚';

/** Igreja gótica em ruínas, sem teto (a câmera vê de cima), portal ao sul. */
export function churchParts() {
  const y0 = heightAt(C.x, C.z) - 0.3, P = [], { x, z } = NAVE, H = 7.5;
  const front = z + NAVE.hd;
  const wall = (x0, z0, x1, z1, h) => (px, py, pz) => Math.max(Math.abs(px - (x0 + x1) / 2) - Math.abs(x1 - x0) / 2 - 0.4, Math.abs(pz - (z0 + z1) / 2) - Math.abs(z1 - z0) / 2 - 0.4, Math.abs(py - y0 - h / 2) - h / 2);
  const windows = (px, py, pz) => Math.max(Math.abs(((pz - z + 40) % 4) - 2) - 0.6, Math.abs(py - y0 - 4.2) - 1.8 - Math.max(0, 0.6 - Math.abs(((pz - z + 40) % 4) - 2)) * 0.8);
  const ruin = (px, py, pz) => (py - y0) - (H - 2.5 - 2.5 * noise3(px * 0.25, 1, pz * 0.25));           // topo quebrado
  const walls = S.union(
    S.subtract(wall(x - NAVE.hw, z - NAVE.hd, x - NAVE.hw, front, H), windows), S.subtract(wall(x + NAVE.hw, z - NAVE.hd, x + NAVE.hw, front, H), windows),
    wall(x - NAVE.hw, z - NAVE.hd, x + NAVE.hw, z - NAVE.hd, H + 3),
    S.subtract(wall(x - NAVE.hw, front, x + NAVE.hw, front, H + 4), (px, py, pz) => Math.max(Math.abs(px - x) - 1.8, py - y0 - 4.2 - Math.max(0, 1.8 - Math.abs(px - x)) * 0.9)));
  P.push({ name: 'igreja profana', f: S.intersect(walls, (px, py, pz) => Math.max(ruin(px, py, pz), -100)), min: [x - NAVE.hw - 0.6, y0 - 0.2, z - NAVE.hd - 0.6], max: [x + NAVE.hw + 0.6, y0 + H + 4.2, front + 0.6], mat: MAT.STONE, spacing: 0.11, flow: [0, 1, 0],
    detail: (p) => (((p[1] - y0) / 0.55 % 1) < 0.1 ? { mat: MAT.DARK, glyph: '─' } : noise3(p[0] * 0.6, p[1] * 0.6, p[2] * 0.6) > 0.66 ? { mat: MAT.MOSS } : null),
    decals: [{ p: [x, y0 + 8.4, z - NAVE.hd + 0.42], n: [0, 0, 1], glyph: '呪', mat: MAT.SPIRIT, size: 1.6, flags: 2, clear: 1.1 }] });
  // piso de lajes, altar profanado, pilares quebrados, círculo ritual
  P.push({ name: 'lajes', f: (px, py, pz) => Math.max(py - y0 - 0.32, y0 + 0.2 - py, Math.abs(px - x) - NAVE.hw, Math.abs(pz - z) - NAVE.hd), min: [x - NAVE.hw, y0 + 0.15, z - NAVE.hd], max: [x + NAVE.hw, y0 + 0.36, front], mat: MAT.GRAVEL, spacing: 0.12, flow: [1, 0, 0], keep: (p, n) => n[1] > 0.5,
    detail: (p) => { const r = Math.hypot(p[0] - x, p[2] - (z - 1)); if (Math.abs(r - 4.5) < 0.12 || Math.abs(r - 3.4) < 0.08) return { mat: MAT.SPIRIT, flags: 2 }; if (r < 4.4 && r > 3.5 && Math.abs(Math.sin(Math.atan2(p[2] - z + 1, p[0] - x) * 7)) > 0.94) return { mat: MAT.SPIRIT, glyph: runes[(Math.abs(p[0] * 9) | 0) % runes.length], flags: 2 }; return ((p[0] / 1.2) % 1 + 1) % 1 < 0.07 || ((p[2] / 1.2) % 1 + 1) % 1 < 0.07 ? { mat: MAT.DARK, glyph: '·' } : null; } });
  for (const s of [-1, 1]) for (const k of [-8, -3, 2, 7]) {
    const px = x + s * 4.2, pz = z + k, hh = 3 + 3.5 * Math.abs(Math.sin(k * 1.7 + s));
    P.push({ name: 'pilar', f: (qx, qy, qz) => Math.max(Math.hypot(qx - px, qz - pz) - 0.5, y0 - qy, qy - y0 - hh - noise3(qx * 3, qy, qz * 3) * 0.6), min: [px - 0.6, y0 - 0.1, pz - 0.6], max: [px + 0.6, y0 + hh + 0.7, pz + 0.6], mat: MAT.STONE, spacing: 0.09, flow: [0, 1, 0] });
  }
  P.push({ name: 'altar profano', f: S.xf(S.box(1.6, 0.6, 0.8, 0.05), [x, y0 + 0.9, z - NAVE.hd + 1.6]), min: [x - 1.8, y0 + 0.2, z - NAVE.hd + 0.6], max: [x + 1.8, y0 + 1.6, z - NAVE.hd + 2.6], mat: MAT.DARK, spacing: 0.06, flow: [1, 0, 0],
    detail: () => (Math.random() < 0.15 ? { mat: MAT.BLOOD } : null) });
  return P;
}
export const CHURCH_COLLIDERS = [
  { type: 'box', x0: NAVE.x - NAVE.hw - 0.5, z0: NAVE.z - NAVE.hd - 0.5, x1: NAVE.x - NAVE.hw + 0.5, z1: NAVE.z + NAVE.hd + 0.5 },
  { type: 'box', x0: NAVE.x + NAVE.hw - 0.5, z0: NAVE.z - NAVE.hd - 0.5, x1: NAVE.x + NAVE.hw + 0.5, z1: NAVE.z + NAVE.hd + 0.5 },
  { type: 'box', x0: NAVE.x - NAVE.hw, z0: NAVE.z - NAVE.hd - 0.5, x1: NAVE.x + NAVE.hw, z1: NAVE.z - NAVE.hd + 2.8 },
  { type: 'box', x0: NAVE.x - NAVE.hw, z0: NAVE.z + NAVE.hd - 0.5, x1: NAVE.x - 1.9, z1: NAVE.z + NAVE.hd + 0.5 },
  { type: 'box', x0: NAVE.x + 1.9, z0: NAVE.z + NAVE.hd - 0.5, x1: NAVE.x + NAVE.hw, z1: NAVE.z + NAVE.hd + 0.5 },
  ...[-1, 1].flatMap(s => [-8, -3, 2, 7].map(k => ({ type: 'circle', x: NAVE.x + s * 4.2, z: NAVE.z + k, r: 0.55 }))),
];

/** O mago (ossos: 1 corpo, 2 braço esquerdo, 3 braço direito com o cajado). */
export function profanoParts() {
  const P = [], add = o => P.push(o);
  const robe = S.intersect(S.shell(S.roundCone([0, 1.55, 0], [0, 0.0, 0], 0.24, 0.55), 0.03), S.above(0.0));
  add({ name: 'túnica', bone: 1, f: robe, min: [-0.62, -0.02, -0.62], max: [0.62, 1.62, 0.62], mat: MAT.CLOTH_IN, spacing: 0.03, flow: [0, 1, 0],
    keep: (p) => !(p[1] < 0.3 && Math.sin(Math.atan2(p[2], p[0]) * 11) > 0.5),
    detail: (p) => { const h = Math.sin(p[0] * 91 + p[1] * 37 + p[2] * 53); if (Math.abs(p[1] - 0.2) < 0.04 || Math.abs(p[1] - 1.1) < 0.03) return { mat: MAT.BLOOD }; return h > 0.93 ? { mat: MAT.SPIRIT, glyph: runes[(Math.abs(h * 999) | 0) % runes.length], flags: 2 } : null; } });
  add({ name: 'manto', bone: 1, f: S.xf(S.ellipsoid(0.46, 0.2, 0.32), [0, 1.62, 0]), min: [-0.5, 1.4, -0.36], max: [0.5, 1.85, 0.36], mat: MAT.ROYAL, spacing: 0.028, flow: [1, 0, 0], detail: (p) => (p[1] < 1.48 ? { mat: MAT.GOLD } : null) });
  add({ name: 'capuz', bone: 1, f: S.subtract(S.xf(S.ellipsoid(0.23, 0.29, 0.25), [0, 1.98, 0.0]), S.xf(S.ellipsoid(0.15, 0.2, 0.18), [0, 1.93, 0.13])), min: [-0.26, 1.66, -0.27], max: [0.26, 2.3, 0.28], mat: MAT.CLOTH_IN, spacing: 0.02, flow: [0, 1, 0] });
  add({ name: 'rosto', bone: 1, f: S.xf(S.ellipsoid(0.12, 0.16, 0.1), [0, 1.92, 0.06]), min: [-0.14, 1.74, -0.06], max: [0.14, 2.1, 0.18], mat: MAT.BONE, spacing: 0.014, flow: [0, 1, 0],
    detail: (p) => (p[1] < 1.86 ? { mat: MAT.DARK, glyph: '¦' } : null),
    decals: [-1, 1].map(s => ({ p: [s * 0.045, 1.95, 0.155], n: [0, 0, 1], glyph: '●', mat: MAT.SPIRIT, size: 0.05, flags: 2 })) });
  const horn = s => S.union(S.capsule([s * 0.12, 2.15, 0], [s * 0.3, 2.38, -0.05], 0.04), S.capsule([s * 0.3, 2.38, -0.05], [s * 0.34, 2.62, -0.15], 0.022));
  add({ name: 'chifres', bone: 1, f: S.union(horn(1), horn(-1)), min: [-0.4, 2.08, -0.2], max: [0.4, 2.66, 0.06], mat: MAT.BONE, spacing: 0.012, flow: [0, 1, 0] });
  for (const [b, s] of [[2, 1], [3, -1]]) {
    add({ name: 'manga', bone: b, f: S.roundCone([0, 0, 0], [0, -0.62, 0], 0.09, 0.16), min: [-0.2, -0.7, -0.2], max: [0.2, 0.1, 0.2], mat: MAT.CLOTH_IN, spacing: 0.022, flow: [0, 1, 0], detail: (p) => (p[1] < -0.56 ? { mat: MAT.BLOOD } : null) });
    add({ name: 'mão de osso', bone: b, f: S.union(S.capsule([0, -0.62, 0], [0, -0.78, 0.02], 0.025), S.capsule([0.03, -0.72, 0], [0.05, -0.86, 0.03], 0.012), S.capsule([-0.03, -0.72, 0], [-0.05, -0.86, 0.03], 0.012)), min: [-0.08, -0.9, -0.05], max: [0.08, -0.58, 0.08], mat: MAT.BONE, spacing: 0.008, flow: [0, 1, 0] });
  }
  add({ name: 'cajado', bone: 3, f: S.union(S.capsule([0, -2.0, 0.06], [0, 0.45, 0.06], 0.025), S.xf(S.torus(0.11, 0.015), [0, 0.6, 0.06], [Math.PI / 2, 0, 0])), min: [-0.14, -2.05, -0.1], max: [0.14, 0.75, 0.2], mat: MAT.DARK, spacing: 0.012, flow: [0, 1, 0],
    detail: (p) => (p[1] > 0.4 ? { mat: MAT.GOLD } : null) });
  add({ name: 'orbe', bone: 3, f: S.xf(S.sphere(0.075), [0, 0.6, 0.06]), min: [-0.09, 0.5, -0.04], max: [0.09, 0.7, 0.16], mat: MAT.SPIRIT, spacing: 0.01, flow: [1, 0, 0], pointFlags: 2 });
  return P;
}

const sm = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };
export const SPELLS = { orbs: 2.4, spikes: 2.6, rain: 3.0, blink: 1.4 };

export class Profano {
  constructor() { this.reset(); }
  reset() { Object.assign(this, { x: NAVE.x, z: NAVE.z - 6, y: 0, yaw: 0, hp: PROFANO_HP, t: 0, state: 'idle', act: null, at: 0, cool: 2.4, fade: 1, dead: 0, phase2: false, orbs: [], marks: [], close: 0 }); }
  get alive() { return this.state === 'fight'; }
  damage(n) { if (this.state !== 'fight') return false; this.hp -= n; if (!this.phase2 && this.hp < PROFANO_HP * 0.5) this.phase2 = true; if (this.hp <= 0) { this.hp = 0; this.state = 'dying'; this.act = null; this.orbs = []; this.marks = []; return true; } return false; }
  doStagger() { this.cool = Math.max(this.cool, 1.5); }
  update(dt, pl, canHit, fx) {
    const ev = [];
    this.t += dt;
    this.y = heightAt(this.x, this.z);
    if (this.state === 'dying') { this.dead = Math.min(1, this.dead + dt / 3.2); if (this.dead >= 1) this.state = 'dead'; return ev; }
    if (this.state !== 'fight') return ev;
    const dx = pl.x - this.x, dz = pl.z - this.z, d = Math.hypot(dx, dz);
    const want = Math.atan2(dx, dz);
    this.yaw += Math.atan2(Math.sin(want - this.yaw), Math.cos(want - this.yaw)) * Math.min(1, dt * 2.5);
    // orbes que perseguem
    for (const o of this.orbs) {
      o.t += dt;
      if (o.t < 0.9) { o.p = v3.add(o.p, [0, dt * 0.4, 0]); continue; }
      const to = v3.sub([pl.x, (pl.y || 0) + 1.1, pl.z], o.p), l = v3.len(to) || 1;
      o.v = v3.add(v3.mul(o.v, 1 - dt * 0.9), v3.mul(to, dt * 4.2 / l));
      const sp = v3.len(o.v); if (sp > 5.2) o.v = v3.mul(o.v, 5.2 / sp);
      o.p = v3.add(o.p, v3.mul(o.v, dt));
      if (!o.done && l < 0.7) { o.done = true; if (canHit) ev.push({ type: 'hit', dmg: 18, from: [o.p[0], o.p[2]] }); ev.push({ type: 'pop', p: o.p }); }
      if (o.t > 7) o.done = true;
    }
    this.orbs = this.orbs.filter(o => !o.done);
    // marcas no chão (lança e chuva)
    for (const m of this.marks) {
      m.t += dt;
      if (!m.fired && m.t >= m.delay) {
        m.fired = true;
        const hit = m.kind === 'line' ? distToSeg([pl.x, pl.z], m.a, m.b) < 0.9 : Math.hypot(pl.x - m.c[0], pl.z - m.c[1]) < m.r;
        if (hit && canHit) ev.push({ type: 'hit', dmg: m.dmg, from: m.kind === 'line' ? m.a : m.c });
        ev.push({ type: m.kind === 'line' ? 'spikes' : 'bones', m });
      }
    }
    this.marks = this.marks.filter(m => m.t < m.delay + 0.6);
    // sumir e reaparecer se o cavaleiro chegar perto
    if (this.act === 'blink') {
      this.at += dt / SPELLS.blink;
      this.fade = this.at < 0.5 ? 1 - this.at * 2 : (this.at - 0.5) * 2;
      if (!this.blinked && this.at >= 0.5) {
        this.blinked = true;
        const a = Math.random() * 6.28;
        this.x = NAVE.x + Math.cos(a) * 4.5; this.z = NAVE.z - 2 + Math.sin(a) * 7;
        ev.push({ type: 'blink' });
      }
      if (this.at >= 1) { this.act = null; this.fade = 1; this.cool = 0.8; }
      return ev;
    }
    if (d < 3.2) this.close += dt; else this.close = Math.max(0, this.close - dt);
    if (!this.act && this.close > 1.2) { this.act = 'blink'; this.at = 0; this.blinked = false; this.close = 0; ev.push({ type: 'vanish' }); return ev; }
    if (this.act) {
      const prev = this.at, dur = SPELLS[this.act] / (this.phase2 ? 1.2 : 1);
      this.at += dt / dur;
      if (prev < 0.45 && this.at >= 0.45) {
        if (this.act === 'orbs') {
          const n = this.phase2 ? 5 : 3;
          for (let i = 0; i < n; i++) { const a = this.yaw + (i - (n - 1) / 2) * 0.7; this.orbs.push({ p: [this.x + Math.sin(a) * 0.9, this.y + 2.2, this.z + Math.cos(a) * 0.9], v: [Math.sin(a) * 1.2, 0.5, Math.cos(a) * 1.2], t: 0 }); }
          ev.push({ type: 'cast', kind: 'orbs' });
        } else if (this.act === 'spikes') {
          const a = [this.x, this.z], dir = [dx / (d || 1), dz / (d || 1)], L = Math.max(d + 3, 9);
          this.marks.push({ kind: 'line', a, b: [a[0] + dir[0] * L, a[1] + dir[1] * L], t: 0, delay: this.phase2 ? 0.8 : 1.1, dmg: 28 });
          ev.push({ type: 'cast', kind: 'spikes' });
        } else if (this.act === 'rain') {
          const n = this.phase2 ? 7 : 5;
          for (let i = 0; i < n; i++) { const a = Math.random() * 6.28, r = i === 0 ? 0 : 1 + Math.random() * 3.2; this.marks.push({ kind: 'circle', c: [pl.x + Math.cos(a) * r, pl.z + Math.sin(a) * r], r: 1.3, t: -i * 0.18, delay: 1.4, dmg: 24 }); }
          ev.push({ type: 'cast', kind: 'rain' });
        }
      }
      if (this.at >= 1) { this.act = null; this.cool = (this.phase2 ? 1.2 : 1.9) + Math.random() * 0.8; }
      return ev;
    }
    // flutua mantendo distância
    const keep = 8;
    if (d < keep - 1) { this.x -= dx / d * 1.2 * dt; this.z -= dz / d * 1.2 * dt; }
    else if (d > keep + 3) { this.x += dx / d * 1.2 * dt; this.z += dz / d * 1.2 * dt; }
    this.x = Math.max(NAVE.x - NAVE.hw + 1.2, Math.min(NAVE.x + NAVE.hw - 1.2, this.x));
    this.z = Math.max(NAVE.z - NAVE.hd + 3.2, Math.min(NAVE.z + NAVE.hd - 1.5, this.z));
    this.cool -= dt;
    if (this.cool <= 0) { const r = Math.random(); this.act = r < 0.38 ? 'orbs' : r < 0.7 ? 'spikes' : 'rain'; this.at = 0; tell(this, 'magic', 2.4); }
    return ev;
  }
  bones() {
    const bob = Math.sin(this.t * 1.6) * 0.1, cast = this.act && this.act !== 'blink' ? sm(Math.min(this.at / 0.35, (1 - this.at) / 0.25)) : 0;
    const sink = this.dead * 1.4;
    const W = m4.mul(m4.translate(this.x, this.y + 0.45 + bob - sink, this.z), m4.rotY(this.yaw));
    const arm = (sx, x0, z0, up) => m4.mul(m4.mul(m4.mul(W, m4.translate(sx * 0.4, 1.62, 0.02)), m4.rotZ(sx * (0.25 + 0.5 * up))), m4.rotX(-0.3 - 1.6 * up));
    return [I, W, arm(1, 0, 0, cast * (this.act === 'rain' ? 1.1 : 0.6) + 0.05 * Math.sin(this.t)), arm(-1, 0, 0, cast * (this.act === 'spikes' ? 0.5 : 1.0))];
  }
}
function distToSeg(p, a, b) { const ab = [b[0] - a[0], b[1] - a[1]], t = Math.max(0, Math.min(1, ((p[0] - a[0]) * ab[0] + (p[1] - a[1]) * ab[1]) / (ab[0] * ab[0] + ab[1] * ab[1]))); return Math.hypot(p[0] - a[0] - ab[0] * t, p[1] - a[1] - ab[1] * t); }

// ─────────────── no jogo ───────────────
export function initProfano(g, sets, atlas) {
  g.prof = new Profano();
  const s = g.inv;
  if (s.profanoDead) { g.prof.state = 'dead'; g.prof.dead = 1; }
  g.profMesh = g.R.addMesh(sets.profano); g.profMesh.area = 'ow'; g.profMesh.visible = false;
  // fogueira + baú que surgem onde ele morreu
  const cp = new PointSet(400);
  const chest = (x, y, z) => { for (let i = 0; i < 260; i++) { const u = Math.random(), v = Math.random(), w = Math.random(); const px = (u - 0.5) * 0.9, py = v * 0.5, pz = (w - 0.5) * 0.55; if (Math.abs(px) < 0.43 && Math.abs(pz) < 0.25 && py < 0.48 && py > 0.02 && Math.random() < 0.7) continue; cp.push([x + px, y + py, z + pz], [0, 1, 0], [1, 0, 0], Math.abs(px) > 0.4 || Math.abs(py - 0.25) < 0.03 ? MAT.GOLD : MAT.WOOD, -1, 0, 0, 0.05, i); } };
  g.profChestMesh = null; g.profChestBuild = chest; g.profChestPS = cp;
  g.profFire = g.fx.addFire([0, -50, 0], 0.2, 100, 0.1); g.profFire.area = 'ow'; g.profFire.off = true;
  g.profLight = { name: 'brasa do profano', pos: [0, -50, 0], col: [0.75, 0.45, 1.0], radius: 9, base: 1.5, flicker: 0.25, area: 'ow', level: 0 };
  g.lights.push(g.profLight);
  if (s.profanoDead) placeReward(g, s.profanoAt || { x: NAVE.x, z: NAVE.z - 4 });
}
function placeReward(g, at) {
  const y = heightAt(at.x, at.z) + 0.32;
  g.profRewardAt = at;
  g.profFire.pos[0] = at.x - 1.2; g.profFire.pos[1] = y + 0.1; g.profFire.pos[2] = at.z; g.profFire.off = false;
  g.profLight.pos = [at.x - 1.2, y + 1, at.z]; g.profLight.level = 1;
  if (!g.profChestMesh) { g.profChestBuild(at.x + 0.9, y, at.z); g.profChestMesh = g.R.addMesh(g.profChestPS, { occlude: false }); g.profChestMesh.area = 'ow'; }
}
export function profanoColliders(g) { return CHURCH_COLLIDERS; }

export function profanoStep(g, dt) {
  if (g.area !== 'ow') return;
  const B = g.prof, p = g.player;
  const inside = Math.abs(p.x - NAVE.x) < NAVE.hw - 0.6 && p.z < NAVE.z + NAVE.hd - 1 && p.z > NAVE.z - NAVE.hd;
  if (B.state === 'idle' && inside && p.dead <= 0) {
    B.state = 'fight'; g.profFight = true; $('boss-name').textContent = 'O PROFANO'; $('boss-bar').classList.remove('hidden');
    g.hud.showRegion({ region: 'III · O Reino Partido', title: 'O PROFANO', subtitle: '冒涜者' }); snd(g, 'roar', 0.7); g.shake = 0.12;
  }
  if (!g.profFight) return;
  // a lâmina acerta
  if (p.atk >= 0 && g.knightBones && B.alive && B.fade > 0.6) {
    const Cc = COMBO[p.combo];
    if (p.atk > Cc.hit[0] - 0.03 && p.atk < Cc.hit[1] + 0.04 && !p.hitSet.has('prof')) {
      const [a, b] = swordSegment(g.knightBones);
      for (const k of [0.3, 0.6, 0.95]) { const q = v3.lerp(a, b, k); if (Math.hypot(q[0] - B.x, q[2] - B.z) < 0.85) {
        p.hitSet.add('prof'); const crit = p.riposte > 0 ? 3 : 1; p.riposte = 0; g.critHit = crit > 1;
        B.damage(DMG_TABLE[p.combo] * crit * g.dmgMul()); registerHit(g, B);
        snd(g, crit > 1 ? 'crit' : 'hit'); g.fx.sparks(q, 16, [0.7, 0.5, 1]); break;
      } }
    }
  }
  const ev = B.update(dt * g.diffK.speed, p, p.dead <= 0 && !g.cinema.active, g.fx);
  for (const e of ev) {
    if (e.type === 'hit') hurtPlayer(g, e.dmg, e.from, B);
    else if (e.type === 'cast') snd(g, e.kind === 'orbs' ? 'ignite' : 'quake', 0.6);
    else if (e.type === 'pop') g.fx.sparks(e.p, 24, [0.7, 0.4, 1]);
    else if (e.type === 'spikes') { for (let k = 0; k <= 1; k += 0.08) { const x = e.m.a[0] + (e.m.b[0] - e.m.a[0]) * k, z = e.m.a[1] + (e.m.b[1] - e.m.a[1]) * k; g.fx.dirt([x, heightAt(x, z) + 0.1, z], 6, 1.3); g.fx.sparks([x, heightAt(x, z) + 0.8, z], 4, [0.6, 0.3, 0.9]); } snd(g, 'slam', 0.8); g.shake = 0.12; }
    else if (e.type === 'bones') { const [x, z] = e.m.c; g.fx.dirt([x, heightAt(x, z) + 0.1, z], 24, 1.4); g.fx.sparks([x, heightAt(x, z) + 0.3, z], 14, [0.95, 0.9, 0.8]); snd(g, 'break', 0.6); }
    else if (e.type === 'vanish' || e.type === 'blink') { g.fx.sparks([B.x, B.y + 1.4, B.z], 30, [0.6, 0.3, 1]); snd(g, 'swap'); }
  }
  // avisos no chão e orbes
  for (const o of B.orbs) g.fx.sparks(o.p, 3, [0.75, 0.35, 1]);
  for (const m of B.marks) {
    if (m.fired || m.t < 0) continue;
    const k = m.t / m.delay;
    if (m.kind === 'line') { for (let i = 0; i < 4; i++) { const u = Math.random(), x = m.a[0] + (m.b[0] - m.a[0]) * u, z = m.a[1] + (m.b[1] - m.a[1]) * u; g.fx.sparks([x, heightAt(x, z) + 0.05, z], 1, [0.6 + k * 0.4, 0.2, 0.9]); } }
    else for (let i = 0; i < 3; i++) { const a = Math.random() * 6.28, x = m.c[0] + Math.cos(a) * m.r, z = m.c[1] + Math.sin(a) * m.r; g.fx.sparks([x, heightAt(x, z) + 0.05, z], 1, [0.95, 0.85 - k * 0.6, 0.7 - k * 0.6]); }
  }
  // ninguém sai da igreja durante a luta
  if (B.alive) { p.z = Math.min(p.z, NAVE.z + NAVE.hd - 0.8); }
  g.hud.bossHp(B.hp / PROFANO_HP);
  if (B.state === 'dead' || (B.state === 'dying' && !g.profDying)) {
    if (!g.profDying) {
      g.profDying = true; snd(g, 'victory'); g.hud.toast('O PROFANO SE DESFAZ EM CINZA', 3200); g.addGold(600);
    }
    if (B.state === 'dead') {
      g.profFight = false; $('boss-bar').classList.add('hidden');
      g.inv.profanoDead = true; g.inv.profanoAt = { x: B.x, z: B.z };
      placeReward(g, { x: B.x, z: B.z }); snd(g, 'ignite'); g.save();
      g.hud.toast('Onde ele caiu, uma fogueira acende e um baú aparece.', 4000);
    }
  }
}
export function profanoRespawn(g) { if (g.profFight) { g.profFight = false; g.prof.reset(); $('boss-bar').classList.add('hidden'); } }

export function profanoRender(g) {
  const B = g.prof;
  g.profMesh.visible = g.area === 'ow' && B.state !== 'dead' && Math.hypot(B.x - g.player.x, B.z - g.player.z) < 80;
  if (!g.profMesh.visible) return;
  const pb = B.bones();
  g.profMesh.boneData = flatBones(pb, g.profMesh.boneData); g.profMesh.flash = hitFlash(g, B);
  g.profMesh.modelMatrix = pb[1]; g.profMesh.animState = enemyState(B);
  g.profMesh.drawCount = Math.round(g.profMesh.n * Math.min(B.fade, 1 - sm((B.dead - 0.1) / 0.9)));
  if (B.dead > 0 && Math.random() < 0.8) g.fx.dirt([B.x + (Math.random() - 0.5), B.y + 0.5 + Math.random() * 1.8, B.z + (Math.random() - 0.5)], 3, 0.6);   // esfarela
}

export function profanoFocus(p, g) {
  if (!g.profRewardAt) return null;
  const at = g.profRewardAt, list = [];
  const dc = Math.hypot(p.x - (at.x + 0.9), p.z - at.z), df = Math.hypot(p.x - (at.x - 1.2), p.z - at.z);
  if (dc < 1.3) list.push({ id: 'pf:chest', title: 'Baú do Profano', prompt: g.inv.profChest ? 'baú vazio' : 'abrir o baú', d: dc, x: at.x + 0.9, z: at.z });
  if (df < 1.4) list.push({ id: 'pf:fire', title: 'Fogueira do Profano', prompt: 'descansar na fogueira', d: df, x: at.x - 1.2, z: at.z });
  list.sort((a, b) => a.d - b.d);
  return list[0] || null;
}
export function profanoInteract(g, it, itemInfo) {
  if (it.id === 'pf:fire') { g.restAt('owchurch'); g.save(); g.hud.toast('Você descansa entre as cinzas do Profano. Progresso salvo.'); return true; }
  if (it.id === 'pf:chest') {
    if (g.inv.profChest) { g.hud.message('O baú está vazio.', 'Baú', it); return true; }
    g.inv.profChest = true; g.addItem('armor'); snd(g, 'chest');
    const I = itemInfo(g, 'armor');
    setTimeout(() => { g.hud.message(I.desc + ' Vista-a pelo inventário.', I.name, null); snd(g, 'blade'); g.save(); }, 700);
    return true;
  }
  return false;
}
export const PROFANO_FIRE = () => null;
