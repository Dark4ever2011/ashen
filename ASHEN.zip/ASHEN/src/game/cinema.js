// ASHEN 3D — Cenas animadas no próprio mundo de caracteres.
// Uma cena = planos de câmera (olho e alvo interpolados), legendas, eventos e escurecimentos.
// Pode ser pulada. Enquanto roda, o jogo não lê os controles.

const sm = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };
const lerp3 = (a, b, k) => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
const $ = id => document.getElementById(id);

export class Cinema {
  constructor(narrator) { this.narrator = narrator; this.cur = null; $('cine-skip').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); this.skip(); }); }
  get active() { return !!this.cur; }
  play(scene) {
    this.cur = { ...scene, t: 0, fired: new Set() };
    $('cine').classList.remove('hidden'); document.body.classList.add('cine');
    $('cine-title').textContent = ''; $('cine-text').textContent = '';
  }
  skip() { if (!this.cur) return; const c = this.cur; for (const e of c.events || []) if (!c.fired.has(e)) { c.fired.add(e); e.fn(true); } this.end(); }
  end() { const c = this.cur; this.cur = null; this.narrator && this.narrator.stop(); $('cine').classList.add('hidden'); document.body.classList.remove('cine'); $('cine-black').style.opacity = 0; c && c.onEnd && c.onEnd(); }
  /** Avança e devolve { eye, target, shake } (ou null se acabou). */
  update(dt) {
    const c = this.cur;
    if (!c) return null;
    c.t += dt;
    for (const e of c.events || []) if (!c.fired.has(e) && c.t >= e.t) { c.fired.add(e); e.fn(false); }
    if (c.t >= c.dur) { this.end(); return null; }
    let shot = c.shots[0];
    for (const s of c.shots) if (c.t >= s.t0) shot = s;
    const k = sm((c.t - shot.t0) / (shot.t1 - shot.t0));
    const cap = (c.captions || []).find(q => c.t >= q.t0 && c.t < q.t1);
    const text = cap ? cap.text : '';
    const el = $('cine-text');
    if (el.dataset.full !== text) { el.dataset.full = text; el.textContent = ''; el.dataset.shown = 0; if (text && this.narrator) this.narrator.speak(text); }
    if (text) { const n = Math.min(text.length, (+el.dataset.shown || 0) + dt * 38); el.dataset.shown = n; el.textContent = text.slice(0, Math.floor(n)); }
    el.style.opacity = cap ? Math.min(1, (c.t - cap.t0) * 2, (cap.t1 - c.t) * 2) : 0;
    const title = (c.titles || []).find(q => c.t >= q.t0 && c.t < q.t1);
    $('cine-title').textContent = title ? title.text : '';
    $('cine-title').style.opacity = title ? Math.min(1, (c.t - title.t0) * 1.5, (title.t1 - c.t) * 1.5) : 0;
    let black = 0;
    for (const b of c.black || []) if (c.t >= b.t0 && c.t < b.t1) black = Math.max(black, b.a(c.t));
    $('cine-black').style.opacity = black;
    const shake = (c.shakes || []).reduce((a, s) => (c.t >= s.t0 && c.t < s.t1 ? Math.max(a, s.amp * (1 - (c.t - s.t0) / (s.t1 - s.t0))) : a), 0);
    return { eye: lerp3(shot.eye0, shot.eye1, k), target: lerp3(shot.tgt0, shot.tgt1, k), shake };
  }
}

/** Abertura: a queda do reino e o despertar do cavaleiro junto ao braseiro. */
export function openingScene(S, W, hooks) {
  const L = S.opening, bz = W.BRAZIER, fz = W.FALLEN, tomb = W.ROYAL_TOMB;
  const kn = [bz.x + 0.9, 0, bz.z + 1.1];
  return {
    dur: 50,
    shots: [
      { t0: 0, t1: 8.5, eye0: [9, 12, 7], eye1: [6, 11.5, 4.5], tgt0: [1.4, 8.5, -9.6], tgt1: [1.8, 9.5, -9.6] },          // fortaleza
      { t0: 8.5, t1: 17, eye0: [-7, 5, 4], eye1: [6, 4.5, 3.5], tgt0: [-3, 3, -4.4], tgt1: [2, 3.2, -4.4] },          // muralhas e portão
      { t0: 17, t1: 25.5, eye0: [tomb.x + 3, 2.2, tomb.z + 4], eye1: [tomb.x + 1.5, 1.4, tomb.z + 2.6], tgt0: [tomb.x, 0.4, tomb.z], tgt1: [tomb.x, 0.3, tomb.z + 0.6] },   // túmulo vazio
      { t0: 25.5, t1: 34, eye0: [fz.x - 1.5, 1.6, fz.z + 3.2], eye1: [fz.x - 0.6, 1.2, fz.z + 2.2], tgt0: [fz.x, 0.7, fz.z], tgt1: [fz.x, 0.6, fz.z] },      // cavaleiro caído
      { t0: 34, t1: 50, eye0: [kn[0] + 2.4, 2.6, kn[2] + 3.4], eye1: [kn[0] + 1.2, 1.5, kn[2] + 3.0], tgt0: [kn[0], 0.3, kn[2]], tgt1: [kn[0], 1.0, kn[2]] },  // despertar
    ],
    captions: L.map((text, i) => ({ t0: [1, 9.2, 17.7, 26.2, 34.8, 41][i], t1: [8, 16.5, 25, 33.5, 40.6, 47.2][i], text })),
    titles: [{ t0: 47.2, t1: 50, text: 'ASHEN · THE LAST OATH' }],
    black: [{ t0: 0, t1: 2, a: t => 1 - t / 2 }, ...[8.5, 17, 25.5, 34].map(c => ({ t0: c - 0.65, t1: c + 0.65, a: t => 1 - Math.abs(t - c) / 0.65 }))],
    events: [{ t: 34, fn: (skip) => hooks.lieDown(skip) }, { t: 41, fn: (skip) => hooks.wake(skip) }],
    onEnd: hooks.done,
  };
}

/** O rei sai do túmulo: tremor, garras na borda, o corpo se ergue, o grito. */
export function bossIntroScene(S, W, hooks) {
  const t = W.ROYAL_TOMB;
  return {
    dur: 10.5,
    shots: [
      { t0: 0, t1: 3.2, eye0: [t.x + 2.6, 1.0, t.z + 3.6], eye1: [t.x + 2.0, 0.8, t.z + 3.0], tgt0: [t.x, 0.2, t.z + 0.8], tgt1: [t.x, 0.3, t.z + 0.9] },
      { t0: 3.2, t1: 7.2, eye0: [t.x + 1.8, 0.7, t.z + 3.4], eye1: [t.x + 2.4, 0.9, t.z + 4.6], tgt0: [t.x, 0.6, t.z + 0.9], tgt1: [t.x, 2.0, t.z + 0.9] },
      { t0: 7.2, t1: 10.5, eye0: [t.x + 1.2, 1.3, t.z + 4.2], eye1: [t.x + 0.8, 1.6, t.z + 4.6], tgt0: [t.x, 2.0, t.z + 0.9], tgt1: [t.x, 2.1, t.z + 0.9] },
    ],
    captions: [{ t0: 0.4, t1: 3.2, text: S.bossIntro[0] }, { t0: 3.6, t1: 6.8, text: S.bossIntro[1] }],
    titles: [{ t0: 7.6, t1: 10.5, text: 'O PRIMEIRO REI, DESENTERRADO' }],
    shakes: [{ t0: 0, t1: 3.2, amp: 0.05 }, { t0: 7.2, t1: 9.2, amp: 0.12 }],
    events: [{ t: 0, fn: (skip) => hooks.quake(skip) }, { t: 3.2, fn: (skip) => hooks.rise(skip) }, { t: 7.2, fn: (skip) => hooks.roar(skip) }],
    onEnd: hooks.done,
  };
}

/** Vitória: o rei vira cinza, a terra devolve tudo, uma nova chama desperta onde ele caiu. */
export function victoryScene(S, at, hooks) {
  return {
    dur: 22,
    shots: [
      { t0: 0, t1: 7.5, eye0: [at.x + 3.2, 2.2, at.z + 3.6], eye1: [at.x + 1.8, 1.6, at.z + 3.2], tgt0: [at.x, 0.8, at.z], tgt1: [at.x, 0.4, at.z] },
      { t0: 7.5, t1: 15, eye0: [at.x - 4.5, 4.5, at.z + 6.5], eye1: [at.x + 4.5, 4.2, at.z + 6.8], tgt0: [at.x, 0.4, at.z - 1], tgt1: [at.x, 0.6, at.z - 1] },
      { t0: 15, t1: 22, eye0: [at.x + 1.6, 1.1, at.z + 2.4], eye1: [at.x + 1.0, 0.8, at.z + 1.8], tgt0: [at.x, 0.25, at.z], tgt1: [at.x, 0.2, at.z] },
    ],
    captions: S.victory.map((text, i) => ({ t0: [0.8, 8.1, 15.4][i], t1: [7.2, 14.6, 21.5][i], text })),
    titles: [],
    shakes: [{ t0: 7.6, t1: 11.5, amp: 0.07 }],
    black: [{ t0: 6.9, t1: 8.1, a: t => 1 - Math.abs(t - 7.5) / 0.6 }, { t0: 14.4, t1: 15.6, a: t => 1 - Math.abs(t - 15) / 0.6 }],
    events: [{ t: 7.5, fn: (skip) => hooks.restore(skip) }, { t: 15.2, fn: (skip) => hooks.shrine(skip) }],
    onEnd: hooks.done,
  };
}

/** O Portão do Rei se abre: a chave gira e a grade sobe. Só isso. */
export function gateScene(GZ, hooks) {
  return {
    dur: 10,
    shots: [
      { t0: 0, t1: 3, eye0: [1.6, 1.5, GZ + 3.2], eye1: [1.1, 1.4, GZ + 2.6], tgt0: [0, 1.4, GZ], tgt1: [0, 1.5, GZ] },
      { t0: 3, t1: 10, eye0: [4.5, 2.6, GZ + 8.5], eye1: [2.2, 2.0, GZ + 6.2], tgt0: [0, 2.6, GZ - 0.5], tgt1: [0, 2.3, GZ - 0.5] },
    ],
    captions: [], titles: [],
    shakes: [{ t0: 3.1, t1: 8.6, amp: 0.025 }, { t0: 8.6, t1: 9.4, amp: 0.09 }],
    black: [{ t0: 2.6, t1: 3.4, a: t => 1 - Math.abs(t - 3) / 0.4 }],
    events: [{ t: 0.6, fn: (skip) => hooks.key(skip) }, { t: 3.0, fn: (skip) => hooks.raise(skip) }],
    onEnd: hooks.done,
  };
}

/** O cavaleiro desmaia na vila viva e desperta no presente: tudo em ruínas. */
export function faintScene(S, at, entry, village, hooks) {
  return {
    dur: 10,
    shots: [
      { t0: 0, t1: 3, eye0: [at.x + 2.2, 1.7, at.z + 2.4], eye1: [at.x + 1.2, 1.2, at.z + 1.4], tgt0: [at.x, 1.0, at.z], tgt1: [at.x, 0.6, at.z] },
      { t0: 3, t1: 10, eye0: [entry.x - 2.5, 3.2, entry.z + 1.5], eye1: [entry.x - 1, 2.4, entry.z + 0.5], tgt0: [village.x, 1.2, village.z], tgt1: [village.x, 1.0, village.z] },
    ],
    captions: [{ t0: 0.3, t1: 2.8, text: S.faint[0] }, { t0: 3.6, t1: 9.6, text: S.faint[1] }],
    titles: [],
    black: [{ t0: 0.4, t1: 3.0, a: t => Math.min(1, (t - 0.4) / 1.6) }, { t0: 3.0, t1: 5.5, a: t => 1 - (t - 3) / 2.5 }],
    events: [{ t: 0.1, fn: (skip) => hooks.fall(skip) }, { t: 2.9, fn: (skip) => hooks.swap(skip) }],
    onEnd: hooks.done,
  };
}

/** O que aconteceu em Orvalho (depois de libertar os quatro mortos). */
export function ruinScene(S, P, hooks) {
  const { O, HOUSES, WELL, CHURCH } = P, h = HOUSES[0], front = CHURCH.z + CHURCH.hd;
  const t = [0, 6.6, 13.2, 19.8, 26.4, 33];
  return {
    dur: 33,
    shots: [
      { t0: t[0], t1: t[1], eye0: [O.x - 7, 4.5, 7], eye1: [O.x + 6, 4.2, 6], tgt0: [O.x, 1, -5], tgt1: [O.x, 1, -6] },
      { t0: t[1], t1: t[2], eye0: [h.x + 3.6, 1.8, h.z + 3.4], eye1: [h.x + 2.6, 1.5, h.z + 2.0], tgt0: [h.x, 1.4, h.z], tgt1: [h.x, 1.2, h.z] },
      { t0: t[2], t1: t[3], eye0: [WELL.x + 2.8, 1.3, WELL.z + 2.6], eye1: [WELL.x - 2.4, 1.1, WELL.z + 2.8], tgt0: [WELL.x, 0.4, WELL.z - 1], tgt1: [WELL.x, 0.4, WELL.z - 1] },
      { t0: t[3], t1: t[4], eye0: [O.x + 3, 9, 2], eye1: [O.x - 2, 8, -6], tgt0: [O.x, 0, -10], tgt1: [O.x, 1, -20] },
      { t0: t[4], t1: t[5], eye0: [O.x + 2.4, 1.8, front + 7], eye1: [O.x + 0.6, 1.6, front + 3.5], tgt0: [O.x, 2.8, front], tgt1: [O.x, 2.4, front] },
    ],
    captions: S.ruin.map((text, i) => ({ t0: t[i] + 0.5, t1: t[i + 1] - 0.4, text })),
    titles: [],
    black: [1, 2, 3, 4].map(i => ({ t0: t[i] - 0.5, t1: t[i] + 0.5, a: x => 1 - Math.abs(x - t[i]) / 0.5 })),
    events: [{ t: t[4], fn: (skip) => hooks.bell && hooks.bell(skip) }],
    onEnd: hooks.done,
  };
}
