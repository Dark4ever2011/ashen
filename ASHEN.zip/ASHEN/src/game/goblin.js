// ASHEN 3D — Goblins: baixinhos (~1 m), pele verde, orelhas compridas, nariz de gancho, olhos amarelos.
// Têm mais vida que os mortos erguidos, batem mais fraco e são bem mais rápidos: correm, golpeiam e
// pulam para trás. O Rei Goblin (chefe da cripta) é o mesmo corpo, gordo, com coroa torta e clava.

import { tell } from './tell.js';
import { m4 } from './math3d.js';
import { MAT } from './glyphs.js';
import * as S from './sdf.js';
import { noise3 } from './math3d.js';
import { bossParts, poseBoss } from './boss3d.js';

const B = { PELVIS: 1, CHEST: 2, HEAD: 3, HAND_R: 9, HAND_L: 6 };
export const GOB_SCALE = 0.5, GOB_HP = 175, GOB_DMG = 8;
export const KING_SCALE = 0.92, KING_HP = 1300;

export function goblinParts(king = false) {
  const out = [];
  const skin = (p, n, c) => { const k = noise3(p[0] * 22, p[1] * 22, p[2] * 22); return k > 0.72 ? { mat: MAT.MOSS } : k < 0.18 ? { mat: MAT.DARK, glyph: '·' } : c > 0.45 ? { mat: MAT.DARK } : null; };
  for (const q of bossParts()) {
    if (q.name === 'coroa' || q.name === 'farrapos' || q.name === 'crânio') continue;
    const fat = king && (q.name === 'tronco' || q.name === 'quadril') ? 0.08 : /braço|coxa/.test(q.name) ? 0.025 : /antebraço|canela/.test(q.name) ? 0.02 : 0.006;
    const f0 = q.f;
    q.f = (x, y, z) => f0(x, y, z) - fat;
    q.aoF = q.f;
    q.min = q.min.map(v => v - fat - 0.01); q.max = q.max.map(v => v + fat + 0.01);
    q.mat = MAT.GOBLIN; q.detail = q.name === 'garra' ? (p) => (p[1] < -0.14 ? { mat: MAT.BONE } : null) : skin; q.decals = [];
    q.spacing *= king ? 0.85 : 0.95;
    out.push(q);
  }
  if (king) {   // barrigão
    out.push({ name: 'pança', bone: B.CHEST, f: S.xf(S.ellipsoid(0.27, 0.25, 0.24), [0, 0.05, 0.08]), min: [-0.3, -0.22, -0.18], max: [0.3, 0.32, 0.34], mat: MAT.GOBLIN, spacing: 0.02, flow: [1, 0, 0], detail: skin });
  }
  // cabeça grande: crânio largo, testa baixa, nariz em gancho, boca com presas, orelhas longas para trás
  const head = S.smooth(0.03, S.xf(S.ellipsoid(0.15, 0.13, 0.15), [0, 0.12, 0.0]), S.xf(S.ellipsoid(0.11, 0.07, 0.1), [0, 0.04, 0.06]));
  const nose = S.roundCone([0, 0.11, 0.13], [0, 0.04, 0.24], 0.035, 0.012);
  const ear = s => S.roundCone([s * 0.12, 0.14, -0.01], [s * 0.36, 0.22, -0.1], 0.045, 0.006);
  const brow = S.xf(S.ellipsoid(0.12, 0.025, 0.04), [0, 0.165, 0.11]);
  add(out, { name: 'cabeça de goblin', bone: B.HEAD, f: S.smooth(0.02, head, nose, brow, S.union(ear(1), ear(-1))), min: [-0.4, -0.06, -0.18], max: [0.4, 0.3, 0.27], mat: MAT.GOBLIN, spacing: 0.011, flow: [0, 1, 0],
    detail: (p, n, c) => {
      if (p[2] > 0.1 && p[1] > 0.005 && p[1] < 0.03 && Math.abs(p[0]) < 0.07) return { mat: MAT.BONE, glyph: Math.abs(p[0]) > 0.045 ? 'Ʌ' : 'ʌ' };    // presas
      if (p[1] > 0.22 && !king && noise3(p[0] * 40, 3, p[2] * 40) > 0.55) return { mat: MAT.DARK, glyph: '⁞' };
      return skin(p, n, c);
    },
    decals: [-1, 1].map(s => ({ p: [s * 0.055, 0.13, 0.135], n: [s * 0.25, 0, 1], glyph: '●', mat: MAT.EMBER, size: 0.032, flags: 2, clear: 0.025 })) });
  // tanga de couro e cinto
  add(out, { name: 'tanga', bone: B.PELVIS, f: (x, y, z) => Math.max(Math.abs(Math.hypot(x, z * 1.15) - (king ? 0.24 : 0.17)) - 0.012, y - 0.06, -0.3 - y), min: [-0.3, -0.32, -0.3], max: [0.3, 0.08, 0.3], mat: MAT.LEATHER, spacing: 0.018, flow: [0, 1, 0],
    keep: (p) => p[1] > -0.02 || Math.abs(Math.sin(Math.atan2(p[2], p[0]) * 3)) > 0.4, detail: (p) => (p[1] > 0.02 ? { mat: MAT.WOOD } : null) });
  // arma: faca enferrujada (goblin) ou clava cravejada (rei)
  if (king) {
    add(out, { name: 'clava', bone: B.HAND_R, f: S.union(S.capsule([0, -0.06, 0.02], [0, -0.06, 0.62], 0.03), S.xf(S.ellipsoid(0.1, 0.1, 0.22), [0, -0.06, 0.78])), min: [-0.12, -0.18, -0.03], max: [0.12, 0.06, 1.02], mat: MAT.WOOD, spacing: 0.016, flow: [0, 0, 1],
      detail: (p) => (p[2] > 0.6 && noise3(p[0] * 30, p[1] * 30, p[2] * 30) > 0.62 ? { mat: MAT.IRON, glyph: '◆' } : null) });
    const band = S.intersect(S.shell(S.xf(S.ellipsoid(0.14, 0.4, 0.14), [0, 0.24, 0]), 0.008), (x, y, z) => Math.max(0.2 - y + x * 0.25, y - 0.26 - x * 0.25));
    const spikes = S.union(...[-1.6, -0.8, 0, 0.8, 1.6].map(a => S.roundCone([Math.sin(a) * 0.14, 0.24 + Math.sin(a) * 0.035, Math.cos(a) * 0.14], [Math.sin(a) * 0.15, 0.33 + Math.sin(a) * 0.035, Math.cos(a) * 0.15], 0.018, 0.003)));
    add(out, { name: 'coroa torta', bone: B.HEAD, f: S.union(band, spikes), min: [-0.17, 0.15, -0.17], max: [0.17, 0.38, 0.17], mat: MAT.GOLD, spacing: 0.01, flow: [1, 0, 0],
      decals: [{ p: [0, 0.25, 0.145], n: [0, 0, 1], glyph: '◆', mat: MAT.BLOOD, size: 0.04, flags: 2, clear: 0.02 }] });
  } else {
    add(out, { name: 'faca', bone: B.HAND_R, f: S.union(S.capsule([0, -0.07, 0.0], [0, -0.07, 0.12], 0.016), (x, y, z) => Math.max(Math.abs(x) - 0.006, Math.abs(y + 0.07) - 0.025 + (z - 0.12) * 0.08, Math.abs(z - 0.27) - 0.15)), min: [-0.03, -0.11, -0.02], max: [0.03, -0.03, 0.43], mat: MAT.IRON, spacing: 0.008, flow: [0, 0, 1],
      detail: (p) => (p[2] < 0.12 ? { mat: MAT.WOOD } : noise3(p[0] * 60, p[1] * 60, p[2] * 60) > 0.6 ? { mat: MAT.EMBER } : null) });
  }
  return out;
}
function add(arr, o) { arr.push(o); }

const ACT = { swipe: 0.62, hop: 0.45 };
/** Goblin comum: corre em zigue-zague, golpeia rápido e pula para trás. */
export class Goblin {
  constructor(id, x, z, yaw = 0) { this.id = id; this.home = { x, z, yaw }; this.goblin = true; this.reset(); }
  reset() { Object.assign(this, { x: this.home.x, z: this.home.z, yaw: this.home.yaw, hp: GOB_HP, phase: Math.random(), blend: 0, t: Math.random() * 9, act: null, at: 0, cool: 0.6 + Math.random(), dead: 0, hurt: 0, state: 'idle', hitDone: false, strafe: Math.random() < 0.5 ? 1 : -1, strafeT: 1 + Math.random() * 2 }); }
  get alive() { return this.state === 'idle' || this.state === 'fight'; }
  damage(n) { if (!this.alive) return false; this.hp -= n; this.hurt = 1; this.state = 'fight'; if (this.act === 'swipe' && this.at < 0.4) { this.act = 'hop'; this.at = 0; } if (this.hp <= 0) { this.state = 'dying'; this.act = null; return true; } return false; }
  doStagger() { this.act = 'hop'; this.at = 0; this.hitDone = true; this.cool = 1.2; }
  update(dt, pl, canHit, aggro = 11) {
    const ev = [];
    this.t += dt; this.hurt = Math.max(0, this.hurt - dt * 4);
    if (this.state === 'dying') { this.dead = Math.min(1, this.dead + dt / 1.8); if (this.dead >= 1) this.state = 'dead'; return ev; }
    if (this.state === 'dead') return ev;
    const dx = pl.x - this.x, dz = pl.z - this.z, d = Math.hypot(dx, dz) || 1e-3, want = Math.atan2(dx, dz);
    if (this.state === 'idle') { this.blend *= 0.95; this.phase = (this.phase + dt * 0.2) % 1; if (d < aggro && canHit) { this.state = 'fight'; ev.push({ type: 'cackle' }); } else return ev; }
    const turn = (k) => { this.yaw += Math.max(-k * dt, Math.min(k * dt, Math.atan2(Math.sin(want - this.yaw), Math.cos(want - this.yaw)))); };
    if (this.act) {
      const prev = this.at; this.at += dt / ACT[this.act];
      if (this.act === 'swipe') {
        turn(this.at < 0.35 ? 5 : 0.8);
        if (prev < 0.35 && this.at >= 0.35) ev.push({ type: 'swing' });
        if (!this.hitDone && this.at > 0.42 && this.at < 0.6) { const ang = Math.abs(Math.atan2(Math.sin(want - this.yaw), Math.cos(want - this.yaw))); if (d < 1.25 && ang < 1.1 && canHit) { this.hitDone = true; ev.push({ type: 'hit', dmg: GOB_DMG, from: [this.x, this.z] }); } }
        if (this.at > 0.3 && this.at < 0.55) { this.x += Math.sin(this.yaw) * 2.2 * dt; this.z += Math.cos(this.yaw) * 2.2 * dt; }
        if (this.at >= 1) { this.act = Math.random() < 0.6 ? 'hop' : null; this.at = 0; this.cool = 0.7 + Math.random() * 0.9; }
      } else if (this.act === 'hop') {            // pulinho para trás
        turn(6);
        const k = Math.sin(Math.min(1, this.at) * Math.PI);
        this.x -= dx / d * 3.6 * dt * k; this.z -= dz / d * 3.6 * dt * k; this.hopY = 0.3 * k;
        if (this.at >= 1) { this.act = null; this.hopY = 0; }
      }
      this.blend += ((this.act === 'hop' ? 0.6 : 0) - this.blend) * Math.min(1, dt * 6);
      this.phase = (this.phase + dt * 1.8) % 1;
      return ev;
    }
    this.cool -= dt; this.strafeT -= dt;
    if (this.strafeT <= 0) { this.strafe = -this.strafe; this.strafeT = 0.8 + Math.random() * 1.8; }
    turn(6);
    let sp = 0, sx = 0, sz = 0;
    if (d > 1.1) { sp = d > 4 ? 2.9 : 2.2; sx = dx / d; sz = dz / d; }
    if (d < 4.5) { const w = d > 1.1 ? 0.55 : 1; sx += -dz / d * this.strafe * w; sz += dx / d * this.strafe * w; sp = Math.max(sp, 1.6); }   // circula
    const sl = Math.hypot(sx, sz);
    if (sl > 0.01) { this.x += sx / sl * sp * dt; this.z += sz / sl * sp * dt; this.phase = (this.phase + sp * dt / 0.9) % 1; this.blend += (1 - this.blend) * Math.min(1, dt * 6); }
    else this.blend += (0 - this.blend) * Math.min(1, dt * 6);
    if (d < 1.5 && this.cool <= 0 && canHit) { this.act = 'swipe'; this.at = 0; this.hitDone = false; tell(this, 'light', 0.95); }
    return ev;
  }
  pose() { return poseBoss({ phase: this.phase, blend: this.blend, t: this.t * 1.6, act: this.act === 'swipe' ? 'swipe' : null, at: this.at, rise: 1, dead: this.dead, hurt: this.hurt }); }
  matrix() { return m4.mul(m4.mul(m4.translate(this.x, (this.y || 0) + (this.hopY || 0), this.z), m4.rotY(this.yaw)), m4.scale(GOB_SCALE, GOB_SCALE, GOB_SCALE)); }
}
