# ASHEN — Registro de progresso

Para continuar o desenvolvimento em outra sessão, leia este arquivo e o `README.md`.

## Versão 0.1.0 · Fase 1 — Motor Gráfico · concluída em 23/11/2026

### Decisões de arquitetura
- **Projeção 3/4 oblíqua** (câmera ao sul, olhando para baixo): `tela_y = mundo_y × 0,72 − z`. Paredes frontais e topos de muralha visíveis; casa bem com células retangulares de caracteres (o isométrico em losango deixaria paredes diagonais serrilhadas). `TILT` em `src/config.js`.
- **Células fixas 6×10 u** para personagens/objetos e 7,2×12 u para o chão. Cada glifo é encaixado na célula: fonte medida pelo `│`, escala horizontal para `─` emendar, compressão extra se uma fonte de fallback vier larga. Blocos (`█▀▄▌▐…`) e diagonais (`╱╲╳`) são desenhados como retângulos/traços exatos.
- **Largura dupla**: `charWidth()` segue as faixas East Asian Wide. Kanji ocupam 2 células, usam a pilha de fontes japonesas (serifada primeiro, estilo gravado).
- **Sombreamento de gravura**: dígitos 0–5 na arte viram hachuras `╱ ╳ ·` sobre fundos de material (aço, pedra). Lado espelhado usa sombreamento invertido (luz sempre da esquerda).
- **Esqueleto tipográfico** do cavaleiro: peças fixas presas a articulações; coxas, canelas e braços carimbados ao longo do osso; IK de 2 ossos no perfil; espada girada glifo a glifo; marcha procedural guiada por distância (sem deslizar). Quadros compostos vão para cache LRU (56).
- **Vista W não é espelho simples**: geometria espelhada, mas a espada (mão direita) passa para trás do corpo.
- **Capa** desenhada em faixas com molas (arrasto, vento, passo), separada do corpo.
- **Renderização**: chão em blocos pré-renderizados com sombras estáticas "assadas"; objetos em cache, ordenados por profundidade, com culling e transparência quando escondem o cavaleiro; luz em mapa de baixa resolução multiplicado (vinheta embutida); brilho aditivo; névoa em texturas tileáveis de glifos.
- **Streaming de sprites**: objetos são construídos perto da câmera e liberados longe dela.
- **Qualidade**: três presets que nunca simplificam armaduras/personagens/arquitetura. O jogo monitora FPS por janelas de 10 s e só *sugere* trocar.
- **Física** em passo fixo 60 Hz com interpolação; FPS limitado a 60 por padrão (tela de 120 Hz do A56).

### Arquivos criados
`index.html`, `manifest.json`, `service-worker.js`, `styles/main.css`, `.github/workflows/publicar.yml`,
`src/main.js`, `src/config.js`,
`src/engine/` typography, canvas, palette, sprite, renderer, camera, physics, input, animation, lighting, particles, atmosphere, perf,
`src/art/` knight, cape, props, architecture,
`src/entities/` knight-rig, player,
`src/world/` world, maps, objects, terrain,
`src/ui/` hud, menus, controls, settings, logo,
`src/systems/` save,
`assets/fonts/DejaVuSansMono.ttf` (+ licença), `assets/icons/` (3 PNG),
`tools/` sprite-viewer.html, viewer.js, viewer-props.js, glyph-test.html, make_icons.py,
`tests/` unit.mjs, play.mjs, desktop.mjs, offline.mjs, soak.mjs, perf.mjs, game.mjs, shot.mjs.

### Funcionalidades implementadas
- Canvas responsivo (DPR até 3, escala interna configurável, retrato/paisagem, aviso para girar).
- Motor tipográfico colorido com suporte japonês, profundidade, câmera 3/4 com suavização, antecipação, limites e enquadramento perto do portão.
- Cavaleiro de armadura completa (elmo com visor e brilho de brasa, aro de ouro partido, peitoral gravado com 誓, ombreiras em lâminas, escarcelas, joelheiras, grevas, sabatons, manoplas, capa vinho rasgada, montante). Vistas S/N/E/W. Respiração, caminhada, corrida (inclinação, passada longa), transição espada fincada ⇄ espada no ombro, movimento secundário (ombreiras e elmo atrasados), poeira nos passos, sombras de contato e projetadas.
- Cenário: Portão do Rei (torres, arco ogival com aduelas e pedra-chave 王, grade levadiça, friso 灰の王国·誓約, ameias e topos em 3/4, seteiras, hera, rachaduras, escombros), muralhas com brecha e contrafortes, fortaleza ao fundo, 23 árvores mortas com balanço, 20 rochas, cemitério com 14 lápides, colunata quebrada, braseiro, tochas, estandartes, cavaleiro caído.
- Fogo tipográfico animado (com 火 no núcleo), luzes oscilantes, brasas, faíscas ao acender, névoa em 2 camadas, cinzas caindo, névoa de distância, vinheta.
- Interações com narrativa ambiental (braseiro acende e salva; portão; 3 lápides; colunata; cavaleiro caído).
- Controles: joystick flutuante multitoque, correr, interagir (com estado visual), menu; teclado com teclas configuráveis; mouse (segurar para andar, clicar para andar/interagir). Bloqueio de zoom, toque duplo, rolagem, menu de contexto, "puxar para atualizar" e botão voltar.
- Menu: presets, resolução interna, limite de FPS, painel de desempenho, vibração, tamanho dos botões, teclas, voltar ao braseiro, apagar progresso.
- PWA: manifest, ícones, service worker com cache, funcionamento offline, tela de carregamento, salvamento local (configurações e progresso).

### Testes executados (todos aprovados)
Ambiente: Chrome headless (Playwright) com GPU emulada por software; emulação do Galaxy A56 (915×412 css, DPR 2,625, toque) e desktop 1600×900.
- `unit.mjs`: 221 verificações — larguras Unicode, glifo largo na grade, validade de toda a arte (materiais e larguras), geradores determinísticos, física (caixa, círculo, movimento rápido, limites), câmera, mapa.
- `glyph-test.html`: 120 glifos usados no jogo (12 kanji de largura dupla) medidos pixel a pixel em DPR 2,625 e 1 — nenhum vaza da célula, todos têm desenho. (Antes da correção, `╱ ╲ ╳` vazavam 2 px — corrigido.)
- `play.mjs` (toque real via CDP): joystick, corrida com 2 dedos simultâneos, foco e acendimento do braseiro, caixa de mensagem, chegada ao portão. (Encontrou e corrigiu: botão "continuar" ficava sob o botão de interagir.)
- `desktop.mjs`: WASD, Shift, clique para andar e interagir, segurar o mouse, Esc, troca de preset, reconfiguração de tecla (E→F), F3. (Corrigido: mensagem aparecia sobre o menu.)
- `offline.mjs`: service worker ativo, 39 arquivos em cache, recarregar sem rede funciona com a fonte embutida.
- `soak.mjs` 45 s: mapa inteiro, retrato⇄paisagem, troca de presets — sem erros; heap JS 8–15 MB; cache do cavaleiro limitado.
- Visual: capturas conferidas a cada etapa (título, cemitério, braseiro, portão, vistas do cavaleiro).

### Desempenho medido (referência relativa — GPU por software, não é o A56)
Emulação A56 a 2402×1082: lógica ≈ 0,2 ms/quadro. Otimizações aplicadas (sem reduzir arte): sombras estáticas assadas no chão (14,5 → 5,6 ms), silhueta do cavaleiro uma vez por quadro, vinheta embutida no mapa de luz e névoa de distância só na faixa de cima (14 → 5 ms), silhuetas por filtro (memória 22,8 → 1,7 MB), recorte de sprites e streaming (sprites 41,6 → 28,7 MB). FPS em software: 15 → 23–25 na ALTA; ~37 na DESEMPENHO.

### Pendente (precisa do aparelho)
- Medir FPS real, aquecimento e memória no Galaxy A56 / Chrome Android (painel de desempenho + `tools/glyph-test.html`).
- Conferir no aparelho: tela cheia + trava de paisagem, gesto voltar, vibração, instalação PWA.
- O artifact do Claude não permite service worker nem tela cheia; para testar PWA/offline use o GitHub Pages.

### Problemas conhecidos / ideias
- Diagonais (SE, SW, NE, NW) usam a vista de perfil; vistas 3/4 dedicadas entram na Fase 2.
- A fortaleza ao fundo só aparece quando a câmera enquadra o portão.
- Ataque, esquiva, bloqueio, parry e cura ainda não existem — os botões serão adicionados na Fase 3 (nenhum botão sem função agora).
- Sem áudio (Fase 7).

## Próxima etapa recomendada — Fase 2 (Protagonista)
1. Vistas diagonais dedicadas (SE/SW/NE/NW) no rig.
2. Esquiva (rolamento com quadros próprios e janela de invulnerabilidade configurável) e corrida com animação própria.
3. Poses de combate (guarda alta, preparação de golpe) reaproveitando a espada girada glifo a glifo.
4. Equipamento visual: slots trocáveis (elmo/peitoral/ombreiras/capa) com 2 conjuntos de armadura.
5. Colisão do cavaleiro com forma de cápsula e passos sobre superfícies diferentes (pedra, terra, grama).

## História (rascunho original)
O Reino das Cinzas — 灰の王国 — foi governado pelo Primeiro Rei, que selou a Chama sob juramento com a Ordem do Juramento (誓約). Quando o rei quebrou a palavra, o reino ardeu e nunca deixou de queimar; as cinzas caem até hoje. O protagonista desperta junto a um braseiro apagado, vestindo a armadura negra da Ordem com o ideograma 誓 gravado no peito, sem lembrar o próprio nome. Pistas espalhadas: um cavaleiro caído com armadura idêntica à sua; um túmulo real vazio, revolvido de dentro para fora; a inscrição no portão — «Só o último juramento abre o que o primeiro fechou». Regiões seguintes: Catedral Esquecida, Catacumbas do Silêncio, Fortaleza do Último Rei.

---

## Etapa A — Protótipo 3D tipográfico (23/11/2026)
Página separada: `prototipo3d.html` (o jogo original em `index.html` não foi alterado).

### Arquitetura
- **Geometria 3D invisível** por campos de distância (SDF): `src/proto3d/sdf.js`. Nunca é desenhada.
- **Distribuição orgânica** (`sampler.js`): varredura hierárquica + projeção na superfície + jitter + Poisson-disk → caracteres sem grade. Curvatura detecta arestas (traços `─ ═ ━` ao longo do vinco); "decals" põem caracteres fixos (誓, 王, rebites, olhos em brasa).
- **Renderizador WebGL2** (`renderer3d.js`), 4 passes: sombra do luar (a partir dos pontos), oclusão invisível (só profundidade), caracteres instanciados (iluminação por caractere: luar com sombra PCF, 3 luzes pontuais oscilantes, especular, névoa), partículas (fogo/brasas aditivos; névoa/fumaça/cinzas transparentes). O caractere muda com a luz (rampa por material), gira seguindo a superfície e vira contorno na silhueta. Culling por blocos espaciais.
- **Atlas** de caracteres gerado da própria fonte (`glyphs.js`), com proibição de blocos/quadrados.
- **Cavaleiro** (`knight3d.js`): 17 ossos, IK de pernas e braços, marcha procedural, respiração, guarda com as duas mãos ⇄ espada baixa ao andar; capa em tecido Verlet presa aos ombros, colidindo com o corpo.
- **Pátio** (`scene3d.js`): muralha com arco ogival, grade levadiça, ameias, contrafortes, friso 灰の王国, pedra-chave 王, tochas, coluna canelada quebrada, árvore morta, braseiro, lápides (墓, 眠), rochas, chão com cascalho e grama morta.
- **Câmera fixa 3/4** (yaw 15°, pitch 42°, FOV 32°) com acompanhamento suave e antecipação. Controles reaproveitados do jogo (`src/engine/input.js`).

### Números
~77 mil caracteres (pátio 68 mil, cavaleiro 8,1 mil, capa 624) + ~700 partículas; ~48–70 mil desenhados por quadro após culling. Construção: ~7,5 s no Chrome headless.

### Testes
Chrome headless (emulação A56, toque real via CDP): carrega sem erros, joystick move o cavaleiro, câmera acompanha, capturas parado/andando/perto do portão. FPS medido aqui é de GPU por software (2–4 FPS) e NÃO representa o aparelho — medir no A56 com o painel "FPS".

### Pendências / riscos
- FPS real no A56 desconhecido; tempo de construção no celular provavelmente 2–3× maior (cache dos pontos em IndexedDB é a próxima otimização).
- Luzes pontuais sem sombra própria (só o luar projeta sombra).
- Ombreiras em perfil ainda parecem "bolas"; a estrutura de lâminas precisa de mais definição.

### Etapa A — Refinamento visual (vento, luz, ambiente vivo)
- Vegetação procedural (veg3d.js): ~890 tufos de 3–5 lâminas + ~90 plantas, densidade por ruído, 4 tons.
- Vento no shader: rajadas que viajam pelo terreno + tremor individual (fases distintas), direção/força variando no tempo; o cavaleiro afasta a grama ao passar.
- Glifo da lâmina escolhido pelo ângulo na tela (| / \ ╱ ╲ ~ ' ` ´).
- Árvore balança (flag 16) proporcional à altura.
- Luz → tipografia: rampas invertidas (sombra = glifos densos, luz = leves), transparência maior na sombra, brilhos metálicos ✦ ✶ * + no aço/ouro, grama translúcida.
- Partículas iluminadas pelas luzes; cinzas com velocidades por tamanho e corrente quente sobre o fogo; névoa ondulando e respirando; poeira rasteira com o vento.
- Braseiro: chama com 3 frequências + estalos.
- Orçamento: ~83 mil caracteres (antes ~77 mil); chão de terra mais esparso para compensar.

### Etapa A — Protagonista refeito a partir da folha de referência
- Elmo fechado de viseira (quilha central, fenda única, sobrancelha saliente, respiros ∴, bevor), sem coroa.
- Couraça de aço enegrecido com gravações de bronze em veios orgânicos, plackart em lâminas e brasão do leão (獅) em escudo de ouro.
- Ombreiras de 4 lâminas com rebites; manto vinho amassado na nuca caindo sobre o ombro direito.
- Cintos de couro cruzados com fivelas, cota de malha na cintura e atrás das coxas, escarcelas de 4 lâminas.
- Manoplas de punho largo, joelheiras com aleta, grevas com quilha, sabatons pontudos em 5 lâminas.
- Espada longa: guarda de braços curvos com remates, chapa central, punho de couro, pomo em roda.
- Tecido: classe Cloth genérica — capa larga e longa com tiras rasgadas e furos + tabardo frontal que os joelhos empurram; normais por nó (mais barato por quadro).
- Pose parada como na referência: espada baixa na mão direita, ponta perto do chão.
- Orçamento: cavaleiro ~11,7 mil + tecidos ~1,2 mil; total ~87 mil.

### Etapa A — Realismo humano e armadura 3D
Diagnóstico: membros eram tubos (sem panturrilha, pulso, juntas), mãos em bloco; sem oclusão entre placas;
luz só do luar e das chamas com o mesmo brilho em todo material; ruído de ±0,45 nível por caractere apagava
o degradê; rampa do aço com letras (M W @ 8) lia como texto; pose parada rígida, sem ataque.
- Oclusão ambiente pré-calculada por caractere (SDF das peças do mesmo osso, 5 amostras ao longo da normal),
  empacotada no float de tamanho (flag 64) — zero custo por quadro.
- Shader: brilho por material (expoente), reflexo do céu/chão nos metais (Fresnel), luz lateral de recorte fria,
  AO na luz ambiente/direta/especular, arestas gastas mais claras, sombra de contato no chão, menos ruído e
  caracteres mais opacos nos modelos com AO; estrelas de reflexo só da luz direta.
- Aço em hachura de gravura (@ % # ≡ = ≈ - ·) alinhada às superfícies.
- Anatomia: bíceps, antebraço afinando, pulso, panturrilha, tornozelo; malha na axila, cotovelo e joelho;
  correias de couro; placa dorsal; manoplas com dorso, palma de couro, 4 dedos em 3 falanges + polegar
  (mão direita fechada no punho da espada); arranhões, amassados; inscrição 最後の誓 no peitoral.
- Movimento: transferência de peso (contrapposto) com joelho solto, respiração nos ombros, cabeça olhando,
  marcha com peso e braço atrasado; golpe diagonal (botão ⚔ / J / espaço) com torção, passo e equilíbrio.
- Orçamento: cavaleiro ~13,6 mil caracteres; total ~89 mil.

### Etapa A — Protagonista em escala humana real + densidade por zoom
Decisões do usuário: humano real médio · caracteres imóveis quando parado · zoom com pinça · noite ·
densidade conforme o zoom · chão: grama densa/alta, variedade, rastro · prioridade: elmo, peitoral e ombreiras.
Referências: antropometria (homem médio ~1,74 m; ombro 1,42 m; quadril 0,92 m; ombros 41,5 cm entre
articulações / 51 cm bideltoide; quadril 34 cm; mão 19 cm) e ombreiras históricas (~24 × 20 cm).
- Proporções: coxa 45 cm, canela 43 cm, braço 31 cm, antebraço 26,5 cm; tronco e pescoço mais curtos;
  escala global 0,955 → ~1,78 m com elmo. Ombreiras históricas (4 lâminas + aba junto ao pescoço).
- Elmo fechado como na imagem: viseira em proa com quilha, sobrancelha saliente, fenda dos olhos,
  respiros em fendas, bevor em lâminas, rosetas nos pinos, crista baixa.
- Densidade por zoom: cavaleiro amostrado fino (~22 mil) e ordenado em níveis encaixados (lodOrder);
  de perto desenha tudo, de longe só os primeiros N com caracteres maiores (~9 mil na distância padrão).
- Zoom com pinça (dois dedos) e roda do mouse; câmera mais baixa de perto, mais alta de longe.
- Caracteres só mudam com movimento: o caractere é escolhido pela luz média estável (a chama muda só o
  brilho); velocidade por osso (linear + angular) faz cintilar/arrastar caracteres quando o corpo se move.
- Chão: tufos mais altos e densos, folhas secas, pedrinhas, cardos e flores murchas; pegadas que deitam a
  grama e ela levanta devagar (8 últimas pegadas).


## v0.2.0 — Parte B: o 3D vira o jogo principal (23/11/2026)
Decisões do usuário: 3D no link principal · versão 2D apagada (fica no histórico do Git) · mapa inteiro recriado em 3D ·
árvores misturadas · clima automático e aleatório (com escolha no menu) · chuva com chão molhado/poças, armadura molhada,
relâmpagos e fogo que reage · animações mais realistas + arrancar/frear/virar + combo de 3 golpes · entrega única.
### Estrutura
`index.html` → `src/game/main.js` (mundo, cavaleiro, clima, interações, salvamento, laço) · `world3d.js` (mapa completo) ·
`trees3d.js` · `weather.js` · `cache.js` (IndexedDB) · `knight3d.js` · `renderer3d.js` · `fx3d.js` · `veg3d.js` · `sampler.js` ·
`sdf.js` · `glyphs.js` · `math3d.js`. Reaproveitados do 2D: `src/engine/input.js`, `typography.js`, `canvas.js`, `src/ui/*`, `src/systems/save.js`.
### Mapa (1 u = 1 cm do mapa 2D)
Muralhas de 37 m com contrafortes e duas brechas com escombros; Portão do Rei (bloco com arco ogival, aduelas, pedra-chave 王,
friso 灰の王国·誓約, ameias, mísulas, grade levadiça, tochas, dois estandartes de tecido com 誓) e torres redondas com seteiras;
fortaleza ao fundo com torre e telhado, janelas acesas; praça lajeada com colunata (5 colunas quebradas); braseiro (apagado no início:
acender = salvar/descansar); cemitério com 14 lápides (arredondadas, cruzes, pontiagudas e o túmulo real revolvido); 23 árvores
(mortas, verdes e de outono, com folhas que tremulam e caem); 20 rochas; cavaleiro caído (mesma armadura, pose sentada, capa).
Interações com mensagens: braseiro, portão, 3 lápides, colunata, cavaleiro caído.
### Clima
Limpo → garoa → chuva → tempestade (automático) ou fixo pelo menu. Chuva com gotas e respingos, superfícies molham rápido e secam
devagar, poças (≈ ondulando com a chuva) refletem céu e fogo, terra e tecido escurecem, a capa fica mais pesada, gotas escorrem
pelo aço, relâmpagos (clarões duplos/triplos com sombra), fogo enfraquece, tremula mais e solta vapor; névoa mais densa.
### Animação
Inércia (inclina ao arrancar e frear), passos curtos ao parar até assentar o pé, tronco e cabeça viram antes do quadril,
inclinação para dentro nas curvas, calcanhar→ponta no passo, corrida com fase de voo e braço bombeando, combo de 3 golpes
(diagonal, revés horizontal, vertical pesado com as duas mãos) com passo à frente e rastro da lâmina.
### Desempenho
Mundo ~200 mil caracteres + vegetação; desenha ~75–100 mil por quadro (blocos fora da tela descartados, densidade cai com a
distância, cavaleiro por zoom). Objetos entre a câmera e o cavaleiro ficam translúcidos. 1ª abertura esculpe e guarda (~11 s no PC,
mais no celular); as seguintes carregam do aparelho (~2 s).
### Testes
`tests/game.mjs`: 1ª carga e carga do cache, título, toque para começar, andar, combo, acender braseiro, tempestade, relâmpago,
portão/cavaleiro caído, cemitério — sem erros.


## v0.3.0 — Combate, tocha/escudo, caixotes, chefe e história (23/11/2026)
Decisões do usuário: combate soulslike · chefe = o rei do túmulo vazio · escudo bloqueia e apara · cenas na abertura e na
entrada do chefe, no próprio mundo 3D · escudo sorteado nos caixotes · frascos de cura · a tocha só ilumina.
- **Tocha** (mão esquerda desde o início): chama em caracteres + luz quente que acompanha o cavaleiro.
- **Caixotes e destroços** (12, `props3d.js`): quebram em 2–3 golpes, lascas voando; o escudo é sorteado (garantido até o
  último); 45% de chance de frasco de cura (máx. 3). Itens giram no chão e são pegos ao passar por cima.
- **Escudo do Juramento**: troca a mão esquerda entre tocha e escudo (⇄ / Q); segurar ⛨ / L bloqueia (gasta estamina);
  apertar no instante do golpe apara: o chefe cambaleia e o próximo golpe causa dano triplo.
- **Combate** (`gameplay.js`): vida, estamina (ataques, rolar, correr, bloquear), rolamento com invulnerabilidade, frascos
  (薬 / R), recuo ao ser atingido, quebra de guarda, morte («O JURAMENTO SE APAGA») e volta ao braseiro; descansar renova
  vida e frascos. HUD: barras de vida/estamina, frascos, barra do chefe.
- **Chefe** (`boss3d.js`): «O Primeiro Rei, Desenterrado» — morto-vivo de ~2,4 m, costelas à mostra, garras, crânio com
  órbitas acesas, coroa partida com 王, manto real em farrapos (tecido simulado), chamas espectrais e luz violeta. Ataques:
  garra, garra dupla, golpe esmagador com onda de choque; 2ª fase com 50% de vida (grito, mais rápido). Arena cercada de névoa.
  Ao morrer vira cinza (caracteres somem aos poucos) e o progresso fica salvo.
- **História** (`story.js`, original, inspirada no tom de Elden Ring): a Chama, o juramento quebrado pelo Primeiro Rei, os
  Apagados. **Cenas** (`cinema.js`): abertura de ~40 s (fortaleza, muralhas, túmulo vazio, cavaleiro caído, o despertar) e a
  entrada do chefe (tremor, o rei sai da cova, o grito, o nome). Dá para pular; «rever a abertura» no menu.
- Teste: `tests/combat.mjs` (abertura, caixotes → escudo, bloqueio, rolamento, cena e luta do chefe) — sem erros.

## APK Android (23/11/2026)
- `android/`: projeto Android mínimo (Java, sem dependências além de `androidx.webkit`). Uma WebView em tela cheia, paisagem,
  tela sempre acesa, serve o jogo de `assets/www` num endereço https local (`WebViewAssetLoader`) — módulos JS, WebGL2,
  IndexedDB e salvamento funcionam sem internet. Voltar do Android abre o menu do jogo. O service worker é desligado no app.
- `.github/workflows/apk.yml`: a cada envio do `ASHEN.zip`, o GitHub extrai o jogo dentro do projeto, compila com
  Gradle 8.7 / Java 17 e publica `ASHEN.apk` em **Releases** (e como artefato da execução). APK de depuração, assinado
  automaticamente — instala direto no celular.

---

## v0.14.0 — Migração para Three.js · Fase 1 (24/11/2026)

### Regra do visual
Tudo é desenhado primeiro como 3D de verdade — terreno, grama densa, personagens, construções, árvores,
flores e efeitos — e um pós-processamento traduz a tela inteira em caracteres, **menos o chão**, que fica
100% sólido. A grama 3D entra na máscara e vira caracteres.

### Arquitetura
- `src/vendor/three/` — Three.js r187 local (three.module.js + three.core.js, licença MIT) e, para a Fase 3,
  `addons/loaders/GLTFLoader.js` + `addons/utils/` (BufferGeometryUtils, SkeletonUtils). `index.html` tem um
  *import map* (`three`, `three/addons/`). Nada é baixado da internet.
- `src/render3/three-renderer.js` — `ThreeRenderer`, com a MESMA interface do `GlyphRenderer` antigo
  (addMesh, addSolid, updateMesh, removeMesh, removeSolid, setupParticles, resize, frame…). O jogo
  (combate, saves, mapas, cenas) não mudou.
  - Malhas sólidas (`SolidGeom`: terreno do mundo aberto, construções, corpos dos personagens) → `THREE.Mesh`
    com Lambert + texturas geradas no shader (alvenaria, madeira, terreno com bioma/trilhas/rocha).
  - Pontos de superfície (armaduras, árvores, objetos) → *surfels*: discos orientados pela normal,
    instanciados, presos aos ossos (18 ossos por uniforme, como antes). Densidade pela distância por bloco.
  - Pontos do chão (pátio, vale, pisos) → **malha contínua**: rasterizados numa grade de 20 cm (altura e cor
    médias), buracos fechados, triangulados por bloco. Frestas escuras (“vão escuro”) deitadas no chão saem.
  - Talos de vegetação → **lâminas de grama 3D** (5 níveis, vento em rajadas, o cavaleiro abre caminho,
    pegadas deitam a grama). Cada talo ganha vizinhos conforme a qualidade (1× a 2,4×).
  - Partículas (fogo aditivo, chuva, cinzas, névoa) → quadros suaves.
  - Luz: lua com sombra (PCF), luz de recorte, céu/chão (hemisfério), 6 luzes de fogo fixas (não recompila),
    névoa exponencial. Objetos entre a câmera e o cavaleiro abrem uma janela pontilhada (Bayer estável).
- **Código no alfa** do alvo da cena: 0 = chão; 1..49 = material+1; 240 fogo, 241 chuva, 242 efeito, 250 céu.
  As partículas gravam o código num 2º passe só no canal alfa.
- `src/render3/ascii-post.js` — dois passes: (1) por célula, 15 amostras → cor média do que é caractere e o
  código dominante (≥ 4 de 15 amostras; menos que isso o detalhe fica sólido junto do chão); (2) composição:
  o caractere sai da rampa do material (aço `@%#≡`, tecido `&§∫`, grama `Yψw`, fogo `·•*✶火炎`…) pela
  luminância; o fundo do caractere é o chão sólido (se o pixel é chão) ou o objeto escurecido.
- `src/render3/animation-names.js` — nomes de clipe aceitos para a Fase 3 (padrão ASHEN + Mixamo, inclusive
  clipe genérico “mixamo.com” resolvido pelo nome do arquivo) e ossos da espada.
- Menu → **Motor gráfico**: Three.js (padrão) ou Clássico. Se o Three.js falhar no aparelho, o jogo entra
  sozinho no clássico.
- Presets: célula de 10 (Extremo) a 14 px css (Desempenho), grama 2,4× a 1×, mapa de sombra 4096 a 1024.

### Testes (Chrome headless, GPU por software — FPS daqui não vale para o A56)
- Novo jogo → abertura → andar → ataque: sem erros. Passeio: Portão do Rei, Vale de Orvalho, Palácio e
  Mundo Aberto (construído na hora): sem erros. Motor clássico: continua funcionando.
- Números (Equilibrada, 1373×618): 125×35 células; Portão ~256 mil instâncias 3D / 235 mil triângulos sólidos /
  65–113 desenhos; Mundo Aberto ~265 mil instâncias / 475 mil triângulos.

### Pendente / riscos
- FPS real no Galaxy A56 desconhecido: a grama 3D e as sombras dos surfels são o maior custo. Se pesar,
  primeiro passo: Desempenho, depois reduzir grama e tirar a sombra dos surfels estáticos.
- Fase 2: densidade de células pelo zoom, caracteres de aresta pela direção da borda, decalques (誓, 王) e
  brilho metálico no pós; afinar exposição por área.
- Fase 3: carregar `assets/models/*.glb` com GLTFLoader + AnimationMixer usando `animation-names.js`.

### v0.14.1 — Ajuste do shader de caracteres (24/11/2026)
- Sem fundo preto: o fundo de cada célula é a própria cor do 3D (×0,55) e o traço é essa cor puxada para a luz
  (ou para a sombra onde o 3D já é claro). Volume, sombra e silhueta vêm do 3D; o chão segue sólido e corta o
  traço na borda dos objetos.
- Células menores (7 a 10,5 px css por preset, antes 10 a 14) e recorte justo do atlas (sem margem): o traço
  encosta na borda da célula.
- Segunda camada: grade deslocada meia célula com o caractere um tom abaixo, a 50% — preenche as frestas e
  forma uma textura contínua de símbolos.
- Ajustes em `ascii-post.js`: `uBody` (fundo), `uInk` (traço), `uCrop` (recorte), `uLayer2` (2ª camada).

### v0.14.2 — Caracteres como gravura sobre o 3D (24/11/2026)
- Cor sempre do pixel 3D em resolução total (sem cor média por célula, sem mosaico); a célula só escolhe
  QUAL caractere. O traço esculpe a cor: relevo que brilha na luz direta, sulco sutil na sombra profunda.
- Profundidade real (DepthTexture do alvo da cena) → os caracteres dissolvem na névoa (mesma densidade da
  cena) e somem entre 14 e 42 m.
- Células de 5 a 7,5 px css (Extremo → Desempenho; Equilibrada 6).
- Ajustes em `ascii-post.js`: `uCarve` (sulco), `uGlow` (brilho do traço), `uFade0/uFade1` (distância), `uLayer2`.
- Visto nas capturas: o que ainda parece "pontilhado" vem da geometria em discos (surfels) das armaduras,
  árvores e pilares, não do shader — alvo da Fase 2 (superfícies contínuas).

## v0.15.0 — Fase 2 (parte 1): caracteres no espaço 3D, geometria contínua (24/11/2026)
- **Fim da grade de tela**: `ascii-post.js` saiu. Os caracteres são gravados nos materiais (`glyph-material.js`):
  - construções, pedras, árvores, água: grade de caracteres **triplanar no mundo** (célula 4,5–9 cm conforme o material);
  - personagens: grade nas **coordenadas de repouso do corpo** (célula 3,4 cm) → andam com a armadura;
  - tecidos: grade no **próprio pano** → seguem as dobras;
  - grama: caracteres ao longo da lâmina; corolas das flores recortadas no formato do caractere (✻ ● ✶).
- **Relevo e brilho**: o traço perturba a normal (derivada do traço, como o bump do Three) e controla o
  especular Blinn-Phong (MeshPhongMaterial) — bordas brilham com a cor da luz real: quente no fogo, fria na lua.
  Brilho por material (`gloss`/`spec` da tabela de materiais).
- **Distância e névoa**: o caractere some quando a célula fica menor que ~3 px e entre 18 e 46 m; a névoa do
  Three cobre o resto. Sem serrilhado (textureGrad com as derivadas da grade contínua).
- **Sem discos**: corpos sólidos (`SolidGeom`) e, para objetos sem corpo (escudo, tocha, caixotes, coroa,
  grade levadiça, relicário), uma casca gerada dos pontos (`hullFromPoints`, 2 cm); chão e rio em grade
  contínua; capa/tabardo/estandartes viram a malha da simulação com a bainha rasgada recortada por máscara.
  Sobram quadrinhos só para caracteres FIXOS (kanji gravados, brasões, brasas, lâmina azul) e partículas —
  cada um desenhado como o próprio caractere recortado, em relevo.
- **Chão**: continua 100% sólido, sem caracteres.
- Ajustes rápidos (uniformes em `three-renderer.js`): `uBump` (relevo), `uGlyphFade0/1` (distância);
  tamanhos de célula em `ashenBase` (SOLID_F).
- Testes: Portão, Vale, Palácio, Mundo Aberto, novo jogo/andar/atacar — sem erros (headless).

## v0.16.0 — Ajustes de realismo + corpos das formas modeladas + preparo do .glb (24/11/2026)
- **Chão**: terra com grão em 3 escalas, pedrinhas, rachaduras finas, tudo em relevo (mesmo bump dos caracteres)
  e mais brilho quando molhado. O chão continua sem caracteres.
- **Sombra de contato**: até 8 personagens visíveis (osso da bacia) escurecem o chão e a grama em volta dos pés;
  base dos talos mais escura (oclusão).
- **Flores**: saturação a 42% e brilho a ~50% (tons secos, sem neon).
- **Anatomia/silhueta**: no motor Three.js, o corpo de cada personagem é a malha das próprias formas modeladas
  (SDF de cada peça → surface nets, `partsMesh` em `solid.js`, 1,4 cm no cavaleiro/samurai e 1,8 cm nos demais),
  em vez da casca tirada dos pontos. Ombreiras, elmo, placas e espada com o volume e o contorno do modelo;
  cavaleiro ~85 mil triângulos. O motor clássico continua com a casca antiga (cache separado).
- **Fase 3 preparada**: `src/render3/glb-models.js` (GLTFLoader + AnimationMixer, crossfade, estados do combate),
  `R.attachModel`; se existir `assets/models/<classe>.glb` ele vira o corpo do jogador. Testado com um .glb de teste
  com clipes no estilo Mixamo ("Sword And Shield Idle", "Armature|Walking|Layer0"…): carregou, normalizou a altura e
  tocou as animações. O arquivo de teste não vai no zip. Capa e tabardo continuam por cima do modelo (decidir na Fase 3).

## v0.17.0 — Fase 3: modelos .glb (24/11/2026)
- `glb-models.js`: `loadTemplate` (GLTFLoader), `instantiate` (cópia com SkeletonUtils + AnimationMixer por malha),
  `stateOf` (jogador), `enemyState` (morte/golpe/ataque dos inimigos), `playState` (crossfade; sem clipe fica no anterior).
- `ThreeRenderer.loadModels(MODEL_NAMES)`: procura `assets/models/<nome>.glb` para 14 personagens; cada conjunto de
  pontos leva `modelName` e TODA malha daquele personagem ganha o modelo (inclusive as criadas depois, como os grupos
  do mundo aberto). O modelo só aparece quando o jogo dá `mesh.modelMatrix`; sem isso fica o corpo atual.
- Materiais do .glb → MeshPhong com a mesma gravação de caracteres (relevo + especular), coordenadas de repouso do
  modelo (em metros pela escala do mundo) → os caracteres andam com o esqueleto. Família de caracteres pelo nome do
  material; senão pela cor/metal.
- Altura: medida do corpo atual pelos ossos (cabeça → pés) e aplicada ao modelo normalizado.
- Ligados: jogador (capa e tabardo do jogo somem com .glb), aldeões, mortos do vale, mortos/goblins do mundo aberto,
  inimigos da cripta. Cavaleiro caído e Ser Caedmon ficam com o corpo atual (poses especiais).
- Teste: .glb de teste com clipes no estilo Mixamo para `knight` e `ghoul` → os dois carregaram, ficaram com caracteres
  gravados, altura certa (~1,65–1,66 no espaço do jogo), animação de andar/parado; sem os arquivos, tudo volta ao normal.
- Pendente: chefes (boss, profano, ogre, spider, rei goblin) ainda não passam a posição para o modelo; tocha e escudo
  do jogador seguem a mão do esqueleto procedural (não a do .glb); cada personagem sem arquivo gera um aviso 404 no console.

## v0.18.0 — Fase 3 concluída (24/11/2026)
- Chefes ligados ao .glb: Rei (`boss`; o manto procedural some com o modelo), Profano, Ogro (parado enquanto emerge),
  Aranha, Rei Goblin (`goblinKing`); enterrados = clipe de morte; o resto via `enemyState` (morte, golpe, ataque) e velocidade.
- Mãos do modelo: `instantiate` acha LeftHand/RightHand (Mixamo com ou sem ":", Hand_L, hand.L…). Tocha e escudo
  seguem a mão esquerda do modelo (mantendo a inclinação do jogo); espada avulsa (`swordMesh`, feita das peças do osso
  da espada) aparece na mão direita quando o modelo não tem espada própria (`Sword`/`Weapon`/`Espada`/`Katana`).
  O acerto do golpe continua calculado pelo esqueleto do jogo (o mesmo de antes).
- Altura: esqueletos humanos medem cabeça → pés; Profano/Aranha/Encapuzado usam `DEFAULT_HEIGHT`.
- Teste: .glb de teste com mãos `mixamorig:LeftHand/RightHand` como `knight` e `boss` → jogador e Rei com modelo,
  espada na mão direita, tocha na esquerda, sem erros; sem arquivos, tudo volta ao corpo atual.

---

# Nova direção visual — ASCII artístico de alta densidade (referências: vídeos "Fake shadows test" e "Waterfall test")

## v0.19.0 — Fase 1: renderizador ASCII sobre preto + tapete de grama em traços (24/11/2026)
Decisões do usuário: motor antigo como reserva escondida; chão sem grama com textura mínima `. :` só onde a luz
de tocha/fogueira/lustre bate; lua gigante e nuvens só nos reflexos da água (Fase 3) e sombras de nuvem na grama.
- **Motor** `ascii` (padrão; `ThreeRenderer` em modo ASCII). Menu → "Motor gráfico (reserva)": ASCII, 3D gravado,
  Clássico. A interface do renderizador é a mesma → mecânicas, saves, HUD, controles e builds intactos.
- **Quadro** (3 passos):
  1. objetos (camada 0) num alvo de 2×2 amostras por célula, com projeção ajustada à grade: cor iluminada,
     código do material no alfa (+100 = personagem) e profundidade;
  2. `ascii-pass.js`: cada célula vira UM caractere nítido sobre preto puro; famílias por material (metal
     `.:+%&#WM@` prateado, pano, pedra `.-=oQ8B#@`, tijolo, madeira, folhagem, carne, água, fogo); personagens com
     mais exposição e um piso de brilho; piso só com `.`/`:` apagado onde há luz de tocha/fogo (posição reconstruída
     da profundidade); grava a profundidade dos objetos;
  3. camada 1 direto na tela, respeitando a profundidade: **grama em traços** (linhas com largura fixa em pixels,
     2 segmentos, verde-musgo/floresta com variação, alguns traços acesos, vento em ondas, abre onde o personagem
     passa e fica deitada nas pegadas), **flores pálidas** (caracteres virados para a câmera), partículas e
     **brasas/folhas laranja** soltas no ar (220, levadas pelo vento; só ao ar livre).
- **Sombras falsas / luz**: sombra da lua (mapa de sombra) na grama, mancha sob os pés (até 8 personagens),
  sombras de nuvens passando (ruído levado pelo vento), luz de tocha/fogueiras tingindo os traços; névoa vai para o preto.
- **Câmera** elevada: 56°–63° conforme o zoom (pinça continua).
- **Presets**: célula 5/5,5/6/7,5 px css; traços por talo 7/4,4/3,4/2,2; grama cai com a distância a partir de 6,5 m.
- Testes headless: Portão, frente do portão, Palácio, Vale, Mundo Aberto — sem erros. (FPS headless não vale.)
- Próximo (Fase 2): personagens/estruturas com ASCII fino de alto contraste, paletas (tijolo/terracota, pedra cinza,
  copas verde-escuro/ferrugem), bordas; (Fase 3) água negra com reflexo da lua/nuvens/personagem, cachoeira, névoa,
  chuva e magia em caracteres, ajuste final dos 4 presets.

## v0.20.0 — Fase 2: paleta sóbria e caracteres finos (24/11/2026)
- `ascii-pass.js`: a cor deixa de ser a do material e passa a ser uma **paleta por família** (escuro → claro):
  metal prata `(0,07…0,93)`, pano na própria cor (capa vinho), pedra cinza profunda, tijolo/terracota escuro
  (reboco), madeira marrom, copas verde-escuro ou ferrugem (pela cor da folha), pele/carne, água, fogo.
- **Sombra some no preto**: em estruturas, abaixo de lum 0,07 a célula fica preta e o brilho cai suavemente
  (smoothstep 0,07–0,4) até sumir; personagens nunca somem.
- **Silhueta dos personagens**: personagem (código +100) tem exposição 2,2×, piso de brilho e **contorno aceso**
  (célula com vizinho vazio ou de outra coisa → traço ≥ 0,72): legível na grama densa. Vale para cavaleiro,
  samurai, inimigos, chefes e modelos .glb.
- **Variação de caractere** entre células vizinhas (± na rampa por célula, estável) → as paredes não viram um bloco
  de `@` iguais.
- Família de cada código numa textura 256×1 (arrays de uniformes de 256 estouravam o limite de alguns Android).

## v0.21.0 — Fase 3: água negra espelhada, efeitos em caracteres, presets (24/11/2026)
- **Casas da vila** em tijolo/terracota escuro (o reboco das casas vira a família "tijolo"); muralhas, castelo,
  igreja e ruínas continuam em pedra cinza.
- **Água espelhada** (`ascii-pass.js` + passo extra no `ThreeRenderer`): rio do Portão (plano = altura média dos
  pontos de água) e lagos do mundo aberto (terreno no nível da água vira código de água).
  - Reflexo real: o mundo inteiro espelhado no plano da água (matriz da cena com determinante negativo → faces
    corretas), recortado por um plano de corte (só o que está acima da água), num alvo de 1 amostra por célula.
  - Água negra; o reflexo vira caracteres azulados ondulando (correnteza + anéis e espuma onde o jogador pisa +
    respingos da chuva); margens refletidas ficam escuras.
  - **Lua cheia gigante** em caracteres (crateras por ruído, halo) e **nuvens** correndo com o vento no céu
    refletido; a lua fica parada num ponto da tela (está no infinito); na Lua Sombria ela fica vermelha.
  - No mundo aberto o reflexo só é desenhado quando há lago perto da câmera (checagem a cada 15 quadros).
- **Efeitos**: chuva, névoa, poeira e magia puxados para branco/azul-gelo (fogo e brasas mantêm a cor); todos já
  são caracteres soltos no ar.
- **Presets** (célula · traços por talo · mapa de sombra · reflexo a cada N quadros):
  Extremo 5 px · 7 · 4096 · 1 | Alta 5,5 · 4,4 · 2048 · 1 | Equilibrada 6 · 3,4 · 2048 · 2 | Desempenho 7,5 · 2,2 · 1024 · 3.
- Cachoeiras: o jogo ainda não tem nenhuma; quando entrar uma, ela usa as mesmas partículas e o mesmo reflexo.
- Testes headless: Portão (rio com reflexo e lua), Vale (casas), Palácio, Mundo Aberto — sem erros.

### v0.26.0 — Legibilidade, contraste e realismo dos seres vivos
**Corcel negro**
- Materiais próprios: pelagem (grafite → aço/chumbo azulado → prata-azulado) e crina/cauda (cinza → prata → branco acinzentado, em fios finos `ʃ | / \ ( ) ‖ ǀ`). Preto puro só nas dobras fundas.
- Borda lunar: linha de prata fria no contorno de cima (cabeça, crina, dorso, garupa).
- Canto do corcel ao lado da fogueira sem árvores nem pedras (raio de ~7 m); ele pasta perto de onde parou, sem ir para trás das árvores.
**Jogador e inimigos no campo escuro (câmera a 15 m)**
- Contorno do jogador mais claro: marfim na borda de cima (elmo, ombros, braços, ponta da espada), prata nas laterais; vale também montado.
- Placas de aço com brilho prata/branco frio mais cedo; borda de cima da capa em carmesim aceso; o cavaleiro nunca fica abaixo de um brilho mínimo.
- Inimigos e NPCs: borda lunar prateada mais discreta.
**Chefes**
- Clarão de impacto nos caracteres em todos os chefes (Rei do túmulo, Profano, Ogro da Lua Sombria, Rei Goblin, Tecelã do Poço) e nos inimigos da vila e da masmorra.
**Correção**
- Os códigos de material no alvo dos personagens foram afastados da marca do jogador (+165): materiais novos não se confundem mais com o jogador.
- Custo de GPU: só cor, rampa e contraste no shader já existente (nenhuma luz ou sombra nova). Mundo guardado no aparelho continua valendo (só o corcel é refeito na primeira abertura).

## v0.25.0 — Seres vivos nítidos, relevo suave e cachoeiras como no vídeo
**Nitidez e densidade**
- Caracteres nítidos em qualquer tamanho: o atlas é lido no nível de detalhe do tamanho real do caractere e o traço é binarizado com borda curta (afiado em vez de borrado).
- Personagens, cavalo, NPCs e inimigos: grade 4× mais fina que o cenário (5× quando a célula é grande), sem o limite antigo de 3×.
- Cenário com ~20% mais caracteres por lado (células do mundo menores em todos os presets). A grama aprovada não mudou.
**Seres vivos mais realistas (tudo pela cor/densidade dos caracteres)**
- Contraste local: cada caractere comparado com os vizinhos esculpe placas da armadura, músculos, cabeça, crina e cauda.
- Contorno com direção: borda de cima acesa pela lua (prata), borda de baixo na sombra; brilho prateado no aço e na pelagem.
- Respiração (onda lenta subindo pelo corpo parado), músculos em movimento (faixas que correm quando anda/galopa, pela velocidade do corpo), capa ondulando e clarão nos caracteres quando apanha (jogador, inimigos do mundo aberto e corcel).
**Relevo**
- Reino predominantemente plano: ondulações leves, colinas baixas, bacias rasas de lagos e rios suaves; montanhas só no anel das bordas. No miolo do mapa a altura varia ~−16 a +18 m (só nos poços e penhascos das cachoeiras).
**Cachoeiras (como no vídeo de referência)**
- 4 penhascos esculpidos no relevo (platô atrás, paredão, poço na base); a mais perto fica a ~45 m da fogueira da chegada.
- Paredão coberto de pedras escuras arredondadas com musgo; moitas verdes em volta.
- Cortina larga de caracteres em colunas listradas (azul do céu no alto → branco embaixo), espuma e respingos `o O * ~ °`, nuvem densa de névoa branca subindo da base, brilhos `✦` piscando, reflexo na água e rumor.

## v0.24.0 — Corcel, mapa do mundo, cachoeiras e personagens em alta definição
**Visual**
- Paleta em 3 faixas por família (sombra → meio-tom → brilho): aço chumbo → azul frio → prata; capa vinho nas dobras → carmesim; pedra azul-negro → ardósia → cinza; copas azul-petróleo → musgo → oliva. Perto de tocha/fogueira/lustre a cor puxa para dourado/âmbar.
- Grama com manchas de tom pelo campo (musgo profundo, verde-azulado frio, oliva apagado) e ponta do traço acesa pela lua/tocha.
- Personagens, criaturas, cavalo e objetos interativos: alvo próprio com grade até 4× mais fina que o cenário (o custo fica só onde eles aparecem; a grade nunca desce de ~4 px por caractere). Rampa própria, mais rica. O tamanho continua preso ao mundo: o zoom não muda a quantidade de caracteres.
- Contorno fino do jogador: traço de 1 célula em volta da silhueta, escolhido pelo ângulo da borda (`/ | \ _ - ( ) < > ~ =`).
**Corcel negro (mundo aberto)**
- Ao lado da Fogueira do Reino Partido: pelagem negra com reflexo prateado-azulado, crina e cauda, sela e bridão vermelho-escuro, estribos e freio de aço. Passo, trote e galope com movimento de pernas, pescoço e cauda; pasta parado; cascos soam.
- Montar/desmontar no botão de interação. Trote (~4,2 m/s) livre; galope (~7,7 m/s) segurando correr, gasta fôlego. Golpe lateral montado (o tronco vira para o lado do inimigo mais próximo).
- Assobio: tecla H ou botão ♪ no HUD (aparece depois de conhecer o corcel). Ele vem galopando e contorna lagos.
- Leva parte do dano quando você está montado; se apanhar demais, derruba você, empina e foge assustado (nunca morre). Volta quando você assobia.
- Posição, se já foi encontrado e se você estava montado ficam no save. Opcional: `assets/models/horse.glb`.
**Mapa do mundo**
- Tecla M, botão ▦ no HUD ou "mapa do mundo" no menu. Desenhado em caracteres: relevo sombreado, água, florestas, montanhas, neve.
- Névoa de guerra (128×128) que se abre conforme você explora, salva no save. Fogueiras e lugares importantes aparecem só depois de vistos; corcel e você (com a direção do olhar).
- Arrastar com um dedo, pinça para zoom, duplo toque para centralizar; + − ◎ ✕ na tela.
**Cachoeiras**
- 5 cachoeiras nas encostas que caem em lagos do Reino Partido (a mais perto fica a ~250 m da fogueira). Colunas de caracteres finos caindo (`| ! : ; . * o O + ~`), espuma branca e névoa na base, reflexo na água negra e rumor de água que cresce quando você chega perto.

## v0.23.0 — Grama leve e volume em caracteres
- Grama ASCII refeita: um caractere simples por talo (`|` `/` `\` `v` `'` `,`) em verde-oliva/musgo apagado, com pontinhos brancos (`o` `*` `.`). No máximo um traço por célula do mundo, então nada se sobrepõe nem borra.
- Sem física de grama: o vento só escolhe a inclinação do caractere e passa uma faixa de luz pela cor. O cavaleiro abre a grama ao passar (inclinação do caractere).
- Mundo aberto: de ~131 mil para ~31 mil traços desenhados, cada um com um shader muito mais simples (1 quadrado, sem rastro/oclusão por personagem).
- Objetos com volume: 9 níveis de luz × 4 variantes por família (letras, números e símbolos do mesmo peso). Luz forte = `@ # 8 Q W M`; meio-tom = `o e c z a`; sombra = `: - , .` menores, até sumir no preto. Exposição recalibrada para não saturar tudo no nível cheio.
- Quinas e silhuetas de pedra, tijolo e madeira viram traços orientados (`|` `/` `-` `\`).
- Movimento sem custo: nas bordas de copas, capa e água, e no fogo, os caracteres trocam de variante com o tempo e a cor tremula.
- Motor "3D gravado" removido do menu e da inicialização (quem estava nele passa para o ASCII). Ficam ASCII (padrão) e Clássico (reserva).

## v0.22.1 — Câmera 3/4 (25/11/2026)
- Inclinação da câmera ASCII de 69°–74° (quase de cima) para **42°–50°** (3/4), mantendo a distância (8–30 m,
  padrão 15 m): dá para ver a altura do personagem e das construções, com profundidade até o horizonte.
- Máscara de sombras cobre 92 m (antes 68) para acompanhar o horizonte maior.
- Capa, tabardo e estandartes do personagem usam a grade fina dos personagens (antes saíam com o caractere grande do cenário).
