// ASHEN — Configurações gráficas e de controle
// Três presets preservam o estilo: só mudam resolução interna, mapa de luz e efeitos SECUNDÁRIOS.
// Armaduras, personagens e arquitetura nunca são simplificados.

export const PRESETS = {
  ALTA: {
    label: 'Alta', desc: 'Máximo detalhamento, luz avançada, névoa em 2 camadas, partículas abundantes.',
    renderScale: 1, lightRes: 0.5, ash: 260, secondary: 1, fogDetail: 1, fogDensity: 1, castShadows: 'all', glow: true,
  },
  EQUILIBRADA: {
    label: 'Equilibrada', desc: 'Mesmo estilo; resolução interna 85%, efeitos secundários moderados.',
    renderScale: 0.85, lightRes: 0.36, ash: 170, secondary: 0.7, fogDetail: 1, fogDensity: 0.9, castShadows: 'all', glow: true,
  },
  DESEMPENHO: {
    label: 'Desempenho', desc: 'Personagens e armaduras intactos; menos partículas e efeitos distantes.',
    renderScale: 0.72, lightRes: 0.25, ash: 100, secondary: 0.4, fogDetail: 0, fogDensity: 0.8, castShadows: 'player', glow: false,
  },
};

export const DEFAULT_SETTINGS = {
  preset: 'ALTA',
  renderScale: null,   // null = usa o do preset
  fpsCap: 60,          // 30 | 60 | 0 (sem limite)
  showPerf: false,
  haptics: true,
  controlScale: 1,
  bindings: null,
};

export function effective(settings) {
  const p = PRESETS[settings.preset] || PRESETS.ALTA;
  return { ...p, renderScale: settings.renderScale ?? p.renderScale };
}
