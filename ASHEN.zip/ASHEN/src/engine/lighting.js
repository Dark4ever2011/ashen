// ASHEN — Iluminação
// Mapa de luz em resolução reduzida (luz é suave; os caracteres continuam nítidos):
//   1) preenche com a cor ambiente (luar), 2) soma as luzes (aditivo),
//   3) multiplica sobre a cena. Depois um passe aditivo de brilho (glow) perto do fogo.
// Luzes oscilam (fogo) com ruído. Também fornece a luz dominante para sombras projetadas.

import { makeCanvas } from './canvas.js';
import { noise1 } from './animation.js';

export class Lighting {
  constructor() {
    this.lights = [];
    this.ambient = [0.34, 0.36, 0.46];
    this.res = 0.5;
    this.canvas = null;
    this.ctx = null;
    this.stamps = new Map();
    this.enabled = true;
    this.glow = true;
    this.vignette = 1;
  }

  add(l) {
    const light = Object.assign({ z: 40, radius: 300, color: [1, 0.6, 0.3], intensity: 1, flicker: 0, speed: 6, seed: Math.random() * 100, on: true, casts: true, glow: 0 }, l);
    light.value = light.intensity;
    this.lights.push(light);
    return light;
  }

  _stamp(color) {
    const key = color.join(',');
    let s = this.stamps.get(key);
    if (s) return s;
    const N = 128;
    s = makeCanvas(N, N);
    const x = s.getContext('2d');
    const g = x.createRadialGradient(N / 2, N / 2, 0, N / 2, N / 2, N / 2);
    const [r, gg, b] = color.map(v => Math.round(Math.min(1, v) * 255));
    // Queda suave (aprox. quadrática) — evita "anéis".
    const stops = [[0, 1], [0.18, 0.86], [0.38, 0.55], [0.6, 0.26], [0.8, 0.08], [1, 0]];
    for (const [t, a] of stops) g.addColorStop(t, `rgba(${r},${gg},${b},${a})`);
    x.fillStyle = g;
    x.fillRect(0, 0, N, N);
    this.stamps.set(key, s);
    return s;
  }

  update(t) {
    for (const l of this.lights) {
      if (!l.on) { l.value += (0 - l.value) * 0.1; continue; }
      let f = 1;
      if (l.flicker > 0) {
        const n = noise1(t * l.speed + l.seed) * 0.6 + noise1(t * l.speed * 2.7 + l.seed * 3) * 0.4;
        f = 1 - l.flicker * (0.5 + 0.5 * n);
      }
      const target = l.intensity * f;
      l.value += (target - l.value) * 0.35;
    }
  }

  ensure(r) {
    const w = Math.max(16, Math.ceil(r.W * this.res)), h = Math.max(16, Math.ceil(r.H * this.res));
    if (!this.canvas || this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas = makeCanvas(w, h);
      this.ctx = this.canvas.getContext('2d');
      this.baseKey = '';
    }
    // Base do mapa: cor ambiente (luar) já com a vinheta — a vinheta sai "de graça" no multiply.
    const key = this.ambient.join(',') + '|' + this.vignette;
    if (key !== this.baseKey) {
      this.baseKey = key;
      if (!this.base || this.base.width !== w || this.base.height !== h) this.base = makeCanvas(w, h);
      const b = this.base.getContext('2d');
      const [ar, ag, ab] = this.ambient;
      b.globalCompositeOperation = 'source-over';
      b.fillStyle = `rgb(${ar * 255 | 0},${ag * 255 | 0},${ab * 255 | 0})`;
      b.fillRect(0, 0, w, h);
      if (this.vignette > 0) {
        const g = b.createRadialGradient(w / 2, h * 0.56, Math.min(w, h) * 0.3, w / 2, h * 0.56, Math.hypot(w, h) * 0.62);
        g.addColorStop(0, 'rgba(0,0,0,0)');
        g.addColorStop(0.7, `rgba(0,0,0,${0.22 * this.vignette})`);
        g.addColorStop(1, `rgba(0,0,0,${0.66 * this.vignette})`);
        b.fillStyle = g; b.fillRect(0, 0, w, h);
      }
    }
  }

  /** Constrói o mapa de luz e multiplica sobre o quadro atual. */
  apply(r) {
    if (!this.enabled) return;
    this.ensure(r);
    const lc = this.ctx, k = this.res;
    lc.globalCompositeOperation = 'copy';
    lc.drawImage(this.base, 0, 0);
    lc.globalCompositeOperation = 'lighter';
    for (const l of this.lights) {
      if (l.value < 0.01) continue;
      const rad = l.radius * r.S;
      const cx = r.dx(l.x), cy = r.dy(l.y, 0);
      if (cx + rad < 0 || cx - rad > r.W || cy + rad < -rad || cy - rad * 0.8 > r.H) continue;
      lc.globalAlpha = Math.min(1, l.value);
      // Elipse: o chão é achatado pela projeção; esticamos um pouco para cima para iluminar corpos.
      const ry = rad * 0.86;
      lc.drawImage(this._stamp(l.color), (cx - rad) * k, (cy - ry - l.z * r.S * 0.35) * k, rad * 2 * k, ry * 2 * k);
    }
    lc.globalAlpha = 1;
    lc.globalCompositeOperation = 'source-over';
    const ctx = r.ctx;
    ctx.globalCompositeOperation = 'multiply';
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(this.canvas, 0, 0, r.W, r.H);
    ctx.globalCompositeOperation = 'source-over';
  }

  /** Brilho aditivo (halo quente) das luzes com glow > 0. */
  applyGlow(r) {
    if (!this.glow) return;
    const ctx = r.ctx;
    ctx.globalCompositeOperation = 'lighter';
    for (const l of this.lights) {
      if (!l.glow || l.value < 0.02) continue;
      const rad = l.radius * 0.42 * r.S;
      const cx = r.dx(l.x), cy = r.dy(l.y, l.z);
      if (cx + rad < 0 || cx - rad > r.W || cy + rad < 0 || cy - rad > r.H) continue;
      ctx.globalAlpha = Math.min(1, l.value * l.glow);
      ctx.drawImage(this._stamp(l.color), cx - rad, cy - rad, rad * 2, rad * 2);
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
  }

  /** Luz pontual dominante num ponto (para sombra projetada). */
  dominant(x, y) {
    let best = null, bestV = 0;
    for (const l of this.lights) {
      if (!l.casts || l.value < 0.05) continue;
      const d = Math.hypot(x - l.x, y - l.y);
      if (d > l.radius) continue;
      const v = l.value * (1 - d / l.radius);
      if (v > bestV) { bestV = v; best = l; }
    }
    return best ? { light: best, strength: bestV } : null;
  }

  /** Luz aproximada (0..1) num ponto: usada para decidir brilho de glifos emissivos. */
  levelAt(x, y) {
    let v = (this.ambient[0] + this.ambient[1] + this.ambient[2]) / 3;
    for (const l of this.lights) {
      const d = Math.hypot(x - l.x, y - l.y);
      if (d < l.radius) v += l.value * (1 - d / l.radius) ** 2;
    }
    return Math.min(1, v);
  }
}
