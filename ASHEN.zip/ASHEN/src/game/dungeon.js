// ASHEN 3D — A Cripta dos Goblins (dungeon do Reino Partido).
// Um mausoléu a oeste da chegada desce para salas escavadas: sala de entrada (fogueira), sala da guarda
// (goblins e um morto), corredor leste até a sala da alavanca, grade que se abre, e o salão do Rei Goblin.
// Vencer o rei abre o baú com a espada nova (uma para cada classe).

import { enemyState } from '../render3/glb-models.js';
import { m4, v3, noise3 } from './math3d.js';
import * as S from './sdf.js';
import { MAT } from './glyphs.js';
import { buildParts, PointSet } from './sampler.js';
import { flatBones } from './renderer3d.js';
import { COMBO, swordSegment } from './knight3d.js';
import { hurtPlayer, DMG_TABLE } from './gameplay.js';
import { registerHit } from './bleed.js';
import { Boss, poseBoss } from './boss3d.js';
import { Ghoul, GSCALE } from './npc3d.js';
import { Goblin, KING_SCALE, KING_HP } from './goblin.js';
import { SITES, heightAt } from './ow.js';
import { itemInfo, applyEquip } from './items.js';

const $ = id => document.getElementById(id);
const snd = (g, n, k) => g.audio && g.audio.play(n, k);
const I = m4.ident();
const sm = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };
export const DO = { x: 700, z: 0 };
const X = x => DO.x + x;
const WALL_H = 3.4;
// salas e corredores (retângulos onde se anda, em coordenadas locais)
const RECTS = [
  [-4, -2, 4, 6],        // entrada (fogueira)
  [-1.2, -8, 1.2, -2],   // corredor
  [-6, -18, 6, -8],      // sala da guarda
  [6, -14, 12, -12],     // corredor leste
  [12, -20, 20, -6],     // sala da alavanca
  [-1.2, -24, 1.2, -18], // corredor da grade
  [-9, -42, 9, -24],     // salão do Rei Goblin
];
const ROOM_NAMES = ['Sala da Entrada', null, 'Sala da Guarda', null, 'Sala da Alavanca', null, 'Salão do Rei Goblin'];
export const DG_ENTRY = { x: X(0), z: 4.6 }, DG_FIRE = { x: X(2.4), z: 3.2 }, DG_LEVER = { x: X(19.3), z: -13 }, DG_CHEST = { x: X(0), z: -40.2 };
const GATE_Z = -18.3;
const KING_AT = { x: X(0), z: -34 };
export const CRYPT = { x: SITES.crypt.x, z: SITES.crypt.z };          // mausoléu no Reino Partido
export const CRYPT_DOOR = { x: CRYPT.x + 3.4, z: CRYPT.z };

const C = 0.5, GX0 = -11, GZ0 = -44, GW = 34 / C, GD = 52 / C;
const walk = (lx, lz) => RECTS.some(([x0, z0, x1, z1]) => lx > x0 && lx < x1 && lz > z0 && lz < z1);
// paredes: células fora das salas que encostam numa sala; juntadas em faixas por linha
const STRIPS = (() => {
  const out = [];
  for (let j = 0; j < GD; j++) {
    let run = -1;
    for (let i = 0; i <= GW; i++) {
      const cx = GX0 + (i + 0.5) * C, cz = GZ0 + (j + 0.5) * C;
      let wall = false;
      if (i < GW && !walk(cx, cz)) for (let a = -1; a <= 1 && !wall; a++) for (let b = -1; b <= 1; b++) if (walk(cx + a * C, cz + b * C)) { wall = true; break; }
      if (wall && run < 0) run = i;
      if (!wall && run >= 0) { out.push([GX0 + run * C, cz - C / 2, GX0 + i * C, cz + C / 2]); run = -1; }
    }
  }
  return out;
})();
const WALL_COLS = STRIPS.map(([x0, z0, x1, z1]) => ({ type: 'box', x0: X(x0), z0, x1: X(x1), z1 }));
const BOUNDS = { x0: X(-11), z0: -44, x1: X(22), z1: 7 };
const GATE_COL = { type: 'box', x0: X(-1.3), z0: GATE_Z - 0.25, x1: X(1.3), z1: GATE_Z + 0.25 };

// ─────────────── modelos ───────────────
function dungeonParts() {
  const P = [];
  for (const [x0, z0, x1, z1] of RECTS) {
    P.push({ name: 'chão da cripta', f: (x, y, z) => Math.max(y, -0.1 - y, Math.abs(x - X((x0 + x1) / 2)) - (x1 - x0) / 2 - 0.3, Math.abs(z - (z0 + z1) / 2) - (z1 - z0) / 2 - 0.3), min: [X(x0) - 0.35, -0.12, z0 - 0.35], max: [X(x1) + 0.35, 0.02, z1 + 0.35], mat: MAT.GRAVEL, spacing: 0.1, flow: [1, 0, 0],
      keep: (p, n) => n[1] > 0.5,
      detail: (p) => { const k = noise3(p[0] * 0.9, 2, p[2] * 0.9); if (((p[0] / 1.1) % 1 + 1) % 1 < 0.08 || ((p[2] / 1.1) % 1 + 1) % 1 < 0.08) return { mat: MAT.DARK, glyph: '·' }; return k > 0.7 ? { mat: MAT.BONE, glyph: ['∴', '⁖', '·'][(Math.abs(p[0] * 13) | 0) % 3] } : k < 0.25 ? { mat: MAT.MOSS } : { mat: MAT.STONE }; } });
  }
  for (const [x0, z0, x1, z1] of STRIPS) {
    const cx = X((x0 + x1) / 2), cz = (z0 + z1) / 2, hw = (x1 - x0) / 2, hd = (z1 - z0) / 2;
    P.push({ name: 'parede da cripta', f: (x, y, z) => Math.max(Math.abs(x - cx) - hw, Math.abs(z - cz) - hd, Math.abs(y - WALL_H / 2) - WALL_H / 2 + noise3(x * 2, y * 2, z * 2) * 0.12 * (y > WALL_H - 0.5 ? 3 : 0)), min: [cx - hw - 0.05, -0.05, cz - hd - 0.05], max: [cx + hw + 0.05, WALL_H + 0.1, cz + hd + 0.05], mat: MAT.STONE, spacing: 0.1, flow: [0, 1, 0],
      keep: (p, n) => n[1] > 0.5 || walk(p[0] + n[0] * 0.4 - DO.x, p[2] + n[2] * 0.4),
      detail: (p, n) => {
        if (((p[1] / 0.45) % 1) < 0.12) return { mat: MAT.DARK, glyph: '─' };
        const k = noise3(p[0] * 0.8, p[1] * 0.8, p[2] * 0.8);
        if (k > 0.72) return { mat: MAT.BONE, glyph: ['☠', '骨', '∴'][(Math.abs(p[0] * 7 + p[2] * 3) | 0) % 3] };       // ossos nos nichos
        return k < 0.22 ? { mat: MAT.MOSS } : null;
      } });
  }
  // fogueira da entrada, alavanca, baú do rei, trono de ossos
  const fx = DG_FIRE.x, fz = DG_FIRE.z;
  P.push({ name: 'pedras da fogueira', f: (x, y, z) => Math.max(Math.abs(Math.hypot(x - fx, z - fz) - 0.42) - 0.1, Math.abs(y - 0.08) - 0.09), min: [fx - 0.6, -0.02, fz - 0.6], max: [fx + 0.6, 0.2, fz + 0.6], mat: MAT.STONE, spacing: 0.03, flow: [1, 0, 0] });
  P.push({ name: 'base da alavanca', f: S.xf(S.box(0.25, 0.45, 0.2, 0.03), [DG_LEVER.x + 0.45, 0.45, DG_LEVER.z]), min: [DG_LEVER.x + 0.15, -0.02, DG_LEVER.z - 0.25], max: [DG_LEVER.x + 0.75, 0.95, DG_LEVER.z + 0.25], mat: MAT.IRON, spacing: 0.03, flow: [0, 1, 0] });
  const ch = DG_CHEST;
  P.push({ name: 'baú do rei', f: S.xf(S.box(0.55, 0.3, 0.32, 0.02), [ch.x, 0.3, ch.z]), min: [ch.x - 0.6, -0.02, ch.z - 0.38], max: [ch.x + 0.6, 0.64, ch.z + 0.38], mat: MAT.WOOD, spacing: 0.025, flow: [1, 0, 0],
    detail: (p) => (Math.abs(Math.abs(p[0] - ch.x) - 0.35) < 0.04 || Math.abs(p[1] - 0.5) < 0.03 ? { mat: MAT.GOLD } : null) });
  const tz = -41.2;
  P.push({ name: 'trono de ossos', f: S.union(S.xf(S.box(1.0, 0.5, 0.6, 0.05), [X(0), 0.5, tz + 0.3]), S.xf(S.box(1.0, 1.4, 0.18, 0.05), [X(0), 1.4, tz - 0.2])), min: [X(-1.1), -0.02, tz - 0.45], max: [X(1.1), 2.9, tz + 0.95], mat: MAT.BONE, spacing: 0.04, flow: [0, 1, 0],
    detail: (p) => (noise3(p[0] * 9, p[1] * 9, p[2] * 9) > 0.55 ? { mat: MAT.BONE, glyph: '☠' } : { mat: MAT.BONE, glyph: ['∴', '§', '%'][(Math.abs(p[1] * 31) | 0) % 3] }) });
  // montes de tesouro goblin roubado
  for (const [dx, dz] of [[-6.5, -39], [6.5, -39], [-7, -27], [7.2, -28]]) P.push({ name: 'saque', f: (x, y, z) => Math.hypot(x - X(dx), (y + 0.2) * 1.8, z - dz) - 0.9, min: [X(dx) - 1, -0.02, dz - 1], max: [X(dx) + 1, 0.4, dz + 1], mat: MAT.GOLD, spacing: 0.05, flow: [1, 0, 0], keep: (p, n) => n[1] > 0.2, detail: (p) => (Math.random() < 0.2 ? { mat: MAT.BONE, glyph: '☠' } : null) });
  // tochas nas paredes
  for (const t of TORCHES) P.push({ name: 'tocheiro', f: S.capsule([t[0], 1.3, t[2]], [t[0], 1.9, t[2]], 0.05), min: [t[0] - 0.1, 1.2, t[2] - 0.1], max: [t[0] + 0.1, 2.0, t[2] + 0.1], mat: MAT.IRON, spacing: 0.02, flow: [0, 1, 0] });
  return P;
}
function gateParts() {
  return [{ name: 'grade', bone: 1, f: S.union(...[-1, -0.6, -0.2, 0.2, 0.6, 1].map(x => S.capsule([x, 0, 0], [x, 3.1, 0], 0.045)), ...[0.6, 1.6, 2.6].map(y => S.capsule([-1.2, y, 0], [1.2, y, 0], 0.035))), min: [-1.3, -0.1, -0.1], max: [1.3, 3.2, 0.1], mat: MAT.IRON, spacing: 0.02, flow: [0, 1, 0] },
    { name: 'alavanca', bone: 2, f: S.union(S.capsule([0, 0, 0], [0, 0.65, 0], 0.03), S.xf(S.sphere(0.07), [0, 0.7, 0])), min: [-0.1, -0.05, -0.1], max: [0.1, 0.8, 0.1], mat: MAT.STEEL, spacing: 0.012, flow: [0, 1, 0] }];
}
const TORCHES = [[-3.7, 0, 2], [3.7, 0, -1], [-5.7, 0, -11], [5.7, 0, -15], [19.7, 0, -9], [12.3, 0, -18], [-8.7, 0, -28], [8.7, 0, -28], [-8.7, 0, -37], [8.7, 0, -37]].map(([x, y, z]) => [X(x), y, z]);
/** Mausoléu no Reino Partido (a entrada da cripta). */
export function cryptParts() {
  const { x, z } = CRYPT, y0 = heightAt(x, z) - 0.2, P = [];
  const body = S.subtract(S.xf(S.box(3, 2.2, 2.6, 0.05), [x, y0 + 2.2, z]), (px, py, pz) => Math.max(px - x - 2, -(px - x - 3.4), Math.abs(pz - z) - 0.9, py - y0 - 2.6 - Math.max(0, 0.9 - Math.abs(pz - z)) * 0.6));
  const roof = (px, py, pz) => Math.max(Math.abs(py - y0 - 4.4 + Math.abs(pz - z) * 0.55) - 0.15, Math.abs(px - x) - 3.3, Math.abs(pz - z) - 3);
  P.push({ name: 'mausoléu', f: S.union(body, roof), min: [x - 3.4, y0 - 0.1, z - 3.1], max: [x + 3.4, y0 + 6.3, z + 3.1], mat: MAT.STONE, spacing: 0.07, flow: [0, 1, 0],
    detail: (p) => (((p[1] - y0) / 0.5 % 1) < 0.1 ? { mat: MAT.DARK, glyph: '─' } : noise3(p[0], p[1], p[2]) > 0.6 ? { mat: MAT.MOSS } : null),
    decals: [{ p: [x + 3.06, y0 + 3.4, z], n: [1, 0, 0], glyph: '墓', mat: MAT.EMBER, size: 0.8, flags: 2, clear: 0.6 }] });
  P.push({ name: 'escuridão', f: (px, py, pz) => Math.max(Math.abs(px - x - 2.2) - 0.05, Math.abs(pz - z) - 0.85, py - y0 - 2.5, y0 - py), min: [x + 2.1, y0, z - 0.9], max: [x + 2.3, y0 + 2.6, z + 0.9], mat: MAT.DARK, spacing: 0.06, flow: [0, 1, 0] });
  return P;
}
export const CRYPT_COLLIDERS = [{ type: 'box', x0: CRYPT.x - 3.1, z0: CRYPT.z - 2.7, x1: CRYPT.x + 2.2, z1: CRYPT.z + 2.7 }, { type: 'box', x0: CRYPT.x + 2.2, z0: CRYPT.z - 2.7, x1: CRYPT.x + 3.1, z1: CRYPT.z - 0.9 }, { type: 'box', x0: CRYPT.x + 2.2, z0: CRYPT.z + 0.9, x1: CRYPT.x + 3.1, z1: CRYPT.z + 2.7 }];

// ─────────────── no jogo ───────────────
const SPAWNS = [
  ['g1', Goblin, -3, -12], ['g2', Goblin, 3, -14], ['g3', Goblin, 0, -16.5], ['z1', Ghoul, 4.5, -9.5],
  ['g4', Goblin, 15, -9], ['g5', Goblin, 17, -17],
];
export function initDungeon(g, sets, atlas) {
  if (!g.inv.dg) g.inv.dg = { lever: false, king: false, chest: false, killed: [], seen: false };
  const D = g.inv.dg;
  g.dgSets = sets; g.dgAtlas = atlas;
  g.dgEnemies = SPAWNS.map(([id, K, x, z]) => { const e = new K(id, X(x), z, Math.PI); if (D.killed.includes(id)) { e.state = 'dead'; e.dead = 1; } return e; });
  g.dgMeshes = g.dgEnemies.map(e => { const m = g.R.addMesh(e.goblin ? sets.goblin : sets.ghoul); m.area = 'dungeon'; m.visible = false; return m; });
  g.dgSummons = [];
  g.dgSumMeshes = [0, 1, 2].map(() => { const m = g.R.addMesh(sets.goblin); m.area = 'dungeon'; m.visible = false; return m; });
  g.king = new Boss({ x: KING_AT.x, z: KING_AT.z }); g.king.sc = KING_SCALE; g.king.reset(); g.king.x = KING_AT.x; g.king.z = KING_AT.z; g.king.hp = KING_HP; g.king.yaw = 0;
  g.king.state = D.king ? 'dead' : 'buried'; if (D.king) g.king.dead = 1;
  g.kingMesh = g.R.addMesh(sets.goblinKing); g.kingMesh.area = 'dungeon'; g.kingMesh.visible = false;
  g.dgLights = [...TORCHES.map((t, i) => ({ name: 'tocha da cripta ' + i, pos: [t[0], 2.1, t[2]], col: [1, 0.55, 0.25], radius: 9.5, base: 1.7, flicker: 0.3, area: 'dungeon', level: 1 })),
    { name: 'fogueira da cripta', pos: [DG_FIRE.x, 0.9, DG_FIRE.z], col: [1, 0.56, 0.24], radius: 8, base: 1.6, flicker: 0.3, area: 'dungeon', level: 1 },
    { name: 'baú do rei', pos: [DG_CHEST.x, 1.2, DG_CHEST.z + 0.8], col: [1, 0.8, 0.35], radius: 4, base: 1.2, flicker: 0.05, area: 'dungeon', level: D.king && !D.chest ? 1 : 0 }];
  g.lights.push(...g.dgLights);
  for (const t of TORCHES) { const f = g.fx.addFire([t[0], 2.0, t[2]], 0.06, 30); f.area = 'dungeon'; }
  const ff = g.fx.addFire([DG_FIRE.x, 0.15, DG_FIRE.z], 0.2, 110, 0.1); ff.area = 'dungeon';
  g.enterDungeon = () => enterDungeon(g);
  // entrada no Reino Partido
  (g.owExtras = g.owExtras || []).push(async (at) => { const s = await buildParts(cryptParts(), at, { seed: 1600, sizeMul: 2.2 }); const m = g.R.addMesh(s, { chunk: 8 }); m.area = 'ow'; return CRYPT_COLLIDERS; });
}

/** Esculpe a cripta na primeira vez que se entra (leva alguns segundos). */
async function ensureBuilt(g) {
  if (g.dgMesh) return;
  if (g.dgBuilding) return g.dgBuilding;
  g.dgBuilding = (async () => {
    const set = await buildParts(dungeonParts(), g.dgAtlas, { seed: 1700, sizeMul: 2.2 });
    g.dgMesh = g.R.addMesh(set, { chunk: 4 }); g.dgMesh.area = 'dungeon';
    const gs = await buildParts(gateParts(), g.dgAtlas, { seed: 1710, sizeMul: 2.1 });
    g.dgGate = g.R.addMesh(gs, { dynamic: true, bones: [I, I, I] }); g.dgGate.area = 'dungeon';
    g.dgGateK = g.inv.dg.lever ? 1 : 0;
  })();
  return g.dgBuilding;
}
function fadeTo(g, fn) {
  if (g.traveling) return; g.traveling = true; $('fade').classList.add('on');
  setTimeout(async () => { try { await fn(); } catch (e) { console.error(e); } g.traveling = false; setTimeout(() => $('fade').classList.remove('on'), 120); }, 650);
}
function enterDungeon(g) {
  fadeTo(g, async () => {
    if (!g.dgMesh) { g.hud.toast('Descendo à cripta…', 3000); await ensureBuilt(g); }
    const p = g.player;
    g.setArea('dungeon');
    Object.assign(p, { x: DG_ENTRY.x, z: DG_ENTRY.z - 0.4, yaw: Math.PI, vx: 0, vz: 0, speed: 0 });
    g.cam.x = p.x; g.cam.z = p.z; g.teleported(); snd(g, 'door');
    if (!g.inv.dg.seen) { g.inv.dg.seen = true; setTimeout(() => g.hud.showRegion({ region: 'III · O Reino Partido', title: 'A Cripta dos Goblins', subtitle: '小鬼の墓所' }), 500); }
  });
}
function leaveDungeon(g) {
  fadeTo(g, () => {
    const p = g.player;
    g.setArea('ow'); g.heightAt = heightAt;
    Object.assign(p, { x: CRYPT_DOOR.x + 1.2, z: CRYPT_DOOR.z, yaw: Math.PI / 2 });
    g.cam.x = p.x; g.cam.z = p.z; g.teleported(); snd(g, 'door');
  });
}

export function dungeonColliders(g) {
  if (g.area !== 'dungeon') return null;
  const cols = g.dgGateK < 0.8 ? [...WALL_COLS, GATE_COL] : WALL_COLS;
  return [cols, BOUNDS];
}
function pushOut(e, r, cols) {
  for (const c of cols) { const qx = Math.max(c.x0, Math.min(e.x, c.x1)), qz = Math.max(c.z0, Math.min(e.z, c.z1)), dx = e.x - qx, dz = e.z - qz, d = Math.hypot(dx, dz); if (d < r && d > 1e-6) { e.x = qx + dx / d * r; e.z = qz + dz / d * r; } }
}
const roomOf = (x, z) => { const lx = x - DO.x; return RECTS.findIndex(([x0, z0, x1, z1]) => lx > x0 && lx < x1 && z > z0 && z < z1); };

export function dungeonStep(g, dt) {
  if (g.area !== 'dungeon' || !g.dgMesh) return;
  const p = g.player, D = g.inv.dg, cols = dungeonColliders(g)[0];
  // grade
  g.dgGateK += Math.max(-dt, Math.min(dt / 3, (D.lever ? 1 : 0) - g.dgGateK));
  // nome da sala
  const ri = roomOf(p.x, p.z);
  if (ri !== g.dgRoom) { g.dgRoom = ri; if (ROOM_NAMES[ri] && ri > 0) g.hud.toast(ROOM_NAMES[ri], 1600); }
  // o rei acorda quando se entra no salão
  const K = g.king;
  if (K.state === 'buried' && ri === 6 && p.dead <= 0) {
    K.state = 'fight'; K.rise = 1; K.start('roar'); g.goblinKingFight = true; g.kingSummonT = 8;
    $('boss-name').textContent = 'O REI GOBLIN'; $('boss-bar').classList.remove('hidden'); snd(g, 'roar', 0.9); snd(g, 'goblin', 1); g.shake = 0.2;
    g.hud.showRegion({ region: 'A Cripta dos Goblins', title: 'O REI GOBLIN', subtitle: '小鬼王' });
  }
  const all = [...g.dgEnemies, ...g.dgSummons];
  // golpes do jogador
  if (p.atk >= 0 && g.knightBones) {
    const Cc = COMBO[p.combo];
    if (p.atk > Cc.hit[0] - 0.03 && p.atk < Cc.hit[1] + 0.04) {
      const [a, b] = swordSegment(g.knightBones);
      for (const e of all) {
        if (!e.alive || p.hitSet.has(e.id)) continue;
        for (const k of [0.3, 0.6, 0.95]) { const q = v3.lerp(a, b, k); if (Math.hypot(q[0] - e.x, q[2] - e.z) < 0.5 && (!e.goblin || q[1] < 1.3)) {
          p.hitSet.add(e.id); const crit = p.riposte > 0 ? 3 : 1; p.riposte = 0; g.critHit = crit > 1;
          if (e.damage(DMG_TABLE[p.combo] * crit * g.dmgMul())) { g.addGold(e.goblin ? 20 + Math.random() * 15 : 12); if (!e.summon) D.killed.push(e.id); }
          registerHit(g, e); snd(g, crit > 1 ? 'crit' : 'hit'); g.fx.sparks(q, 12, [0.8, 0.9, 0.5]); break;
        } }
      }
      if (K.alive && !p.hitSet.has('king')) for (const k of [0.3, 0.6, 0.95]) { const q = v3.lerp(a, b, k); if (Math.hypot(q[0] - K.x, q[2] - K.z) < 0.55 * KING_SCALE + 0.2) {
        p.hitSet.add('king'); const crit = p.riposte > 0 ? 3 : 1; p.riposte = 0; g.critHit = crit > 1; K.damage(DMG_TABLE[p.combo] * crit * g.dmgMul()); registerHit(g, K); snd(g, crit > 1 ? 'crit' : 'hit'); g.fx.sparks(q, 16, [0.9, 0.8, 0.4]); break;
      } }
    }
  }
  for (const e of all) {
    if (e.state === 'dead') continue;
    const ev = e.update(dt * g.diffK.speed, p, p.dead <= 0 && !g.cinema.active, e.summon ? 30 : 8);
    e.y = 0;
    for (const v of ev) { if (v.type === 'hit') hurtPlayer(g, v.dmg, v.from, e); else if (v.type === 'swing') snd(g, 'claw', 0.6); else if (v.type === 'cackle') snd(g, 'goblin', 0.9); }
    pushOut(e, 0.35, cols);
    if (e.alive) { const dx = p.x - e.x, dz = p.z - e.z, d = Math.hypot(dx, dz), rr = e.goblin ? 0.48 : 0.62; if (d < rr && d > 1e-4) { p.x = e.x + dx / d * rr; p.z = e.z + dz / d * rr; } }
  }
  g.dgSummons = g.dgSummons.filter(e => e.state !== 'dead');
  // o rei
  if (K.state === 'fight' || K.state === 'dying') {
    const ev = K.update(dt * g.diffK.speed, p, p.dead <= 0);
    pushOut(K, 0.6, cols);
    for (const e of ev) {
      if (e.type === 'hit') hurtPlayer(g, e.dmg * 0.9, e.from, K);
      else if (e.type === 'slam') { snd(g, 'slam'); g.shake = 0.22; g.fx.dirt([e.x, 0.1, e.z], 60, 1.8); if (Math.hypot(p.x - e.x, p.z - e.z) < 2.2) hurtPlayer(g, 26, [e.x, e.z], K); }
      else if (e.type === 'roar') { snd(g, 'roar', 0.9); g.shake = 0.15; }
    }
    if (K.alive) {
      const dx = p.x - K.x, dz = p.z - K.z, d = Math.hypot(dx, dz), rr = 0.5 * KING_SCALE + 0.35; if (d < rr && d > 1e-4) { p.x = K.x + dx / d * rr; p.z = K.z + dz / d * rr; }
      // chama os goblins pequenos
      g.kingSummonT -= dt;
      if (g.kingSummonT <= 0 && g.dgSummons.length < 3) {
        g.kingSummonT = K.phase2 ? 11 : 15; snd(g, 'goblin', 1); snd(g, 'roar', 0.5);
        for (let i = 0; i < (K.phase2 ? 2 : 1) + 1 && g.dgSummons.length < 3; i++) { const sx = X(i % 2 ? -7.5 : 7.5), sz = -26 - Math.random() * 3; const e = new Goblin('s' + Math.random().toString(36).slice(2, 6), sx, sz, 0); e.summon = true; e.state = 'fight'; g.dgSummons.push(e); g.fx.dirt([sx, 0.1, sz], 30, 1.2); }
        g.hud.toast('O Rei Goblin chama os seus!', 1800);
      }
    }
    g.hud.bossHp(Math.max(0, K.hp) / KING_HP);
    if (!K.alive && !D.king) {
      D.king = true; g.goblinKingFight = false; $('boss-bar').classList.add('hidden'); snd(g, 'victory'); g.addGold(700);
      for (const e of g.dgSummons) if (e.alive) e.damage(9999);
      g.dgLights[g.dgLights.length - 1].level = 1;
      g.hud.toast('O REI GOBLIN CAIU. O baú do salão está destrancado.', 4000); g.save();
    }
  }
}
export const dungeonReady = (g) => ensureBuilt(g);
export function dungeonRespawn(g) {
  if (g.goblinKingFight) { g.goblinKingFight = false; const K = g.king; K.reset(); K.x = KING_AT.x; K.z = KING_AT.z; K.hp = KING_HP; K.state = 'buried'; $('boss-bar').classList.add('hidden'); }
  for (const e of g.dgEnemies) if (e.state !== 'dead') e.reset();
  g.dgSummons = [];
  if (g.lastRest === 'dungeon') { g.setArea('dungeon'); return { x: DG_FIRE.x - 0.9, z: DG_FIRE.z + 0.6 }; }
  return null;
}

export function dungeonRender(g) {
  const on = g.area === 'dungeon';
  const draw = (m, e, sc) => {
    m.visible = on && !!e && e.state !== 'dead';
    if (!m.visible) return;
    const W = e.matrix ? e.matrix() : null, b = e.pose().map(x => m4.mul(W, x)); b[0] = I;
    m.boneData = flatBones(b, m.boneData); m.drawCount = Math.round(m.n * (1 - sm((e.dead - 0.45) / 0.55)));
    if (W) { m.modelMatrix = W; m.animState = enemyState(e); }
  };
  g.dgEnemies.forEach((e, i) => draw(g.dgMeshes[i], e));
  g.dgSumMeshes.forEach((m, i) => draw(m, g.dgSummons[i]));
  const K = g.king;
  g.kingMesh.visible = on && K.state !== 'buried' ? K.dead < 1 : on && K.state === 'buried';
  if (g.kingMesh.visible) {
    const W = m4.mul(m4.mul(m4.translate(K.x, 0, K.z), m4.rotY(K.yaw)), m4.scale(KING_SCALE, KING_SCALE, KING_SCALE));
    const pose = K.state === 'buried' ? poseBoss({ phase: 0, blend: 0, t: g.t * 0.3, act: null, at: 0, rise: 1, dead: 0, hurt: 0 }) : poseBoss({ phase: K.phase, blend: K.blend, t: K.t, act: K.act, at: K.at, rise: 1, dead: K.dead, hurt: K.hurt });
    const b = pose.map(m => m4.mul(W, m)); b[0] = I; g.kingMesh.boneData = flatBones(b, g.kingMesh.boneData);
    g.kingMesh.modelMatrix = W; g.kingMesh.animState = K.state === 'buried' ? 'death' : enemyState(K);
    g.kingMesh.drawCount = Math.round(g.kingMesh.n * (1 - sm((K.dead - 0.5) / 0.5)));
  }
  if (g.dgGate) {
    g.dgGate.visible = on;
    const lv = g.inv.dg.lever ? 1 : 0;
    g.dgGate.boneData = flatBones([I, m4.translate(X(0), sm(g.dgGateK) * 2.9, GATE_Z), m4.mul(m4.translate(DG_LEVER.x + 0.45, 0.85, DG_LEVER.z), m4.rotZ(lv ? -0.9 : 0.9))], g.dgGate.boneData);
  }
}

export function dungeonFocus(p, g) {
  if (g.area === 'ow') { const d = Math.hypot(p.x - CRYPT_DOOR.x, p.z - CRYPT_DOOR.z); return d < 1.8 ? { id: 'dg:enter', title: 'Mausoléu Selado', prompt: 'descer à cripta', d, x: CRYPT_DOOR.x, z: CRYPT_DOOR.z } : null; }
  if (g.area !== 'dungeon') return null;
  const D = g.inv.dg, list = [];
  const add = (it, x, z, r) => { const d = Math.hypot(p.x - x, p.z - z); if (d < r) list.push({ ...it, x, z, d }); };
  add({ id: 'dg:exit', title: 'Escadaria', prompt: 'subir ao Reino Partido' }, DG_ENTRY.x, DG_ENTRY.z + 0.8, 1.6);
  add({ id: 'dg:fire', title: 'Fogueira da Cripta', prompt: 'descansar na fogueira' }, DG_FIRE.x, DG_FIRE.z, 1.5);
  add({ id: 'dg:lever', title: 'Alavanca enferrujada', prompt: D.lever ? 'a grade já está erguida' : 'puxar a alavanca' }, DG_LEVER.x, DG_LEVER.z, 1.4);
  add({ id: 'dg:chest', title: 'Baú do Rei Goblin', prompt: D.chest ? 'baú vazio' : D.king ? 'abrir o baú' : 'trancado' }, DG_CHEST.x, DG_CHEST.z + 0.5, 1.4);
  list.sort((a, b) => a.d - b.d);
  return list[0] || null;
}
export function dungeonInteract(g, it) {
  if (!it.id.startsWith('dg:')) return false;
  const D = g.inv.dg;
  if (it.id === 'dg:enter') { g.enterDungeon(); return true; }
  if (it.id === 'dg:exit') { leaveDungeon(g); return true; }
  if (it.id === 'dg:fire') { g.restAt('dungeon'); for (const e of g.dgEnemies) if (e.state !== 'dead') e.reset(); g.save(); g.hud.toast('Você descansa no fundo da terra. Progresso salvo.', 3000); return true; }
  if (it.id === 'dg:lever') { if (!D.lever) { D.lever = true; snd(g, 'lever'); setTimeout(() => snd(g, 'gate'), 500); g.shake = 0.08; g.hud.toast('Correntes rangem ao longe: uma grade se ergue na Sala da Guarda.', 3500); g.save(); } return true; }
  if (it.id === 'dg:chest') {
    if (!D.king) { g.hud.message('Um cadeado do tamanho de um punho. A chave deve estar com quem senta naquele trono.', 'Baú do Rei Goblin', it); return true; }
    if (D.chest) { g.hud.message('Vazio. O resto do tesouro é só latão pintado.', 'Baú do Rei Goblin', it); return true; }
    D.chest = true; g.inv.sword = true; g.dgLights[g.dgLights.length - 1].level = 0; snd(g, 'chest');
    applyEquip(g);
    const S2 = itemInfo(g, 'sword');
    setTimeout(() => { snd(g, 'blade'); g.hud.message(S2.desc, S2.name, null); g.achieve('Herdeiro do Trono de Ossos'); g.save(); }, 700);
    return true;
  }
  return false;
}
