// ASHEN — testes unitários (Node 18+). Rode: node tests/unit.mjs
// Não precisa de navegador: testa largura Unicode, arte, física, câmera, sombreamento e mapa.
import { charWidth, layoutRow } from '../src/engine/typography.js';
import { parseArt, TypoGrid } from '../src/engine/sprite.js';
import { resolveShade, MATERIALS } from '../src/engine/palette.js';
import { Physics } from '../src/engine/physics.js';
import { Camera } from '../src/engine/camera.js';
import * as K from '../src/art/knight.js';
import { GRAVES, BRAZIER, TORCH, FALLEN, makeDeadTree, makeRock, makePillar, makeBanner } from '../src/art/props.js';
import { makeGatehouse, makeWallSegment, makeKeep } from '../src/art/architecture.js';
import { makeCape } from '../src/art/cape.js';
import { ASHEN_GATE } from '../src/world/maps.js';

let pass = 0, fail = 0;
const ok = (cond, name) => { if (cond) pass++; else { fail++; console.log('  ✗', name); } };

// 1. Largura de caracteres
ok(charWidth('A'.codePointAt(0)) === 1, 'A = 1');
ok(charWidth('█'.codePointAt(0)) === 1, '█ = 1');
ok(charWidth('╬'.codePointAt(0)) === 1, '╬ = 1');
for (const ch of '誓灰王国門火眠墓艹丫个田の休') ok(charWidth(ch.codePointAt(0)) === 2, `${ch} = 2`);
ok(charWidth(0x0301) === 0, 'acento combinante = 0');
ok(charWidth('Ａ'.codePointAt(0)) === 2, 'A largo (fullwidth) = 2');
const row = layoutRow('▐誓▌');
ok(row.width === 4 && row.cells[2].col === 3, 'layoutRow posiciona após glifo largo');

// 2. Grade com glifo largo: sobrescrever a continuação limpa o glifo
const g = new TypoGrid(6, 1);
g.set(1, 0, '誓', '#fff');
ok(g.get(2, 0) === '' && g.cont[2] === 1, 'continuação marcada');
g.set(2, 0, 'x', '#fff');
ok(g.get(1, 0) === ' ' && g.get(2, 0) === 'x', 'sobrescrever metade apaga o largo');

// 3. Toda a arte do cavaleiro e do cenário: materiais válidos e larguras coerentes
const checkDef = (def, name) => {
  const art = parseArt(def);
  ok(art.errors.length === 0, `${name}: ${art.errors.join('; ')}`);
  const widths = def.g.map(s => layoutRow(s).width);
  (def.m || []).forEach((m, i) => { if (m) ok(m.length <= widths[i] + 1, `${name} linha ${i}: materiais (${m.length}) > glifos (${widths[i]})`); });
  return art;
};
let parts = 0;
for (const view of ['S', 'N', 'E']) for (const k in K[view]) { checkDef(K[view][k], `${view}.${k}`); parts++; }
checkDef(K.SWORD, 'espada');
ok(parts >= 30, `peças do cavaleiro (${parts})`);
for (const a of [...GRAVES, BRAZIER, TORCH, FALLEN]) ok(a.errors.length === 0 && a.cells.length > 10, `arte ${a.name}`);

// 4. Geradores procedurais produzem células e são determinísticos
const t1 = makeDeadTree(3, 1).art, t2 = makeDeadTree(3, 1).art;
ok(t1.cells.length > 150 && t1.cells.length === t2.cells.length, 'árvore determinística e detalhada');
ok(makeRock(1, 12, 7).art.cells.length > 40, 'rocha');
ok(makePillar(1, 24).art.cells.length > 100, 'pilar');
ok(makeBanner(1).art.cells.length > 80, 'estandarte');
const gate = makeGatehouse(7).art;
ok(gate.cells.length > 6000, `portão com ${gate.cells.length} células`);
ok(gate.cells.some(c => c.ch === '王') && gate.cells.some(c => c.ch === '╋'), 'portão tem selo 王 e grade levadiça');
ok(makeWallSegment(3, { breach: true }).art.cells.length > 2500, 'muralha');
ok(makeKeep().art.cells.length > 2000, 'fortaleza');
const cape = makeCape({ emblem: '誓' });
ok(cape.cells.some(c => c.ch === '誓' && c.w === 2), 'capa com emblema largo');
for (const c of gate.cells) if (c.w === 2) ok(!gate.cells.some(o => o.row === c.row && o.col === c.col + 1), `glifo largo ${c.ch} sem sobreposição`);

// 5. Sombreamento de gravura
const sh = resolveShade('steel', 1, 0, 0);
ok(sh && MATERIALS[sh.bg] && MATERIALS[sh.fg], 'nível de aço resolve para materiais válidos');
ok(resolveShade('steel', 5, 3, 3).bg === 'n', 'nível 5 = aço profundo');

// 6. Física: círculo não atravessa caixa nem círculo
const ph = new Physics();
ph.addStatic({ type: 'box', x0: 100, y0: 100, x1: 200, y1: 200 });
ph.addStatic({ type: 'circle', x: 400, y: 150, r: 40 });
const b = { x: 50, y: 150, r: 15 };
for (let i = 0; i < 60; i++) ph.move(b, 5, 0);
ok(b.x <= 100 - 15 + 0.01, `parou na caixa (x=${b.x.toFixed(2)})`);
const c = { x: 300, y: 150, r: 15 };
for (let i = 0; i < 60; i++) ph.move(c, 4, 0);
ok(Math.hypot(c.x - 400, c.y - 150) >= 55 - 0.01, 'parou no círculo');
const fast = { x: 50, y: 150, r: 15 };
ph.move(fast, 400, 0);
ok(fast.x < 100, 'movimento rápido não atravessa (subpassos)');
ph.bounds = { x0: 0, y0: 0, x1: 1000, y1: 1000 };
const e = { x: 10, y: 10, r: 15 }; ph.move(e, -50, -50);
ok(e.x >= 15 && e.y >= 15, 'limites do mapa');

// 7. Câmera respeita limites da região
const cam = new Camera();
cam.setBounds({ x0: 0, y0: 0, x1: 1000, y1: 1000 });
cam.snap(0, 0); cam.clamp(400, 300);
ok(cam.x >= 200 && cam.y >= 150, 'câmera presa ao limite');

// 8. Mapa: objetos e região
const kinds = ASHEN_GATE.objects.reduce((m, o) => (m[o.type] = (m[o.type] || 0) + 1, m), {});
ok(kinds.tree >= 15 && kinds.rock >= 15 && kinds.grave >= 10 && kinds.brazier === 1 && kinds.gate === 1 && kinds.wall >= 6, 'mapa completo ' + JSON.stringify(kinds));

console.log(`\n${pass} aprovados, ${fail} falharam`);
process.exit(fail ? 1 : 0);
