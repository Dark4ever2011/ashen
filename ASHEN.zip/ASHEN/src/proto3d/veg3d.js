// ASHEN 3D — Vegetação viva.
// Cada talo de grama é uma pequena coluna de 2–3 segmentos de caractere. A GPU dobra o talo
// com o vento (campo de rajadas que viaja pelo terreno + tremulação individual) e com o
// empurrão do cavaleiro, e escolhe o caractere pela inclinação real na tela: | / ╱ ~ ' ` ´
// Codificação por instância: pos = raiz; tan = (fração de altura, altura do talo, inclinação natural);
// flags 8 = vegetação, 32 = planta rasteira.

import { MAT } from './glyphs.js';
import { noise3, rng } from './math3d.js';
import { PointSet } from './sampler.js';

const groundH = (x, z) => 0.04 * noise3(x * 0.7, 0, z * 0.7) + 0.02 * noise3(x * 2.3, 1, z * 2.3);

export function buildVegetation({ count = 1150, area = [-11.5, -4.1, 11.5, 9.2], avoid = () => false, seed = 3, atlas = null } = {}) {
  const G = (ch) => atlas ? atlas.get(ch) : -1;
  let extras = 0;
  const R = rng(seed);
  const ps = new PointSet(count * 8);
  let tufts = 0, plants = 0, tries = 0;
  while (tufts + plants < count && tries++ < count * 30) {
    const x = area[0] + R() * (area[2] - area[0]), z = area[1] + R() * (area[3] - area[1]);
    // densidade irregular: manchas de grama, clareiras de cinza
    const dens = noise3(x * 0.42, 3, z * 0.42) * 0.75 + noise3(x * 1.7, 9, z * 1.7) * 0.25;
    if (R() > Math.pow(Math.max(0, dens - 0.26) * 1.6, 1.2)) continue;
    if (avoid(x, z)) continue;
    const y = groundH(x, z);
    const kind = R();
    // folhas secas e pedrinhas: deitadas no chão (paradas, mudam só com a luz e o ângulo)
    if (kind < 0.1) {
      const n = 2 + ((R() * 4) | 0);
      for (let k = 0; k < n; k++) {
        const a = R() * 6.28, r = R() * 0.22, leaf = R() < 0.65;
        ps.push([x + Math.cos(a) * r, y + 0.008, z + Math.sin(a) * r], [0, 1, 0], [Math.cos(a * 3), 0, Math.sin(a * 3)], leaf ? MAT.LEAF : MAT.GRAVEL,
          leaf ? G(['‹', '›', ','][(R() * 3) | 0]) : G(['°', '•', '·'][(R() * 3) | 0]), 0, 0, leaf ? 0.05 + R() * 0.03 : 0.035 + R() * 0.02, R() * 1000);
      }
      extras++; continue;
    }
    // cardos e flores murchas: haste que balança + cabeça no topo
    if (kind < 0.16) {
      const h = 0.32 + R() * 0.3, natural = R() * 6.28, sd = R() * 1000, thistle = R() < 0.5;
      for (let k = 0; k < 3; k++) ps.push([x, y, z], [0, 1, 0], [(k + 0.5) / 3.5, h, natural], MAT.GRASS3, -1, 0, 8, 0.07 + h * 0.1, sd + k * 0.37);
      ps.push([x, y, z], [0, 1, 0], [1.0, h, natural], MAT.FLOWER, G(thistle ? '✶' : '⁎'), 0, 8, thistle ? 0.075 : 0.065, sd + 2);
      extras++; continue;
    }
    const isPlant = kind < 0.24;
    const lean = R() * Math.PI * 2;
    if (isPlant) {
      // planta rasteira: 3–5 folhas curtas em volta de um centro
      const n = 3 + ((R() * 3) | 0);
      for (let k = 0; k < n; k++) {
        const a = k / n * Math.PI * 2 + R() * 0.6, r = 0.04 + R() * 0.06;
        ps.push([x + Math.cos(a) * r, y, z + Math.sin(a) * r], [0, 1, 0], [0.6 + R() * 0.4, 0.1 + R() * 0.12, a], R() < 0.5 ? MAT.MOSS : MAT.GRASS2, -1, 0, 8 | 32, 0.085 + R() * 0.04, R() * 1000);
      }
      plants++;
      continue;
    }
    // tufo: 3–7 talos de alturas diferentes (mais altos no centro)
    const blades = 3 + ((R() * 4) | 0);
    const tall = (0.18 + dens * 0.35 + R() * 0.18) * 1.35;
    const mat = dens > 0.62 ? MAT.GRASS2 : (R() < 0.35 ? MAT.GRASS3 : MAT.GRASS);
    for (let b = 0; b < blades; b++) {
      const a = R() * Math.PI * 2, r = R() * 0.09;
      const h = tall * (0.55 + R() * 0.55) * (1 - r * 2.5);
      const segs = h > 0.3 ? 3 : 2;
      const bx = x + Math.cos(a) * r, bz = z + Math.sin(a) * r;
      const natural = lean + (R() - 0.5) * 1.2;
      const s = R() * 1000;
      for (let k = 0; k < segs; k++) {
        const f = (k + 0.5) / segs;
        ps.push([bx, y, bz], [0, 1, 0], [f, h, natural], mat, -1, 0, 8, 0.06 + h * 0.13, s + k * 0.37);
      }
    }
    tufts++;
  }
  return { ps, tufts, plants: plants + extras };
}
