// ASHEN — O corcel negro do Reino Partido (montaria).
// Esqueleto: 0 mundo, 1 corpo (barril, peito, garupa, sela), 2 pescoço+cabeça (crina, bridão),
// 3 cauda, 4..11 pernas (4 × braço/canela). Andaduras: passo (4 tempos), trote (diagonais), galope.
// Montado: trote livre, galope gasta fôlego, golpe lateral do cavaleiro. Assobio (H) chama de longe.
// Leva dano junto com o cavaleiro; quando cansa de apanhar, derruba o cavaleiro e foge (nunca morre).

import { m4 } from './math3d.js';
import { MAT } from './glyphs.js';
import * as S from './sdf.js';
import { heightAt, blockedAt, OW_FIRE } from './ow.js';
import { flatBones } from './renderer3d.js';

export const HORSE_V = 3;            // versão da forma (muda → o corpo é esculpido de novo)
export const HORSE_H = 1.32;          // altura do centro do corpo
export const RIDE_LIFT = 0.82;        // quanto o cavaleiro sobe quando monta
export const HORSE_HOME = { x: OW_FIRE.x + 3.6, z: OW_FIRE.z + 1.4 };
const UP = 0.62, LO = 0.6;
const LEGS = [                         // [x, y, z] da junta no corpo, dianteira?
  { j: [0.19, -0.12, 0.6], front: true, side: 1 }, { j: [-0.19, -0.12, 0.6], front: true, side: -1 },
  { j: [0.2, -0.06, -0.6], front: false, side: 1 }, { j: [-0.2, -0.06, -0.6], front: false, side: -1 },
];
const GAIT = {                         // fase de cada perna (FD, FE, TD, TE)
  walk: [0.25, 0.75, 0.0, 0.5], trot: [0.0, 0.5, 0.5, 0.0], gallop: [0.55, 0.45, 0.1, 0.0],
};

export function horseParts() {
  const P = [], add = o => P.push(o);
  // corpo: barril + peito + garupa + cernelha
  const barrel = S.ellipsoid(0.33, 0.37, 0.8);
  const chest = S.xf(S.ellipsoid(0.3, 0.36, 0.3), [0, 0.03, 0.52]);
  const rump = S.xf(S.ellipsoid(0.34, 0.35, 0.36), [0, 0.05, -0.55]);
  const withers = S.xf(S.ellipsoid(0.14, 0.12, 0.22), [0, 0.3, 0.42]);
  add({ name: 'corpo', bone: 1, f: S.smooth(0.16, barrel, chest, rump, withers), min: [-0.42, -0.45, -0.98], max: [0.42, 0.48, 0.9], mat: MAT.COAT, spacing: 0.04, flow: [0, 0, 1],
    detail: (p) => (Math.abs(p[2] - 0.18) < 0.045 && p[1] < 0.2 ? { mat: MAT.BLOOD } : null) });          // cilha vermelha
  // sela de couro vermelho-escuro com manta
  const seat = S.intersect(S.intersect(S.shell(S.xf(S.ellipsoid(0.35, 0.4, 0.82), [0, 0.0, 0]), 0.035), S.above(0.2)), (x, y, z) => Math.abs(z + 0.04) - 0.3);
  add({ name: 'sela', bone: 1, f: S.smooth(0.03, seat, S.xf(S.ellipsoid(0.2, 0.09, 0.28), [0, 0.4, -0.04])), min: [-0.42, 0.12, -0.46], max: [0.42, 0.52, 0.42], mat: MAT.BLOOD, spacing: 0.03, flow: [0, 0, 1],
    detail: (p) => (p[1] > 0.44 && Math.abs(p[2] - 0.2) < 0.06 ? { mat: MAT.ROYAL } : null) });
  for (const s of [-1, 1]) add({ name: 'estribo', bone: 1, f: S.xf(S.torus(0.05, 0.012), [s * 0.39, -0.28, 0], [Math.PI / 2, 0, 0]), min: [s * 0.39 - 0.08, -0.36, -0.08], max: [s * 0.39 + 0.08, -0.2, 0.08], mat: MAT.STEEL, spacing: 0.015, flow: [0, 1, 0] });
  // pescoço e cabeça (osso 2, origem na base do pescoço)
  const neck = S.roundCone([0, 0, 0], [0, 0.56, 0.3], 0.2, 0.13);
  const head = S.roundCone([0, 0.62, 0.36], [0, 0.34, 0.74], 0.13, 0.085);
  const ears = S.union(...[-1, 1].map(s => S.roundCone([s * 0.06, 0.7, 0.33], [s * 0.075, 0.85, 0.31], 0.03, 0.008)));
  add({ name: 'cabeça', bone: 2, f: S.smooth(0.07, neck, head, ears), min: [-0.26, -0.22, -0.24], max: [0.26, 0.9, 0.86], mat: MAT.COAT, spacing: 0.03, flow: [0, 1, 0],
    detail: (p) => {
      // bridão: focinheira, testeira e faceira em couro vermelho
      if (Math.abs(p[2] - 0.6) < 0.025 && p[1] < 0.52) return { mat: MAT.BLOOD };
      if (Math.abs(p[1] - 0.66) < 0.025 && p[2] > 0.3 && p[2] < 0.5) return { mat: MAT.BLOOD };
      if (Math.abs(p[0]) > 0.08 && Math.abs((p[1] - 0.62) + (p[2] - 0.36) * 0.75) < 0.022) return { mat: MAT.BLOOD };
      return null;
    } });
  for (const s of [-1, 1]) add({ name: 'freio', bone: 2, f: S.xf(S.sphere(0.028), [s * 0.085, 0.4, 0.66]), min: [s * 0.085 - 0.05, 0.35, 0.61], max: [s * 0.085 + 0.05, 0.45, 0.71], mat: MAT.STEEL, spacing: 0.012, flow: [0, 1, 0] });
  // crina: lâmina ondulada no alto do pescoço
  const mane = (x, y, z) => { const w = 0.03 * Math.sin(y * 22) ; return S.roundCone([0, 0.06, -0.12], [0, 0.72, 0.26], 0.075, 0.04)(x - w, y, z); };
  add({ name: 'crina', bone: 2, f: S.intersect(mane, (x, y, z) => -(z - y * 0.45 + 0.02)), min: [-0.14, -0.05, -0.24], max: [0.14, 0.82, 0.36], mat: MAT.MANE, spacing: 0.025, flow: [0, 1, 0] });
  // cauda (osso 3)
  add({ name: 'cauda', bone: 3, f: S.smooth(0.04, S.roundCone([0, 0, 0], [0, -0.36, -0.2], 0.09, 0.07), S.roundCone([0, -0.36, -0.2], [0, -0.78, -0.22], 0.08, 0.035)), min: [-0.14, -0.86, -0.34], max: [0.14, 0.1, 0.1], mat: MAT.MANE, spacing: 0.025, flow: [0, 1, 0] });
  // pernas (osso cresce em -y a partir da junta)
  for (let k = 0; k < 4; k++) {
    add({ name: 'braço', bone: 4 + k * 2, f: S.roundCone([0, 0.04, 0], [0, -UP, 0], k < 2 ? 0.12 : 0.14, 0.065), min: [-0.17, -UP - 0.08, -0.17], max: [0.17, 0.18, 0.17], mat: MAT.COAT, spacing: 0.03, flow: [0, 1, 0] });
    add({ name: 'canela', bone: 5 + k * 2, f: S.smooth(0.03, S.roundCone([0, 0, 0], [0, -LO + 0.06, 0], 0.055, 0.045), S.xf(S.cylinder(0.065, 0.05), [0, -LO + 0.03, 0.015])), min: [-0.1, -LO - 0.06, -0.1], max: [0.1, 0.06, 0.1], mat: MAT.COAT, spacing: 0.022, flow: [0, 1, 0],
      detail: (p) => (p[1] < -LO + 0.08 ? { mat: MAT.DARK } : null) });   // casco
  }
  return P;
}

const snd = (g, n, k) => g.audio && g.audio.play(n, k);
const sm = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };
/** Pose no mundo. st: { x, y, z, yaw, phase, speed, t, graze (0..1), rear (0..1) } */
export function poseHorse(st) {
  const b = new Array(12);
  b[0] = m4.ident();
  const sp = st.speed || 0, T = st.t || 0, ph = st.phase || 0;
  const gait = sp > 5.2 ? 'gallop' : sp > 2.3 ? 'trot' : 'walk', mv = Math.min(1, sp / 1.2);
  const amp = gait === 'gallop' ? 0.62 : gait === 'trot' ? 0.42 : 0.3;
  const bob = (gait === 'gallop' ? 0.07 : 0.035) * Math.sin(ph * Math.PI * (gait === 'walk' ? 4 : 2)) * mv;
  const pitch = gait === 'gallop' ? Math.sin(ph * Math.PI * 2) * 0.07 * mv : 0;
  const breathe = Math.sin(T * 1.7) * 0.008;
  const rear = st.rear || 0;
  const W = m4.mul(m4.mul(m4.translate(st.x, (st.y || 0) + HORSE_H + bob + breathe + rear * 0.35, st.z), m4.rotY(st.yaw)), m4.rotX(-pitch - rear * 0.55));
  b[1] = W;
  // pescoço: abaixa para pastar, balança no galope
  const graze = st.graze || 0;
  const neckA = -0.05 + graze * 1.15 + Math.sin(ph * Math.PI * 2) * 0.12 * mv * (gait === 'walk' ? 0.6 : 1) - rear * 0.3;
  b[2] = m4.mul(m4.mul(W, m4.translate(0, 0.16, 0.66)), m4.rotX(neckA));
  b[3] = m4.mul(m4.mul(m4.mul(W, m4.translate(0, 0.2, -0.84)), m4.rotX(0.3 + 0.45 * mv + Math.sin(T * 1.3) * 0.08)), m4.rotZ(Math.sin(T * 0.9 + ph * 6) * (0.12 + 0.1 * mv)));
  const offs = GAIT[gait];
  LEGS.forEach((L, k) => {
    const q = (ph + offs[k]) % 1, s = Math.sin(q * Math.PI * 2);
    let a1 = -s * amp * mv, a2 = Math.max(0, Math.cos(q * Math.PI * 2)) * (L.front ? 0.9 : 0.7) * mv;
    if (rear > 0 && L.front) { a1 = -1.1 * rear; a2 = 1.6 * rear; }
    if (rear > 0 && !L.front) a1 += 0.5 * rear;
    const up = m4.mul(m4.mul(W, m4.translate(...L.j)), m4.rotX(a1 + pitch));
    b[4 + k * 2] = up;
    b[5 + k * 2] = m4.mul(m4.mul(up, m4.translate(0, -UP, 0)), m4.rotX(L.front ? a2 : -a2 * 0.6 + a2 * 0.9 * 0));
  });
  return b;
}

/** O corcel: estado, IA simples (pastar, vir ao assobio, fugir), montaria. */
export class Horse {
  constructor(at) { Object.assign(this, { x: at.x, z: at.z, y: heightAt(at.x, at.z), yaw: Math.PI * 0.8, speed: 0, phase: 0, t: 0, graze: 0, rear: 0, hp: 100, state: 'idle', fleeT: 0, met: false, wander: 3 }); }
  go(tx, tz, v, dt) {
    const want = Math.atan2(tx - this.x, tz - this.z);
    let d = Math.atan2(Math.sin(want - this.yaw), Math.cos(want - this.yaw));
    this.yaw += Math.max(-2.6 * dt, Math.min(2.6 * dt, d));
    this.speed += (v - this.speed) * Math.min(1, dt * 3);
    let nx = this.x + Math.sin(this.yaw) * this.speed * dt, nz = this.z + Math.cos(this.yaw) * this.speed * dt;
    if (blockedAt(nx, nz)) { this.yaw += 1.2 * dt * 4; nx = this.x; nz = this.z; this.speed *= 0.6; }   // contorna lago/borda
    this.x = nx; this.z = nz;
  }
  update(dt, g) {
    const p = g.player;
    this.t += dt;
    this.rear = Math.max(0, this.rear - dt * 1.4);
    if (this.state !== 'idle') this.ax = null;
    if (this.state === 'ridden') {
      this.x = p.x; this.z = p.z; this.yaw = p.yaw; this.speed = Math.hypot(p.vx || 0, p.vz || 0);
      this.hp = Math.min(100, this.hp + dt * 0.5);
    } else if (this.state === 'come') {
      const d = Math.hypot(p.x - this.x, p.z - this.z);
      if (d < 2.4) { this.state = 'idle'; this.wander = 4; }
      else this.go(p.x, p.z, d > 8 ? 7.4 : 3.2, dt);
    } else if (this.state === 'flee') {
      this.fleeT -= dt;
      this.go(this.x + this.fx * 10, this.z + this.fz * 10, 7.8, dt);
      if (this.fleeT <= 0) { this.state = 'idle'; this.wander = 5; }
    } else {
      this.hp = Math.min(100, this.hp + dt * 1.2);
      this.wander -= dt;
      if (this.ax == null) { this.ax = this.x; this.az = this.z; }          // pasta perto de onde parou (não vai para trás das árvores)
      if (this.wander < 0) { this.wander = 4 + Math.random() * 6; this.tx = this.ax + (Math.random() - 0.5) * 3; this.tz = this.az + (Math.random() - 0.5) * 3; }
      if (this.tx != null && Math.hypot(this.tx - this.x, this.tz - this.z) > 0.6 && this.wander < 3) this.go(this.tx, this.tz, 0.9, dt);
      else this.speed += (0 - this.speed) * Math.min(1, dt * 3);
      // assusta com mortos por perto
      for (const gh of (g.ow && g.ow.ghouls) || []) if (gh.alive && gh.state !== 'dead' && Math.hypot(gh.x - this.x, gh.z - this.z) < 3.5) { this.spook(gh.x, gh.z, 3); break; }
    }
    this.graze += ((this.state === 'idle' && this.speed < 0.3 && Math.sin(this.t * 0.35) > 0 ? 1 : 0) - this.graze) * Math.min(1, dt * 1.2);
    this.y = heightAt(this.x, this.z);
    const ph0 = this.phase;
    this.phase = (this.phase + this.speed * dt / (this.speed > 5.2 ? 3.4 : this.speed > 2.3 ? 2.4 : 1.6)) % 1;
    if (this.speed > 0.4 && Math.floor(ph0 * 4) !== Math.floor(this.phase * 4) && Math.hypot(p.x - this.x, p.z - this.z) < 25) snd(g, 'hoof', Math.min(1.2, 0.4 + this.speed * 0.12));
  }
  spook(fx, fz, time = 6) {
    const dx = this.x - fx, dz = this.z - fz, d = Math.hypot(dx, dz) || 1;
    this.fx = dx / d; this.fz = dz / d; this.state = 'flee'; this.fleeT = time; this.rear = 1; this.neigh = true;
  }
  pose() { return poseHorse(this); }
}

// ───────────── integração com o jogo ─────────────

export function initHorse(g, sets) {
  if (!sets.horse) return;
  const s = (g.savedData && g.savedData.horse) || null;
  const h = g.horse = new Horse(s && Number.isFinite(s.x) ? s : HORSE_HOME);
  if (s) { h.met = !!s.met; if (Number.isFinite(s.yaw)) h.yaw = s.yaw; g._mountPending = !!s.mounted; }
  g.horseMesh = g.R.addMesh(sets.horse);
  g.horseMesh.area = 'ow'; g.horseMesh.visible = false; g.horseMesh.modelName = 'horse';
  (g.saveHooks = g.saveHooks || []).push(() => ({ horse: { x: +h.x.toFixed(2), z: +h.z.toFixed(2), yaw: +h.yaw.toFixed(2), met: h.met, mounted: !!g.player.mounted } }));
  // dano montado: o corcel recebe parte do golpe; se apanhar demais, derruba o cavaleiro e foge
  g.onMountedHit = (dmg, from) => {
    h.hp -= dmg * 0.9; h.hitT = 1;
    if (h.hp <= 0) { h.hp = 35; dismount(g, true); h.spook(from[0], from[1], 7); g.hud.toast('O corcel se assusta e derruba você! Assobie (H) para chamá-lo.', 2600); }
    return dmg * 0.55;
  };
}
export function mount(g) {
  const h = g.horse, p = g.player; if (!h) return;
  p.mounted = true; h.state = 'ridden'; h.met = true;
  p.x = h.x; p.z = h.z; p.yaw = h.yaw; p.speed = 0; p.atk = -1; p.roll = -1;
  g.teleported && (g.cape.inited = false, g.tabard.inited = false);
  snd(g, 'swap'); snd(g, 'step', 1.2);
  if (!g.rideTipped) { g.rideTipped = true; g.hud.toast('Montado: ande para trotar, segure correr para galopar (gasta fôlego). Atacar = golpe lateral.', 3600); }
}
export function dismount(g, thrown) {
  const h = g.horse, p = g.player; if (!h || !p.mounted) return;
  p.mounted = false; h.state = 'idle'; h.wander = 3; h.speed = 0;
  const side = thrown ? -1 : 1;
  p.x = h.x + Math.cos(h.yaw) * 1.05 * side; p.z = h.z - Math.sin(h.yaw) * 1.05 * side;
  if (blockedAt(p.x, p.z)) { p.x = h.x - Math.cos(h.yaw) * 1.05 * side; p.z = h.z + Math.sin(h.yaw) * 1.05 * side; }
  p.y = heightAt(p.x, p.z); p.speed = 0;
  if (thrown) { p.stun = 0.9; p.hurt = 1; }
  g.cape.inited = false; g.tabard.inited = false;
  snd(g, 'roll');
}
export function whistle(g) {
  const h = g.horse;
  if (!h || !h.met) return;
  if (g.area !== 'ow') { g.hud.toast('O corcel não ouve você daqui.', 1600); return; }
  if (g.player.mounted) return;
  snd(g, 'whistle');
  g.hud.toast('Você assobia. O corcel vem galopando.', 1600);
  if (Math.hypot(h.x - g.player.x, h.z - g.player.z) > 140) {    // longe demais: reaparece correndo da borda da vista
    const a = Math.random() * 6.28; h.x = g.player.x + Math.cos(a) * 40; h.z = g.player.z + Math.sin(a) * 40;
    if (blockedAt(h.x, h.z)) { h.x = g.player.x + 6; h.z = g.player.z + 6; }
  }
  h.state = 'come'; setTimeout(() => snd(g, 'neigh', 0.7), 900);
}
export function horseStep(g, dt) {
  const h = g.horse, p = g.player; if (!h) return;
  if (p.mounted && (g.area !== 'ow' || p.dead > 0 || p.sitting)) dismount(g);
  if (g._mountPending && g.area === 'ow' && g.owReady) { g._mountPending = false; mount(g); }
  if (g.area !== 'ow') return;
  if (!h.met && Math.hypot(p.x - h.x, p.z - h.z) < 10) { h.met = true; g.hud.toast('Um corcel negro de arreio vermelho pasta perto da fogueira.', 2600); }
  // golpe lateral montado: o cavaleiro vira o tronco para o lado do inimigo mais próximo
  if (p.mounted && p.atk >= 0 && p._rideSwing !== p.swing) {
    p._rideSwing = p.swing; let side = 1, bd = 7;
    for (const gh of (g.ow && g.ow.ghouls) || []) { if (!gh.alive) continue; const d = Math.hypot(gh.x - p.x, gh.z - p.z); if (d < bd) { bd = d; const cx = Math.sin(p.yaw) * (gh.z - p.z) - Math.cos(p.yaw) * (gh.x - p.x); side = cx > 0 ? -1 : 1; } }
    p.rideSide = side;
  }
  h.update(dt, g);
  if (h.neigh) { h.neigh = false; snd(g, 'neigh'); }
}
export function horseRender(g) {
  const h = g.horse, m = g.horseMesh; if (!h || !m) return;
  const p = g.player;
  m.visible = g.area === 'ow' && Math.hypot(h.x - p.x, h.z - p.z) < 60;
  if (!m.visible) return;
  m.boneData = flatBones(h.pose(), m.boneData);
  m.modelMatrix = m4.mul(m4.translate(h.x, h.y, h.z), m4.rotY(h.yaw));
  m.animState = h.speed > 5.2 ? 'run' : h.speed > 0.3 ? 'walk' : 'idle';
  h.hitT = Math.max(0, (h.hitT || 0) - 0.05); m.flash = h.hitT;
}
export function horseFocus(p, g) {
  const h = g.horse; if (!h || g.area !== 'ow') return null;
  if (p.mounted) return { id: 'horse:off', title: 'Corcel negro', prompt: 'desmontar', x: h.x, z: h.z, d: 0 };
  const d = Math.hypot(p.x - h.x, p.z - h.z);
  return d < 2.2 && h.state !== 'flee' ? { id: 'horse:on', title: 'Corcel negro', prompt: 'montar', x: h.x, z: h.z, d } : null;
}
export function horseInteract(g, it) {
  if (it.id === 'horse:on') { mount(g); return true; }
  if (it.id === 'horse:off') { dismount(g); return true; }
  return false;
}
