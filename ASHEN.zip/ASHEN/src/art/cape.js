// ASHEN — Gerador de capas tipográficas
// Capa vinho envelhecida e rasgada: dobras verticais, luz vinda da esquerda (luar),
// barra esfarrapada e furos determinísticos (semente). Retorna uma arte (células).

import { TypoGrid } from '../engine/sprite.js';
import { matColor } from '../engine/palette.js';
import { rng, noise1 } from '../engine/animation.js';

/**
 * opts: { w, h, top, bottom (meias-larguras em colunas), folds, seed, lining (lado de dentro, mais escuro),
 *         emblem (glifo), emblemRow, tear (profundidade máx. dos rasgos), holes }
 */
export function makeCape(opts) {
  const o = Object.assign({ w: 18, h: 17, top: 5, bottom: 9, folds: 4, seed: 7, lining: false, emblem: null, emblemRow: 3, tear: 3, holes: 2, light: 1 }, opts);
  const g = new TypoGrid(o.w, o.h);
  const R = rng(o.seed);
  const cx = o.w / 2;
  const deep = matColor('v'), base = matColor('c'), lit = matColor('C'), edge = matColor('R'), dark = matColor('d');
  const lineCol = o.lining ? '#1a0306' : deep;
  // Comprimento por coluna (barra rasgada).
  const len = [];
  for (let x = 0; x < o.w; x++) {
    const n = noise1(x * 0.9, o.seed) * 0.7 + R() * 0.3;
    len[x] = o.h - Math.round(n * o.tear);
  }
  for (let y = 0; y < o.h; y++) {
    const t = Math.min(1, y / 4);
    const s = t * t * (3 - 2 * t);
    const hw = o.top + (o.bottom - o.top) * s + (y > 10 ? (y - 10) * 0.12 : 0);
    const x0 = Math.max(0, Math.round(cx - hw)), x1 = Math.min(o.w - 1, Math.round(cx + hw) - 1);
    for (let x = x0; x <= x1; x++) {
      if (y >= len[x]) continue;
      const u = (x + 0.5 - cx) / hw;                  // -1..1
      const fold = Math.cos((x + 0.5 - cx) / (o.w / o.folds) * Math.PI * 2 + o.seed);
      let v = 0.5 + 0.32 * fold - u * 0.22 * o.light;   // luz da esquerda
      v -= Math.abs(u) > 0.82 ? 0.12 : 0;              // borda curva
      if (o.lining) v -= 0.22;
      let ch, fg, bg = o.lining ? '#1f0408' : deep;
      if (v > 0.72) { ch = '▓'; fg = edge; bg = lit; }
      else if (v > 0.55) { ch = '▓'; fg = lit; }
      else if (v > 0.4) { ch = '▒'; fg = base; }
      else if (v > 0.26) { ch = '░'; fg = base; }
      else { ch = '│'; fg = lineCol; }
      if (y === 0) { ch = '▄'; fg = lit; bg = null; }
      // Bordas laterais arredondadas.
      if (x === x0 && y > 0) { ch = '▐'; fg = y < 3 ? lit : base; bg = null; }
      if (x === x1 && y > 0) { ch = '▌'; fg = o.lining ? deep : base; bg = null; }
      // Última célula da coluna: franja irregular.
      if (y === len[x] - 1 && y > 3) {
        const r = R();
        ch = r < 0.3 ? '▀' : r < 0.55 ? '▘' : r < 0.8 ? '▝' : '▔';
        fg = o.lining ? deep : base; bg = null;
      }
      g.set(x, y, ch, fg, bg);
    }
  }
  // Furos de traça/lâmina.
  for (let i = 0; i < o.holes; i++) {
    const hx = Math.round(cx + (R() - 0.5) * o.bottom * 1.2), hy = 5 + Math.floor(R() * (o.h - 9));
    if (!g.isEmpty(hx, hy)) { g.set(hx, hy, R() < 0.5 ? '▖' : '▝', base, null); }
  }
  if (o.emblem) {
    const ex = Math.round(cx - 1);
    g.set(ex - 1, o.emblemRow, '╲', matColor('o'), deep);
    g.set(ex, o.emblemRow, o.emblem, matColor('g'), deep);
    g.set(ex + 2, o.emblemRow, '╱', matColor('o'), deep);
    g.set(ex, o.emblemRow + 1, '▾', matColor('o'), deep);
    g.setBg(ex + 1, o.emblemRow + 1, deep);
  }
  void dark;
  return g.toArt();
}
