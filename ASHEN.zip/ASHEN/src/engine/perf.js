// ASHEN — Monitor de desempenho
// FPS, tempo de update/render, histórico de sessão longa (detecta queda térmica).
// NÃO reduz a qualidade sozinho: apenas informa e sugere.

export class Perf {
  constructor() {
    this.fps = 60; this.frameMs = 16.7; this.updateMs = 0; this.renderMs = 0;
    this.samples = [];       // média a cada 10 s
    this.windowStart = performance.now();
    this.windowFrames = 0;
    this.windowWorst = 0;
    this.sessionStart = performance.now();
    this.suggested = false;
    this.onSuggest = null;
    this.last = performance.now();
  }

  frame(now, updateMs, renderMs) {
    const dt = now - this.last;
    this.last = now;
    if (dt > 0 && dt < 1000) {
      this.frameMs += (dt - this.frameMs) * 0.08;
      this.fps = 1000 / this.frameMs;
      this.windowWorst = Math.max(this.windowWorst, dt);
    }
    this.updateMs += (updateMs - this.updateMs) * 0.1;
    this.renderMs += (renderMs - this.renderMs) * 0.1;
    this.windowFrames++;
    if (now - this.windowStart >= 10000) {
      const avg = this.windowFrames / ((now - this.windowStart) / 1000);
      this.samples.push({ t: Math.round((now - this.sessionStart) / 1000), fps: Math.round(avg), worst: Math.round(this.windowWorst) });
      if (this.samples.length > 90) this.samples.shift();
      this.windowStart = now; this.windowFrames = 0; this.windowWorst = 0;
      this._checkThermal();
    }
  }

  _checkThermal() {
    const s = this.samples;
    if (s.length < 4 || this.suggested) return;
    const first = s.slice(0, 2).reduce((a, b) => a + b.fps, 0) / 2;
    const last = s.slice(-2).reduce((a, b) => a + b.fps, 0) / 2;
    if (last < 27 || (first > 45 && last < first * 0.7)) {
      this.suggested = true;
      this.onSuggest && this.onSuggest({ first: Math.round(first), last: Math.round(last) });
    }
  }

  report() {
    return { fps: Math.round(this.fps), frameMs: this.frameMs.toFixed(1), updateMs: this.updateMs.toFixed(2), renderMs: this.renderMs.toFixed(2), samples: this.samples.slice(-6) };
  }
}
