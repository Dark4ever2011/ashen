// ASHEN 3D — Palácio da Vigília: chegada, os quatro cômodos, o trono e a ida ao mundo aberto.

import { m4 } from './math3d.js';
import { throneScene } from './cinema.js';
import { PALACE, VALLEY } from './story2.js';
import * as P3 from './region3.js';

const $ = id => document.getElementById(id);
const snd = (g, n, k) => g.audio && g.audio.play(n, k);

export function initPalace(g, sets) {
  const m = g.R.addMesh(sets.palace, { chunk: 3 }); m.area = 'palace';
  g.palaceMesh = m;
  g.palaceLights = P3.PALACE_LIGHTS.map(l => ({ ...l, value: l.base, level: 1 }));
  g.lights.push(...g.palaceLights);
  for (const b of P3.BRAZIERS3) { const f = g.fx.addFire(b.slice(), 0.22, 90, 0.08); f.area = 'palace'; }
  g.enterPalace = () => enterPalace(g);
}

/** Chega ao palácio deitado no mármore do salão. */
function enterPalace(g) {
  const p = g.player;
  g.setArea('palace');
  Object.assign(p, { x: P3.PALACE_ENTRY.x, z: P3.PALACE_ENTRY.z, yaw: Math.PI, dead: 1, vx: 0, vz: 0, speed: 0 });
  g.cam.x = p.x; g.cam.z = p.z; g.teleported();
  g.lastRest = 'palace'; g.save();
  setTimeout(() => { g.hud.showRegion({ region: 'III · Reino Partido', title: PALACE.name, subtitle: '不寝の宮' }); g.hud.toast(PALACE.wake, 5000); }, 1500);
}

export function palaceColliders(g) { return g.area === 'palace' ? [P3.PALACE_COLLIDERS, P3.PALACE_BOUNDS] : null; }

export function palaceFocus(p, g) {
  if (g.area !== 'palace') return null;
  const list = [];
  const add = (it, x, z, r) => { const d = Math.hypot(p.x - x, p.z - z); if (d < r) list.push({ ...it, x, z, d }); };
  add({ id: 'p:throne', title: 'Trono da Rainha', prompt: 'sentar no trono' }, P3.THRONE.x, P3.THRONE.z + 1.25, 1.4);
  add({ id: 'p:chapel', title: PALACE.rooms.chapel, prompt: 'examinar o altar', text: PALACE.chapel }, P3.PO.x - 12.1, 0, 1.4);
  add({ id: 'p:treasure', title: PALACE.rooms.treasure, prompt: 'olhar o tesouro', text: PALACE.treasure }, P3.PO.x + 9.6, 0, 2.2);
  list.sort((a, b) => a.d - b.d);
  return list[0] || null;
}

export function palaceInteract(g, it) {
  if (!it.id.startsWith('p:')) return false;
  if (it.id === 'p:throne') { sitThrone(g); return true; }
  g.hud.message(it.text, it.title, it);
  if (it.id === 'p:treasure' && !g.inv.palaceGold) { g.inv.palaceGold = true; setTimeout(() => { g.addGold(500); g.hud.toast('Você enche a bolsa com moedas do tesouro. Ninguém vai sentir falta.', 3500); g.save(); }, 600); }
  return true;
}

/** Senta no trono: a cena conta a história do palácio enquanto o Reino Partido é erguido. */
function sitThrone(g) {
  const p = g.player;
  Object.assign(p, { x: P3.THRONE.x, z: P3.THRONE.z + 0.18, yaw: 0, sitting: true, atk: -1, speed: 0 });
  g.teleported();
  snd(g, 'ignite');
  const loading = g.buildOpenWorld ? g.buildOpenWorld() : Promise.resolve();
  g.cinema.play(throneScene(VALLEY, P3.THRONE, {
    done: () => {
      $('fade').classList.add('on');
      const go = () => { p.sitting = false; g.enterOpenWorld(); setTimeout(() => $('fade').classList.remove('on'), 300); };
      let shown = false;
      loading.then(go);
      setTimeout(() => { if (!g.owReady && !shown) { shown = true; g.hud.toast('O Reino Partido se ergue…', 6000); } }, 400);
    },
  }));
}

/** Avisa o nome do cômodo ao entrar nele. */
export function palaceStep(g) {
  if (g.area !== 'palace') return;
  const r = P3.roomAt(g.player.x, g.player.z);
  if (r && r !== g.lastRoom) { g.lastRoom = r; g.hud.toast(PALACE.rooms[r] + (r === 'hall' ? ' — ' + PALACE.hall : ''), 3200); }
}
export const PALACE_THRONE = P3.THRONE;
