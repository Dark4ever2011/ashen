// ASHEN — Mundo
// Monta a região a partir do mapa: objetos, colisores, luzes, partículas, terreno.
// Passes de desenho: chão → sombras → objetos ordenados (com o cavaleiro) → partículas.

import { CONFIG } from '../config.js';
import { Physics } from '../engine/physics.js';
import { Lighting } from '../engine/lighting.js';
import { Particles, P } from '../engine/particles.js';
import { GlyphPainter, GlyphAtlas } from '../engine/typography.js';
import { makeCanvas } from '../engine/canvas.js';
import { Terrain } from './terrain.js';
import { Prop, Brazier, Torch, rectsOverlap } from './objects.js';
import { makeDeadTree, makeRock, makePillar, GRAVES, BRAZIER, TORCH, makeBanner, FALLEN } from '../art/props.js';
import { makeGatehouse, makeWallSegment, makeKeep, GATE, WALL } from '../art/architecture.js';
import { LORE } from './maps.js';
import { castShadow } from '../entities/player.js';

const TILT = CONFIG.TILT;

/** Pintores por resolução (objetos distantes usam glifos menores). */
class Painters {
  constructor() { this.map = new Map(); this.S = 0; }
  sync(S) { if (S !== this.S) { this.S = S; for (const [res, p] of this.map) p.setCell(CONFIG.CELL_W * S * res, CONFIG.CELL_H * S * res); } }
  get(res = 1) {
    let p = this.map.get(res);
    if (!p) { p = new GlyphPainter(); p.setCell(CONFIG.CELL_W * this.S * res, CONFIG.CELL_H * this.S * res); this.map.set(res, p); }
    return p;
  }
}

export class World {
  constructor(map, state = {}) {
    this.map = map;
    this.time = 0;
    this.physics = new Physics();
    this.physics.bounds = map.walk;
    this.lighting = new Lighting();
    this.lighting.ambient = map.ambient.slice();
    this.particles = new Particles();
    this.particles.wind = map.wind;
    this.windNorm = 0.4;
    this.terrain = new Terrain(map);
    this.painters = new Painters();
    this.atlas = null;
    this.props = [];
    this.state = state;
    this.blob = null;
    this.ready = false;
    this.terrain.world = this;
    this.terrain.castShadow = castShadow;
    this._build();
  }

  _add(p) { this.props.push(p); if (p.attach) p.attach(this); return p; }

  _build() {
    const ph = this.physics;
    for (const o of this.map.objects) {
      switch (o.type) {
        case 'gate': {
          // O portão é gerado inteiro e dividido em 3 sprites: torres (mais à frente) e bloco central
          // (recuado). Cada um com sua profundidade — o cavaleiro, tochas e estandartes no recuo
          // ficam na frente do bloco central e atrás das torres.
          const full = makeGatehouse(7).art;
          const crop = (c0, c1) => ({ ...full, w: c1 - c0, cells: full.cells.filter(c => c.col >= c0 && c.col + c.w <= c1).map(c => ({ ...c, col: c.col - c0 })) });
          const T = GATE.towerW, H = GATE.H, recessY = GATE.recess * 10 / TILT;
          const parts = [
            { c0: 0, c1: T, y: o.y, ay: H },
            { c0: T, c1: GATE.W - T, y: o.y - recessY, ay: H - GATE.recess },
            { c0: GATE.W - T, c1: GATE.W, y: o.y, ay: H },
          ];
          for (const pt of parts) {
            const art = crop(pt.c0, pt.c1);
            const cx = o.x + ((pt.c0 + pt.c1) / 2 - GATE.W / 2) * CONFIG.CELL_W;
            const g = this._add(new Prop({ kind: 'gate', x: cx, y: pt.y, build: () => ({ art, anchor: [art.w / 2, pt.ay] }), occluder: false, castShadow: false, moonShadow: false, heightU: 780 }));
            if (pt.c0 === T) g.interact = { r: 150, at: { x: o.x, y: o.y - 50 }, prompt: 'Examinar o portão', text: LORE.gate };
          }
          const hw = GATE.W * 3, tw = GATE.towerW * 6;
          ph.addStatic({ type: 'box', x0: o.x - hw, y0: o.y - 130, x1: o.x - hw + tw, y1: o.y - 6 });
          ph.addStatic({ type: 'box', x0: o.x + hw - tw, y0: o.y - 130, x1: o.x + hw, y1: o.y - 6 });
          break;
        }
        case 'wall': {
          this._add(new Prop({ kind: 'wall', x: o.x, y: o.y, build: () => makeWallSegment(o.seed, { breach: o.breach, buttress: o.buttress }), occluder: false, castShadow: false, moonShadow: false, heightU: 560 }));
          break;
        }
        case 'keep': {
          this._add(new Prop({ kind: 'keep', x: o.x, y: o.y, z: 100, res: 0.6, build: () => makeKeep(5), occluder: false, castShadow: false, moonShadow: false, depthBias: -500 }));
          break;
        }
        case 'torch': this._add(new Torch({ x: o.x, y: o.y, z: o.z, seed: o.seed, build: () => ({ art: TORCH, anchor: [2.5, 5] }) })); break;
        case 'banner': this._add(new Prop({ kind: 'banner', x: o.x, y: o.y, z: o.z, build: () => makeBanner(o.seed, 9, 20), hang: { amp: 1.6, speed: 1.3 }, occluder: false, castShadow: false, moonShadow: false })); break;
        case 'brazier': {
          const lit = !!this.state.brazierLit;
          const b = this._add(new Brazier({ x: o.x, y: o.y, lit, build: () => ({ art: BRAZIER, anchor: [6.5, 12] }), blob: 52 }));
          b.interact = { r: 120, prompt: () => (b.lit ? 'Descansar junto ao fogo' : 'Acender o braseiro'),
            run: (game) => { if (!b.lit) { b.setLit(true, this); this.state.brazierLit = true; game.save(); game.hud.message(LORE.brazierUnlit, 'Chama do Último Juramento'); } else { game.rest(); game.hud.message(LORE.brazierLit, 'Chama do Último Juramento'); } } };
          ph.addStatic({ type: 'circle', x: o.x, y: o.y, r: 40 });
          break;
        }
        case 'pillar': {
          const p = this._add(new Prop({ kind: 'pillar', x: o.x, y: o.y, build: () => makePillar(o.seed, o.h), heightU: o.h * 10, blob: 34 }));
          if (o.lore) p.interact = { r: 90, prompt: 'Ler a inscrição', text: LORE[o.lore] };
          ph.addStatic({ type: 'circle', x: o.x, y: o.y, r: 26 });
          break;
        }
        case 'fallen': {
          this._add(new Prop({ kind: 'fallen', x: o.x, y: o.y, build: () => ({ art: FALLEN, anchor: [6, 9] }), heightU: 90, blob: 50, castShadow: false,
            interact: { r: 110, prompt: 'Examinar o cavaleiro caído', text: LORE.fallen } }));
          ph.addStatic({ type: 'box', x0: o.x - 40, y0: o.y - 30, x1: o.x + 40, y1: o.y + 6 });
          break;
        }
        case 'grave': {
          const art = GRAVES[o.v % GRAVES.length];
          const p = this._add(new Prop({ kind: 'grave', x: o.x, y: o.y, build: () => ({ art, anchor: [art.w / 2, art.h] }), heightU: 70, blob: 26 }));
          if (o.lore) p.interact = { r: 80, prompt: 'Ler a lápide', text: LORE[o.lore] };
          ph.addStatic({ type: 'box', x0: o.x - 22, y0: o.y - 12, x1: o.x + 22, y1: o.y + 2 });
          break;
        }
        case 'tree': {
          const d = makeDeadTree(o.seed, o.size);
          this._add(new Prop({ kind: 'tree', x: o.x, y: o.y, build: () => d, sway: { amp: 1.1, speed: 0.9 + (o.seed % 5) * 0.08 }, heightU: 420 * o.size, blob: 40 }));
          ph.addStatic({ type: 'circle', x: o.x, y: o.y, r: Math.max(14, d.trunk * 0.5) });
          break;
        }
        case 'rock': {
          const d = makeRock(o.seed, o.w, o.h);
          this._add(new Prop({ kind: 'rock', x: o.x, y: o.y, build: () => d, heightU: o.h * 10, blob: o.w * 3, occluder: o.h > 6 }));
          ph.addStatic({ type: 'circle', x: o.x, y: o.y, r: d.radius });
          break;
        }
      }
    }
    // Muralha contínua (bloqueia o norte)
    ph.addStatic({ type: 'box', x0: -100, y0: this.map.walk.y0 - 160, x1: 3700, y1: this.map.walk.y0 + 2 });
    this.playerLight = this.lighting.add({ x: 0, y: 0, z: 60, radius: 250, color: [0.62, 0.68, 0.86], intensity: 0.34, flicker: 0, casts: false });
  }

  /**
   * Prepara sprites dos objetos PERTO da câmera (streaming): constrói os que entram na área
   * de 1,7× a tela e libera os que ficam a mais de 3× (memória controlada no celular).
   * budget = custo máximo em glifos por chamada. Retorna true quando a vizinhança está pronta.
   */
  prepare(r, budget = Infinity, center = null) {
    this.painters.sync(r.S);
    if (!this.atlas || this.atlasS !== r.S) { this.atlas = new GlyphAtlas(this.painters.get(1)); this.atlasS = r.S; this._blob(r); }
    const v = r.view;
    const cx = center ? center.x : (v.x0 + v.x1) / 2, cy = center ? center.y : (v.y0 + v.y1) / 2 / r.tilt;
    const vw = (v.x1 - v.x0), vh = (v.y1 - v.y0) / r.tilt;
    let spent = 0, done = true;
    for (const p of this.props) {
      // Margem extra no eixo y: objetos altos (muralha, árvores) aparecem antes de os pés entrarem na tela.
      const near = Math.abs(p.x - cx) < vw * 0.62 + 320 && Math.abs(p.y - cy) < vh * 0.62 + 700;
      const far = Math.abs(p.x - cx) > vw * 1.1 + 600 || Math.abs(p.y - cy) > vh * 1.1 + 1100;
      if (far && p.sprite && p.kind !== 'keep') { p.sprite = null; p.sil = null; p.spriteS = 0; continue; }
      if (!near || p.spriteS === r.S) continue;
      if (spent >= budget) { done = false; continue; }
      spent += p.ensure(r, this.painters, true);
    }
    this.ready = done;
    return done;
  }

  /** Fração dos objetos próximos já prontos (barra de carregamento). */
  progress(r) { let n = 0, t = 0; for (const p of this.props) { if (p.spriteS === r.S) n++; t++; } return Math.min(1, n / Math.max(1, t * 0.55)); }

  /** Memória aproximada em canvas (MB), para o painel de desempenho. */
  canvasMB() {
    const B = c => c ? c.width * c.height * 4 : 0;
    let b = 0;
    for (const p of this.props) b += B(p.sprite && p.sprite.canvas) + B(p.sil && p.sil.canvas);
    for (const c of this.terrain.cache.values()) b += B(c.canvas);
    return b / 1048576;
  }

  _blob(r) {
    const s = 128;
    this.blob = makeCanvas(s, s);
    const x = this.blob.getContext('2d');
    const g = x.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
    g.addColorStop(0, 'rgba(0,0,0,0.75)'); g.addColorStop(0.55, 'rgba(0,0,0,0.42)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    x.fillStyle = g; x.fillRect(0, 0, s, s);
  }

  update(dt, player) {
    this.time += dt;
    const t = this.time;
    this.windNorm = 0.35 + 0.35 * Math.sin(t * 0.13) + 0.2 * Math.sin(t * 0.41);
    this.particles.wind = this.map.wind * (0.6 + this.windNorm);
    for (const p of this.props) p.update(dt, t, this);
    this.lighting.update(t);
    this.playerLight.x = player.x; this.playerLight.y = player.y + 10;
    this.particles.update(dt, t);
  }

  onFootstep(x, y, run) {
    const n = Math.round((run > 0.5 ? 7 : 4) * this.particles.secondary);
    for (let i = 0; i < n; i++) this.particles.spawn(P.DUST, x + (Math.random() - 0.5) * 18, y + (Math.random() - 0.5) * 8, 2,
      (Math.random() - 0.5) * 50, (Math.random() - 0.5) * 22, 10 + Math.random() * 25, 0.5 + Math.random() * 0.5);
  }

  /** Sombras: manchas de contato + projetadas pela luz dominante + luar. */
  drawShadows(r, player, quality) {
    const ctx = r.ctx;
    const blob = this.blob;
    const drawBlob = (x, y, rad) => {
      const w = rad * 2 * r.S, h = rad * 0.9 * r.S;
      ctx.drawImage(blob, r.dx(x) - w / 2, r.dy(y) - h / 2, w, h);
    };
    // Sombras de contato e de luar dos objetos já estão "assadas" no chão (terrain._bakeShadows).
    // Aqui ficam só as dinâmicas: luzes que oscilam/acendem.
    const moon = { x: 0, y: 0, z: 900 };
    for (const p of this.props) {
      if (!p.sprite || !p.castShadow || quality.castShadows !== 'all') continue;
      if (!this.lighting.dominant(p.x, p.y)) continue;
      const b = p.bounds(r);
      if (!b || !r.visible(b[0], b[1], b[2], b[3] + 200, 260)) continue;
      {
        const dom = this.lighting.dominant(p.x, p.y);
        if (dom && dom.light.x !== p.x) castShadow(r, p.silhouette(), p.x, p.y, dom.light, dom.strength * 0.85, Math.min(1.3, 180 / p.heightU + 0.25));
      }
    }
    const pp = player._pos || player;
    drawBlob(pp.x, pp.y + 3, 34);
    if (quality.castShadows !== 'none') {
      const dom = this.lighting.dominant(pp.x, pp.y);
      if (dom) player.drawCastShadow(r, dom.light, dom.strength);
      moon.x = pp.x - 500; moon.y = pp.y - 900;
      player.drawCastShadow(r, moon, 0.3);
    }
  }

  /** Envia objetos visíveis para a lista ordenada, com transparência quando escondem o cavaleiro. */
  submit(r, playerItem, player, dt) {
    const pr = player.screenRect;
    for (const p of this.props) {
      const it = p.drawItem(r, this);
      if (!it) continue;
      let target = 1;
      if (p.occluder && pr && p.y > player.y) {
        const b = it.bounds;
        const rect = [b[0] * r.S + r.ox + 30 * r.S, b[1] * r.S + r.oy, b[2] * r.S + r.ox - 30 * r.S, b[3] * r.S + r.oy];
        const core = [pr[0] + (pr[2] - pr[0]) * 0.25, pr[1] + (pr[3] - pr[1]) * 0.1, pr[2] - (pr[2] - pr[0]) * 0.25, pr[3] - (pr[3] - pr[1]) * 0.1];
        if (rectsOverlap(rect, core)) target = 0.38;
      }
      p.fade += (target - p.fade) * Math.min(1, dt * 8);
      r.submit(it);
    }
    r.submit(playerItem);
  }

  /** Objeto interativo mais próximo. */
  findInteractable(x, y) {
    let best = null, bd = 1e9;
    for (const p of this.props) {
      if (!p.interact) continue;
      const at = p.interact.at || p;
      const d = Math.hypot(x - at.x, (y - at.y) * 1.2);
      if (d < p.interact.r && d < bd) { bd = d; best = p; }
    }
    return best;
  }

  /** Objeto sob um ponto da tela (clique do mouse). */
  pickAt(wx, wy) {
    let best = null, bd = 1e9;
    for (const p of this.props) {
      if (!p.interact) continue;
      const at = p.interact.at || p;
      const d = Math.hypot(wx - at.x, wy - at.y);
      if (d < Math.max(70, p.interact.r * 0.9) && d < bd) { bd = d; best = p; }
    }
    return best;
  }
}

export { WALL };
