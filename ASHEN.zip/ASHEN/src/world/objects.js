// ASHEN — Objetos do mundo
// Prop: sprite tipográfico em cache (refeito quando a escala muda, sem "piscar"),
// colisor, sombra (blob + projetada), transparência quando cobre o cavaleiro,
// balanço por faixas (árvores, estandartes) e interação.

import { renderArt, makeSilhouette } from '../engine/sprite.js';
import { makeRamp } from '../engine/palette.js';
import { noise2, rng } from '../engine/animation.js';
import { P } from '../engine/particles.js';
import { CONFIG } from '../config.js';

let PROP_ID = 0;

export class Prop {
  constructor(o) {
    Object.assign(this, {
      x: 0, y: 0, z: 0, kind: 'prop', name: '', res: 1, depthBias: 0,
      castShadow: true, moonShadow: true, occluder: true, blob: 0,
      sway: null, hang: null, interact: null, collider: null, heightU: 200,
    }, o);
    this.id = ++PROP_ID;
    this.def = null;
    this.sprite = null; this.spriteS = 0; this.sil = null;
    this.fade = 1;
    this.phase = Math.random() * 10;
  }

  getDef() { if (!this.def) this.def = this.build(); return this.def; }

  /** (Re)constrói o sprite se a escala mudou. Retorna nº de glifos pintados (custo). */
  ensure(r, painters, allowBuild = true) {
    if (this.spriteS === r.S && this.sprite) return 0;
    if (!allowBuild) return 0;
    const d = this.getDef();
    const p = painters.get(this.res);
    this.sprite = renderArt(p, d.art, d.anchor[0], d.anchor[1]);
    this.spriteS = r.S;
    this.sil = null;
    return this.sprite.glyphs || 1;
  }

  silhouette() { if (!this.sil && this.sprite) this.sil = makeSilhouette(this.sprite); return this.sil; }

  update(dt, t, world) { this.t = t; }

  /** Escala extra quando o sprite ainda é da escala antiga (reconstrução pendente). */
  _k(r) { return (r.S / this.spriteS) / this.res; }

  bounds(r) {
    const s = this.sprite; if (!s) return null;
    const u = 1 / (this.spriteS * this.res); // unidades de mundo por pixel do sprite
    const sx = s.ax * u, sy = s.ay * u;
    const px = this.x, py = this.y * r.tilt - this.z;
    return [px - sx - 30, py - sy, px - sx + s.w * u + 30, py - sy + s.h * u];
  }

  drawItem(r, world) {
    const s = this.sprite; if (!s) return null;
    return { depth: this.y + this.depthBias, bounds: this.bounds(r), prop: this, draw: (ctx) => this.draw(ctx, r, world) };
  }

  draw(ctx, r, world) {
    const s = this.sprite;
    const k = this._k(r);
    const scaled = Math.abs(k - 1) > 0.001;
    const fx = r.dx(this.x), fy = r.dy(this.y, this.z);
    const x0 = Math.round(fx - s.ax * k), y0 = Math.round(fy - s.ay * k);
    if (this.fade < 0.999) ctx.globalAlpha = this.fade;
    if (this.sway || this.hang) this._drawStrips(ctx, s, x0, y0, k, world.time);
    else if (scaled) ctx.drawImage(s.canvas, x0, y0, s.w * k, s.h * k);
    else ctx.drawImage(s.canvas, x0, y0);
    ctx.globalAlpha = 1;
  }

  _drawStrips(ctx, s, x0, y0, k, t) {
    const strip = Math.max(4, Math.round(s.h / 24));
    const amp = (this.sway ? this.sway.amp : this.hang.amp) * (s.w / 40) * k;
    const sp = this.sway ? this.sway.speed : this.hang.speed;
    const gust = 0.6 + 0.4 * noise2(t * 0.25, this.id, 3);
    for (let sy = 0; sy < s.h; sy += strip) {
      const h = Math.min(strip + 1, s.h - sy);
      let f;
      if (this.sway) { f = 1 - (sy + h / 2) / s.ay; f = Math.max(0, f); f = f * f; }
      else { f = Math.pow((sy + h / 2) / s.h, 1.3); }
      const off = Math.sin(t * sp + this.phase - (this.hang ? f * 2.2 : f * 0.8)) * amp * f * gust;
      ctx.drawImage(s.canvas, 0, sy, s.w, h, Math.round(x0 + off), y0 + sy * k, s.w * k, h * k);
    }
  }
}

// ─────────────── Fogo tipográfico ───────────────
const FIRE_RAMP = makeRamp(['#2a0804', '#7a1a0a', '#c2361a', '#f06a20', '#ffaa3c', '#ffe08a', '#fff6d8'], 16);
const FIRE_GLYPHS = [' ', '.', '\'', ':', ';', '^', '*', '≈', '§', '▲'];

export class Fire {
  constructor(w, h, seed = 1, intensity = 1) {
    this.w = w; this.h = h; this.seed = seed;
    this.heat = new Float32Array(w * h);
    this.intensity = intensity;
    this.acc = 0;
    this.R = rng(seed);
  }
  update(dt, t) {
    this.acc += dt;
    if (this.acc < 1 / 24) return;
    this.acc = 0;
    const { w, h, heat } = this;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const u = (x + 0.5) / w - 0.5;
      const v = 1 - y / (h - 1);              // 1 = base
      const shape = Math.max(0, 1 - Math.abs(u) * (1.6 + (1 - v) * 2.2));
      const n = noise2(x * 0.9 + t * 0.6, y * 0.55 + t * 4.2, this.seed);
      heat[y * w + x] = Math.max(0, shape * (0.35 + v * 0.75) * (0.55 + n * 0.75) * this.intensity - (1 - v) * 0.25);
    }
  }
  /** (x,y) = canto superior esquerdo em pixels. */
  draw(ctx, atlas, x, y) {
    const cw = atlas.p.cw, ch = atlas.p.ch;
    const { w, h, heat } = this;
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
      const v = heat[j * w + i];
      if (v < 0.08) continue;
      const gi = Math.min(FIRE_GLYPHS.length - 1, Math.floor(v * FIRE_GLYPHS.length));
      let g = FIRE_GLYPHS[gi];
      // Núcleo mais quente às vezes vira o kanji de fogo (largo, ocupa 2 células)
      if (v > 0.88 && i < w - 1 && (j + i + Math.floor(this.acc * 1000)) % 7 === 0) { atlas.draw(ctx, '火', FIRE_RAMP(Math.min(1, v)), x + i * cw, y + j * ch, 2); i++; continue; }
      atlas.draw(ctx, g, FIRE_RAMP(Math.min(1, v * 1.15 + 0.08)), x + i * cw, y + j * ch);
    }
  }
}

/** Braseiro: luz principal, fogo animado, brasas subindo, interação (acender). */
export class Brazier extends Prop {
  constructor(o) {
    super(Object.assign({ kind: 'brazier', heightU: 120 }, o));
    this.fire = new Fire(11, 9, 4, o.lit ? 1 : 0.62);
    this.lit = !!o.lit;
    this.emberAcc = 0;
  }
  attach(world) {
    this.light = world.lighting.add({ x: this.x, y: this.y + 4, z: 90, radius: 560, color: [1, 0.56, 0.26], intensity: this.lit ? 1.05 : 0.55, flicker: 0.22, speed: 7, glow: 0.55, casts: true });
  }
  setLit(v, world) {
    this.lit = v;
    this.fire.intensity = v ? 1 : 0.62;
    this.light.intensity = v ? 1.05 : 0.55;
    if (v) for (let i = 0; i < 70; i++) world.particles.spawn(P.SPARK, this.x + (Math.random() - 0.5) * 30, this.y, 80, (Math.random() - 0.5) * 140, (Math.random() - 0.5) * 60, 80 + Math.random() * 160, 0.8 + Math.random() * 1.2);
  }
  update(dt, t, world) {
    this.fire.update(dt, t);
    this.emberAcc += dt * (this.lit ? 14 : 2) * world.particles.secondary;
    while (this.emberAcc > 1) {
      this.emberAcc -= 1;
      world.particles.spawn(P.EMBER, this.x + (Math.random() - 0.5) * 34, this.y + (Math.random() - 0.5) * 10, 92 + Math.random() * 20,
        (Math.random() - 0.5) * 20, (Math.random() - 0.5) * 10, 50 + Math.random() * 70, 1.4 + Math.random() * 2.2);
    }
  }
  draw(ctx, r, world) {
    super.draw(ctx, r, world);
    const a = world.atlas;
    const fx = r.dx(this.x), fy = r.dy(this.y, this.z);
    const s = this.sprite, k = this._k(r);
    // Fogo começa na boca da bacia (topo do sprite)
    this.fire.draw(ctx, a, fx - this.fire.w * a.p.cw / 2, fy - s.ay * k - this.fire.h * a.p.ch + a.p.ch * 1.6);
  }
}

/** Tocha de parede: luz oscilante + chama pequena. */
export class Torch extends Prop {
  constructor(o) {
    super(Object.assign({ kind: 'torch', castShadow: false, moonShadow: false, occluder: false, heightU: 40 }, o));
    this.fire = new Fire(5, 6, 11 + (o.seed || 0), 1);
  }
  attach(world) {
    this.light = world.lighting.add({ x: this.x, y: this.y + 30, z: this.z, radius: 330, color: [1, 0.52, 0.22], intensity: 0.85, flicker: 0.3, speed: 9, glow: 0.42, casts: true, seed: this.x });
  }
  update(dt, t, world) {
    this.fire.update(dt, t);
    if (Math.random() < dt * 3 * world.particles.secondary) world.particles.spawn(P.EMBER, this.x + (Math.random() - 0.5) * 8, this.y + 2, this.z + 30, (Math.random() - 0.5) * 16, 0, 30 + Math.random() * 40, 1 + Math.random() * 1.5);
  }
  draw(ctx, r, world) {
    super.draw(ctx, r, world);
    const a = world.atlas;
    const fx = r.dx(this.x), fy = r.dy(this.y, this.z);
    const s = this.sprite, k = this._k(r);
    this.fire.draw(ctx, a, fx - 2.5 * a.p.cw, fy - s.ay * k - 6 * a.p.ch + a.p.ch * 0.9);
  }
}

/** Distância horizontal "na tela" usada para occlusion. */
export function rectsOverlap(a, b) { return a[0] < b[2] && a[2] > b[0] && a[1] < b[3] && a[3] > b[1]; }

export const TILT = CONFIG.TILT;
