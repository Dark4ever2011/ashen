// ASHEN — Câmera 3/4
// Acima e atrás do protagonista, com acompanhamento suave, antecipação do movimento
// e limites por região. Coordenadas de mundo independentes da tela.

import { CONFIG } from '../config.js';

export class Camera {
  constructor() {
    this.x = 0; this.y = 0;
    this.px = 0; this.py = 0;     // estado anterior (interpolação)
    this.lift = 22;               // jogador um pouco abaixo do centro: mais leitura do que está à frente
    this.stiffness = 5.5;
    this.lookAhead = 0.28;        // segundos de antecipação
    this.bounds = null;           // {x0,y0,x1,y1} em mundo
    this.shake = 0;
    this.ax = 0; this.ay = 0;     // antecipação suavizada
  }

  setBounds(b) { this.bounds = b; }

  snap(x, y) { this.x = this.px = x; this.y = this.py = y; this.ax = this.ay = 0; }

  update(dt, target, viewW, viewH) {
    this.px = this.x; this.py = this.y;
    const k = 1 - Math.exp(-dt * 3.0);
    this.ax += (target.vx * this.lookAhead - this.ax) * k;
    this.ay += (target.vy * this.lookAhead - this.ay) * k;
    const tx = target.x + this.ax, ty = target.y + this.ay;
    const f = 1 - Math.exp(-dt * this.stiffness);
    this.x += (tx - this.x) * f;
    this.y += (ty - this.y) * f;
    this.clamp(viewW, viewH);
  }

  /** viewW/viewH = tamanho visível em unidades de mundo (W/S, H/S/tilt). */
  clamp(viewW, viewH) {
    const b = this.bounds;
    if (!b) return;
    const hw = viewW / 2, hh = viewH / 2;
    const ly = this.lift / CONFIG.TILT;
    if (b.x1 - b.x0 <= viewW) this.x = (b.x0 + b.x1) / 2;
    else this.x = Math.max(b.x0 + hw, Math.min(b.x1 - hw, this.x));
    if (b.y1 - b.y0 <= viewH) this.y = (b.y0 + b.y1) / 2;
    else this.y = Math.max(b.y0 + hh + ly, Math.min(b.y1 - hh + ly, this.y));
  }

  /** Estado interpolado para o render. */
  lerp(a) {
    return { x: this.px + (this.x - this.px) * a, y: this.py + (this.y - this.py) * a, lift: this.lift };
  }
}
