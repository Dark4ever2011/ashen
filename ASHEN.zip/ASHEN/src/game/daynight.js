// ASHEN 3D — Dia e noite. 1 hora do jogo = 1 minuto real (um dia inteiro = 24 min).
// O sol nasce às 6h e se põe às 18h; nas pontas o céu fica laranja e a luz vem baixa e comprida.
// À noite a lua volta a iluminar como antes. Descansar numa fogueira adianta 5 horas.

const v3n = (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
const mix = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
const ss = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

export function advanceTime(g, dt) {
  g.hour = (g.hour == null ? 21 : g.hour) + dt / 60;
  while (g.hour >= 24) { g.hour -= 24; g.day = (g.day || 0) + 1; g.onNewDay && g.onNewDay(g.day); }
}
export function skipHours(g, h) { advanceTime(g, h * 60); }
export const clockText = (g) => { const h = Math.floor(g.hour || 0), m = Math.floor(((g.hour || 0) % 1) * 60); return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`; };

/** Luz do momento. night = valores da noite que o jogo já usava (lua). */
export function skyAt(g, night, cloud, rain) {
  const h = g.hour == null ? 21 : g.hour;
  const ang = (h - 6) / 12 * Math.PI, el = Math.sin(ang);               // >0 com o sol acima do horizonte
  const day = ss(-0.12, 0.28, el), golden = Math.exp(-el * el * 22) * ss(-0.25, 0.0, el);
  const indoor = g.indoor;
  const out = { ...night, day, golden };
  if (indoor || day <= 0.001 && golden < 0.01) return out;
  const sunDir = v3n([Math.cos(ang) * 0.85, Math.max(0.1, el), 0.32]);
  const sunCol = mix([1.75, 1.6, 1.4], [1.9, 0.95, 0.5], golden).map(c => c * cloud);
  const k = Math.max(day, golden * 0.85);
  out.moonDir = day > 0.35 || golden > 0.3 ? sunDir : night.moonDir;
  out.moonCol = mix(night.moonCol, sunCol, k);
  out.sky = mix(night.sky, mix([0.5, 0.6, 0.82], [0.6, 0.38, 0.34], golden).map(c => c * (0.6 + 0.4 * cloud) + rain * 0.04), k);
  out.ground = mix(night.ground, [0.2, 0.17, 0.13], k);
  out.rimCol = mix(night.rimCol, mix([0.6, 0.65, 0.8], [1.0, 0.55, 0.3], golden), k);
  out.fog = [...mix(night.fog.slice(0, 3), mix([0.46, 0.54, 0.68], [0.62, 0.4, 0.33], golden), k), night.fog[3] * (1 - 0.45 * day)];
  out.clear = mix(night.clear, mix([0.36, 0.48, 0.68], [0.68, 0.36, 0.24], golden), k);
  out.exposure = 12 - 3.5 * day;                                         // de dia a luz é forte: menos ganho
  return out;
}
