// ASHEN — Retratos dos personagens em caracteres, no traço de mangá/anime.
// Cada rosto é desenhado em 2D (contorno a nanquim, olhos grandes com brilho, mechas de cabelo,
// retícula/hachura nas sombras) e depois convertido em caracteres: a borda vira traço (| / \ _ -),
// a mancha vira densidade (· : + # @), a cor de cada célula vem do desenho.
// Personagens originais; o "estilo" muda o papel, a tinta e o jeito de sombrear.

const COLS = 84, ROWS = 96, CW = 5, RH = 6, W = COLS * CW, H = ROWS * RH;
const RAMP = ' .\'`,:;-~+=*o#%@';

const STYLES = {
  ink: { bg: '#e7e2d7', line: '#141210', lw: 5, skin: '#f3efe7', shade: 'hatch', blush: 0 },
  line: { bg: '#f2f0ec', line: '#26221f', lw: 2.6, skin: '#fbfaf6', shade: 'light', blush: 0 },
  pastel: { bg: '#f5e6ee', line: '#a8868f', lw: 2.4, skin: '#fff3ee', shade: 'soft', blush: 0.55 },
  chibi: { bg: '#efefef', line: '#0c0c0c', lw: 7, skin: '#fbfbfb', shade: 'tone', blush: 0 },
  sketch: { bg: '#d8d4cc', line: '#191816', lw: 4, skin: '#bdbab4', shade: 'hatch', blush: 0, splatter: 1 },
  anime: { bg: '#1c2434', line: '#3b2518', lw: 3, skin: '#f2d0b0', skinShade: '#dba886', shade: 'cel', blush: 0.25, dark: 1 },
};

/** Personagens (originais), cada um no estilo de uma das referências. */
export const FACE_SPECS = {
  bram: { style: 'ink', hair: '#141414', hairStyle: 'spiky', face: 'adult', eyes: 'sharp', iris: '#1a1a1a', beard: 1, collar: 'high', cloth: '#171717', soot: 1 },
  oswin: { style: 'line', hair: '#efe9dc', hairLine: 1, hairStyle: 'shaggy', face: 'thin', eyes: 'tired', iris: '#8b8378', cloth: '#121212', collar: 'tee', neck: 'long' },
  maren: { style: 'pastel', hair: '#f1e6d3', hairStyle: 'bob', face: 'soft', eyes: 'big', iris: '#b0629a', cloth: '#f3d9e3', collar: 'soft', ribbon: '#e8a3b8' },
  ilsa: { style: 'chibi', hair: '#0d0d0d', hairStyle: 'long', face: 'round', eyes: 'dots', iris: '#0d0d0d', glasses: 1, cloth: '#f4f4f4', collar: 'blouse', bow: '#151515' },
  pip: { style: 'anime', hair: '#5b3920', hairShade: '#3b2414', hairStyle: 'messy', face: 'child', eyes: 'big', iris: '#6a8cc4', cloth: '#2c3a59', clothShade: '#1e2840', collar: 'tee' },
  caedmon: { style: 'sketch', helm: 'tvisor', cloth: '#2a2826', glint: '#e8dcc0' },
  you: { style: 'sketch', helm: 'slit', cloth: '#5a1418', glint: '#ff8a2a', mark: '誓' },
};

// ─────────────── utilidades de desenho ───────────────
function rng(seed) { let s = seed * 9301 + 49297; return () => { s = (s * 16807) % 2147483647; return s / 2147483647; }; }
function shapePath(x, pts, close = true) {
  x.beginPath(); x.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) {
    const p = pts[i], n = pts[(i + 1) % pts.length];
    if (i < pts.length - 1 || close) x.quadraticCurveTo(p[0], p[1], (p[0] + n[0]) / 2, (p[1] + n[1]) / 2); else x.lineTo(p[0], p[1]);
  }
  if (close) x.closePath();
}
function hatch(x, clip, angle, gap, color, width = 1.4) {
  x.save(); clip(); x.clip();
  x.strokeStyle = color; x.lineWidth = width;
  const c = Math.cos(angle), s = Math.sin(angle);
  for (let d = -W; d < W + H; d += gap) { x.beginPath(); x.moveTo(d * c - 0 * s, d * s + 0 * c); x.lineTo(d * c - H * 2 * s, d * s + H * 2 * c); x.stroke(); }
  x.restore();
}
function tone(x, clip, gap, color) {
  x.save(); clip(); x.clip(); x.fillStyle = color;
  for (let j = 0; j < H; j += gap) for (let i = (j / gap) % 2 ? gap / 2 : 0; i < W; i += gap) { x.beginPath(); x.arc(i, j, gap * 0.22, 0, 6.283); x.fill(); }
  x.restore();
}

// ─────────────── rosto ───────────────
function faceOutline(f) {
  const cx = 210;
  if (f === 'child') return [[cx - 98, 236], [cx - 102, 320], [cx - 60, 384], [cx, 402], [cx + 60, 384], [cx + 102, 320], [cx + 98, 236], [cx + 88, 150], [cx, 128], [cx - 88, 150]];
  if (f === 'round') return [[cx - 104, 240], [cx - 100, 330], [cx - 50, 392], [cx, 404], [cx + 50, 392], [cx + 100, 330], [cx + 104, 240], [cx + 90, 150], [cx, 126], [cx - 90, 150]];
  if (f === 'thin') return [[cx - 82, 226], [cx - 80, 318], [cx - 40, 400], [cx, 432], [cx + 40, 400], [cx + 80, 318], [cx + 82, 226], [cx + 76, 140], [cx, 118], [cx - 76, 140]];
  if (f === 'soft') return [[cx - 92, 232], [cx - 90, 318], [cx - 46, 388], [cx, 410], [cx + 46, 388], [cx + 90, 318], [cx + 92, 232], [cx + 84, 146], [cx, 124], [cx - 84, 146]];
  return [[cx - 96, 228], [cx - 94, 318], [cx - 52, 396], [cx, 420], [cx + 52, 396], [cx + 94, 318], [cx + 96, 228], [cx + 88, 140], [cx, 118], [cx - 88, 140]];
}

function drawBody(x, S, st) {
  const cx = 210, neckW = S.neck === 'long' ? 34 : S.face === 'child' ? 40 : 46, neckTop = S.face === 'thin' ? 380 : 370, shoulderY = S.neck === 'long' ? 500 : 478;
  // pescoço
  x.fillStyle = st.skin; x.strokeStyle = st.line; x.lineWidth = st.lw * 0.7;
  x.beginPath(); x.moveTo(cx - neckW, neckTop); x.lineTo(cx - neckW - 4, shoulderY + 10); x.lineTo(cx + neckW + 4, shoulderY + 10); x.lineTo(cx + neckW, neckTop); x.closePath(); x.fill(); x.stroke();
  if (st.shade === 'hatch') hatch(x, () => { x.beginPath(); x.rect(cx - neckW, neckTop, neckW * 2, 40); }, 0.9, 6, st.line, 1.2);
  if (st.shade === 'cel' || st.shade === 'soft') { x.fillStyle = st.skinShade || 'rgba(200,150,140,.35)'; x.fillRect(cx - neckW, neckTop, neckW * 2, 34); }
  // roupa
  x.fillStyle = S.cloth; x.strokeStyle = st.line; x.lineWidth = st.lw;
  x.beginPath(); x.moveTo(-10, H + 10); x.quadraticCurveTo(10, shoulderY + 20, 120, shoulderY); x.lineTo(cx - neckW - 6, shoulderY - 6);
  if (S.collar === 'high') { x.lineTo(cx - neckW - 8, neckTop + 40); x.quadraticCurveTo(cx, neckTop + 70, cx + neckW + 8, neckTop + 40); }
  else { x.quadraticCurveTo(cx, shoulderY + (S.collar === 'blouse' ? 40 : 26), cx + neckW + 6, shoulderY - 6); }
  x.lineTo(300, shoulderY); x.quadraticCurveTo(410, shoulderY + 20, 430, H + 10); x.closePath(); x.fill(); x.stroke();
  if (S.clothShade) { x.fillStyle = S.clothShade; x.beginPath(); x.moveTo(300, shoulderY); x.quadraticCurveTo(410, shoulderY + 20, 430, H + 10); x.lineTo(250, H + 10); x.closePath(); x.fill(); }
  if (S.collar === 'blouse') {          // gola branca com laço escuro
    x.fillStyle = '#fafafa'; x.beginPath(); x.moveTo(cx - neckW - 6, shoulderY - 6); x.lineTo(cx - 70, shoulderY + 40); x.lineTo(cx, shoulderY + 30); x.lineTo(cx + 70, shoulderY + 40); x.lineTo(cx + neckW + 6, shoulderY - 6); x.closePath(); x.fill(); x.stroke();
    x.fillStyle = S.bow; shapePath(x, [[cx, shoulderY + 34], [cx - 48, shoulderY + 14], [cx - 52, shoulderY + 62], [cx, shoulderY + 44], [cx + 52, shoulderY + 62], [cx + 48, shoulderY + 14]]); x.fill(); x.stroke();
    hatch(x, () => shapePath(x, [[cx, shoulderY + 34], [cx - 48, shoulderY + 14], [cx - 52, shoulderY + 62], [cx, shoulderY + 44], [cx + 52, shoulderY + 62], [cx + 48, shoulderY + 14]]), 0.3, 5, '#555', 1.5);
  }
  if (S.ribbon) { x.fillStyle = S.ribbon; shapePath(x, [[cx, shoulderY + 22], [cx - 30, shoulderY + 8], [cx - 30, shoulderY + 40], [cx, shoulderY + 28], [cx + 30, shoulderY + 40], [cx + 30, shoulderY + 8]]); x.fill(); }
  if (st.shade === 'hatch' && !S.helm) hatch(x, () => { x.beginPath(); x.rect(0, shoulderY, W, H); }, -0.7, 7, 'rgba(255,255,255,.08)', 1);
}

function drawEyes(x, S, st, blink) {
  const child = S.face === 'child', y = child ? 292 : S.face === 'round' ? 286 : 276, dx = child ? 50 : S.eyes === 'dots' ? 50 : 46;
  for (const s of [-1, 1]) {
    const ex = 210 + s * dx;
    x.save();
    if (blink) {          // olho fechado: curva para baixo
      x.strokeStyle = st.line; x.lineWidth = st.lw * 0.9; x.beginPath(); x.moveTo(ex - 26, y); x.quadraticCurveTo(ex, y + 12, ex + 26, y); x.stroke();
      x.restore(); continue;
    }
    if (S.eyes === 'dots') {           // estilo chibi: olho grande e escuro, quase sem branco
      x.fillStyle = st.line; x.beginPath(); x.ellipse(ex, y + 4, 19, 24, 0, 0, 6.283); x.fill();
      x.fillStyle = '#fff'; x.beginPath(); x.arc(ex - 6, y - 6, 5, 0, 6.283); x.fill();
      x.lineWidth = st.lw; x.strokeStyle = st.line; x.beginPath(); x.moveTo(ex - 30, y - 22); x.quadraticCurveTo(ex, y - 34, ex + 30, y - 22); x.stroke();
      x.restore(); continue;
    }
    const big = S.eyes === 'big', tired = S.eyes === 'tired', sharp = S.eyes === 'sharp';
    const w = big ? 40 : 32, h = big ? 38 : sharp ? 17 : 22;
    const lid = (path) => { x.beginPath(); x.moveTo(ex - w, y + (sharp ? 2 : 4)); x.quadraticCurveTo(ex - w * 0.2 * s, y - h - (big ? 4 : 0), ex + w, y - (sharp ? 8 : 4)); x.quadraticCurveTo(ex + w * 0.3, y + h * 0.9, ex - w, y + (sharp ? 2 : 4)); if (path) x.closePath(); };
    // branco do olho
    x.fillStyle = '#fbfbfb'; lid(true); x.fill();
    x.save(); lid(true); x.clip();
    // íris com degradê e pupila
    const ir = big ? 28 : sharp ? 14 : 16, iy = y + (tired ? 4 : 2);
    const gr = x.createLinearGradient(ex, iy - ir, ex, iy + ir);
    gr.addColorStop(0, '#000'); gr.addColorStop(0.35, S.iris); gr.addColorStop(1, lighten(S.iris, 0.45));
    x.fillStyle = gr; x.beginPath(); x.ellipse(ex + s * 2, iy, ir * 0.85, ir, 0, 0, 6.283); x.fill();
    x.fillStyle = '#060606'; x.beginPath(); x.ellipse(ex + s * 2, iy + 1, ir * 0.38, ir * 0.48, 0, 0, 6.283); x.fill();
    x.fillStyle = 'rgba(255,255,255,.95)'; x.beginPath(); x.arc(ex - 6 + s * 2, iy - ir * 0.45, big ? 6 : 4, 0, 6.283); x.fill();
    x.beginPath(); x.arc(ex + 6 + s * 2, iy + ir * 0.4, big ? 3 : 2, 0, 6.283); x.fill();
    if (tired) { x.fillStyle = st.skin; x.beginPath(); x.rect(ex - w - 4, y - h - 10, w * 2 + 8, h * 0.95); x.fill(); }
    x.restore();
    // pálpebra de cima (traço grosso com cílios) e de baixo (fina)
    x.strokeStyle = st.line; x.lineCap = 'round';
    x.lineWidth = st.lw * (big ? 1.4 : 1.15);
    x.beginPath(); x.moveTo(ex - w - 2, y + (sharp ? 0 : 2)); x.quadraticCurveTo(ex - w * 0.2 * s, y - h - (big ? 6 : 2) + (tired ? h * 0.75 : 0), ex + w + 2, y - (sharp ? 10 : 6) + (tired ? 6 : 0)); x.stroke();
    if (big) for (let k = 0; k < 3; k++) { const kx = ex + s * (w - 2 - k * 5); x.lineWidth = st.lw * 0.8; x.beginPath(); x.moveTo(kx, y - h * 0.7 + k * 3); x.lineTo(kx + s * 9, y - h * 0.9 - 4 + k * 4); x.stroke(); }
    x.lineWidth = st.lw * 0.45; x.beginPath(); x.moveTo(ex - w * 0.6, y + h * 0.75); x.quadraticCurveTo(ex, y + h * 0.95, ex + w * 0.8, y + h * 0.55); x.stroke();
    if (tired) { x.lineWidth = st.lw * 0.4; x.beginPath(); x.moveTo(ex - w * 0.7, y + h + 6); x.quadraticCurveTo(ex, y + h + 10, ex + w * 0.6, y + h + 4); x.stroke(); }   // olheira
    x.restore();
  }
  // sobrancelhas
  x.strokeStyle = S.hairLine ? st.line : (S.style === 'pastel' ? '#c4a98e' : st.line); x.lineCap = 'round';
  for (const s of [-1, 1]) {
    const ex = 210 + s * dx, by = y - (S.eyes === 'sharp' ? 34 : S.eyes === 'dots' ? 46 : 42);
    x.lineWidth = st.lw * (S.style === 'ink' ? 1.3 : 0.8);
    x.beginPath(); x.moveTo(ex - s * 26, by + (S.eyes === 'sharp' ? 8 : 2)); x.quadraticCurveTo(ex, by - 6, ex + s * 28, by + (S.eyes === 'tired' ? 6 : 2)); x.stroke();
  }
}

function drawMouth(x, S, st, open) {
  const y = S.face === 'child' ? 362 : S.face === 'thin' ? 380 : S.face === 'round' ? 366 : 362, cx = 210;
  // nariz: um traço curto (ou sombra) bem no estilo
  x.strokeStyle = st.line; x.lineWidth = st.lw * 0.5; x.lineCap = 'round';
  x.beginPath(); x.moveTo(cx + 2, y - 52); x.quadraticCurveTo(cx + 7, y - 40, cx - 2, y - 34); x.stroke();
  if (st.shade === 'cel') { x.fillStyle = st.skinShade; x.beginPath(); x.moveTo(cx + 2, y - 60); x.lineTo(cx + 10, y - 38); x.lineTo(cx, y - 36); x.fill(); }
  if (S.style === 'ink') { x.fillStyle = st.line; x.fillRect(cx - 9, y - 36, 4, 3); x.fillRect(cx + 5, y - 36, 4, 3); }
  // boca
  x.lineWidth = st.lw * 0.6;
  if (open <= 0) { x.beginPath(); x.moveTo(cx - 15, y); x.quadraticCurveTo(cx, y + (S.eyes === 'tired' ? 0 : 2), cx + 15, y); x.stroke(); }
  else {
    const h = open > 0.7 ? 13 : 7, w = open > 0.7 ? 13 : 10;
    x.fillStyle = S.style === 'anime' ? '#6b2a24' : st.line; x.beginPath(); x.ellipse(cx, y + 2, w, h, 0, 0, 6.283); x.fill();
    if (open > 0.7) { x.fillStyle = S.style === 'anime' ? '#c86a60' : '#777'; x.beginPath(); x.ellipse(cx, y + 2 + h * 0.5, w * 0.6, h * 0.35, 0, 0, 6.283); x.fill(); }
  }
  // bochechas coradas
  if (st.blush) for (const s of [-1, 1]) { x.fillStyle = `rgba(240,140,150,${st.blush})`; x.beginPath(); x.ellipse(210 + s * 66, y - 40, 22, 9, 0, 0, 6.283); x.fill(); if (S.style === 'pastel') { x.strokeStyle = 'rgba(220,110,130,.6)'; x.lineWidth = 1.2; for (let k = 0; k < 3; k++) { x.beginPath(); x.moveTo(210 + s * 56 + k * 7, y - 46); x.lineTo(210 + s * 52 + k * 7, y - 36); x.stroke(); } } }
  if (S.beard) {         // barba curta a nanquim
    x.save(); shapePath(x, faceOutline(S.face)); x.clip();
    x.fillStyle = 'rgba(20,20,20,.85)';
    const R = rng(7);
    for (let i = 0; i < 900; i++) { const a = R() * Math.PI, r = 60 + R() * 60, px = 210 + Math.cos(a) * r * 1.05, py = 330 + Math.sin(a) * r * 0.85; if (py > 335 && !(Math.abs(px - 210) < 22 && Math.abs(py - y) < 10)) x.fillRect(px, py, 2, 3); }
    x.restore();
  }
}

function hairSpikes(S, front) {
  const R = rng(front ? 31 : 17), pts = [];
  const top = S.face === 'thin' ? 92 : 100, n = S.hairStyle === 'bob' || S.hairStyle === 'long' ? 9 : 12;
  if (!front) {          // massa de trás
    const w = S.hairStyle === 'long' ? 150 : S.hairStyle === 'bob' ? 135 : 125, low = S.hairStyle === 'long' ? 560 : S.hairStyle === 'bob' ? 370 : 330;
    pts.push([210 - w, low]);
    for (let i = 0; i <= n; i++) { const a = Math.PI + i / n * Math.PI; const r = 128 + (S.hairStyle === 'spiky' || S.hairStyle === 'messy' ? R() * 26 : 6); pts.push([210 + Math.cos(a) * (r + 10) * (w / 125), 240 + Math.sin(a) * (r + 14)]); }
    pts.push([210 + w, low]);
    if (S.hairStyle === 'spiky' || S.hairStyle === 'shaggy' || S.hairStyle === 'messy') for (let i = 0; i < 5; i++) pts.push([210 + w - i * 10, low - 20 - R() * 30]);
    return pts;
  }
  // franja: mechas pontudas que caem até as sobrancelhas
  const fringeY = S.hairStyle === 'bob' || S.hairStyle === 'long' ? 252 : S.hairStyle === 'spiky' ? 262 : 240;
  pts.push([82, 230]);
  for (let i = 0; i <= n; i++) {
    const t = i / n, xx = 92 + t * 236;
    const tip = fringeY + Math.sin(t * Math.PI) * 14 + (R() - 0.5) * (S.hairStyle === 'bob' || S.hairStyle === 'long' ? 10 : 46);
    pts.push([xx - 6, tip]); pts.push([xx + 6, tip - 40 - R() * 30]);
  }
  pts.push([338, 230]); pts.push([320, top + 30]); pts.push([210, top - 6]); pts.push([100, top + 30]);
  return pts;
}

function drawHair(x, S, st, front) {
  const pts = hairSpikes(S, front);
  x.fillStyle = S.hair; x.strokeStyle = st.line; x.lineWidth = st.lw * (front ? 0.9 : 1); x.lineJoin = 'round';
  x.beginPath(); x.moveTo(pts[0][0], pts[0][1]); for (const p of pts.slice(1)) x.lineTo(p[0], p[1]); x.closePath(); x.fill(); x.stroke();
  // fios e brilhos
  const R = rng(front ? 5 : 9);
  x.save(); x.beginPath(); x.moveTo(pts[0][0], pts[0][1]); for (const p of pts.slice(1)) x.lineTo(p[0], p[1]); x.closePath(); x.clip();
  if (S.hairShade) { x.fillStyle = S.hairShade; x.fillRect(240, 0, 200, H); }
  x.strokeStyle = S.hairLine || st.shade === 'soft' ? lighten(st.line, 0.2) : st.dark ? 'rgba(255,220,180,.25)' : 'rgba(255,255,255,.3)';
  x.lineWidth = S.hairLine ? 1.4 : 1.6;
  for (let i = 0; i < (S.hairLine ? 40 : 24); i++) { const sx = 90 + R() * 240, sy = 110 + R() * 60; x.beginPath(); x.moveTo(sx, sy); x.quadraticCurveTo(sx + (R() - 0.5) * 30, sy + 60, sx + (R() - 0.5) * 50, sy + 120 + R() * 40); x.stroke(); }
  if (st.shade === 'soft' || st.dark) { x.strokeStyle = 'rgba(255,255,255,.55)'; x.lineWidth = 4; x.beginPath(); x.arc(200, 210, 95, 3.6, 4.6); x.stroke(); }
  x.restore();
}

function drawHelm(x, S, st) {
  const cx = 210, R = rng(13);
  if (st.splatter) { x.fillStyle = st.line; for (let i = 0; i < 160; i++) { const a = R() * 6.28, r = 130 + R() * 120; x.beginPath(); x.arc(cx + Math.cos(a) * r, 260 + Math.sin(a) * r * 0.9, R() * R() * 5 + 0.6, 0, 6.283); x.fill(); } }
  // capuz de malha / gorjal
  x.fillStyle = '#4a4744'; x.strokeStyle = st.line; x.lineWidth = st.lw;
  shapePath(x, [[cx - 150, 560], [cx - 140, 420], [cx - 100, 380], [cx + 100, 380], [cx + 140, 420], [cx + 150, 560]]); x.fill(); x.stroke();
  x.fillStyle = '#2a2826'; for (let j = 400; j < 560; j += 9) for (let i = cx - 150 + (j % 18 ? 4 : 0); i < cx + 150; i += 9) { x.beginPath(); x.arc(i, j, 2.2, 0, 6.283); x.fill(); }
  // elmo: cúpula, aba lateral e a frente em quilha
  const helm = [[cx - 118, 400], [cx - 124, 250], [cx - 98, 150], [cx - 40, 96], [cx, 84], [cx + 40, 96], [cx + 98, 150], [cx + 124, 250], [cx + 118, 400], [cx + 20, 430], [cx, 436], [cx - 20, 430]];
  const helmPath = () => shapePath(x, helm);
  const gr = x.createLinearGradient(cx - 120, 0, cx + 120, 0);
  gr.addColorStop(0, '#8c8984'); gr.addColorStop(0.45, '#cfccc5'); gr.addColorStop(0.55, '#77736d'); gr.addColorStop(1, '#3f3c39');
  x.fillStyle = gr; helmPath(); x.fill();
  hatch(x, helmPath, 1.1, 7, 'rgba(20,20,20,.55)', 1.3);
  x.save(); helmPath(); x.clip(); hatch(x, () => { x.beginPath(); x.rect(cx + 10, 0, 200, H); }, -1.0, 6, 'rgba(10,10,10,.5)', 1.3); x.restore();
  for (let i = 0; i < 60; i++) { x.fillStyle = `rgba(30,25,20,${0.2 + R() * 0.4})`; x.beginPath(); x.arc(cx + (R() - 0.5) * 200, 120 + R() * 300, 1 + R() * 3, 0, 6.283); x.fill(); }   // ferrugem e amassados
  x.strokeStyle = st.line; x.lineWidth = st.lw; helmPath(); x.stroke();
  x.lineWidth = st.lw * 0.8; x.beginPath(); x.moveTo(cx, 86); x.lineTo(cx, 432); x.stroke();                                         // quilha
  // aberturas dos olhos
  x.fillStyle = '#070707';
  if (S.helm === 'tvisor') {
    for (const s of [-1, 1]) { x.beginPath(); x.moveTo(cx + s * 12, 236); x.lineTo(cx + s * 92, 228); x.lineTo(cx + s * 88, 262); x.lineTo(cx + s * 12, 266); x.closePath(); x.fill(); }
    x.beginPath(); x.rect(cx - 12, 236, 24, 140); x.fill();
    for (const s of [-1, 1]) { x.fillStyle = S.glint; x.beginPath(); x.ellipse(cx + s * 50, 250, 6, 3, 0, 0, 6.283); x.fill(); }   // olhos cansados lá dentro
    x.strokeStyle = '#7a1a14'; x.lineWidth = 3; x.beginPath(); x.moveTo(cx - 70, 270); x.quadraticCurveTo(cx - 74, 330, cx - 62, 380); x.stroke();     // sangue escorrendo
  } else {
    x.beginPath(); x.rect(cx - 104, 238, 208, 14); x.fill();
    for (const s of [-1, 1]) { x.fillStyle = S.glint; x.shadowColor = S.glint; x.shadowBlur = 14; x.beginPath(); x.ellipse(cx + s * 46, 245, 9, 3.5, 0, 0, 6.283); x.fill(); x.shadowBlur = 0; }
    x.fillStyle = '#070707'; for (let k = 0; k < 6; k++) for (const s of [-1, 1]) { x.beginPath(); x.arc(cx + s * (26 + k * 11), 330 + (k % 2) * 8, 3, 0, 6.283); x.fill(); }   // furos de respiro
    if (S.mark) { x.fillStyle = '#c8a060'; x.font = 'bold 40px serif'; x.textAlign = 'center'; x.fillText(S.mark, cx, 190); }
  }
}

/** Desenha o personagem num canvas comum (W×H). */
function drawPortrait(c, S, open, blink) {
  const st = STYLES[S.style], x = c.getContext('2d');
  x.fillStyle = st.bg; x.fillRect(0, 0, W, H);
  if (st.dark) { const g = x.createRadialGradient(120, 140, 10, 210, 260, 420); g.addColorStop(0, '#36445f'); g.addColorStop(1, st.bg); x.fillStyle = g; x.fillRect(0, 0, W, H); x.fillStyle = '#4a3a2a'; x.fillRect(330, 0, 90, H); }
  if (S.helm) { drawBody(x, S, st); drawHelm(x, S, st); return; }
  drawHair(x, S, st, false);
  drawBody(x, S, st);
  // orelhas e rosto
  x.fillStyle = st.skin; x.strokeStyle = st.line; x.lineWidth = st.lw * 0.8;
  for (const s of [-1, 1]) { x.beginPath(); x.ellipse(210 + s * 96, 290, 14, 26, 0, 0, 6.283); x.fill(); x.stroke(); }
  shapePath(x, faceOutline(S.face)); x.fill();
  // sombra do rosto conforme o estilo
  const shadeClip = () => { shapePath(x, faceOutline(S.face)); };
  x.save(); shadeClip(); x.clip();
  if (st.shade === 'cel') { x.fillStyle = st.skinShade; x.beginPath(); x.moveTo(280, 0); x.quadraticCurveTo(300, 300, 230, 440); x.lineTo(420, 440); x.lineTo(420, 0); x.fill(); x.fillRect(0, 150, W, 70); }
  if (st.shade === 'hatch') { x.restore(); hatch(x, () => { x.beginPath(); x.moveTo(250, 120); x.quadraticCurveTo(320, 300, 230, 440); x.lineTo(420, 440); x.lineTo(420, 120); x.closePath(); shapePath(x, faceOutline(S.face)); }, 0.95, 6, 'rgba(20,18,16,.7)', 1.2); x.save(); shadeClip(); x.clip(); }
  if (st.shade === 'soft') { const g = x.createLinearGradient(0, 150, 0, 260); g.addColorStop(0, 'rgba(220,170,170,.35)'); g.addColorStop(1, 'rgba(220,170,170,0)'); x.fillStyle = g; x.fillRect(0, 150, W, 120); }
  if (st.shade === 'tone') tone(x, () => { x.beginPath(); x.rect(0, 150, W, 60); }, 7, 'rgba(0,0,0,.35)');
  if (S.soot) { x.fillStyle = 'rgba(30,30,30,.35)'; x.beginPath(); x.ellipse(150, 340, 22, 12, 0.4, 0, 6.283); x.fill(); }
  x.restore();
  x.strokeStyle = st.line; x.lineWidth = st.lw; shapePath(x, faceOutline(S.face)); x.stroke();
  drawEyes(x, S, st, blink);
  drawMouth(x, S, st, open);
  drawHair(x, S, st, true);
  if (S.glasses) {
    x.strokeStyle = st.line; x.lineWidth = st.lw * 0.75;
    for (const s of [-1, 1]) { x.beginPath(); x.roundRect ? x.roundRect(210 + s * 50 - 40, 256, 80, 52, 10) : x.rect(210 + s * 50 - 40, 256, 80, 52); x.stroke(); }
    x.beginPath(); x.moveTo(200, 276); x.lineTo(220, 276); x.stroke();
    x.strokeStyle = 'rgba(255,255,255,.9)'; x.lineWidth = 3; for (const s of [-1, 1]) { x.beginPath(); x.moveTo(210 + s * 50 + 14, 264); x.lineTo(210 + s * 50 + 26, 276); x.stroke(); }
  }
}
function lighten(hex, k) { const n = parseInt(hex.slice(1), 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255; const f = v => Math.round(v + (255 - v) * k); return `rgb(${f(r)},${f(g)},${f(b)})`; }

/** Converte o desenho em caracteres. */
function toGlyphs(src, out, S) {
  const st = STYLES[S.style], sx = src.getContext('2d'), img = sx.getImageData(0, 0, W, H).data;
  const lum = new Float32Array(COLS * ROWS), col = new Float32Array(COLS * ROWS * 3);
  for (let j = 0; j < ROWS; j++) for (let i = 0; i < COLS; i++) {
    let r = 0, g = 0, b = 0;
    for (let y = 0; y < RH; y++) for (let x = 0; x < CW; x++) { const k = ((j * RH + y) * W + i * CW + x) * 4; r += img[k]; g += img[k + 1]; b += img[k + 2]; }
    const n = CW * RH * 255, c = (j * COLS + i);
    col[c * 3] = r / n; col[c * 3 + 1] = g / n; col[c * 3 + 2] = b / n;
    lum[c] = 0.3 * r / n + 0.55 * g / n + 0.15 * b / n;
  }
  const bg = st.bg, bn = parseInt(bg.slice(1), 16), br = (bn >> 16) / 255, bgg = ((bn >> 8) & 255) / 255, bb = (bn & 255) / 255;
  const ln = parseInt(st.line.slice(1), 16), lc = [(ln >> 16) / 255, ((ln >> 8) & 255) / 255, (ln & 255) / 255];
  const x = out.getContext('2d');
  x.fillStyle = bg; x.fillRect(0, 0, W, H);
  // fundo de tinta: a mancha de cor de cada célula, suave — os caracteres desenham o traço por cima
  for (let j = 0; j < ROWS; j++) for (let i = 0; i < COLS; i++) {
    const c = j * COLS + i, k = st.dark ? 0.55 : 0.6;
    const r = br + (col[c * 3] - br) * k, g = bgg + (col[c * 3 + 1] - bgg) * k, b = bb + (col[c * 3 + 2] - bb) * k;
    x.fillStyle = `rgb(${r * 255 | 0},${g * 255 | 0},${b * 255 | 0})`; x.fillRect(i * CW, j * RH, CW, RH);
  }
  x.font = `bold ${RH + 1.6}px "AshenMono", monospace`; x.textBaseline = 'top';
  const L = (i, j) => lum[Math.max(0, Math.min(ROWS - 1, j)) * COLS + Math.max(0, Math.min(COLS - 1, i))];
  for (let j = 0; j < ROWS; j++) for (let i = 0; i < COLS; i++) {
    const c = j * COLS + i, l = lum[c];
    const gx = L(i + 1, j) - L(i - 1, j), gy = L(i, j + 1) - L(i, j - 1), gm = Math.hypot(gx, gy);
    // tinta: o quanto a célula se afasta do papel
    const dist = (Math.abs(col[c * 3] - br) + Math.abs(col[c * 3 + 1] - bgg) + Math.abs(col[c * 3 + 2] - bb)) / 3;
    const ink = Math.min(1, st.dark ? dist * 1.4 + l * 0.5 : dist * 1.6 + (1 - l) * 0.35);
    let ch;
    let edge = false;
    if (gm > 0.2) { edge = true;                    // borda → traço na direção do contorno
      const a = Math.atan2(gy, gx), t = Math.abs(Math.cos(a)), u = Math.abs(Math.sin(a));
      ch = t > 0.85 ? '|' : u > 0.85 ? (gy > 0 ? '_' : '-') : (Math.sign(gx) === Math.sign(gy) ? '\\' : '/');
    } else ch = RAMP[Math.max(0, Math.min(RAMP.length - 1, Math.round(ink * (RAMP.length - 1))))];
    if (ch === ' ' || (ink < 0.08 && !edge)) continue;
    let r = col[c * 3], g = col[c * 3 + 1], b = col[c * 3 + 2];
    if (edge) { r = lc[0]; g = lc[1]; b = lc[2]; if (st.dark) { r = Math.min(1, r * 0.4 + 0.05); g *= 0.4; b *= 0.4; } }
    else if (!st.dark) { const k = l > 0.75 ? 0.68 : 0.5; r *= k; g *= k; b *= k; } else { r = Math.min(1, r * 1.35 + 0.08); g = Math.min(1, g * 1.35 + 0.08); b = Math.min(1, b * 1.35 + 0.08); }
    x.fillStyle = `rgb(${r * 255 | 0},${g * 255 | 0},${b * 255 | 0})`;
    x.fillText(ch, i * CW, j * RH);
  }
}

/** Retrato animado: fala mexe a boca, pisca de vez em quando. */
export class Portrait {
  constructor(canvas) { this.cv = canvas; this.cache = new Map(); this.who = null; this.t = 0; this.blinkT = 2; this.src = null; }
  build(who) {
    if (this.cache.has(who)) return Promise.resolve(this.cache.get(who));
    const S = FACE_SPECS[who] || FACE_SPECS.you, fr = {};
    if (!this.src) { this.src = document.createElement('canvas'); this.src.width = W; this.src.height = H; }
    for (const [k, o, b] of S.helm ? [['0:0', 0, 0]] : [['0:0', 0, 0], ['0.5:0', 0.5, 0], ['1:0', 1, 0], ['0:1', 0, 1]]) {
      drawPortrait(this.src, S, o, b);
      const c = document.createElement('canvas'); c.width = W; c.height = H;
      toGlyphs(this.src, c, S);
      fr[k] = c;
    }
    this.cache.set(who, fr);
    return Promise.resolve(fr);
  }
  show(who) {
    this.who = who; this.cv.width = W; this.cv.height = H; this.last = null;
    this.build(who); this.frames = this.cache.get(who);
    this.draw(0, false);
  }
  draw(dt, talking) {
    if (!this.frames) return;
    this.t += dt; this.blinkT -= dt;
    let blink = 0;
    if (this.blinkT < 0) { blink = 1; if (this.blinkT < -0.14) this.blinkT = 2 + Math.random() * 3.5; }
    let open = 0;
    if (talking) { const s = Math.abs(Math.sin(this.t * 13)) * (0.6 + 0.4 * Math.sin(this.t * 3.1)); open = s > 0.6 ? 1 : s > 0.25 ? 0.5 : 0; }
    let k = blink ? '0:1' : open + ':0';
    if (!this.frames[k]) k = '0:0';
    if (k === this.last) return;
    this.last = k;
    this.cv.getContext('2d').drawImage(this.frames[k], 0, 0);
  }
}

/** Para testes: desenha a folha com todos os retratos. */
export function contactSheet(canvas, glyphs = true) {
  const names = Object.keys(FACE_SPECS); canvas.width = W * 4; canvas.height = H * 2;
  const x = canvas.getContext('2d'), src = document.createElement('canvas'), c = document.createElement('canvas');
  src.width = c.width = W; src.height = c.height = H;
  names.forEach((n, i) => { drawPortrait(src, FACE_SPECS[n], i === 2 ? 1 : 0, 0); if (glyphs) toGlyphs(src, c, FACE_SPECS[n]); x.drawImage(glyphs ? c : src, (i % 4) * W, ((i / 4) | 0) * H); });
}
