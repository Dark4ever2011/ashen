// ASHEN — Arte do Cavaleiro (Armadura de Aço Negro do Juramento)
//
// COMO EDITAR (dá para fazer pelo celular):
//  Cada peça é uma lista de linhas: [glifos, materiais, fundo(opcional)].
//  • Dígitos 0–5 nos glifos = sombreamento de gravura do aço (1 claro … 5 sombra; 0 liso).
//    Viram hachuras ╱ ╳ · automaticamente — a luz vem da esquerda (luar).
//  • Outros caracteres são desenhados como estão; a cor vem da coluna de materiais
//    (códigos em src/engine/palette.js: S prata, G ouro, e brasa, n aço profundo…).
//  • Espaço = transparente. O fundo da silhueta é preenchido sozinho (bg da peça).
//  Vistas: S (frente), N (costas), E (perfil direito). W é derivado de E com glifos
//  espelhados e camadas trocadas (a espada passa para trás do corpo).
//  Trocar equipamento no futuro = trocar as peças de um slot (helm, torso, pauldron…).

const A = (name, rows, extra = {}) => ({
  name, fg: 'k', bg: 'n', style: 'steel',
  g: rows.map(r => r[0]),
  m: rows.map(r => r[1] || ''),
  b: rows.map(r => r[2] || ''),
  ...extra,
});

// ───────────────────────── FRENTE (S) ─────────────────────────
export const S = {
  helm: A('elmo-S', [
    ['  ▄██▄  ', '  kSsk  '],
    [' ▟1123▙ ', ' K    k '],
    ['▐▀▀▀▀▀▀▌', 'kGGYggok', ' kkkkkk '],
    ['▐━•━━•━▌', 'knennenk'],
    [' ▜2┇┇4▛ ', ' K zz k '],
  ]),
  torso: A('peitoral-S', [
    ['   ▄▟22▙▄   ', '   KK  kk   '],
    [' ▄▟1123344▙▄', ' KK       kk'],
    ['▐11╲0誓0╱44▌', 'K  g GG g  k'],
    ['▐112╲▕▏╱344▌', 'K   gssg   k'],
    ['▐1122▕▏3344▌', 'K    ss    k'],
    ['▐2233▕▏3445▌', 'K    zz    k'],
    [' ▜▀▀▀▀▀▀▀▀▛ ', ' kssSSssszk ', '  kkkkkkkk  '],
    ['  ╞══╪╪══╡  ', '  ggGgggog  '],
    ['  ▐223344▌  ', '  K      k  '],
  ]),
  pauldron: A('ombreira-S', [
    ['    ▄▆▆▄', '    KKkk'],
    ['  ▄▟1122', '  KK    '],
    [' ▟112233', ' K      '],
    ['▟╤═╤═╤══', 'KGgGgGgg'],
    ['█1122333', 'K       '],
    ['▐▀▀▀▀▀▀▀', 'KssSsszz', ' kkkkkkk'],
    [' ▜11233▛', ' K     k'],
    ['  ▀▀▀▀▀ ', '  zssz  '],
  ]),
  tasset: A('escarcela-S', [
    ['▐112▌', 'K   k'],
    ['▐▀▀▀▌', 'KsSzk', ' kkk '],
    ['▐123▌', 'K   k'],
    [' ▀▀▀ ', ' sSz '],
  ]),
  knee: A('joelheira-S', [
    ['▗▟◆▙▖', 'KKSkk', '  k  '],
    [' ▀▀▀ ', ' zsz '],
  ]),
  boot: A('bota-S', [
    ['▐1223▌', 'K    k'],
    ['▟1223▙', 'K    k'],
    ['▀▀▀▀▀▀', 'zsSssz'],
  ]),
  gauntlet: A('manopla-S', [
    ['▟12▙', 'K  k'],
    ['▜╨╨▛', 'Kzzk'],
  ]),
  couter: A('cotoveleira-S', [['▟◆▙', 'KSk', ' k ']]),
  thighRow: A('coxote-S', [['▐1234▌', 'K    k']]),
  shinRow: A('greva-S', [['▐123▌', 'K   k']]),
  armRow: A('braçal-S', [['▐12▌', 'K  k']]),
};

// ───────────────────────── COSTAS (N) ─────────────────────────
export const N = {
  helm: A('elmo-N', [
    ['  ▄██▄  ', '  kSsk  '],
    [' ▟1123▙ ', ' K    k '],
    ['▐▀▀▀▀▀▀▌', 'KgggGgok', ' kkkkkk '],
    ['▐12║║34▌', 'K  ss  k'],
    [' ▜2334▛ ', ' K    k '],
  ]),
  torso: A('costal-N', [
    ['   ▄▟22▙▄   ', '   KK  kk   '],
    [' ▄▟112334▙▄ ', ' KK      kk '],
    ['▐1122║║3344▌', 'K    ss    k'],
    ['▐1122║║3344▌', 'K    ss    k'],
    ['▐1223║║3445▌', 'K    zz    k'],
    ['▐2233║║4455▌', 'K    zz    k'],
    [' ▜▀▀▀▀▀▀▀▀▛ ', ' kssSSssszk ', '  kkkkkkkk  '],
    ['  ╞══╪╪══╡  ', '  ggGgggog  '],
    ['  ▐223344▌  ', '  K      k  '],
  ]),
  boot: A('bota-N', [
    ['▐1223▌', 'K    k'],
    ['▐1223▌', 'K    k'],
    ['▀▀▀▀▀▀', 'zsSssz'],
  ]),
  knee: A('joelheira-N', [
    ['▐2│3▌', 'K s k'],
    ['▐▀▀▀▌', 'Kzzzk'],
  ]),
};
Object.assign(N, {
  pauldron: S.pauldron, tasset: S.tasset, gauntlet: S.gauntlet, couter: S.couter,
  thighRow: S.thighRow, shinRow: S.shinRow, armRow: S.armRow,
});

// ───────────────────────── PERFIL (E) ─────────────────────────
export const E = {
  helm: A('elmo-E', [
    ['  ▄██▄  ', '  kSsk  '],
    [' ▟11233▙', ' K     k'],
    ['▐▀▀▀▀▀▀▌', 'KgGGYGgk', ' kkkkkk '],
    ['▐1234━━•', 'K    nne'],
    [' ▜234┇┇▛', ' K   zzk'],
  ]),
  torso: A('peitoral-E', [
    ['  ▄▟22▙▄  ', '  KK  kk  '],
    [' ▟1122334▙', ' K       k'],
    ['▐1122╱344▙', 'K    g   k'],
    ['▐112╱3344█', 'K   g    k'],
    ['▐11233444▛', 'K        k'],
    ['▐1223344▛ ', 'K       k '],
    [' ▜▀▀▀▀▀▀▘ ', ' kssSSssz ', '  kkkkkk  '],
    [' ╞══╪══╡  ', ' ggGggog  '],
    [' ▐223344▌ ', ' K      k '],
  ]),
  pauldron: A('ombreira-E', [
    ['  ▗▄▆▄▖  ', '  KKKkk  '],
    [' ▟11223▙ ', ' K     k '],
    ['▟1122334▙', 'K       k'],
    ['█╤═╤═╤═╤█', 'KGgGgGgGk'],
    ['█1122334█', 'K       k'],
    ['▜▀▀▀▀▀▀▀▛', 'KssSsszzk', ' kkkkkkk '],
    [' ▜11234▛ ', ' K     k '],
    ['  ▀▀▀▀▀  ', '  zssz   '],
  ]),
  tasset: S.tasset,
  knee: A('joelheira-E', [
    ['▗▟◆▙', 'KKsk', '  k '],
    [' ▀▀▘', ' zsz'],
  ]),
  boot: A('bota-E', [
    ['▐12▌  ', 'K  k  '],
    ['▐1233▙', 'K    k'],
    ['▀▀▀▀▀▀', 'zsSssz'],
  ]),
  gauntlet: A('manopla-E', [
    ['▟1▙', 'K k'],
    ['▜╨▛', 'Kzk'],
  ]),
  couter: S.couter,
  thighRow: A('coxote-E', [['▐123▌', 'K   k']]),
  shinRow: S.shinRow,
  armRow: S.armRow,
};

// ───────────────────────── ESPADA ─────────────────────────
// Montante (espada de duas mãos), desenhado na vertical com a ponta para baixo.
// O pivô da empunhadura fica em (col 2.5, linha 2.5). Ela é girada glifo a glifo.
const blade = [' ▐│▌ ', ' Bzb ', '  b  '];
export const SWORD = {
  name: 'montante', fg: 'b', bg: null, pivot: [2.5, 2.5],
  g: ['  ●  ', '  ╫  ', '  ╫  ', '  ║  ', '━━╋━━', ' ▐█▌ ', ...Array(12).fill(blade[0]), ' ▐█▌ ', ' ▐█▌ ', '  ▼  '],
  m: ['  G  ', '  L  ', '  L  ', '  L  ', 'gGGGg', ' BSb ', ...Array(12).fill(blade[1]), ' BBb ', ' Bbb ', '  B  '],
  b: ['     ', '  l  ', '  l  ', '  l  ', '     ', '     ', ...Array(12).fill(blade[2]), '     ', '     ', '     '],
};
