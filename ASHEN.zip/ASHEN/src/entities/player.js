// ASHEN — Protagonista
// Controle com peso (aceleração/desaceleração), escolha de vista com histerese,
// ciclo de passada dirigido pela distância, respiração, poeira nos passos e interação.

import { CONFIG } from '../config.js';
import { KnightRig } from './knight-rig.js';
import { P } from '../engine/particles.js';
import { clamp } from '../engine/animation.js';
import { makeCanvas } from '../engine/canvas.js';

const VIEW_ANGLES = { E: 0, S: Math.PI / 2, W: Math.PI, N: -Math.PI / 2 };

export class Player {
  constructor(x, y) {
    this.x = x; this.y = y; this.px = x; this.py = y;
    this.vx = 0; this.vy = 0;
    this.r = 15;
    this.view = 'S';
    this.facing = Math.PI / 2;
    this.blend = 0;           // 0 parado → 1 andando
    this.run = 0;
    this.phase = 0;
    this.breath = 0;
    this.lastPhase = 0;
    this.rig = new KnightRig();
    this.speedNorm = 0;
    this.moveTarget = null;   // clique para mover (desktop)
    this.focus = null;        // objeto interativo próximo
    this.steps = 0;
    this.scratch = null;
  }

  update(dt, input, world) {
    this.px = this.x; this.py = this.y;
    const st = input.state;
    let mx = st.mx, my = st.my;
    // Clique/segurar mouse: anda até o ponto.
    if (this.moveTarget) {
      const mt = this.moveTarget;
      const dx = mt.x - this.x, dy = mt.y - this.y, d = Math.hypot(dx, dy);
      const stop = mt.stop || 10;
      if (mx || my) this.moveTarget = null;               // teclado/joystick assume o controle
      else if (d < stop) { this.moveTarget = null; mt.onArrive && mt.onArrive(); }
      else {
        mx = dx / d; my = dy / d * CONFIG.TILT;
        // Preso numa parede/objeto: desiste (e interage se já está perto o bastante).
        mt.stuck = Math.hypot(this.vx, this.vy) < 25 && (mt.t = (mt.t || 0) + dt) > 0.3 ? (mt.stuck || 0) + dt : 0;
        if (mt.stuck > 0.45) { this.moveTarget = null; if (mt.onArrive && d < stop * 2.4) mt.onArrive(); }
      }
    }
    // Direção da tela → direção do mundo (o chão é achatado por TILT).
    let wx = mx, wy = my / CONFIG.TILT;
    const wl = Math.hypot(wx, wy);
    const mag = Math.min(1, Math.hypot(mx, my));
    if (wl > 0) { wx /= wl; wy /= wl; }
    const running = st.run && mag > 0.3;
    this.run += ((running ? 1 : 0) - this.run) * Math.min(1, dt * 5);
    const maxSpeed = (CONFIG.WALK_SPEED + (CONFIG.RUN_SPEED - CONFIG.WALK_SPEED) * this.run) * (st.analog ? Math.max(0.35, mag) : (mag > 0 ? 1 : 0));
    const comp = 1 + 0.16 * Math.abs(wy);
    const tvx = wx * maxSpeed * comp, tvy = wy * maxSpeed * comp;
    // Aceleração com peso: arrancar é mais lento que parar; virar 180° freia antes.
    const dot = (this.vx * tvx + this.vy * tvy);
    const acc = (mag > 0 ? CONFIG.ACCEL : CONFIG.DECEL) * (dot < 0 ? 1.6 : 1);
    const dvx = tvx - this.vx, dvy = tvy - this.vy, dl = Math.hypot(dvx, dvy);
    if (dl > 0) { const k = Math.min(1, acc * dt / dl); this.vx += dvx * k; this.vy += dvy * k; }
    world.physics.move(this, this.vx * dt, this.vy * dt);
    // Velocidade real (após colisões)
    const rvx = (this.x - this.px) / dt, rvy = (this.y - this.py) / dt;
    const speed = Math.hypot(rvx, rvy);
    this.speedNorm = clamp(speed / CONFIG.RUN_SPEED, 0, 1);
    this.rvx = rvx; this.rvy = rvy;
    const moving = speed > 12;
    this.blend += ((moving ? 1 : 0) - this.blend) * Math.min(1, dt * (moving ? 7 : 5));
    if (this.blend < 0.02) this.blend = 0;
    // Passada: avança pela distância (sem deslizar).
    const stride = (this.run > 0.5 ? 150 : 108);
    this.lastPhase = this.phase;
    if (moving) this.phase = (this.phase + speed * dt / stride) % 1;
    else if (this.blend === 0) this.phase = 0;
    this.breath = (this.breath + dt / (3.4 - this.speedNorm)) % 1;
    // Vista: ângulo na tela com histerese.
    if (moving && (Math.abs(tvx) + Math.abs(tvy) > 1 || this.moveTarget)) {
      const ang = Math.atan2(rvy * CONFIG.TILT, rvx);
      this.facing = ang;
      this._chooseView(ang);
    }
    // Passos: poeira quando um pé toca o chão.
    const crossed = (a, b, c) => (a < c && b >= c) || (a > b && (a < c || b >= c));
    if (moving && (crossed(this.lastPhase, this.phase, 0.5) || crossed(this.lastPhase, this.phase, 0.0))) {
      this.steps++;
      const foot = this.steps % 2 ? 1 : -1;
      world.onFootstep(this.x + foot * 12, this.y + 4, this.run);
    }
    this.rig.updateCape(dt, this.view, rvx, this.speedNorm, this.phase, world.time, world.windNorm);
  }

  _chooseView(ang) {
    const sector = a => {
      const d = Math.abs(a);
      if (d < Math.PI / 3) return 'E';
      if (d > Math.PI * 2 / 3) return 'W';
      return a > 0 ? 'S' : 'N';
    };
    const target = sector(ang);
    if (target === this.view) return;
    // Histerese: só troca se estiver 8° dentro do novo setor.
    const h = 8 * Math.PI / 180;
    if (sector(ang + h) === target && sector(ang - h) === target) this.view = target;
  }

  /** Estado de animação para o rig. */
  animState() {
    return { view: this.view, blend: this.blend, phase: this.phase, breath: this.breath, run: this.run };
  }

  lerpPos(a) { return { x: this.px + (this.x - this.px) * a, y: this.py + (this.y - this.py) * a }; }

  /** Item para a lista de desenho do renderer. */
  drawItem(r, painter, alpha) {
    const pos = this.lerpPos(alpha);
    const fr = this.rig.frame(painter, r.version, this.animState());
    this._frame = fr; this._pos = pos;
    const bx = Math.round(r.dx(pos.x)), by = Math.round(r.dy(pos.y));
    const rect = [bx - fr.ax, by - fr.ay, bx - fr.ax + fr.w, by - fr.ay + fr.h];
    this.screenRect = rect;
    return {
      depth: pos.y, order: 1,
      bounds: [pos.x - 100, pos.y * r.tilt - 380, pos.x + 100, pos.y * r.tilt + 20],
      draw: (ctx) => {
        const view = this.view;
        const behind = view !== 'N';
        if (behind) this.rig.drawCape(ctx, painter, r.version, view, bx, by, fr.J);
        ctx.drawImage(fr.canvas, bx - Math.round(fr.ax), by - Math.round(fr.ay));
        if (!behind) {
          this.rig.drawCape(ctx, painter, r.version, view, bx, by, fr.J);
          if (fr.over) ctx.drawImage(fr.over.canvas, bx - Math.round(fr.over.ax), by - Math.round(fr.over.ay));
        }
      },
    };
  }

  /** Sombra projetada pela luz dominante (silhueta do quadro atual). */
  drawCastShadow(r, light, strength) {
    const fr = this._frame, pos = this._pos;
    if (!fr || !pos) return;
    if (!this.scratch || this.scratch.width < fr.w || this.scratch.height < fr.h) {
      this.scratch = makeCanvas(Math.max(fr.w, 260), Math.max(fr.h, 480));
      this._silOf = null;
    }
    const sc = this.scratch;
    if (this._silOf !== fr) {          // refaz a silhueta só quando o quadro muda
      this._silOf = fr;
      const sx = sc.getContext('2d');
      sx.globalCompositeOperation = 'source-over';
      sx.clearRect(0, 0, sc.width, sc.height);
      sx.drawImage(fr.canvas, 0, 0);
      sx.globalCompositeOperation = 'source-in';
      sx.fillStyle = '#000';
      sx.fillRect(0, 0, fr.w, fr.h);
      sx.globalCompositeOperation = 'source-over';
    }
    castShadow(r, { canvas: sc, ax: fr.ax, ay: fr.ay, w: fr.w, h: fr.h }, pos.x, pos.y, light, strength);
  }
}

/** Desenha a silhueta deitada no chão, afastando-se da luz. */
export function castShadow(r, sil, x, y, light, strength, heightScale = 1, useFilter = false) {
  const ctx = r.ctx;
  let dx = x - light.x, dy = y - light.y;
  const d = Math.hypot(dx, dy) || 1;
  dx /= d; dy /= d;
  const lenF = clamp((d / Math.max(30, light.z)) * 0.42, 0.35, 1.5) * heightScale;
  const vx = dx, vy = dy * CONFIG.TILT;
  // Eixo da largura do corpo: perpendicular à direção da sombra (no chão, projetado).
  let ux = -dy, uy = dx * CONFIG.TILT;
  if (ux < 0) { ux = -ux; uy = -uy; }
  const ul = Math.hypot(ux, uy) || 1;
  const wk = Math.max(0.55, ul);
  ux = ux / ul * wk; uy = uy / ul * wk;
  const fx = r.dx(x), fy = r.dy(y);
  ctx.save();
  ctx.globalAlpha = Math.min(0.6, strength * 0.9);
  // Linha local -y (para cima no sprite) → direção da sombra no chão.
  ctx.setTransform(ux, uy, -vx * lenF, -vy * lenF * 0.85, fx, fy);
  if (useFilter) ctx.filter = 'brightness(0)';  // silhueta preta sem guardar outro canvas
  ctx.drawImage(sil.canvas, 0, 0, sil.w, sil.h, -sil.ax, -sil.ay, sil.w, sil.h);
  ctx.restore();
}
