// ASHEN 3D — III · O Reino Partido: mundo aberto de ~2 km × 2 km (≈ 4 km²).
// O relevo é uma função contínua (montanhas em crista, colinas, cânions, platôs, lagos) e os
// biomas saem de temperatura × umidade × altura × inclinação. O chão perto do cavaleiro é gerado
// em blocos de 32 m que entram e saem conforme ele anda (alguns por quadro, sem travar);
// um "horizonte" grosso mostra as montanhas ao longe. Lugares gigantescos são esculpidos uma vez
// enquanto a cena do trono passa.

import { PointSet, buildParts } from './sampler.js';
import { MAT } from './glyphs.js';
import { makeTree } from './trees3d.js';
import * as S from './sdf.js';
import { Ghoul } from './npc3d.js';
import { Goblin } from './goblin.js';
import { SolidGeom, xfYaw, rock } from './solid.js';

// ─────────────── chão sólido: cor do bioma (tom) e pesos de rocha/areia/neve/lama por vértice ───────────────
const TINT = { plains: [0.36, 0.42, 0.19], forest: [0.21, 0.38, 0.15], swamp: [0.24, 0.31, 0.17], ash: [0.36, 0.32, 0.27], shore: [0.4, 0.38, 0.25], rock: [0.32, 0.33, 0.24], snow: [0.5, 0.52, 0.5] };
function groundVert(out, x, z, mat, e) {
  const h = heightAt(x, z), hx = heightAt(x + e, z) - heightAt(x - e, z), hz = heightAt(x, z + e) - heightAt(x, z - e);
  const nl = Math.hypot(hx, 2 * e, hz), slope = Math.hypot(hx, hz) / (2 * e);
  const b = biome(x, z, h, slope), t = TINT[b];
  const wR = b === 'rock' ? 0.85 : b === 'snow' ? 0.25 : 0, wS = b === 'shore' ? 0.9 : 0, wN = b === 'snow' ? 1 : 0;
  const wM = h < WL ? 0.75 : b === 'swamp' ? 0.35 + 0.4 * vn(x / 9, z / 9) : 0;
  return out.vert(x, h, z, -hx / nl, 2 * e / nl, -hz / nl, mat, t[0], t[1], t[2], wR, wS, wN, wM);
}
/** Grade de chão (step m) e lâmina d'água nos lagos. */
function groundGrid(out, x0, z0, size, step, mat) {
  const n = Math.round(size / step), base = out.nv, wet = [];
  for (let j = 0; j <= n; j++) for (let i = 0; i <= n; i++) groundVert(out, x0 + i * step, z0 + j * step, mat, Math.max(0.6, step * 0.6));
  for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
    const a = base + j * (n + 1) + i, b = a + 1, c = a + n + 1, d = c + 1;
    out.tri(a, c, b); out.tri(b, c, d);
    const v = out.v, S = 14;
    if (Math.min(v[a * S + 1], v[b * S + 1], v[c * S + 1], v[d * S + 1]) < WL) wet.push([x0 + i * step, z0 + j * step]);
  }
  for (const [x, z] of wet) {         // água: quad no nível do lago (o shader a reconhece pela altura)
    const w0 = out.vert(x, WL, z, 0, 1, 0, mat, 0.1, 0.2, 0.26, 0, 0, 0, 0), w1 = out.vert(x + step, WL, z, 0, 1, 0, mat, 0.1, 0.2, 0.26, 0, 0, 0, 0);
    const w2 = out.vert(x, WL, z + step, 0, 1, 0, mat, 0.1, 0.2, 0.26, 0, 0, 0, 0), w3 = out.vert(x + step, WL, z + step, 0, 1, 0, mat, 0.1, 0.2, 0.26, 0, 0, 0, 0);
    out.tri(w0, w2, w1); out.tri(w1, w2, w3);
  }
}

export const OWO = { x: 2000, z: 0 };
const HALF = 1000, TILE = 32, NEAR = 1.75, FAR_UNLOAD = 2.6, WL = -6;
export const OW_SPAWN = { x: OWO.x + 0, z: 34 };
export const OW_FIRE = { x: OWO.x + 1.6, z: 31 };

// ─────────────── ruído rápido (valor 2D com hash inteiro) ───────────────
function hash2(i, j) { let h = (i * 374761393 + j * 668265263) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; }
function vn(x, z) {
  const i = Math.floor(x), j = Math.floor(z), fx = x - i, fz = z - j;
  const u = fx * fx * (3 - 2 * fx), v = fz * fz * (3 - 2 * fz);
  const a = hash2(i, j), b = hash2(i + 1, j), c = hash2(i, j + 1), d = hash2(i + 1, j + 1);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
function fbm(x, z, o = 4) { let s = 0, a = 0.5, f = 1, n = 0; for (let k = 0; k < o; k++) { s += a * vn(x * f + k * 17.3, z * f - k * 9.1); n += a; a *= 0.5; f *= 2.03; } return s / n; }
function ridged(x, z, o = 4) { let s = 0, a = 0.5, f = 1, n = 0; for (let k = 0; k < o; k++) { const r = 1 - Math.abs(2 * vn(x * f + k * 31.7, z * f + k * 7.7) - 1); s += a * r * r; n += a; a *= 0.5; f *= 2.1; } return s / n; }
const sstep = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

/** Lugares aplainados: a igreja do Profano (montanhas do norte), a vila do moinho e a casa distante. */
export const SITES = {
  church: { x: OWO.x + 160, z: -700, r: 36 },
  village: { x: OWO.x + 580, z: -590, r: 44 },
  her: { x: OWO.x + 574, z: -420, r: 16 },
  crypt: { x: OWO.x - 250, z: 0, r: 14 },
};
for (const s of Object.values(SITES)) s.h = null;
/** Altura do terreno (metros). */
export function heightAt(x, z) {
  let h = rawHeight(x, z);
  for (const s of Object.values(SITES)) {
    const d = Math.hypot(x - s.x, z - s.z);
    if (d < s.r) { if (s.h == null) s.h = rawHeight(s.x, s.z); h += (s.h - h) * (1 - sstep(s.r * 0.6, s.r, d)); }
  }
  for (const F of FALLS) h = fallShape(F, x, z, h);
  return h;
}
/** Cachoeiras (v0.25): no mundo quase plano, cada uma tem o seu penhasco (platô atrás, paredão na frente) e um poço na base.
 *  c = beira do penhasco, d = direção da queda (do alto para o poço), H = altura, W = meia largura do paredão. */
export const FALLS = [
  { x: OWO.x - 34, z: -10, dx: 0, dz: 1, H: 11, W: 9 },          // perto da fogueira da chegada (~45 m)
  { x: OWO.x + 280, z: 420, dx: 0, dz: 1, H: 14, W: 11 },
  { x: OWO.x - 240, z: -420, dx: 0.6, dz: 0.8, H: 16, W: 12 },
  { x: OWO.x + 150, z: -200, dx: -0.3, dz: 0.954, H: 12, W: 9 },
];
for (const F of FALLS) { F.px = F.x + F.dx * 7; F.pz = F.z + F.dz * 7; }   // centro do poço
function fallShape(F, x, z, h) {
  const rx = x - F.x, rz = z - F.z, d2 = rx * rx + rz * rz;
  if (d2 > 3600) return h;
  const d = Math.sqrt(d2), a = rx * F.dx + rz * F.dz, b = -rx * F.dz + rz * F.dx;
  h = 1 + (h - 1) * sstep(26, 58, d);                                            // em volta: chão calmo
  const lip = vn(b * 0.45 + F.x, F.z) * 1.6 - 0.8;                               // beira irregular
  const across = 1 - sstep(F.W, F.W * 1.7 + 6, Math.abs(b)), back = 1 - sstep(24, 42, -a), front = 1 - sstep(-1.4, 0.4, a + lip);
  const rough = (vn(x * 0.35, z * 0.35) - 0.5) * 2.2 * front;                     // rochas do paredão
  h += (F.H + rough) * across * back * front;
  const rp = Math.hypot(x - F.px, z - F.pz);
  h -= 13 * (1 - sstep(4.5, 10.5, rp));                                          // o poço
  return h;
}
function rawHeight(x, z) {
  const lx = x - OWO.x, lz = z - OWO.z;
  // v0.25: reino predominantemente plano — ondulações leves, colinas baixas e pequenas depressões;
  // montanhas só no anel de fora (bordas), lagos em bacias rasas e rios em leitos suaves
  const edge0 = Math.max(Math.abs(lx), Math.abs(lz)), ring = sstep(760, 900, edge0);
  let h = (fbm(lx / 380, lz / 380, 4) - 0.42) * 10 + 2;                         // ondulação larga
  const M = sstep(0.4, 0.64, vn(lx / 620 + 3.1, lz / 620 - 7.7));
  h += M * ridged(lx / 190, lz / 190, 4) * 120 * ring;                          // montanhas: só nas bordas
  h += (fbm(lx / 140, lz / 140, 3) - 0.45) * 6;                                 // colinas baixas
  h += (fbm(lx / 40, lz / 40, 2) - 0.5) * 1.6;                                  // ondulação miúda
  h -= sstep(0.27, 0.19, vn(lx / 260 + 17, lz / 260 - 4)) * 12;                 // bacias dos lagos
  const cd = Math.abs(vn(lx / 520 + 11, lz / 520 + 5) - 0.5);                   // rios serpenteando
  if (cd < 0.022) { const k = 1 - cd / 0.022; h -= k * k * 10; }
  const desert = sstep(0.58, 0.7, vn(lx / 700 + 50, lz / 700 - 20)) * sstep(0.55, 0.4, vn(lx / 600 - 30, lz / 600 + 9));
  if (desert > 0.01) { const t = Math.floor(h / 2.5) * 2.5 + sstep(0.7, 1, (h / 2.5) % 1) * 2.5; h += (t - h) * desert * 0.7; }   // degraus baixos
  const sd = Math.hypot(lx - (OW_SPAWN.x - OWO.x), lz - OW_SPAWN.z);
  h = 1.5 + (h - 1.5) * sstep(28, 110, sd);                                     // clareira da chegada
  const edge = Math.max(Math.abs(lx), Math.abs(lz));
  h += sstep(880, 1000, edge) * 90;                                             // as bordas do mundo viram paredões
  return h;
}
// o canto do corcel, ao lado da fogueira da chegada: sem árvore nem pedra (nada tampa o cavalo)
const nearHorseHome = (x, z, r) => Math.hypot(x - (OW_FIRE.x + 3.6), z - (OW_FIRE.z + 1.4)) < r;
export const inSite = (x, z, pad = 0) => Object.values(SITES).some(s => Math.hypot(x - s.x, z - s.z) < s.r * 0.75 + pad);
export const blockedAt = (x, z) => heightAt(x, z) < WL - 0.7 || Math.abs(x - OWO.x) > HALF - 6 || Math.abs(z - OWO.z) > HALF - 6;

function biome(x, z, h, slope) {
  const lx = x - OWO.x, lz = z - OWO.z;
  const temp = vn(lx / 700 + 50, lz / 700 - 20), wet = vn(lx / 600 - 30, lz / 600 + 9);
  if (h > 62 + vn(lx / 40, lz / 40) * 10) return 'snow';
  if (slope > 0.95) return 'rock';
  if (h < WL + 1.4) return 'shore';
  if (temp > 0.58 && wet < 0.45) return 'ash';
  if (wet > 0.64 && h < 8) return 'swamp';
  if (wet > 0.5) return 'forest';
  return 'plains';
}
const MATS = {
  snow: [MAT.SNOW, MAT.SNOW, MAT.STONE], rock: [MAT.STONE, MAT.STONE, MAT.GRAVEL], shore: [MAT.SAND, MAT.SAND, MAT.GRAVEL],
  ash: [MAT.GROUND, MAT.GRAVEL, MAT.SAND], swamp: [MAT.MOSS, MAT.GROUND, MAT.DARK], forest: [MAT.MOSS, MAT.GROUND, MAT.LEAF], plains: [MAT.GROUND, MAT.MOSS, MAT.GRAVEL],
};

// ─────────────── lugares gigantescos ───────────────
export const LANDMARKS = [
  { id: 'tree', name: 'A Árvore do Primeiro Outono', x: OWO.x + 320, z: -380 },
  { id: 'statue', name: 'O Rei Ajoelhado', x: OWO.x - 420, z: -260 },
  { id: 'arch', name: 'O Arco Partido', x: OWO.x + 80, z: -640 },
  { id: 'tower', name: 'A Torre Afundada', x: OWO.x - 300, z: 420 },
  { id: 'bones', name: 'A Ossada do Gigante', x: OWO.x + 450, z: 300 },
];
function landmarkParts(L) {
  const y0 = heightAt(L.x, L.z) - 0.5, P = [], add = o => P.push(o);
  const { x, z } = L;
  const rough = (p) => (vn(p[0] * 2.1, p[2] * 2.1 + p[1]) > 0.7 ? { mat: MAT.MOSS } : null);
  if (L.id === 'statue') {
    // rei de pedra de 40 m, ajoelhado sobre um plinto, mãos no punho da espada fincada
    const s = 18, Y = y0 + 3;
    const plinth = S.xf(S.box(14, 3, 14, 0.5), [x, y0 + 1.5, z]);
    const knee = S.capsule([x - 0.25 * s, Y + 0.25 * s, z + 0.1 * s], [x - 0.25 * s, Y + 0.05 * s, z + 0.65 * s], 0.14 * s);
    const shin = S.capsule([x + 0.25 * s, Y + 0.45 * s, z], [x + 0.25 * s, Y + 0.05 * s, z - 0.35 * s], 0.13 * s);
    const torso = S.xf(S.ellipsoid(0.38 * s, 0.6 * s, 0.26 * s), [x, Y + 1.15 * s, z + 0.05 * s]);
    const head = S.xf(S.sphere(0.2 * s), [x, Y + 1.98 * s, z + 0.12 * s]);
    const crown = S.subtract(S.xf(S.cylinder(0.22 * s, 0.08 * s), [x, Y + 2.15 * s, z + 0.12 * s]), S.xf(S.box(0.3 * s, 0.2 * s, 0.1 * s), [x + 0.15 * s, Y + 2.25 * s, z + 0.3 * s]));
    const arms = S.union(S.capsule([x - 0.36 * s, Y + 1.5 * s, z], [x - 0.12 * s, Y + 1.05 * s, z + 0.65 * s], 0.1 * s), S.capsule([x + 0.36 * s, Y + 1.5 * s, z], [x + 0.12 * s, Y + 1.05 * s, z + 0.65 * s], 0.1 * s));
    const sword = S.union(S.xf(S.box(0.06 * s, 0.75 * s, 0.015 * s), [x, Y + 0.3 * s, z + 0.75 * s]), S.xf(S.box(0.3 * s, 0.035 * s, 0.04 * s), [x, Y + 1.06 * s, z + 0.75 * s]));
    add({ name: 'plinto', f: plinth, min: [x - 15, y0 - 1, z - 15], max: [x + 15, y0 + 3.2, z + 15], mat: MAT.STONE, spacing: 0.32, flow: [1, 0, 0], detail: rough });
    add({ name: 'rei de pedra', f: S.smooth(0.08 * s, knee, shin, torso, head, arms), min: [x - 0.6 * s, Y - 0.2 * s, z - 0.6 * s], max: [x + 0.6 * s, Y + 2.25 * s, z + 0.9 * s], mat: MAT.STONE, spacing: 0.3, flow: [0, 1, 0], detail: rough });
    add({ name: 'coroa partida', f: crown, min: [x - 0.3 * s, Y + 2.0 * s, z - 0.2 * s], max: [x + 0.3 * s, Y + 2.3 * s, z + 0.45 * s], mat: MAT.GOLD, spacing: 0.22, flow: [1, 0, 0] });
    add({ name: 'espada fincada', f: sword, min: [x - 0.35 * s, Y - 0.5 * s, z + 0.7 * s], max: [x + 0.35 * s, Y + 1.12 * s, z + 0.8 * s], mat: MAT.IRON, spacing: 0.22, flow: [0, 1, 0] });
    L.collider = { type: 'circle', x, z, r: 14.5 };
  } else if (L.id === 'arch') {
    // arco de 60 m, metade desabada em blocos pelo chão
    const R = 26, w = 6;
    const ring = (px, py, pz) => Math.max(Math.abs(Math.hypot(px - x, py - y0) - R) - w, Math.abs(pz - z) - 5, -(py - y0 + 2));
    const broken = (px, py) => (px > x + 4 && py > y0 + 14 ? 1 : -1);
    add({ name: 'arco partido', f: (px, py, pz) => Math.max(ring(px, py, pz), broken(px, py)), min: [x - R - w, y0 - 2, z - 5.5], max: [x + R + w, y0 + R + w, z + 5.5], mat: MAT.STONE, spacing: 0.34, flow: [1, 0, 0],
      detail: (p, n) => (((p[1] - y0) / 2.2 % 1) < 0.08 ? { mat: MAT.DARK, glyph: '─' } : rough(p)) });
    for (let i = 0; i < 5; i++) { const bx = x + 14 + i * 4.5, bz = z + (i % 2 ? 6 : -5); add({ name: 'bloco', f: S.xf(S.box(2.4, 1.6, 2.2, 0.3), [bx, heightAt(bx, bz) + 1, bz], [0.3 * i, i, 0.2]), min: [bx - 3.5, heightAt(bx, bz) - 1, bz - 3.5], max: [bx + 3.5, heightAt(bx, bz) + 3.5, bz + 3.5], mat: MAT.STONE, spacing: 0.3, flow: [1, 0, 0], detail: rough }); }
    L.collider = { type: 'circle', x: x - R, z, r: 6.5 }; L.collider2 = { type: 'circle', x: x + R, z, r: 6.5 };
  } else if (L.id === 'tower') {
    // torre de 35 m afundada e inclinada no pântano
    const tilt = 0.22;
    const f = (px, py, pz) => { const ly = py - y0 + 6, lx2 = px - x - ly * tilt; return Math.max(Math.hypot(lx2, pz - z) - 4.2, Math.abs(ly - 17) - 17, -(Math.hypot(lx2, pz - z) - 3.6) * (ly > 30 ? 1 : 0)); };
    add({ name: 'torre afundada', f, min: [x - 6, y0 - 6, z - 6], max: [x + 14, y0 + 30, z + 6], mat: MAT.STONE, spacing: 0.3, flow: [0, 1, 0],
      detail: (p) => (((p[1] - y0) / 1.6 % 1) < 0.1 ? { mat: MAT.DARK, glyph: '─' } : (vn(p[1] * 0.8, p[0] * 0.8) > 0.8 ? { mat: MAT.EMBER, glyph: '¦', flags: 2 } : rough(p))) });
    L.collider = { type: 'circle', x, z, r: 4.6 };
  } else if (L.id === 'bones') {
    // costelas de um gigante, cada uma um arco de 20 m
    for (let i = 0; i < 7; i++) {
      const rz = z - 18 + i * 6, r = 14 - Math.abs(i - 3) * 1.5;
      const rib = (px, py, pz) => Math.max(Math.abs(Math.hypot(px - x, py - y0) - r) - 0.7, Math.abs(pz - rz) - 0.6, -(py - y0));
      add({ name: 'costela', f: rib, min: [x - r - 1, y0 - 0.5, rz - 0.8], max: [x + r + 1, y0 + r + 1, rz + 0.8], mat: MAT.BONE, spacing: 0.25, flow: [0, 1, 0] });
    }
    add({ name: 'espinha', f: S.capsule([x, y0 + 0.5, z - 22], [x, y0 + 0.8, z + 22], 1.0), min: [x - 1.2, y0 - 0.5, z - 23.5], max: [x + 1.2, y0 + 2, z + 23.5], mat: MAT.BONE, spacing: 0.22, flow: [0, 0, 1] });
    add({ name: 'crânio', f: S.subtract(S.xf(S.ellipsoid(5, 4.2, 6), [x, y0 + 2.5, z + 28]), S.union(S.xf(S.sphere(1.4), [x - 2, y0 + 3.5, z + 32.5]), S.xf(S.sphere(1.4), [x + 2, y0 + 3.5, z + 32.5]))), min: [x - 5.5, y0 - 1, z + 21.5], max: [x + 5.5, y0 + 7, z + 34.5], mat: MAT.BONE, spacing: 0.24, flow: [0, 1, 0] });
  }
  return P;
}

// ─────────────── blocos de chão ───────────────
function* genTile(W, ti, tj) {
  const x0 = OWO.x + ti * TILE, z0 = OWO.z + tj * TILE, sp = 0.42;
  const ps = new PointSet(6000), cols = [], ghouls = [];
  const solid = new SolidGeom(1600);
  groundGrid(solid, x0, z0, TILE, 1, -1);
  yield;
  let seed = (ti * 92821 + tj * 68917) >>> 0;
  const R = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  let n = 0;
  for (let x = x0; x < x0 + TILE; x += sp) {
    for (let z = z0; z < z0 + TILE; z += sp) {
      const px = x + (R() - 0.5) * sp * 0.9, pz = z + (R() - 0.5) * sp * 0.9;
      const h = heightAt(px, pz), e = 0.6, hx = heightAt(px + e, pz) - heightAt(px - e, pz), hz = heightAt(px, pz + e) - heightAt(px, pz - e);
      const nl = Math.hypot(hx, 2 * e, hz), nrm = [-hx / nl, 2 * e / nl, -hz / nl], slope = Math.hypot(hx, hz) / (2 * e);
      const b = biome(px, pz, h, slope), m = MATS[b][R() < 0.62 ? 0 : R() < 0.7 ? 1 : 2];
      if (h < WL - 0.25) {     // lago: a lâmina sólida está embaixo; os caracteres fazem as ondas
        if (R() < 0.45) ps.push([px, WL, pz], [0, 1, 0], [0.1 + 0.1 * vn(px / 30, pz / 30), Math.min(0.6, Math.max(0, (h - WL + 1.2) * 0.4)), 0.08], MAT.RIVER, -1, 0, 256, 0.14, R() * 1000);
        continue;
      }
      // (o chão agora é sólido: sem caracteres de terra)
      // vegetação conforme o bioma
      const r = R();
      const inChurch = Math.abs(px - SITES.church.x) < 8.5 && Math.abs(pz - SITES.church.z + 2) < 14.5, inHouse = [[SITES.village.x - 7, SITES.village.z + 3], [SITES.village.x + 8, SITES.village.z - 2], [SITES.her.x, SITES.her.z - 1.5]].some(([hx_, hz_]) => Math.abs(px - hx_) < 2.3 && Math.abs(pz - hz_) < 2);
      const vegP = inChurch || inHouse ? 0 : b === 'plains' ? 0.8 : b === 'forest' ? 0.62 : b === 'swamp' ? 0.75 : b === 'ash' ? 0.16 : b === 'shore' ? 0.14 : b === 'rock' ? 0.08 : 0;
      if (r < vegP * (vn(px / 7, pz / 7) * 0.5 + 0.75) && slope < 0.9) {
        const blades = 3 + ((R() * 4) | 0), tall = (b === 'swamp' ? 0.7 : b === 'plains' ? 0.42 : 0.3) * (0.7 + R() * 0.6);
        const mat = b === 'ash' ? MAT.GRASS3 : b === 'swamp' ? MAT.GRASS : R() < 0.6 ? MAT.GRASS2 : MAT.GRASS;
        const lean = R() * 6.28;
        for (let k = 0; k < blades; k++) { const a = R() * 6.28, rr = R() * 0.08, hh = tall * (0.6 + R() * 0.5); for (let s = 0; s < 2; s++) ps.push([px + Math.cos(a) * rr, h, pz + Math.sin(a) * rr], [0, 1, 0], [(s + 0.5) / 2, hh, lean + (R() - 0.5)], mat, -1, 0, 8, 0.07 + hh * 0.12, R() * 1000); }
      } else if (r < vegP + (b === 'plains' ? 0.1 : b === 'forest' ? 0.03 : b === 'swamp' ? 0.02 : 0) && W.pushFlower) {
        W.pushFlower(ps, W.G, px, h, pz, R, [MAT.FLOWER_R, MAT.FLOWER_Y, MAT.FLOWER_W, MAT.FLOWER_B, MAT.PETAL_P][(vn(px / 12, pz / 12) * 11 | 0) % 5], 1.1);
      }
    }
    if (++n % 6 === 0) yield;
  }
  // árvores (cópias de modelos prontos, giradas) e pedras
  const cx = x0 + TILE / 2, cz = z0 + TILE / 2, hb = heightAt(cx, cz);
  const bc = biome(cx, cz, hb, 0);
  const nTrees = bc === 'forest' ? 9 : bc === 'plains' ? 2 : bc === 'ash' ? 2 : bc === 'swamp' ? 3 : 0;
  for (let k = 0; k < nTrees; k++) {
    const tx = x0 + 2 + R() * (TILE - 4), tz = z0 + 2 + R() * (TILE - 4), th = heightAt(tx, tz);
    if (th < WL + 0.5 || th > 60 || inSite(tx, tz, 4) || nearHorseHome(tx, tz, 7.5)) continue;
    const kind = bc === 'ash' ? 'dead' : bc === 'swamp' ? (R() < 0.6 ? 'dead' : 'green') : (R() < 0.75 ? 'green' : 'autumn');
    const proto = W.trees[kind][(R() * W.trees[kind].length) | 0];
    const a = R() * 6.28, ca = Math.cos(a), sa = Math.sin(a), sc = 0.8 + R() * 0.6;
    if (proto.wood.solid) solid.append(proto.wood.solid, xfYaw(tx, th - 0.1, tz, ca, sa, sc));
    for (const src of [proto.wood, proto.leaves]) for (let i = 0; i < src.n; i++) {
      const lx = src.pos[i * 3] * sc, ly = src.pos[i * 3 + 1] * sc, lz = src.pos[i * 3 + 2] * sc;
      const nx = src.nrm[i * 3], nz = src.nrm[i * 3 + 2], tnx = src.tan[i * 3], tnz = src.tan[i * 3 + 2];
      ps.push([tx + lx * ca - lz * sa, th + ly - 0.1, tz + lx * sa + lz * ca], [nx * ca - nz * sa, src.nrm[i * 3 + 1], nx * sa + nz * ca], [tnx * ca - tnz * sa, src.tan[i * 3 + 1], tnx * sa + tnz * ca],
        src.attr[i * 4], src.attr[i * 4 + 1], 0, src.attr[i * 4 + 3], src.extra[i * 2] * Math.sqrt(sc), src.extra[i * 2 + 1]);
    }
    cols.push({ type: 'circle', x: tx, z: tz, r: 0.35 * sc });
    yield;
  }
  const nRocks = bc === 'rock' || bc === 'snow' ? 6 : bc === 'ash' ? 4 : 1;
  for (let k = 0; k < nRocks; k++) {
    const rx = x0 + R() * TILE, rz = z0 + R() * TILE, rh = heightAt(rx, rz), rad = 0.5 + R() * R() * 3;
    if (rh < WL || inSite(rx, rz, 3) || nearHorseHome(rx, rz, 4 + rad)) continue;
    rock(solid, rx, rh - rad * 0.15, rz, rad, rx * 0.37, vn, MAT.STONE, bc === 'snow' ? MAT.SNOW : MAT.MOSS);
    const cnt = Math.round(rad * rad * 28);               // musgo e rachaduras em caracteres por cima
    for (let i = 0; i < cnt; i++) {
      const u = R() * 2 - 1, t = R() * 6.28, s = Math.sqrt(1 - u * u), nx = s * Math.cos(t), ny = u * 0.75, nz = s * Math.sin(t);
      if (ny < 0) continue;
      const bump = 1.04 + 0.18 * (vn(nx * 4 + rx, nz * 4 + ny * 3) - 0.5);
      ps.push([rx + nx * rad * 1.2 * bump, rh - rad * 0.15 + ny * rad * bump, rz + nz * rad * bump], [nx, ny, nz], [-nz, 0, nx], ny > 0.4 ? (bc === 'snow' ? MAT.SNOW : MAT.MOSS) : MAT.DARK, -1, 0, 0, 0.1 + rad * 0.03, R() * 1000);
    }
    if (rad > 0.8) cols.push({ type: 'circle', x: rx, z: rz, r: rad * 1.1 });
  }
  // mortos errantes (poucos; o mundo é mais para explorar)
  if ((bc === 'ash' || bc === 'swamp' || bc === 'forest') && R() < 0.3 && Math.hypot(cx - OW_SPAWN.x, cz - OW_SPAWN.z) > 80) {
    const gx = x0 + 4 + R() * (TILE - 8), gz = z0 + 4 + R() * (TILE - 8);
    if (heightAt(gx, gz) > WL + 0.5 && !inSite(gx, gz, 20)) ghouls.push(new Ghoul('w' + ti + '_' + tj, gx, gz, R() * 6.28));
  }
  // bandos de goblins (2 a 3) nas florestas e planícies
  if ((bc === 'forest' || bc === 'plains') && R() < 0.22 && Math.hypot(cx - OW_SPAWN.x, cz - OW_SPAWN.z) > 70) {
    const gx = x0 + 6 + R() * (TILE - 12), gz = z0 + 6 + R() * (TILE - 12), n = 2 + (R() < 0.4 ? 1 : 0);
    for (let k = 0; k < n; k++) { const x = gx + (R() - 0.5) * 3, z = gz + (R() - 0.5) * 3; if (heightAt(x, z) > WL + 0.5 && !inSite(x, z, 20)) ghouls.push(new Goblin('b' + ti + '_' + tj + '_' + k, x, z, R() * 6.28)); }
  }
  ps.solid = solid;
  return { ps, cols, ghouls };
}

/** Horizonte: grade grossa até ~500 m, caracteres grandes (montanhas e vales ao longe). */
function* genHorizon(cx, cz) {
  // chão sólido longe (grade de 8 m; afunda no shader onde os blocos perto já cobrem)
  const solid = new SolidGeom(18000), STEP = 8, SPAN = 520;
  const gx0 = Math.round((cx - SPAN) / STEP) * STEP, gz0 = Math.round((cz - SPAN) / STEP) * STEP;
  const n = Math.round(SPAN * 2 / STEP);
  for (let j = 0; j <= n; j++) { for (let i = 0; i <= n; i++) { const vi = groundVert(solid, gx0 + i * STEP, gz0 + j * STEP, -2, 4), o = vi * 14, V = solid.v; if (V[o + 1] < WL) { V[o + 1] = WL; V[o + 3] = 0; V[o + 4] = 1; V[o + 5] = 0; V[o + 7] = 0.1; V[o + 8] = 0.2; V[o + 9] = 0.26; V[o + 10] = V[o + 11] = V[o + 12] = V[o + 13] = 0; } } if (j % 16 === 0) yield; }
  for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) { const a = j * (n + 1) + i, b = a + 1, c = a + n + 1, d = c + 1; solid.tri(a, c, b); solid.tri(b, c, d); }
  solid.far = true;
  const ps = new PointSet(4000), step = 9;
  for (let x = cx - 520; x <= cx + 520; x += step) {
    for (let z = cz - 520; z <= cz + 520; z += step) {
      const px = x + (hash2(x | 0, z | 0) - 0.5) * step * 0.8, pz = z + (hash2(z | 0, x | 0) - 0.5) * step * 0.8;
      const d = Math.hypot(px - cx, pz - cz);
      if (d > 520 || d < 58) continue;
      const h = heightAt(px, pz), e = 3, hx = heightAt(px + e, pz) - heightAt(px - e, pz), hz = heightAt(px, pz + e) - heightAt(px, pz - e);
      const nl = Math.hypot(hx, 2 * e, hz), slope = Math.hypot(hx, hz) / (2 * e);
      const b = biome(px, pz, h, slope);
      if (h < WL) { if (hash2(px | 0, 3) < 0.3) ps.push([px, WL, pz], [0, 1, 0], [0.1, 0.0, 0.05], MAT.RIVER, -1, 0, 256, 2.4, d); continue; }
      if (b === 'forest' && hash2(px | 0, 7) < 0.7) ps.push([px, h + 3, pz], [0, 1, 0], [1, 0, 0], MAT.LEAF_G, -1, 0, 0, 2.6, d + 1);
    }
    yield;
  }
  return { ps, solid };
}

// ─────────────── o mundo ───────────────
export class OpenWorld {
  constructor(g, atlas, pushFlower) {
    this.g = g; this.R = g.R; this.atlas = atlas; this.tiles = new Map(); this.queue = []; this.job = null;
    this.W = { trees: null, pushFlower, G: ch => atlas.get(ch) };
    this.ready = false; this.landmarkMeshes = []; this.horizon = null; this.hJob = null; this.hAt = null;
    this.ghouls = []; this.cols = [];
  }
  /** Esculpe o que é fixo (modelos de árvore, lugares gigantes) e os blocos em volta da chegada. */
  async build(onProgress) {
    if (this.ready || this.building) return this.building;
    this.building = (async () => {
      const yieldF = () => new Promise(r => setTimeout(r, 0));
      this.W.trees = { green: [], autumn: [], dead: [] };
      let s = 900;
      for (const kind of ['green', 'autumn', 'dead']) for (let i = 0; i < 3; i++) { this.W.trees[kind].push(makeTree(0, 0, s++, 1.1 + i * 0.25, kind)); await yieldF(); }
      for (let i = 0; i < LANDMARKS.length; i++) {
        const L = LANDMARKS[i];
        const set = await buildParts(landmarkParts(L), this.atlas, { seed: 600 + i * 11, sizeMul: 2.3, onProgress: f => onProgress && onProgress((i + f) / (LANDMARKS.length + 2)) });
        const m = this.R.addMesh(set, { chunk: 8 }); m.area = 'ow'; this.landmarkMeshes.push(m);
      }
      const big = makeTree(LANDMARKS[0].x, LANDMARKS[0].z, 4242, 7, 'autumn');
      const by = heightAt(LANDMARKS[0].x, LANDMARKS[0].z) - 0.3;
      for (const src of [big.wood, big.leaves]) { for (let i = 0; i < src.n; i++) src.pos[i * 3 + 1] += by; const m = this.R.addMesh(src, { chunk: 8 }); m.area = 'ow'; this.landmarkMeshes.push(m); }
      LANDMARKS[0].collider = { type: 'circle', x: LANDMARKS[0].x, z: LANDMARKS[0].z, r: 2.6 };
      this.fixedCols = LANDMARKS.flatMap(L => [L.collider, L.collider2].filter(Boolean)).concat([{ type: 'circle', x: OW_FIRE.x, z: OW_FIRE.z, r: 0.5 }]);
      // igreja do Profano, Vau do Moinho, casa de Elowen
      for (const fn of this.g.owExtras || []) { try { const c = await fn(this.atlas); if (c) this.fixedCols.push(...c); } catch (e) { console.error('ow extra', e); } await yieldF(); }
      // fogueira da chegada
      const fy = heightAt(OW_FIRE.x, OW_FIRE.z), fp = new PointSet(64);
      for (let i = 0; i < 9; i++) { const a = i * 0.7; fp.push([OW_FIRE.x + Math.cos(a) * 0.4, fy + 0.06, OW_FIRE.z + Math.sin(a) * 0.4], [0, 1, 0], [1, 0, 0], MAT.STONE, this.atlas.get('@'), 0, 0, 0.16, i); }
      for (let i = 0; i < 6; i++) fp.push([OW_FIRE.x + Math.cos(i) * 0.15, fy + 0.12, OW_FIRE.z + Math.sin(i) * 0.15], [0, 1, 0], [Math.cos(i), 0, Math.sin(i)], MAT.WOOD, this.atlas.get('='), 0, 0, 0.14, i + 20);
      const fm = this.R.addMesh(fp, { occlude: false }); fm.area = 'ow';
      this.fire = this.g.fx.addFire([OW_FIRE.x, fy + 0.15, OW_FIRE.z], 0.2, 110, 0.1); this.fire.area = 'ow';
      this.fireLight = { name: 'fogueira do reino', pos: [OW_FIRE.x, fy + 0.9, OW_FIRE.z], col: [1.0, 0.56, 0.24], radius: 8, base: 1.6, flicker: 0.3, area: 'ow', level: 1, value: 1.6 };
      this.g.lights.push(this.fireLight);
      // blocos em volta da chegada (sem pressa, mas antes de entrar)
      this.update(OW_SPAWN.x, OW_SPAWN.z, 1e9);
      while (this.queue.length || this.job) { this.update(OW_SPAWN.x, OW_SPAWN.z, 40); onProgress && onProgress(Math.min(0.99, (LANDMARKS.length + 1 - this.queue.length / 20) / (LANDMARKS.length + 2))); await yieldF(); }
      const it = genHorizon(OW_SPAWN.x, OW_SPAWN.z); let r; while (!(r = it.next()).done) { /* direto */ } this._setHorizon(r.value, OW_SPAWN.x, OW_SPAWN.z);
      this.ready = true;
    })();
    return this.building;
  }
  _setHorizon(h, x, z) {
    if (this.horizon) this.R.removeMesh(this.horizon);
    if (this.hSolid) this.R.removeSolid(this.hSolid);
    this.horizon = this.R.addMesh(h.ps, { occlude: false, chunk: 60 }); this.horizon.area = 'ow'; this.horizon.noLod = true; this.hAt = [x, z];
    this.hSolid = this.R.addSolid(h.solid, { chunk: 64, castShadow: false }); if (this.hSolid) this.hSolid.area = 'ow';
  }
  /** A cada quadro: gera alguns blocos novos, solta os que ficaram longe (orçamento em ms). */
  update(px, pz, budget = 4) {
    const t0 = performance.now();
    const ci = Math.floor((px - OWO.x) / TILE), cj = Math.floor((pz - OWO.z) / TILE);
    if (!this.job) {
      const want = [];
      for (let i = ci - 2; i <= ci + 2; i++) for (let j = cj - 2; j <= cj + 2; j++) {
        const k = i + ',' + j; if (this.tiles.has(k) || Math.abs(i) > HALF / TILE || Math.abs(j) > HALF / TILE) continue;
        const d = Math.hypot(i + 0.5 - (px - OWO.x) / TILE, j + 0.5 - (pz - OWO.z) / TILE);
        if (d < NEAR) want.push([d, i, j]);
      }
      want.sort((a, b) => a[0] - b[0]); this.queue = want;
      if (want.length) { const [, i, j] = want[0]; this.job = { i, j, it: genTile(this.W, i, j) }; }
    }
    while (this.job && performance.now() - t0 < budget) {
      const r = this.job.it.next();
      if (r.done) {
        const { ps, cols, ghouls } = r.value, mesh = this.R.addMesh(ps, { chunk: 8, occlude: false }); mesh.area = 'ow';
        this.tiles.set(this.job.i + ',' + this.job.j, { mesh, cols, ghouls });
        this.ghouls.push(...ghouls);
        this.job = null;
      }
    }
    // soltar blocos longe
    for (const [k, t] of this.tiles) { const [i, j] = k.split(',').map(Number); const d = Math.hypot(i + 0.5 - (px - OWO.x) / TILE, j + 0.5 - (pz - OWO.z) / TILE); if (d > FAR_UNLOAD) { this.R.removeMesh(t.mesh); this.tiles.delete(k); this.ghouls = this.ghouls.filter(g => !t.ghouls.includes(g)); } }
    this.cols = (this.fixedCols || []).concat(...[...this.tiles.values()].map(t => t.cols));
    // horizonte refeito aos poucos quando ele anda ~120 m
    if (this.ready && this.hAt && !this.hJob && Math.hypot(px - this.hAt[0], pz - this.hAt[1]) > 28) this.hJob = { it: genHorizon(px, pz), x: px, z: pz };
    if (this.hJob) { const r = this.hJob.it.next(); if (r.done) { this._setHorizon(r.value, this.hJob.x, this.hJob.z); this.hJob = null; } }
  }
}
export { biome, HALF as OW_HALF, WL as OW_WL };
