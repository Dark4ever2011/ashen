# ASHEN — Registro de progresso

Para continuar o desenvolvimento em outra sessão, leia este arquivo e o `README.md`.

## Versão 0.1.0 · Fase 1 — Motor Gráfico · concluída em 23/11/2026

### Decisões de arquitetura
- **Projeção 3/4 oblíqua** (câmera ao sul, olhando para baixo): `tela_y = mundo_y × 0,72 − z`. Paredes frontais e topos de muralha visíveis; casa bem com células retangulares de caracteres (o isométrico em losango deixaria paredes diagonais serrilhadas). `TILT` em `src/config.js`.
- **Células fixas 6×10 u** para personagens/objetos e 7,2×12 u para o chão. Cada glifo é encaixado na célula: fonte medida pelo `│`, escala horizontal para `─` emendar, compressão extra se uma fonte de fallback vier larga. Blocos (`█▀▄▌▐…`) e diagonais (`╱╲╳`) são desenhados como retângulos/traços exatos.
- **Largura dupla**: `charWidth()` segue as faixas East Asian Wide. Kanji ocupam 2 células, usam a pilha de fontes japonesas (serifada primeiro, estilo gravado).
- **Sombreamento de gravura**: dígitos 0–5 na arte viram hachuras `╱ ╳ ·` sobre fundos de material (aço, pedra). Lado espelhado usa sombreamento invertido (luz sempre da esquerda).
- **Esqueleto tipográfico** do cavaleiro: peças fixas presas a articulações; coxas, canelas e braços carimbados ao longo do osso; IK de 2 ossos no perfil; espada girada glifo a glifo; marcha procedural guiada por distância (sem deslizar). Quadros compostos vão para cache LRU (56).
- **Vista W não é espelho simples**: geometria espelhada, mas a espada (mão direita) passa para trás do corpo.
- **Capa** desenhada em faixas com molas (arrasto, vento, passo), separada do corpo.
- **Renderização**: chão em blocos pré-renderizados com sombras estáticas "assadas"; objetos em cache, ordenados por profundidade, com culling e transparência quando escondem o cavaleiro; luz em mapa de baixa resolução multiplicado (vinheta embutida); brilho aditivo; névoa em texturas tileáveis de glifos.
- **Streaming de sprites**: objetos são construídos perto da câmera e liberados longe dela.
- **Qualidade**: três presets que nunca simplificam armaduras/personagens/arquitetura. O jogo monitora FPS por janelas de 10 s e só *sugere* trocar.
- **Física** em passo fixo 60 Hz com interpolação; FPS limitado a 60 por padrão (tela de 120 Hz do A56).

### Arquivos criados
`index.html`, `manifest.json`, `service-worker.js`, `styles/main.css`, `.github/workflows/publicar.yml`,
`src/main.js`, `src/config.js`,
`src/engine/` typography, canvas, palette, sprite, renderer, camera, physics, input, animation, lighting, particles, atmosphere, perf,
`src/art/` knight, cape, props, architecture,
`src/entities/` knight-rig, player,
`src/world/` world, maps, objects, terrain,
`src/ui/` hud, menus, controls, settings, logo,
`src/systems/` save,
`assets/fonts/DejaVuSansMono.ttf` (+ licença), `assets/icons/` (3 PNG),
`tools/` sprite-viewer.html, viewer.js, viewer-props.js, glyph-test.html, make_icons.py,
`tests/` unit.mjs, play.mjs, desktop.mjs, offline.mjs, soak.mjs, perf.mjs, game.mjs, shot.mjs.

### Funcionalidades implementadas
- Canvas responsivo (DPR até 3, escala interna configurável, retrato/paisagem, aviso para girar).
- Motor tipográfico colorido com suporte japonês, profundidade, câmera 3/4 com suavização, antecipação, limites e enquadramento perto do portão.
- Cavaleiro de armadura completa (elmo com visor e brilho de brasa, aro de ouro partido, peitoral gravado com 誓, ombreiras em lâminas, escarcelas, joelheiras, grevas, sabatons, manoplas, capa vinho rasgada, montante). Vistas S/N/E/W. Respiração, caminhada, corrida (inclinação, passada longa), transição espada fincada ⇄ espada no ombro, movimento secundário (ombreiras e elmo atrasados), poeira nos passos, sombras de contato e projetadas.
- Cenário: Portão do Rei (torres, arco ogival com aduelas e pedra-chave 王, grade levadiça, friso 灰の王国·誓約, ameias e topos em 3/4, seteiras, hera, rachaduras, escombros), muralhas com brecha e contrafortes, fortaleza ao fundo, 23 árvores mortas com balanço, 20 rochas, cemitério com 14 lápides, colunata quebrada, braseiro, tochas, estandartes, cavaleiro caído.
- Fogo tipográfico animado (com 火 no núcleo), luzes oscilantes, brasas, faíscas ao acender, névoa em 2 camadas, cinzas caindo, névoa de distância, vinheta.
- Interações com narrativa ambiental (braseiro acende e salva; portão; 3 lápides; colunata; cavaleiro caído).
- Controles: joystick flutuante multitoque, correr, interagir (com estado visual), menu; teclado com teclas configuráveis; mouse (segurar para andar, clicar para andar/interagir). Bloqueio de zoom, toque duplo, rolagem, menu de contexto, "puxar para atualizar" e botão voltar.
- Menu: presets, resolução interna, limite de FPS, painel de desempenho, vibração, tamanho dos botões, teclas, voltar ao braseiro, apagar progresso.
- PWA: manifest, ícones, service worker com cache, funcionamento offline, tela de carregamento, salvamento local (configurações e progresso).

### Testes executados (todos aprovados)
Ambiente: Chrome headless (Playwright) com GPU emulada por software; emulação do Galaxy A56 (915×412 css, DPR 2,625, toque) e desktop 1600×900.
- `unit.mjs`: 221 verificações — larguras Unicode, glifo largo na grade, validade de toda a arte (materiais e larguras), geradores determinísticos, física (caixa, círculo, movimento rápido, limites), câmera, mapa.
- `glyph-test.html`: 120 glifos usados no jogo (12 kanji de largura dupla) medidos pixel a pixel em DPR 2,625 e 1 — nenhum vaza da célula, todos têm desenho. (Antes da correção, `╱ ╲ ╳` vazavam 2 px — corrigido.)
- `play.mjs` (toque real via CDP): joystick, corrida com 2 dedos simultâneos, foco e acendimento do braseiro, caixa de mensagem, chegada ao portão. (Encontrou e corrigiu: botão "continuar" ficava sob o botão de interagir.)
- `desktop.mjs`: WASD, Shift, clique para andar e interagir, segurar o mouse, Esc, troca de preset, reconfiguração de tecla (E→F), F3. (Corrigido: mensagem aparecia sobre o menu.)
- `offline.mjs`: service worker ativo, 39 arquivos em cache, recarregar sem rede funciona com a fonte embutida.
- `soak.mjs` 45 s: mapa inteiro, retrato⇄paisagem, troca de presets — sem erros; heap JS 8–15 MB; cache do cavaleiro limitado.
- Visual: capturas conferidas a cada etapa (título, cemitério, braseiro, portão, vistas do cavaleiro).

### Desempenho medido (referência relativa — GPU por software, não é o A56)
Emulação A56 a 2402×1082: lógica ≈ 0,2 ms/quadro. Otimizações aplicadas (sem reduzir arte): sombras estáticas assadas no chão (14,5 → 5,6 ms), silhueta do cavaleiro uma vez por quadro, vinheta embutida no mapa de luz e névoa de distância só na faixa de cima (14 → 5 ms), silhuetas por filtro (memória 22,8 → 1,7 MB), recorte de sprites e streaming (sprites 41,6 → 28,7 MB). FPS em software: 15 → 23–25 na ALTA; ~37 na DESEMPENHO.

### Pendente (precisa do aparelho)
- Medir FPS real, aquecimento e memória no Galaxy A56 / Chrome Android (painel de desempenho + `tools/glyph-test.html`).
- Conferir no aparelho: tela cheia + trava de paisagem, gesto voltar, vibração, instalação PWA.
- O artifact do Claude não permite service worker nem tela cheia; para testar PWA/offline use o GitHub Pages.

### Problemas conhecidos / ideias
- Diagonais (SE, SW, NE, NW) usam a vista de perfil; vistas 3/4 dedicadas entram na Fase 2.
- A fortaleza ao fundo só aparece quando a câmera enquadra o portão.
- Ataque, esquiva, bloqueio, parry e cura ainda não existem — os botões serão adicionados na Fase 3 (nenhum botão sem função agora).
- Sem áudio (Fase 7).

## Próxima etapa recomendada — Fase 2 (Protagonista)
1. Vistas diagonais dedicadas (SE/SW/NE/NW) no rig.
2. Esquiva (rolamento com quadros próprios e janela de invulnerabilidade configurável) e corrida com animação própria.
3. Poses de combate (guarda alta, preparação de golpe) reaproveitando a espada girada glifo a glifo.
4. Equipamento visual: slots trocáveis (elmo/peitoral/ombreiras/capa) com 2 conjuntos de armadura.
5. Colisão do cavaleiro com forma de cápsula e passos sobre superfícies diferentes (pedra, terra, grama).

## História (rascunho original)
O Reino das Cinzas — 灰の王国 — foi governado pelo Primeiro Rei, que selou a Chama sob juramento com a Ordem do Juramento (誓約). Quando o rei quebrou a palavra, o reino ardeu e nunca deixou de queimar; as cinzas caem até hoje. O protagonista desperta junto a um braseiro apagado, vestindo a armadura negra da Ordem com o ideograma 誓 gravado no peito, sem lembrar o próprio nome. Pistas espalhadas: um cavaleiro caído com armadura idêntica à sua; um túmulo real vazio, revolvido de dentro para fora; a inscrição no portão — «Só o último juramento abre o que o primeiro fechou». Regiões seguintes: Catedral Esquecida, Catacumbas do Silêncio, Fortaleza do Último Rei.

---

## Etapa A — Protótipo 3D tipográfico (23/11/2026)
Página separada: `prototipo3d.html` (o jogo original em `index.html` não foi alterado).

### Arquitetura
- **Geometria 3D invisível** por campos de distância (SDF): `src/proto3d/sdf.js`. Nunca é desenhada.
- **Distribuição orgânica** (`sampler.js`): varredura hierárquica + projeção na superfície + jitter + Poisson-disk → caracteres sem grade. Curvatura detecta arestas (traços `─ ═ ━` ao longo do vinco); "decals" põem caracteres fixos (誓, 王, rebites, olhos em brasa).
- **Renderizador WebGL2** (`renderer3d.js`), 4 passes: sombra do luar (a partir dos pontos), oclusão invisível (só profundidade), caracteres instanciados (iluminação por caractere: luar com sombra PCF, 3 luzes pontuais oscilantes, especular, névoa), partículas (fogo/brasas aditivos; névoa/fumaça/cinzas transparentes). O caractere muda com a luz (rampa por material), gira seguindo a superfície e vira contorno na silhueta. Culling por blocos espaciais.
- **Atlas** de caracteres gerado da própria fonte (`glyphs.js`), com proibição de blocos/quadrados.
- **Cavaleiro** (`knight3d.js`): 17 ossos, IK de pernas e braços, marcha procedural, respiração, guarda com as duas mãos ⇄ espada baixa ao andar; capa em tecido Verlet presa aos ombros, colidindo com o corpo.
- **Pátio** (`scene3d.js`): muralha com arco ogival, grade levadiça, ameias, contrafortes, friso 灰の王国, pedra-chave 王, tochas, coluna canelada quebrada, árvore morta, braseiro, lápides (墓, 眠), rochas, chão com cascalho e grama morta.
- **Câmera fixa 3/4** (yaw 15°, pitch 42°, FOV 32°) com acompanhamento suave e antecipação. Controles reaproveitados do jogo (`src/engine/input.js`).

### Números
~77 mil caracteres (pátio 68 mil, cavaleiro 8,1 mil, capa 624) + ~700 partículas; ~48–70 mil desenhados por quadro após culling. Construção: ~7,5 s no Chrome headless.

### Testes
Chrome headless (emulação A56, toque real via CDP): carrega sem erros, joystick move o cavaleiro, câmera acompanha, capturas parado/andando/perto do portão. FPS medido aqui é de GPU por software (2–4 FPS) e NÃO representa o aparelho — medir no A56 com o painel "FPS".

### Pendências / riscos
- FPS real no A56 desconhecido; tempo de construção no celular provavelmente 2–3× maior (cache dos pontos em IndexedDB é a próxima otimização).
- Luzes pontuais sem sombra própria (só o luar projeta sombra).
- Ombreiras em perfil ainda parecem "bolas"; a estrutura de lâminas precisa de mais definição.

### Etapa A — Refinamento visual (vento, luz, ambiente vivo)
- Vegetação procedural (veg3d.js): ~890 tufos de 3–5 lâminas + ~90 plantas, densidade por ruído, 4 tons.
- Vento no shader: rajadas que viajam pelo terreno + tremor individual (fases distintas), direção/força variando no tempo; o cavaleiro afasta a grama ao passar.
- Glifo da lâmina escolhido pelo ângulo na tela (| / \ ╱ ╲ ~ ' ` ´).
- Árvore balança (flag 16) proporcional à altura.
- Luz → tipografia: rampas invertidas (sombra = glifos densos, luz = leves), transparência maior na sombra, brilhos metálicos ✦ ✶ * + no aço/ouro, grama translúcida.
- Partículas iluminadas pelas luzes; cinzas com velocidades por tamanho e corrente quente sobre o fogo; névoa ondulando e respirando; poeira rasteira com o vento.
- Braseiro: chama com 3 frequências + estalos.
- Orçamento: ~83 mil caracteres (antes ~77 mil); chão de terra mais esparso para compensar.

### Etapa A — Protagonista refeito a partir da folha de referência
- Elmo fechado de viseira (quilha central, fenda única, sobrancelha saliente, respiros ∴, bevor), sem coroa.
- Couraça de aço enegrecido com gravações de bronze em veios orgânicos, plackart em lâminas e brasão do leão (獅) em escudo de ouro.
- Ombreiras de 4 lâminas com rebites; manto vinho amassado na nuca caindo sobre o ombro direito.
- Cintos de couro cruzados com fivelas, cota de malha na cintura e atrás das coxas, escarcelas de 4 lâminas.
- Manoplas de punho largo, joelheiras com aleta, grevas com quilha, sabatons pontudos em 5 lâminas.
- Espada longa: guarda de braços curvos com remates, chapa central, punho de couro, pomo em roda.
- Tecido: classe Cloth genérica — capa larga e longa com tiras rasgadas e furos + tabardo frontal que os joelhos empurram; normais por nó (mais barato por quadro).
- Pose parada como na referência: espada baixa na mão direita, ponta perto do chão.
- Orçamento: cavaleiro ~11,7 mil + tecidos ~1,2 mil; total ~87 mil.

### Etapa A — Realismo humano e armadura 3D
Diagnóstico: membros eram tubos (sem panturrilha, pulso, juntas), mãos em bloco; sem oclusão entre placas;
luz só do luar e das chamas com o mesmo brilho em todo material; ruído de ±0,45 nível por caractere apagava
o degradê; rampa do aço com letras (M W @ 8) lia como texto; pose parada rígida, sem ataque.
- Oclusão ambiente pré-calculada por caractere (SDF das peças do mesmo osso, 5 amostras ao longo da normal),
  empacotada no float de tamanho (flag 64) — zero custo por quadro.
- Shader: brilho por material (expoente), reflexo do céu/chão nos metais (Fresnel), luz lateral de recorte fria,
  AO na luz ambiente/direta/especular, arestas gastas mais claras, sombra de contato no chão, menos ruído e
  caracteres mais opacos nos modelos com AO; estrelas de reflexo só da luz direta.
- Aço em hachura de gravura (@ % # ≡ = ≈ - ·) alinhada às superfícies.
- Anatomia: bíceps, antebraço afinando, pulso, panturrilha, tornozelo; malha na axila, cotovelo e joelho;
  correias de couro; placa dorsal; manoplas com dorso, palma de couro, 4 dedos em 3 falanges + polegar
  (mão direita fechada no punho da espada); arranhões, amassados; inscrição 最後の誓 no peitoral.
- Movimento: transferência de peso (contrapposto) com joelho solto, respiração nos ombros, cabeça olhando,
  marcha com peso e braço atrasado; golpe diagonal (botão ⚔ / J / espaço) com torção, passo e equilíbrio.
- Orçamento: cavaleiro ~13,6 mil caracteres; total ~89 mil.

### Etapa A — Protagonista em escala humana real + densidade por zoom
Decisões do usuário: humano real médio · caracteres imóveis quando parado · zoom com pinça · noite ·
densidade conforme o zoom · chão: grama densa/alta, variedade, rastro · prioridade: elmo, peitoral e ombreiras.
Referências: antropometria (homem médio ~1,74 m; ombro 1,42 m; quadril 0,92 m; ombros 41,5 cm entre
articulações / 51 cm bideltoide; quadril 34 cm; mão 19 cm) e ombreiras históricas (~24 × 20 cm).
- Proporções: coxa 45 cm, canela 43 cm, braço 31 cm, antebraço 26,5 cm; tronco e pescoço mais curtos;
  escala global 0,955 → ~1,78 m com elmo. Ombreiras históricas (4 lâminas + aba junto ao pescoço).
- Elmo fechado como na imagem: viseira em proa com quilha, sobrancelha saliente, fenda dos olhos,
  respiros em fendas, bevor em lâminas, rosetas nos pinos, crista baixa.
- Densidade por zoom: cavaleiro amostrado fino (~22 mil) e ordenado em níveis encaixados (lodOrder);
  de perto desenha tudo, de longe só os primeiros N com caracteres maiores (~9 mil na distância padrão).
- Zoom com pinça (dois dedos) e roda do mouse; câmera mais baixa de perto, mais alta de longe.
- Caracteres só mudam com movimento: o caractere é escolhido pela luz média estável (a chama muda só o
  brilho); velocidade por osso (linear + angular) faz cintilar/arrastar caracteres quando o corpo se move.
- Chão: tufos mais altos e densos, folhas secas, pedrinhas, cardos e flores murchas; pegadas que deitam a
  grama e ela levanta devagar (8 últimas pegadas).
