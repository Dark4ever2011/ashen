// ASHEN 3D — Jogar no Reino Partido: entrar, descansar na fogueira, os mortos errantes, renascer.

import { m4, v3 } from './math3d.js';
import { flatBones } from './renderer3d.js';
import { COMBO, swordSegment } from './knight3d.js';
import { hurtPlayer, DMG_TABLE } from './gameplay.js';
import { OpenWorld, heightAt, blockedAt, OW_SPAWN, OW_FIRE, LANDMARKS, SITES } from './ow.js';
import { pushFlower } from './veg3d.js';
import { registerHit } from './bleed.js';
import { initProfano, profanoStep, profanoRender, profanoFocus, profanoInteract, profanoRespawn, churchParts, CHURCH_COLLIDERS } from './profano.js';
import { initDarkMoon, darkMoonStep, darkMoonRender, darkMoonRespawn } from './darkmoon.js';
import { initFV, fvStep, fvRender, fvFocus, fvInteract, ELOWEN_REST } from './farvillage.js';
import { itemInfo } from './items.js';
import { buildParts } from './sampler.js';

const I = m4.ident();
const snd = (g, n, k) => g.audio && g.audio.play(n, k);
const sm = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };
const POOL = 6;

export function initOW(g, sets, atlas) {
  g.ow = new OpenWorld(g, atlas, pushFlower);
  g.owPool = [...Array(POOL)].map(() => { const m = g.R.addMesh(sets.ghoul); m.area = 'ow'; m.visible = false; return m; });
  g.gobPool = [...Array(POOL)].map(() => { const m = g.R.addMesh(sets.goblin); m.area = 'ow'; m.visible = false; return m; });
  initProfano(g, sets, atlas); initDarkMoon(g, sets); initFV(g, sets, atlas);
  (g.owExtras = g.owExtras || []).unshift(async (at) => { const set = await buildParts(churchParts(), at, { seed: 1200, sizeMul: 2.2 }); const m = g.R.addMesh(set, { chunk: 8 }); m.area = 'ow'; return CHURCH_COLLIDERS; });
  const PLACES = [{ n: 'Igreja do Profano', ...SITES.church }, { n: 'Vau do Moinho', ...SITES.village }, { n: 'Casa de Elowen', ...SITES.her }, { n: 'Mausoléu da Cripta', ...SITES.crypt }, ...LANDMARKS.map(L => ({ n: L.name, x: L.x, z: L.z }))];
  g.owWhere = () => { const p = g.player; let b = null, bd = 1e9; for (const q of PLACES) { const d = Math.hypot(p.x - q.x, p.z - q.z); if (d < bd) { bd = d; b = q; } } return bd < 90 ? b.n : 'as terras sem rei'; };
  g.buildOpenWorld = (onProgress) => g.ow.build(onProgress).then(() => { g.owReady = true; });
  g.enterOpenWorld = (keepPos) => {
    const p = g.player;
    g.setArea('ow'); g.heightAt = heightAt;
    if (!keepPos) { Object.assign(p, { x: OW_SPAWN.x, z: OW_SPAWN.z, yaw: Math.PI, dead: 1, wake: 1, sitting: false }); }
    g.cam.x = p.x; g.cam.z = p.z; g.teleported();
    g.lastSafe = { x: p.x, z: p.z };
    if (!keepPos) { g.lastRest = 'ow'; g.save(); }
    setTimeout(() => { const L = document.getElementById('loading'); if (!L || L.classList.contains('hidden')) g.hud.showRegion({ region: 'III · O Reino Partido', title: 'As Terras Sem Rei', subtitle: '割れた王国' }); }, 600);
  };
}

export function owColliders(g) { return g.area === 'ow' && g.ow ? [g.ow.cols, { x0: -1e9, z0: -1e9, x1: 1e9, z1: 1e9 }] : null; }

export function owStep(g, dt) {
  if (g.area !== 'ow' || !g.ow) return;
  const p = g.player;
  // a água funda e as bordas do mundo seguram o cavaleiro
  if (blockedAt(p.x, p.z)) { if (g.lastSafe) { p.x = g.lastSafe.x; p.z = g.lastSafe.z; p.y = heightAt(p.x, p.z); } }
  else g.lastSafe = { x: p.x, z: p.z };
  g.ow.update(p.x, p.z, g.cinema.active ? 2 : 4);
  // lugares gigantes: o nome aparece quando chega perto
  for (const L of LANDMARKS) if (!L.seen && Math.hypot(p.x - L.x, p.z - L.z) < 60) { L.seen = true; g.hud.showRegion({ region: 'III · O Reino Partido', title: L.name, subtitle: '' }); }
  // mortos errantes
  const list = g.ow.ghouls.filter(gh => gh.state !== 'dead' && Math.hypot(gh.x - p.x, gh.z - p.z) < 45);
  if (p.atk >= 0 && g.knightBones) {
    const C = COMBO[p.combo];
    if (p.atk > C.hit[0] - 0.03 && p.atk < C.hit[1] + 0.04) {
      const [a, b] = swordSegment(g.knightBones);
      for (const gh of list) {
        if (!gh.alive || p.hitSet.has(gh.id)) continue;
        for (const k of [0.3, 0.6, 0.95]) { const q = v3.lerp(a, b, k); if (Math.hypot(q[0] - gh.x, q[2] - gh.z) < 0.5 && (!gh.goblin || q[1] < (gh.y || 0) + 1.3)) {
          p.hitSet.add(gh.id); const crit = p.riposte > 0 ? 3 : 1; p.riposte = 0; g.critHit = crit > 1;
          if (gh.damage(DMG_TABLE[p.combo] * crit * g.dmgMul())) g.addGold(gh.goblin ? 16 + Math.random() * 18 : 10 + Math.random() * 12); registerHit(g, gh); snd(g, crit > 1 ? 'crit' : 'hit'); g.fx.sparks(q, 12, [0.85, 0.8, 0.7]); break;
        } }
      }
    }
  }
  for (const gh of list) {
    const ev = gh.update(dt * g.diffK.speed, p, p.dead <= 0 && !g.cinema.active, 9);
    gh.y = heightAt(gh.x, gh.z);
    for (const e of ev) { if (e.type === 'hit') hurtPlayer(g, e.dmg, e.from, gh); else if (e.type === 'swing') snd(g, 'claw', 0.7); }
    for (const e of ev) if (e.type === 'cackle') snd(g, 'goblin', 0.8);
    const rr = gh.goblin ? 0.48 : 0.62;
    if (gh.alive) { const dx = p.x - gh.x, dz = p.z - gh.z, d = Math.hypot(dx, dz); if (d < rr && d > 1e-4) { p.x = gh.x + dx / d * rr; p.z = gh.z + dz / d * rr; } }
  }
  profanoStep(g, dt); darkMoonStep(g, dt); fvStep(g, dt);
}

export function owRender(g) {
  if (g.prof) { profanoRender(g); darkMoonRender(g); fvRender(g); }
  if (g.area !== 'ow' || !g.ow) { if (g.owPool) for (const m of [...g.owPool, ...g.gobPool]) m.visible = false; return; }
  const p = g.player;
  // um passe só, listas reaproveitadas (zeradas a cada quadro), só quem está a menos de 40 m
  const gob = g._gobN || (g._gobN = []), gho = g._ghoN || (g._ghoN = []); gob.length = 0; gho.length = 0;
  for (const gh of g.ow.ghouls) { if (gh.state === 'dead') continue; const dx = gh.x - p.x, dz = gh.z - p.z, d2 = dx * dx + dz * dz; if (d2 > 1600) continue; gh._d2 = d2; (gh.goblin ? gob : gho).push(gh); }
  gob.sort(byD2); gho.sort(byD2);
  drawPool(g.gobPool, gob, p);
  drawPool(g.owPool, gho, p);
}
const byD2 = (a, b) => a._d2 - b._d2;
function drawPool(pool, near, p) {
  pool.forEach((m, i) => {
    const gh = near[i];
    m.visible = !!gh && Math.hypot(gh.x - p.x, gh.z - p.z) < 40;
    if (!m.visible) return;
    const W = gh.matrix(), b = gh.pose().map(x => m4.mul(W, x)); b[0] = I;
    m.boneData = flatBones(b, m.boneData); m.drawCount = Math.round(m.n * (1 - sm((gh.dead - 0.45) / 0.55)));
  });
}

export function owFocus(p, g) {
  if (g.area !== 'ow') return null;
  const o = profanoFocus(p, g) || fvFocus(p, g); if (o) return o;
  const d = Math.hypot(p.x - OW_FIRE.x, p.z - OW_FIRE.z);
  return d < 1.6 ? { id: 'ow:fire', title: 'Fogueira do Reino Partido', prompt: 'descansar na fogueira', text: 'Uma fogueira acesa por mãos que você não viu. A Rainha passou por aqui?', x: OW_FIRE.x, z: OW_FIRE.z, d } : null;
}
export function owInteract(g, it) {
  if (profanoInteract(g, it, itemInfo) || fvInteract(g, it)) return true;
  if (it.id !== 'ow:fire') return false;
  g.restAt('ow'); g.hud.message(it.text, it.title, it); g.save(); g.hud.toast('Você descansa: vida e frascos renovados. Progresso salvo.');
  for (const gh of g.ow.ghouls) if (gh.state !== 'dead') gh.reset();
  return true;
}
/** Renascer no Reino Partido (ou no palácio). */
export function owRespawn(g) {
  profanoRespawn(g); darkMoonRespawn(g);
  const pts = { ow: { x: OW_FIRE.x - 0.9, z: OW_FIRE.z + 1.2 }, owchurch: g.profRewardAt && { x: g.profRewardAt.x - 1.2, z: g.profRewardAt.z + 1.1 }, elowen: ELOWEN_REST };
  const at = pts[g.lastRest];
  if (at && g.owReady) { g.setArea('ow'); g.heightAt = heightAt; for (const gh of g.ow.ghouls) if (gh.state !== 'dead') gh.reset(); return at; }
  return null;
}
