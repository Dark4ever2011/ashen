// ASHEN — Arte de objetos do cenário (procedural + desenhada à mão)
// Todos retornam { art, anchor:[col,row] } — âncora = ponto que toca o chão.

import { TypoGrid, parseArt } from '../engine/sprite.js';
import { matColor as M, resolveShade, mixHex } from '../engine/palette.js';
import { rng, noise1 } from '../engine/animation.js';

const CW = 6, CH = 10; // proporção da célula (para traçar ângulos corretos)

// ─────────────── Árvore morta ───────────────
const WOOD = { dark: '#2b231d', mid: '#54473a', lit: '#867764', pale: '#a69882', moss: '#46512f' };
const BRANCH_GLYPHS = (ang) => {
  // ang: ângulo a partir da vertical (rad), positivo = para a direita
  const a = Math.abs(ang);
  if (a < 0.3) return ['│', '┃', '¦'];
  if (a < 1.0) return ang > 0 ? ['╱', '/', '╱'] : ['╲', '\\', '╲'];
  return ['─', '━', '⌐'];
};

export function makeDeadTree(seed = 1, size = 1) {
  const R = rng(seed * 977 + 13);
  const W = Math.round(46 * size), H = Math.round(50 * size);
  const g = new TypoGrid(W, H);
  const cx = W / 2;
  const base = H - 2;
  const trunkH = Math.round((17 + R() * 7) * size);
  const lean = (R() - 0.5) * 0.45;
  let topX = cx, topY = base - trunkH;
  // Tronco grosso com casca gravada (lado esquerdo iluminado pelo luar)
  for (let i = 0; i <= trunkH; i++) {
    const y = base - i;
    const t = i / trunkH;
    const off = Math.sin(i * 0.17 + seed) * 1.1 + lean * i * 0.35;
    const half = (3.4 - t * 2.0) * size + (i < 3 ? (3 - i) * 0.8 : 0);
    const x0 = Math.round(cx + off - half), x1 = Math.round(cx + off + half);
    for (let x = x0; x <= x1; x++) {
      const u = (x - x0) / Math.max(1, x1 - x0);
      let ch, fg, bg;
      if (x === x0) { ch = '▐'; fg = WOOD.lit; bg = null; }
      else if (x === x1) { ch = '▌'; fg = WOOD.dark; bg = null; }
      else {
        const r = R();
        ch = r < 0.4 ? '│' : r < 0.6 ? '║' : r < 0.72 ? '¦' : r < 0.78 ? '◦' : r < 0.84 ? 'ǀ' : ' ';
        fg = u < 0.4 ? WOOD.pale : u < 0.7 ? WOOD.lit : WOOD.mid;
        bg = u < 0.35 ? WOOD.mid : WOOD.dark;
        if (t < 0.35 && R() < 0.2) { ch = R() < 0.5 ? '▒' : '·'; fg = WOOD.moss; }
      }
      g.set(x, y, ch, fg, bg);
    }
    if (i === trunkH) { topX = cx + off; topY = y; }
  }
  // Raízes
  for (const dir of [-1, 1]) {
    const n = 2 + Math.floor(R() * 3);
    for (let k = 0; k < n; k++) {
      const x = Math.round(cx + dir * (3.6 * size + k));
      g.set(x, base + (k > 0 ? 1 : 0), k === n - 1 ? (dir < 0 ? '◢' : '◣') : '▄', k === 0 ? WOOD.lit : WOOD.mid, null);
    }
    g.set(Math.round(cx + dir * (4.2 * size)), base + 1, dir < 0 ? '╰' : '╯', WOOD.mid);
  }
  // Galhos recursivos: os primeiros níveis são grossos (2 células com fundo)
  const branch = (x, y, ang, len, depth) => {
    const thick = depth <= 1;
    const steps = Math.ceil(len * 2.4);
    let px = x, py = y;
    const dx = Math.sin(ang) * CH / CW, dy = -Math.cos(ang);
    const norm = Math.hypot(dx, dy);
    const opts = BRANCH_GLYPHS(ang);
    const fg = depth === 0 ? WOOD.pale : depth <= 2 ? WOOD.lit : WOOD.pale;
    for (let s = 0; s < steps; s++) {
      px += dx / norm * 0.5; py += dy / norm * 0.5;
      px += (noise1(s * 0.3 + seed + depth, depth) - 0.5) * 0.22;
      const gx = Math.round(px), gy = Math.round(py);
      if (!g.inside(gx, gy)) break;
      if (thick) {
        g.set(gx, gy, opts[0], fg, WOOD.mid);
        const ox = Math.abs(ang) < 1 ? 1 : 0, oy = Math.abs(ang) < 1 ? 0 : 1;
        if (g.isEmpty(gx + ox, gy + oy)) g.set(gx + ox, gy + oy, opts[1], WOOD.mid, WOOD.dark);
      } else if (g.isEmpty(gx, gy)) g.set(gx, gy, opts[(s + depth) % 3], fg);
    }
    if (depth >= 5 || len < 2) {
      const tx = Math.round(px), ty = Math.round(py) - 1;
      if (g.isEmpty(tx, ty) && g.isEmpty(tx + 1, ty) && R() < 0.4) g.set(tx, ty, R() < 0.5 ? '丫' : '个', WOOD.pale);
      else if (g.isEmpty(tx, ty)) g.set(tx, ty, ['⸌', '`', 'ˎ', '‚', '\''][Math.floor(R() * 5)], WOOD.pale);
      return;
    }
    const n = depth < 3 ? 2 + (R() < 0.45 ? 1 : 0) : 2;
    for (let i = 0; i < n; i++) {
      const spread = (i - (n - 1) / 2) * (0.6 + R() * 0.35) + (R() - 0.5) * 0.3;
      branch(px, py, ang * 0.6 + spread, len * (0.6 + R() * 0.16), depth + 1);
    }
  };
  branch(topX, topY + 1, lean - 0.1, 8 * size, 0);
  branch(topX - 1, topY + 4, -0.95 - R() * 0.3, 7 * size, 1);
  branch(topX + 1, topY + 6, 0.85 + R() * 0.4, 6.5 * size, 1);
  if (R() < 0.7) branch(topX, topY + 9, (R() < 0.5 ? -1 : 1) * 1.2, 5 * size, 2);
  return { art: g.toArt(), anchor: [cx, H - 1], trunk: 3.4 * size * CW };
}

// ─────────────── Rocha ───────────────
export function makeRock(seed = 1, w = 12, h = 7) {
  const R = rng(seed * 31 + 7);
  const g = new TypoGrid(w, h + 1);
  const cx = w / 2, cy = h / 2 + 0.6;
  const L = [-0.55, -0.62, 0.55];
  const bumps = Array.from({ length: 6 }, () => 0.85 + R() * 0.3);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const nx = (x + 0.5 - cx) / (w / 2), ny = (y + 0.5 - cy) / (h / 2);
    const ang = Math.atan2(ny, nx);
    const rad = bumps[Math.floor(((ang + Math.PI) / (Math.PI * 2)) * 6) % 6];
    const d = Math.hypot(nx, ny * (ny > 0 ? 1.25 : 1)) / rad;
    if (d > 1) continue;
    const nz = Math.sqrt(Math.max(0, 1 - d * d));
    let lv = -(nx * L[0] + ny * L[1]) * 0.9 + nz * L[2];
    let level = lv > 0.62 ? 1 : lv > 0.42 ? 2 : lv > 0.22 ? 3 : lv > 0.02 ? 4 : 5;
    if (y >= h - 1) level = Math.max(level, 4);
    const sh = resolveShade('stone', level, x, y);
    let ch = sh.ch, fg = M(sh.fg), bg = M(sh.bg);
    // Borda: meio-bloco para recortar a silhueta
    if (d > 0.86) {
      if (ny < -0.5) { ch = '▄'; fg = bg; bg = null; }
      else if (nx < -0.6) { ch = '▐'; fg = bg; bg = null; }
      else if (nx > 0.6) { ch = '▌'; fg = bg; bg = null; }
    }
    if (bg && R() < 0.07) { ch = R() < 0.5 ? '╱' : '╲'; fg = M('1'); }
    if (bg && ny < -0.2 && R() < 0.22) { ch = R() < 0.5 ? '·' : '▒'; fg = M('M'); }
    g.set(x, y, ch, fg, bg);
  }
  return { art: g.toArt(), anchor: [cx, h], radius: w * CW * 0.42 };
}

// ─────────────── Lápides (à mão) ───────────────
const st = (name, rows, extra = {}) => parseArt({ name, fg: '5', bg: '3', g: rows.map(r => r[0]), m: rows.map(r => r[1] || ''), b: rows.map(r => r[2] || ''), ...extra });

export const GRAVES = [
  st('lapide-arco', [
    [' ▄▆█▆▄ ', ' 6776  '],
    ['▟▀▀▀▀▀▙', '7666655'],
    ['▐ 墓  ▌', '6 77  4', ' 3333 '],
    ['▐╶──╴ ▌', '65555 4', ' 3333 '],
    ['▐ ╱· ·▌', '6 25 54', ' 3333 '],
    ['▐▁▁▁▁▁▌', '6444444', ' 2222 '],
    ['▀▀▀▀▀▀▀', '3322221'],
  ]),
  st('lapide-cruz', [
    ['  ▄█▄  ', '  676  '],
    ['▄▄▟┼▙▄▄', '6667655'],
    ['▀▀▜ ▛▀▀', '555 444', '   3   '],
    ['  ▐▒▌  ', '  645  '],
    ['  ▐▒▌  ', '  645  '],
    [' ▄▟▒▙▄ ', ' 56454 '],
    ['▀▀▀▀▀▀▀', '3322221'],
  ]),
  st('lapide-quebrada', [
    ['  ▗▄   ', '  66   '],
    [' ▟▀ ▙▖ ', ' 76 55 '],
    ['▐ 眠 ▒▌', '6 77 44', ' 33333 '],
    ['▐╱ ·  ▌', '62 5  4', ' 33333 '],
    ['▐▁▁▁▁▁▌', '6444444', ' 22222 '],
    ['▀▀▀▀▀▀▀', '3322221'],
  ]),
  st('lapide-rei', [
    [' ▗▄▄▄▖ ', ' 66665 '],
    ['▟▀王▀▀▙', '76GG665', ' 33333 '],
    ['▐ ┼┼┼ ▌', '6 555 4', ' 33333 '],
    ['▐ 誓  ▌', '6 gg  4', ' 33333 '],
    ['▐▁▁▁▁▁▌', '6444444', ' 22222 '],
    ['▀▀▀▀▀▀▀', '3322221'],
  ]),
];

// ─────────────── Pilar quebrado (procedural) ───────────────
export function makePillar(seed = 1, height = 26) {
  const R = rng(seed * 101 + 3);
  const W = 9, H = height + 4;
  const g = new TypoGrid(W, H);
  const top = 4 + Math.floor(R() * 6);
  // Base (plinto)
  for (let x = 0; x < W; x++) {
    const sh = resolveShade('stone', x < 3 ? 2 : x < 6 ? 3 : 4, x, H - 1);
    g.set(x, H - 1, '▀', M(sh.bg), M('2'));
    g.set(x, H - 2, x === 0 ? '▐' : x === W - 1 ? '▌' : '▄', M(x < 4 ? '6' : '4'), x === 0 || x === W - 1 ? null : M('3'));
  }
  // Fuste canelado
  for (let y = top; y < H - 2; y++) {
    for (let x = 1; x < W - 1; x++) {
      const u = (x - 1) / (W - 3);
      const level = u < 0.25 ? 1 : u < 0.5 ? 2 : u < 0.75 ? 3 : 4;
      const sh = resolveShade('stone', level, x, y);
      const flute = x % 2 === 0;
      g.set(x, y, flute ? '│' : sh.ch, flute ? M(level < 3 ? '7' : '3') : M(sh.fg), M(sh.bg));
    }
    if (R() < 0.08) g.set(1 + Math.floor(R() * (W - 2)), y, R() < 0.5 ? '╱' : '╲', M('1'));
  }
  // Topo quebrado irregular
  for (let x = 1; x < W - 1; x++) {
    const cut = top - Math.floor(noise1(x * 0.8, seed) * 3);
    for (let y = cut; y < top; y++) g.set(x, y, y === cut ? (R() < 0.5 ? '▗' : '▖') : '█', M(x < 4 ? '6' : '4'), y === cut ? null : M('3'));
  }
  // Musgo
  for (let i = 0; i < 6; i++) g.set(1 + Math.floor(R() * (W - 2)), top + Math.floor(R() * 4), R() < 0.5 ? '▒' : '·', M('M'));
  return { art: g.toArt(), anchor: [W / 2, H - 1], radius: 22 };
}

// ─────────────── Braseiro (à mão) ───────────────
export const BRAZIER = parseArt({
  name: 'braseiro', fg: 'I', bg: 'i',
  g: [
    '▄▄▄▄▄▄▄▄▄▄▄▄▄',
    '█▓▒░╳*╳*╳░▒▓█',
    '▜█▓▓▒▒▒▒▒▓▓█▛',
    ' ▜▄▄▄▄▄▄▄▄▄▛ ',
    '    ▐█▓▓▌    ',
    '    ▐█▓▓▌    ',
    '   ▟██▓▓█▙   ',
    '  ╱ ▐█▓▓▌ ╲  ',
    ' ╱  ▐█▓▓▌  ╲ ',
    '▟▄▄▄▟██▓█▙▄▄▙',
    '▐33333333333▌',
    '▀▀▀▀▀▀▀▀▀▀▀▀▀',
  ],
  m: [
    'JJJJJJJIIIIii',
    'JJIItftftIIii',
    'JJJIIIIIiiiii',
    ' JJIIIIIiiii ',
    '    JJIi     ',
    '    JJIi     ',
    '   JJJIiii   ',
    '  J JJIi i   ',
    ' J  JJIi  i  ',
    'JJJJJJJIiiiii',
    '6           4',
    '3332222221111',
  ],
  b: ['', '  ffffffff   ', '', '', '', '', '', '', '', '', ' 33333333333 ', ''],
  style: 'stone',
});

// ─────────────── Tocha de parede (à mão) ───────────────
export const TORCH = parseArt({
  name: 'tocha', fg: 'I', bg: 'i',
  g: ['▄▄▄▄▄', '▜▓▒▓▛', ' ▜█▛ ', '  ║  ', '══╝  '],
  m: ['JJIIi', 'JftfI', ' JIi ', '  I  ', 'JII  '],
});

// ─────────────── Estandarte rasgado (procedural) ───────────────
export function makeBanner(seed = 1, w = 9, h = 20, emblem = '誓') {
  const R = rng(seed * 17 + 5);
  const g = new TypoGrid(w + 2, h + 1);
  // Haste
  for (let x = 0; x < w + 2; x++) g.set(x, 0, x === 0 ? '╺' : x === w + 1 ? '╸' : '━', M(x % 3 ? 'I' : 'J'));
  const len = [];
  for (let x = 0; x < w; x++) len[x] = h - Math.floor((noise1(x * 0.9, seed) * 0.6 + R() * 0.4) * 6);
  const cx = w / 2;
  for (let y = 1; y <= h; y++) for (let x = 0; x < w; x++) {
    if (y >= len[x]) continue;
    const fold = Math.cos((x + 0.5) / w * Math.PI * 3 + seed) * 0.5 + 0.5;
    const shade = fold * 0.7 + (1 - x / w) * 0.3;
    let ch = shade > 0.62 ? '▓' : shade > 0.38 ? '▒' : '░';
    let fg = shade > 0.62 ? M('C') : M('c');
    let bg = M('v');
    if (x === 0) { ch = '▐'; fg = M('C'); bg = null; }
    else if (x === w - 1) { ch = '▌'; fg = M('c'); bg = null; }
    if (y === len[x] - 1 && y > 3) { ch = R() < 0.5 ? '▘' : '▝'; fg = M('c'); bg = null; }
    if (y === 2 || y === 3) { if (x > 0 && x < w - 1) { ch = y === 2 ? '═' : '╌'; fg = M(y === 2 ? 'G' : 'g'); } }
    g.set(x + 1, y, ch, fg, bg);
  }
  // Emblema: coroa partida + juramento
  const ey = 6, ex = Math.round(cx);
  g.set(ex - 1, ey, '╦', M('G'), M('v'));
  g.set(ex + 1, ey, '╦', M('G'), M('v'));
  g.set(ex, ey, '╩', M('g'), M('v'));
  g.set(ex, ey + 2, emblem, M('G'), M('v'));
  g.setBg(ex + 1, ey + 2, M('v'));
  g.set(ex, ey + 4, '▾', M('g'), M('v'));
  return { art: g.toArt(), anchor: [(w + 2) / 2, 0] };
}

// ─────────────── Cavaleiro caído (à mão) — encosta na muralha ───────────────
export const FALLEN = parseArt({
  name: 'cavaleiro-caido', fg: 'k', bg: 'n', style: 'steel',
  g: [
    '   ▄██▄      ',
    '  ▟123▙      ',
    '  ▐━·━▌▄▄    ',
    ' ▄▟1223▙▄▖   ',
    '▐11╲誓╱344▌  ',
    '▐1122334▌╲╲  ',
    ' ▜▀▀▀▀▀▛  ╲╲▄',
    ' ▐223▄▄▄▄▄▄▄▟',
    ' ▀▀▀▀▀▀▀▀▀▀▀ ',
  ],
  m: [
    '   kssk      ',
    '  K   k      ',
    '  kn5nk33    ',
    ' KK    kk    ',
    'K  tGGt   k  ',
    'K       kbb  ',
    ' kzzszzk  bbB',
    ' K   kkkkkkkk',
    ' zszzzzzzzzz ',
  ],
});

/** Cor de terra/cinzas com variação (usado pelo terreno e decalques). */
export function dirtColor(v) { return mixHex('#16141a', '#2a241f', v); }
