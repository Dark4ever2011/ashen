// ASHEN — Configurações gráficas e de controle (versão 3D)
// Os presets nunca simplificam o cavaleiro nem a arquitetura: mudam a resolução de tela,
// a densidade de efeitos (cinzas, chuva, névoa) e o alcance da sombra.

export const PRESETS = {
  EXTREMO: { label: 'Extremo', desc: 'O máximo: chão 3x mais denso perto do cavaleiro, sombra suave e longa, luz mais fiel, longe mais detalhado. Pesado.', dpr: 3.0, fx: 1.35, shadow: 13, shadowEvery: 1, lodNear: 9, lodMin: 0.4, far: 70, ring: true, pcf: 2, solidQ: 2, dens: 1, cell: 5, grass: 2.4, shadowMap: 4096, strokes: 2.0, reflEvery: 1, adpr: 2.2, worldCell: 0.135, grassBudget: 110000, shEvery: 2 },
  ALTA: { label: 'Alta', desc: 'Resolução máxima, todos os efeitos, sombra longa.', dpr: 2.4, fx: 1, shadow: 11, shadowEvery: 1, lodNear: 5, lodMin: 0.2, far: 52, solidQ: 2, dens: 0.9, cell: 5.5, grass: 1.7, shadowMap: 2048, strokes: 1.6, reflEvery: 1, adpr: 1.8, worldCell: 0.15, grassBudget: 80000, shEvery: 3 },
  EQUILIBRADA: { label: 'Equilibrada', desc: 'Mesmo estilo; resolução um pouco menor, sombra atualizada a cada 2 quadros.', dpr: 1.9, fx: 0.8, shadow: 9, shadowEvery: 2, lodNear: 4.5, lodMin: 0.16, far: 46, solidQ: 1, dens: 0.75, cell: 6, grass: 1.3, shadowMap: 2048, strokes: 1.3, reflEvery: 2, adpr: 1.4, worldCell: 0.165, grassBudget: 55000, shEvery: 4 },
  DESEMPENHO: { label: 'Desempenho', desc: 'Cavaleiro e arquitetura intactos; menos partículas, resolução menor, longe mais leve.', dpr: 1.45, fx: 0.55, shadow: 7, shadowEvery: 3, lodNear: 3.8, lodMin: 0.12, far: 40, solidQ: 0, dens: 0.42, cell: 7.5, grass: 1, shadowMap: 1024, strokes: 1.0, reflEvery: 3, adpr: 1.05, worldCell: 0.2, grassBudget: 35000, shEvery: 6 },
};

export const WEATHER_MODES = [['auto', 'Automático'], ['limpo', 'Limpo'], ['garoa', 'Garoa'], ['chuva', 'Chuva'], ['tempestade', 'Tempestade']];

export const DEFAULT_SETTINGS = {
  preset: 'EQUILIBRADA',
  fpsCap: 60,          // 30 | 60 | 0 (sem limite)
  showPerf: false,
  haptics: true,
  controlScale: 1,
  bindings: null,
  weather: 'auto',
  sound: true,
  volume: 0.8,
  narration: true,
  autoQ: 'on',         // ajuste automático de qualidade (baixa o preset sozinho se o FPS cair)
  engine: 'ascii',     // 'ascii' (padrão: ASCII artístico sobre preto) | 'classico' (reserva)
};

export function effective(settings) { return PRESETS[settings.preset] || PRESETS.ALTA; }
