// ASHEN 3D — Sangramento (classe Samurai): os três cortes do combo no mesmo inimigo abrem a ferida.
// O inimigo perde vida aos poucos, pinga sangue e deixa uma poça que cresce no chão e seca devagar.
// Com a Coroa do Ogro, dois cortes bastam e a ferida sangra 50% mais.

import { PointSet } from './sampler.js';
import { MAT } from './glyphs.js';

const POOLS = 10, PTS = 900;

export function initBleed(g, atlas) {
  g.bleeds = [];
  g.pools = [...Array(POOLS)].map(() => {
    const ps = new PointSet(PTS);
    for (let i = 0; i < PTS; i++) ps.push([0, -50, 0], [0, 1, 0], [1, 0, 0], MAT.BLOOD, atlas.get(['%', '&', '§', '~', '≈'][i % 5]), 0, 0, 0.06, i);
    const m = g.R.addMesh(ps, { dynamic: true, occlude: false }); m.drawCount = 0; m.visible = false;
    return { ps, m, t: 99, x: 0, z: 0, y: 0, r: 0, area: null };
  });
  g.poolNext = 0;
}

/** Chamar a cada golpe que acerta. enemy precisa de x, z, (y) e damage(n). */
/** Clarão do impacto nos caracteres (0..1), ~0,28 s depois do golpe que acertou. */
export const hitFlash = (g, e) => (e && e._flashT != null ? Math.max(0, 1 - (g.t - e._flashT) / 0.28) : 0);
export function registerHit(g, e) {
  if (e) e._flashT = g.t;
  // peso do impacto: micro-pausa + tremor (golpe final do combo e crítico pesam mais)
  const p0 = g.player, crit = g.critHit, heavy = p0.combo === 2;
  g.hitstop = Math.max(g.hitstop || 0, crit ? 0.11 : heavy ? 0.075 : 0.045);
  g.shake = Math.max(g.shake || 0, crit ? 0.16 : heavy ? 0.09 : 0.04);
  if (crit) { g.hud.flash && g.hud.flash('crit'); g.critHit = false; }
  if (g.cls !== 'samurai') return;
  const p = g.player, c = p.combo, need = g.crownOn ? 2 : 3;
  if (c === 0 || e._bChain !== p.chain) { e._bChain = p.chain; e._bCount = 0; }
  if (e._bCount === c) { e._bCount = c + 1; if (!e._bleedApplied && g.hud.pips) g.hud.pips(Math.min(e._bCount, need), need); }
  if (e._bCount >= need && !e._bleedApplied) {
    e._bleedApplied = true;
    const old = g.bleeds.find(b => b.e === e);
    const T = g.inv && g.inv.sword ? 14 : 7;
    if (old) old.t = T; else g.bleeds.push({ e, t: T, drip: 0, pool: newPool(g, e) });
    g.hud.toast('Sangramento!', 1100); g.audio && g.audio.play('crit', 0.7);
  }
  if (c === 0) e._bleedApplied = false;
}
function newPool(g, e) {
  const P = g.pools[g.poolNext++ % POOLS];
  Object.assign(P, { t: 0, x: e.x, z: e.z, y: (e.y || 0) + 0.012, r: 0.15, area: g.area, follow: e });
  P.m.area = g.area; P.m.visible = true;
  return P;
}

export function bleedStep(g, dt) {
  if (!g.bleeds) return;
  const dps = 7 * (g.crownOn ? 1.5 : 1) * (g.diffK ? g.diffK.dealt : 1);
  for (const b of g.bleeds) {
    b.t -= dt;
    const alive = b.e.state !== 'dead' && b.e.state !== 'dying' && b.e.hp > 0;
    if (alive) b.e.damage(dps * dt);
    b.drip -= dt;
    if (b.drip <= 0 && alive) { b.drip = 0.12; g.fx.sparks([b.e.x + (Math.random() - 0.5) * 0.4, (b.e.y || 0) + 0.8 + Math.random() * 0.6, b.e.z + (Math.random() - 0.5) * 0.4], 2, [0.6, 0.02, 0.02]); }
    // a poça segue o ferido enquanto ele anda, e cresce
    if (b.pool && alive) { const P = b.pool, d = Math.hypot(b.e.x - P.x, b.e.z - P.z); if (d > 1.2) b.pool = newPool(g, b.e); else P.r = Math.min(1.1, P.r + dt * 0.12); }
  }
  g.bleeds = g.bleeds.filter(b => b.t > 0 && b.e.state !== 'dead');
  for (const P of g.pools) {
    if (!P.m.visible) continue;
    P.t += dt;
    if (P.t > 40) { P.m.visible = false; continue; }
    if (P.t - (P.last || -1) < 0.25 && P.t > 1) continue;
    P.last = P.t;
    // pontos espalhados num disco irregular; somem aos poucos depois de 25 s
    const ps = P.ps, n = Math.round(PTS * Math.min(1, P.r / 1.1) * (P.t > 25 ? Math.max(0, 1 - (P.t - 25) / 15) : 1));
    ps.n = 0;
    for (let i = 0; i < PTS; i++) {
      const a = i * 2.39996, rr = Math.sqrt((i + 0.5) / PTS) * P.r * (0.75 + 0.25 * Math.sin(a * 3 + i * 0.01));
      const y = g.heightAt && g.area === 'ow' ? g.heightAt(P.x + Math.cos(a) * rr, P.z + Math.sin(a) * rr) + 0.015 : P.y;
      ps.push([P.x + Math.cos(a) * rr, y, P.z + Math.sin(a) * rr], [0, 1, 0], [Math.cos(a), 0, Math.sin(a)], MAT.BLOOD, ps.attr ? ps.attr[i * 4 + 1] : -1, 0, 0, 0.07, i);
      if (ps.n >= PTS) break;
    }
    P.m.drawCount = n;
    g.R.updateMesh(P.m, ps);
  }
}
