// ASHEN — Rig tipográfico do cavaleiro
// Esqueleto em células (origem = pés, y negativo = para cima). Peças de armadura são artes
// fixas presas às articulações; coxas, canelas e braços são "carimbados" ao longo do osso;
// a espada gira glifo a glifo. Cada quadro composto vai para um cache LRU.
// A capa é desenhada à parte, em faixas, com molas (reage à velocidade, ao vento e ao passo).

import { S as ART_S, N as ART_N, E as ART_E, SWORD } from '../art/knight.js';
import { makeCape } from '../art/cape.js';
import { parseArt, paintArt, paintArtRotated, composeParts, SpriteCache } from '../engine/sprite.js';
import { makeCanvas } from '../engine/canvas.js';
import { Spring, lerp, ease } from '../engine/animation.js';

// Cada peça é lida duas vezes: normal e com sombreamento invertido (para o lado espelhado,
// mantendo a luz vindo da esquerda).
const parseSet = set => {
  const o = {};
  for (const k in set) { o[k] = parseArt(set[k]); o[k].inv = parseArt({ ...set[k], invert: true }); }
  return o;
};

const HIP_Y = -14.4, ANKLE_Y = -3.0;
const THIGH = 5.9, SHIN = 5.5;      // linhas
const UPPER = 3.3, FORE = 3.2;
const FRAMES = { walk: 16, idle: 12 };

const mix = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t)];

/** IK de 2 ossos em espaço de pixels (células não são quadradas). bend = +1/-1 lado do joelho. */
function ik(hip, ankle, l1, l2, bend, cw, ch) {
  const hx = hip[0] * cw, hy = hip[1] * ch, ax = ankle[0] * cw, ay = ankle[1] * ch;
  const L1 = l1 * ch, L2 = l2 * ch;
  let dx = ax - hx, dy = ay - hy;
  let d = Math.hypot(dx, dy);
  const max = (L1 + L2) * 0.999;
  if (d > max) { dx *= max / d; dy *= max / d; d = max; }
  const a = (L1 * L1 - L2 * L2 + d * d) / (2 * d);
  const h = Math.sqrt(Math.max(0, L1 * L1 - a * a));
  const ux = dx / d, uy = dy / d;
  const px = hx + ux * a, py = hy + uy * a;
  // perpendicular: (-uy, ux) aponta para +x quando o osso desce
  const kx = px + -uy * h * bend, ky = py + ux * h * bend;
  return [kx / cw, ky / ch];
}

export class KnightRig {
  constructor() {
    this.arts = { S: parseSet(ART_S), N: parseSet(ART_N), E: parseSet(ART_E) };
    this.sword = parseArt(SWORD);
    this.capeArts = {
      S: makeCape({ w: 18, h: 17, top: 5, bottom: 9, folds: 4, seed: 3, lining: true, tear: 3, holes: 1 }),
      N: makeCape({ w: 18, h: 18, top: 5.5, bottom: 9, folds: 4.5, seed: 9, emblem: '誓', emblemRow: 4, tear: 3, holes: 0 }),
      E: makeCape({ w: 10, h: 17, top: 2.8, bottom: 4.6, folds: 2, seed: 5, tear: 2, holes: 0, light: 0.6 }),
    };
    this.cache = new SpriteCache(56);
    this.capeCanvas = {};
    this.capeVersion = -1;
    this.capeSprings = Array.from({ length: 18 }, (_, i) => new Spring(70 - i * 2.6, 7 + i * 0.12));
    this.capeLift = new Spring(40, 8);
    this.equipKey = 'aco-negro';
    this.stats = { builds: 0, glyphs: 0 };
  }

  /** Pose contínua → posições das articulações (em células). */
  pose(view, st) {
    const side = view === 'W' ? -1 : 1;
    const isSide = view === 'E' || view === 'W';
    const b = ease.smooth(st.blend);          // 0 = parado, 1 = andando
    const run = st.run || 0;
    const ph = st.phase;
    const breath = Math.sin(st.breath * Math.PI * 2) * (1 - b);
    const bobAmt = lerp(0.32, 0.6, run) * b;
    const bob = -bobAmt * Math.abs(Math.sin(ph * Math.PI * 2));
    const bobLag = -bobAmt * Math.abs(Math.sin((ph - 0.04) * Math.PI * 2));
    const sx = isSide ? 0 : 0.24 * Math.sin(ph * Math.PI * 2) * b;
    const lean = isSide ? side * run * 0.9 * b : 0;
    const lift = lerp(1.3, 2.3, run) * b;
    const half = lerp(3.6, 5.2, run) * b;
    const legs = [];
    for (const k of [0, 1]) {
      const p = (ph + k * 0.5) % 1;
      const swing = p < 0.5, q = swing ? p / 0.5 : (p - 0.5) / 0.5;
      const depth = (swing ? -Math.cos(q * Math.PI) : Math.cos(q * Math.PI));
      const lv = swing ? Math.sin(q * Math.PI) * lift : 0;
      legs.push({ depth: depth * b, lift: lv });
    }
    const J = { side, isSide, bob, bobLag, sx, lean, breath, legs, run, b };
    const hipY = HIP_Y + bob * 0.95;
    if (!isSide) {
      const dz = view === 'S' ? 0.38 : -0.38;
      J.hip = [[-2.6 + sx, hipY], [2.6 + sx, hipY]];
      J.ankle = legs.map((l, i) => [(i ? 2.6 : -2.6) + sx * 0.3, ANKLE_Y - l.lift * 0.72 + l.depth * dz]);
      J.knee = legs.map((l, i) => [lerp(J.hip[i][0], J.ankle[i][0], 0.5) + (i ? 0.12 : -0.12) * l.lift,
        lerp(hipY, J.ankle[i][1], THIGH / (THIGH + SHIN)) - l.lift * 0.42 + l.depth * dz * 0.4]);
    } else {
      const hx = lean * 0.35;
      J.hip = [[hx - side * 0.15, hipY], [hx + side * 0.15, hipY]];
      J.ankle = legs.map((l, i) => [J.hip[i][0] + side * l.depth * half, ANKLE_Y - l.lift]);
      J.knee = legs.map((l, i) => ik(J.hip[i], J.ankle[i], THIGH, SHIN, side, 6, 10));
    }
    // Tronco, cabeça, ombros
    const by = bob, bp = bobLag * 1.12 - breath * 0.2, bh = bobLag * 1.06 - breath * 0.15, bt = by - breath * 0.12;
    J.torso = [sx + lean * 0.6, -24 + bt];
    J.helm = [sx * 1.1 + lean * 1.0, -24.2 + bh];
    J.pauldron = isSide ? [lean * 0.7 - side * 0.3, -21.8 + bp] : [6.8 + sx, -21.6 + bp];
    const sw = Math.sin(ph * Math.PI * 2) * b;
    const swingAmp = lerp(1, 1.6, run);
    // Braços: mãos e cotovelos, interpolados entre "espada fincada" (parado) e "espada no ombro" (andando).
    if (!isSide) {
      const s = view === 'S' ? 1 : -1; // em N o braço da espada fica à direita da tela
      const shR = [-6.4 * s + sx, -20.9 + bp], shL = [6.4 * s + sx, -20.9 + bp];
      const idleHandR = [-1.1 * s + sx * 0.3, -13.8 + bt * 0.3], idleHandL = [1.1 * s + sx * 0.3, -13.8 + bt * 0.3];
      const idleElR = [-5.7 * s + sx * 0.6, -16.4 + bp * 0.6], idleElL = [5.7 * s + sx * 0.6, -16.4 + bp * 0.6];
      const walkHandR = [-5.0 * s + sx, -18.4 + bp], walkElR = [-7.7 * s + sx, -17.1 + bp];
      const walkHandL = [7.0 * s + sx + sw * 0.2, -13.9 + bp * 0.5 + sw * 0.5 * swingAmp], walkElL = [7.4 * s + sx, -17.0 + bp * 0.8 + sw * 0.15];
      J.arms = [
        { sh: shR, el: mix(idleElR, walkElR, b), hand: mix(idleHandR, walkHandR, b), sword: true },
        { sh: shL, el: mix(idleElL, walkElL, b), hand: mix(idleHandL, walkHandL, b) },
      ];
      const idlePiv = [sx * 0.3, -13.8 + bt * 0.3];
      J.swordPivot = mix(idlePiv, J.arms[0].hand, b);
      J.swordAngle = lerp(0, s * 2.78, b);
      J.swordSy = lerp(0.6, 0.92, b) - 0.45 * Math.sin(Math.PI * b); // gira "pela profundidade" na transição
    } else {
      const sh = [lean * 0.7 + side * 0.3, -20.7 + bp];
      const shFar = [lean * 0.7 - side * 0.4, -20.5 + bp];
      const idleHand = [side * 2.7 + lean, -13.7 + bt * 0.3];
      const idleEl = [side * 1.2 + lean, -16.7 + bp * 0.5];
      const walkHand = [side * 2.1 + lean, -18.9 + bp], walkEl = [side * 1.9 + lean, -16.9 + bp];
      const farHand = [lean * 0.8 + side * sw * 1.9 * swingAmp, -14.0 + bp * 0.5 - Math.abs(sw) * 0.3];
      const farEl = [lean * 0.7 + side * sw * 0.9 * swingAmp - side * 0.2, -17.1 + bp];
      // Braço da espada é o direito. Em E ele está perto da câmera; em W, longe.
      J.arms = [
        { sh, el: mix(idleEl, walkEl, b), hand: mix(idleHand, walkHand, b), sword: true },
        { sh: shFar, el: mix([idleEl[0] - side * 0.4, idleEl[1]], farEl, b), hand: mix([idleHand[0] - side * 0.2, idleHand[1]], farHand, b) },
      ];
      J.swordPivot = mix([idleHand[0], idleHand[1] + 0.1], J.arms[0].hand, b);
      J.swordAngle = lerp(-side * 0.04, side * 2.72, b);
      J.swordSy = lerp(0.78, 0.95, b) - 0.4 * Math.sin(Math.PI * b);
    }
    J.cape = isSide ? [-side * 3.0 + lean * 0.4, -23.3 + bp] : [sx, -23.2 + bp];
    return J;
  }

  /** Lista de operações de desenho (com caixas para calcular limites justos). */
  _ops(view, J) {
    const A = this.arts[view === 'W' ? 'E' : view];
    const ops = [];
    const mirrorSide = view === 'W';
    const art = (a, cx, cy, ax, ay, opt = {}) => {
      const m = opt.mirror ?? mirrorSide;
      const x = m ? cx - (a.w - ax) : cx - ax;
      ops.push({ k: 'art', a: m && a.inv && !mirrorSide ? a.inv : a, x, y: cy - ay, m, tone: (opt.tone ?? 1) * (mirrorSide ? 0.94 : 1) });
    };
    const seg = (row, p, q, tone = 1, m = mirrorSide) => ops.push({ k: 'seg', a: row, p, q, tone, m, noInv: mirrorSide });
    const sword = (tone = 1) => ops.push({ k: 'sword', p: J.swordPivot, ang: J.swordAngle, sy: J.swordSy, tone });
    const leg = (i, tone = 1) => {
      seg(A.thighRow, J.hip[i], J.knee[i], tone);
      seg(A.shinRow, J.knee[i], J.ankle[i], tone);
      art(A.knee, J.knee[i][0], J.knee[i][1], A.knee.w / 2, 1, { tone });
      art(A.boot, J.ankle[i][0], J.ankle[i][1], J.isSide ? 2 : A.boot.w / 2, 0.2, { tone });
    };
    const arm = (a, tone = 1, withHand = true) => {
      seg(A.armRow, a.sh, a.el, tone);
      seg(A.armRow, a.el, a.hand, tone);
      art(A.couter, a.el[0], a.el[1], A.couter.w / 2, 0.5, { tone });
      if (withHand) art(A.gauntlet, a.hand[0], a.hand[1], A.gauntlet.w / 2, 1, { tone });
    };
    const tassets = () => {
      if (!J.isSide) {
        const ty = J.torso[1] + 8.6;
        art(A.tasset, J.torso[0] - 2.5, ty - J.legs[0].lift * 0.22, 2.5, 0, { mirror: false });
        art(A.tasset, J.torso[0] + 2.5, ty - J.legs[1].lift * 0.22, 2.5, 0, { mirror: true });
      } else {
        art(A.tasset, J.torso[0] + J.side * 0.4, J.torso[1] + 8.6 - Math.max(J.legs[0].lift, J.legs[1].lift) * 0.15, 2.5, 0);
      }
    };
    const torso = () => art(A.torso, J.torso[0], J.torso[1], A.torso.w / 2, 0);
    const helm = () => art(A.helm, J.helm[0], J.helm[1], A.helm.w / 2, 5);
    const pauldrons = () => {
      if (!J.isSide) {
        art(A.pauldron, -J.pauldron[0] + J.sx * 2, J.pauldron[1], 5, 2, { mirror: false });
        art(A.pauldron, J.pauldron[0], J.pauldron[1], 5, 2, { mirror: true });
      } else art(A.pauldron, J.pauldron[0], J.pauldron[1], 4.5, 2.2);
    };
    const [swordArm, freeArm] = J.arms;
    const under = ops, over = [];
    if (view === 'S') {
      leg(0); leg(1); tassets(); torso(); arm(freeArm, 1, false); arm(swordArm, 1, false); pauldrons(); helm();
      sword();
      art(A.gauntlet, swordArm.hand[0], swordArm.hand[1], 2, 1);
      art(A.gauntlet, freeArm.hand[0], freeArm.hand[1], 2, 1, { mirror: true });
      return { under, over: null, split: false };
    }
    if (view === 'N') {
      if (J.b < 0.5) sword(0.8);
      arm(swordArm, 0.85); arm(freeArm, 0.85);
      leg(0); leg(1); tassets(); torso();
      const o = over; const push = ops.length;
      // Camadas por cima da capa
      pauldrons(); helm();
      if (J.b >= 0.5) sword();
      const tail = ops.splice(push);
      o.push(...tail);
      return { under, over: o, split: true };
    }
    // Perfil
    const far = 0.58;
    const nearSword = view === 'E';
    if (nearSword) {
      arm(freeArm, far); leg(1, far);
      leg(0); tassets(); torso(); helm(); pauldrons();
      arm(swordArm, 1, false); sword(); art(A.gauntlet, swordArm.hand[0], swordArm.hand[1], A.gauntlet.w / 2, 1);
    } else {
      sword(far); arm(swordArm, far); leg(0, far);
      leg(1); tassets(); torso(); helm(); arm(freeArm, 1); pauldrons();
    }
    return { under, over: null, split: false };
  }

  _bounds(ops, cw, ch) {
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    const add = (x, y) => { if (x < x0) x0 = x; if (y < y0) y0 = y; if (x > x1) x1 = x; if (y > y1) y1 = y; };
    for (const o of ops) {
      if (o.k === 'art') { add(o.x, o.y); add(o.x + o.a.w, o.y + o.a.h); }
      else if (o.k === 'seg') { const hw = o.a.w / 2 + 0.5; for (const p of [o.p, o.q]) { add(p[0] - hw, p[1] - 1); add(p[0] + hw, p[1] + 1); } }
      else {
        const s = this.sword, [pc, pr] = SWORD.pivot;
        const c = Math.cos(o.ang), sn = Math.sin(o.ang);
        for (const [u, v] of [[-pc, -pr], [s.w - pc, -pr], [-pc, s.h - pr], [s.w - pc, s.h - pr]]) {
          const px = u * cw, py = v * ch * o.sy;
          add(o.p[0] + (px * c - py * sn) / cw, o.p[1] + (px * sn + py * c) / ch);
        }
      }
    }
    return { x0: x0 - 0.6, y0: y0 - 0.6, x1: x1 + 0.6, y1: y1 + 0.6 };
  }

  _compose(painter, ops) {
    const cw = painter.cw, ch = painter.ch;
    const bounds = this._bounds(ops, cw, ch);
    const parts = ops.map(o => {
      if (o.k === 'art') return { art: o.a, x: o.x, y: o.y, mirror: o.m, tone: o.tone };
      if (o.k === 'seg') return { draw: (ctx, toPx, p) => this._stampSeg(ctx, toPx, p, o) };
      return { draw: (ctx, toPx, p) => { const [x, y] = toPx(o.p[0], o.p[1]); paintArtRotated(ctx, p, this.sword, x, y, SWORD.pivot[0], SWORD.pivot[1], o.ang, { sy: o.sy, tone: o.tone }); return this.sword.cells.length; } };
    });
    const res = composeParts(painter, parts, bounds);
    this.stats.builds++; this.stats.glyphs += res.glyphs;
    return res;
  }

  _stampSeg(ctx, toPx, painter, o) {
    const cw = painter.cw, ch = painter.ch;
    const dxp = (o.q[0] - o.p[0]) * cw, dyp = (o.q[1] - o.p[1]) * ch;
    const len = Math.hypot(dxp, dyp);
    const n = Math.max(1, Math.ceil(len / (ch * 0.95)));
    let g = 0;
    for (let i = 0; i <= n; i++) {
      const t = i / n;
      const x = lerp(o.p[0], o.q[0], t) - o.a.w / 2, y = lerp(o.p[1], o.q[1], t) - 0.5;
      const [px, py] = toPx(x, y);
      g += paintArt(ctx, painter, o.m && o.a.inv && !o.noInv ? o.a.inv : o.a, px, py, { mirror: o.m, tone: o.tone });
    }
    return g;
  }

  /** Quadro composto (com cache). st: {view, blend, phase, breath, run} */
  frame(painter, version, st) {
    this.cache.sync(version);
    const moving = st.blend > 0.001;
    const bq = Math.round(st.blend * 4) / 4;
    const runq = Math.round((st.run || 0) * 2) / 2;
    let key, fst;
    if (bq >= 1) {
      const f = Math.floor(st.phase * FRAMES.walk) % FRAMES.walk;
      key = `${st.view}|w|${runq}|${f}`;
      fst = { blend: 1, phase: f / FRAMES.walk, breath: 0, run: runq };
    } else if (!moving || bq <= 0) {
      const f = Math.floor(st.breath * FRAMES.idle) % FRAMES.idle;
      key = `${st.view}|i|${f}`;
      fst = { blend: 0, phase: 0, breath: f / FRAMES.idle, run: 0 };
    } else {
      const f = Math.floor(st.phase * 8) % 8;
      key = `${st.view}|t${bq}|${f}`;
      fst = { blend: bq, phase: f / 8, breath: st.breath, run: runq };
    }
    key += '|' + this.equipKey;
    return this.cache.get(key, () => {
      const J = this.pose(st.view, fst);
      const ops = this._ops(st.view, J);
      const out = this._compose(painter, ops.under);
      if (ops.split && ops.over.length) {
        // A camada de cima usa a mesma âncora para alinhar.
        const o2 = this._compose(painter, ops.over);
        out.over = o2;
      }
      out.J = J;
      return out;
    });
  }

  // ───────────── Capa ─────────────
  _capeSprites(painter, version) {
    if (this.capeVersion === version) return this.capeCanvas;
    this.capeVersion = version;
    const mk = (art, mirror) => {
      const cw = painter.cw, ch = painter.ch;
      const c = makeCanvas(art.w * cw + 4, art.h * ch + 4);
      paintArt(c.getContext('2d'), painter, art, 2, 2, { mirror });
      return { canvas: c, w: art.w, h: art.h, pad: 2 };
    };
    this.capeCanvas = { S: mk(this.capeArts.S), N: mk(this.capeArts.N), E: mk(this.capeArts.E), W: mk(this.capeArts.E, true) };
    return this.capeCanvas;
  }

  /** Atualiza as molas da capa. vx em u/s (tela), facing view, speedNorm 0..1 */
  updateCape(dt, view, vxScreen, speedNorm, phase, t, wind) {
    const isSide = view === 'E' || view === 'W';
    const side = view === 'W' ? -1 : 1;
    const n = this.capeSprings.length;
    for (let i = 0; i < n; i++) {
      const f = i / (n - 1);
      const w = Math.pow(f, 1.35);
      let target = -vxScreen * 0.016 * w;                                    // arrasto
      target += Math.sin(t * 1.7 + f * 2.2) * 0.22 * w * (0.5 + wind);      // vento
      if (isSide) target += -side * speedNorm * 2.2 * w;                     // esvoaça para trás
      else target += Math.sin(phase * Math.PI * 4 - f * 2.4) * 0.5 * speedNorm * w; // balanço do passo
      this.capeSprings[i].update(target, dt);
    }
    this.capeLift.update(speedNorm * (isSide ? 1 : 0.45), dt);
  }

  /** Desenha a capa em faixas. (bx,by) = pés em pixels; J = pose do quadro atual. */
  drawCape(ctx, painter, version, view, bx, by, J, tone = 1) {
    const sprites = this._capeSprites(painter, version);
    const sp = sprites[view];
    const cw = painter.cw, ch = painter.ch;
    const ax = J.cape[0], ay = J.cape[1];
    const left = bx + (ax - sp.w / 2) * cw - sp.pad;
    const top = by + ay * ch;
    const lift = this.capeLift.x;
    const n = sp.h;
    const sprs = this.capeSprings;
    let y = top;
    for (let i = 0; i < n; i++) {
      const f = i / (n - 1);
      const off = sprs[Math.min(sprs.length - 1, Math.round(f * (sprs.length - 1)))].x;
      const rowH = ch * (1 - lift * 0.28 * f);
      const sy = sp.pad + i * ch;
      ctx.drawImage(sp.canvas, 0, Math.floor(sy), sp.canvas.width, Math.ceil(ch) + 1,
        Math.round(left + off * cw), Math.round(y), sp.canvas.width, Math.ceil(rowH) + 1);
      y += rowH;
    }
    void tone;
  }
}
