// ASHEN 3D — Objetos de mão e do mapa: tocha, escudo, caixotes, destroços e itens no chão.
// Todos são nuvens de caracteres presas ao "osso 1" do próprio objeto: o jogo move cada um
// com uma matriz (a tocha segue o punho, o escudo o antebraço, os caixotes ficam no chão).

import * as S from './sdf.js';
import { MAT } from './glyphs.js';
import { noise3, rng } from './math3d.js';

const P1 = 1;   // osso do objeto

/** Tocha: cabo de madeira com faixas de couro e cesto de ferro (a chama é partícula + luz). */
export function torchParts() {
  const shaft = S.roundCone([0, -0.32, 0], [0, 0.28, 0], 0.022, 0.026);
  const basket = S.union(S.xf(S.torus(0.045, 0.008), [0, 0.3, 0]), S.xf(S.torus(0.05, 0.008), [0, 0.38, 0]),
    ...[0, 1, 2, 3].map(i => { const a = i * 1.571; return S.capsule([Math.cos(a) * 0.04, 0.28, Math.sin(a) * 0.04], [Math.cos(a) * 0.052, 0.4, Math.sin(a) * 0.052], 0.006); }));
  const rag = S.xf(S.ellipsoid(0.042, 0.06, 0.042), [0, 0.36, 0]);
  return [
    { name: 'tocha', bone: P1, f: shaft, min: [-0.04, -0.34, -0.04], max: [0.04, 0.3, 0.04], mat: MAT.WOOD, spacing: 0.011, flow: [0, 1, 0],
      detail: (p) => (Math.abs(p[1] + 0.05) < 0.03 || Math.abs(p[1] - 0.18) < 0.02 ? { mat: MAT.LEATHER } : null) },
    { name: 'cesto', bone: P1, f: basket, min: [-0.07, 0.26, -0.07], max: [0.07, 0.42, 0.07], mat: MAT.IRON, spacing: 0.008, flow: [1, 0, 0] },
    { name: 'pano em brasa', bone: P1, f: rag, min: [-0.05, 0.29, -0.05], max: [0.05, 0.43, 0.05], mat: MAT.EMBER, spacing: 0.01, flow: [0, 1, 0], pointFlags: 2 },
  ];
}

/** Escudo de cavaleiro (heater): aço enegrecido, aro de bronze, umbo e o 誓 gravado. Frente = +z. */
export function shieldParts() {
  const outline = (x, y) => { const w = 0.27 * Math.min(1, (y + 0.36) / 0.32) ** 0.6; return Math.max(Math.abs(x) - w, y - 0.26, -0.36 - y); };
  const curve = (x, y, z) => z - 0.04 * (1 - (x / 0.28) ** 2);
  const plate = (x, y, z) => Math.max(outline(x, y), Math.abs(curve(x, y, z)) - 0.012);
  const rim = (x, y, z) => Math.max(Math.abs(outline(x, y) + 0.012) - 0.013, Math.abs(curve(x, y, z) - 0.006) - 0.016);
  const boss = S.xf(S.ellipsoid(0.055, 0.055, 0.03), [0, -0.02, 0.05]);
  const straps = S.union(S.xf(S.box(0.16, 0.018, 0.008), [0, 0.06, 0.005]), S.xf(S.box(0.16, 0.018, 0.008), [0, -0.14, 0.005]));
  return [
    { name: 'escudo', bone: P1, f: S.union(plate, boss), min: [-0.3, -0.38, -0.04], max: [0.3, 0.28, 0.1], mat: MAT.STEEL, spacing: 0.012, flow: [0, 1, 0],
      detail: (p, n, c) => {
        if (c > 0.35) return { mat: MAT.BRONZE };
        if (n[2] > 0.3 && Math.abs(noise3(p[0] * 40, p[1] * 40, 5) - 0.5) < 0.03) return { mat: MAT.BRONZE, size: 0.8 };
        if (n[2] < -0.3) return { mat: MAT.LEATHER };
        return null;
      },
      decals: [{ p: [0, 0.1, 0.06], n: [0, 0, 1], glyph: '誓', mat: MAT.GOLD, size: 0.13, clear: 0.07 }] },
    { name: 'aro', bone: P1, f: rim, min: [-0.31, -0.39, -0.03], max: [0.31, 0.29, 0.08], mat: MAT.BRONZE, spacing: 0.01, flow: [1, 0, 0] },
    { name: 'alças', bone: P1, f: straps, min: [-0.18, -0.17, -0.01], max: [0.18, 0.09, 0.02], mat: MAT.LEATHER, spacing: 0.01, flow: [1, 0, 0], keep: (p, n) => n[2] < 0 },
  ];
}

/** Caixote de tábuas com cantoneiras de ferro (0,9 × 0,7 × 0,7 m). */
export function crateParts() {
  const body = S.xf(S.box(0.42, 0.33, 0.33, 0.02), [0, 0.33, 0]);
  return [{ name: 'caixote', bone: P1, f: body, min: [-0.46, -0.02, -0.37], max: [0.46, 0.7, 0.37], mat: MAT.WOOD, spacing: 0.03, flow: [1, 0, 0],
    detail: (p, n, c) => {
      if (c > 0.3) return { mat: MAT.IRON };
      const ax = Math.abs(n[1]) > 0.7 ? p[2] : p[1];
      if (((ax + 1) % 0.14) < 0.016) return { mat: MAT.DARK, glyph: '─' };          // vãos entre as tábuas
      if (Math.abs(n[2]) > 0.7 && Math.abs(Math.abs(p[0]) - Math.abs(p[1] - 0.33) * 1.27) < 0.025) return { mat: MAT.WOOD, glyph: '╲' };   // travessa em X
      return null;
    } }];
}

/** Destroços: pilha de pedras, vigas quebradas e tábuas. */
export function debrisParts(seed = 3) {
  const R = rng(seed);
  const stones = Array.from({ length: 6 }, () => { const a = R() * 6.28, r = R() * 0.35; return S.xf(S.ellipsoid(0.16 + R() * 0.1, 0.1 + R() * 0.08, 0.14 + R() * 0.1), [Math.cos(a) * r, 0.08, Math.sin(a) * r], [R(), R() * 3, R()]); });
  const beams = [S.xf(S.box(0.45, 0.05, 0.06, 0.01), [0.05, 0.22, 0.02], [0.2, 0.7, 0.35]), S.xf(S.box(0.38, 0.04, 0.05, 0.01), [-0.1, 0.12, 0.15], [-0.1, -0.5, -0.2])];
  return [
    { name: 'destroços', bone: P1, f: S.union(...stones), min: [-0.65, -0.05, -0.65], max: [0.65, 0.35, 0.65], mat: MAT.STONE, spacing: 0.035, flow: [1, 0.2, 0],
      detail: (p) => (noise3(p[0] * 6, p[1] * 6, p[2] * 6) > 0.68 ? { mat: MAT.MOSS } : null) },
    { name: 'vigas', bone: P1, f: S.union(...beams), min: [-0.6, -0.05, -0.5], max: [0.6, 0.5, 0.5], mat: MAT.WOOD, spacing: 0.025, flow: [1, 0, 0] },
  ];
}

/** Onde ficam os caixotes e destroços (12). */
export const BREAKABLES = [
  { x: -1.9, z: -3.3, kind: 'crate', rot: 0.2 }, { x: 4.0, z: -1.9, kind: 'crate', rot: -0.4 }, { x: 6.2, z: -3.5, kind: 'debris' },
  { x: 4.3, z: 0.6, kind: 'crate', rot: 0.6 }, { x: 1.6, z: -2.9, kind: 'debris' }, { x: -13.6, z: 0.8, kind: 'crate', rot: 0.1 },
  { x: -3.9, z: 5.6, kind: 'crate', rot: -0.2 }, { x: 8.4, z: 3.9, kind: 'debris' }, { x: 11.8, z: -1.6, kind: 'crate', rot: 0.9 },
  { x: -12.1, z: -2.9, kind: 'debris' }, { x: 2.9, z: 7.4, kind: 'crate', rot: 0.3 }, { x: 13.9, z: 6.1, kind: 'debris' },
];
