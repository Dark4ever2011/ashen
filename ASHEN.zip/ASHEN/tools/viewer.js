// Visualizador: mostra o cavaleiro em todas as vistas (parado, transição, andando, correndo)
// e as peças do cenário. Abra tools/sprite-viewer.html no navegador.
import { loadFonts, GlyphPainter, fontStatus } from '../src/engine/typography.js';
import { setOffscreenAllowed } from '../src/engine/canvas.js';
import { KnightRig } from '../src/entities/knight-rig.js';

const cv = document.getElementById('c');
const ctx = cv.getContext('2d');
const info = document.getElementById('info');
let painter, rig, version = 1, t0 = performance.now();
let extra = [];

export function registerExtra(fn) { extra.push(fn); }
window.ASHEN_VIEWER = { registerExtra };

async function boot() {
  await loadFonts('../assets/fonts/');
  setOffscreenAllowed(fontStatus.offscreenFonts);
  painter = new GlyphPainter();
  rig = new KnightRig();
  try { const m = await import('./viewer-props.js'); m.default && m.default(registerExtra); } catch (e) { console.warn('props', e); }
  document.getElementById('scale').oninput = () => { version++; };
  requestAnimationFrame(loop);
}

function loop(now) {
  requestAnimationFrame(loop);
  const anim = document.getElementById('anim').checked;
  const t = anim ? (now - t0) / 1000 : 0;
  const s = parseFloat(document.getElementById('scale').value) * (window.devicePixelRatio || 1);
  painter.setCell(6 * s, 10 * s);
  const colW = 40 * 6 * s, rowH = 42 * 10 * s;
  const states = [
    { name: 'parado', blend: 0, phase: 0, breath: (t / 3.4) % 1, run: 0 },
    { name: 'transição', blend: 0.5, phase: 0.25, breath: 0, run: 0 },
    { name: 'andando', blend: 1, phase: (t * 1.2) % 1, breath: 0, run: 0 },
    { name: 'andando ¼', blend: 1, phase: 0.25, breath: 0, run: 0 },
    { name: 'correndo', blend: 1, phase: (t * 1.5) % 1, breath: 0, run: 1 },
  ];
  const views = ['S', 'E', 'N', 'W'];
  const W = Math.ceil(colW * states.length), H = Math.ceil(rowH * views.length) + (extra.length ? 900 * s : 0);
  if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; cv.style.width = W / (window.devicePixelRatio || 1) + 'px'; }
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = document.getElementById('bg').value;
  ctx.fillRect(0, 0, W, H);
  ctx.font = `${12 * s / 2}px system-ui`;
  views.forEach((v, vi) => states.forEach((st, si) => {
    const fr = rig.frame(painter, version, { view: v, ...st });
    const bx = Math.round(si * colW + colW / 2), by = Math.round(vi * rowH + rowH - 30 * s);
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.beginPath(); ctx.ellipse(bx, by, 9 * 6 * s / 2, 3 * s * 2, 0, 0, Math.PI * 2); ctx.fill();
    rig.updateCape(1 / 60, v, st.blend ? (v === 'E' ? 130 : v === 'W' ? -130 : 0) : 0, st.blend * (st.run ? 1 : 0.55), st.phase, t, 0.4);
    if (v !== 'N') rig.drawCape(ctx, painter, version, v, bx, by, fr.J);
    ctx.drawImage(fr.canvas, bx - Math.round(fr.ax), by - Math.round(fr.ay));
    if (v === 'N') { rig.drawCape(ctx, painter, version, v, bx, by, fr.J); if (fr.over) ctx.drawImage(fr.over.canvas, bx - Math.round(fr.over.ax), by - Math.round(fr.over.ay)); }
    ctx.fillStyle = '#c9c2b8';
    ctx.fillText(`${v} · ${st.name}`, si * colW + 8, vi * rowH + 16 * s / 2);
  }));
  let y = rowH * views.length;
  for (const fn of extra) y = fn(ctx, painter, s, y, t, version) || y;
  info.textContent = `fonte: ${fontStatus.mono} · CJK: ${fontStatus.cjk} · cache ${rig.cache.map.size} · builds ${rig.stats.builds}`;
}

boot().catch(e => { info.textContent = 'ERRO: ' + e.message; console.error(e); });
