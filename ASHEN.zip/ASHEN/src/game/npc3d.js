// ASHEN 3D — Gente do vale: camponeses (mesmo esqueleto do cavaleiro) e os mortos que se levantaram
// (meio zumbis, meio esqueletos: mesmo esqueleto do rei, menores, com o osso à mostra).

import { m4, noise3 } from './math3d.js';
import { MAT } from './glyphs.js';
import * as S from './sdf.js';
import { bossParts, poseBoss, ACTIONS } from './boss3d.js';
import { BONE } from './knight3d.js';

/** Camponês: 'man' (túnica de linho, calça, cabelo curto) ou 'woman' (vestido de lã, avental, lenço). */
export function villagerParts(kind) {
  const P = [], add = o => P.push(o), woman = kind === 'woman';
  const cloth = woman ? MAT.WOOL : MAT.LINEN;
  const seams = (p) => (noise3(p[0] * 40, p[1] * 40, p[2] * 40) > 0.74 ? { mat: MAT.DARK, glyph: '·' } : null);
  // tronco
  add({ name: 'túnica', bone: BONE.CHEST, f: S.smooth(0.04, S.xf(S.ellipsoid(0.17, 0.2, 0.115), [0, 0.18, 0]), S.xf(S.ellipsoid(0.15, 0.08, 0.1), [0, 0.33, -0.01])), min: [-0.22, -0.06, -0.15], max: [0.22, 0.42, 0.15], mat: cloth, spacing: 0.02, flow: [0, 1, 0],
    detail: (p) => (woman && p[2] > 0.07 && Math.abs(p[0]) < 0.11 && p[1] < 0.22 ? { mat: MAT.LINEN } : (!woman && Math.abs(p[0]) < 0.015 && p[2] > 0 && p[1] > 0.22 ? { mat: MAT.LEATHER, glyph: '┼' } : seams(p))) });
  add({ name: 'pescoço', bone: BONE.CHEST, f: S.capsule([0, 0.34, 0.0], [0, 0.42, 0.01], 0.042), min: [-0.06, 0.3, -0.06], max: [0.06, 0.46, 0.06], mat: MAT.SKIN, spacing: 0.012, flow: [0, 1, 0] });
  // cabeça: rosto, nariz, olhos, cabelo / lenço
  const head = S.smooth(0.02, S.xf(S.ellipsoid(0.083, 0.105, 0.092), [0, 0.12, 0.01]), S.xf(S.ellipsoid(0.02, 0.03, 0.02), [0, 0.11, 0.098]));
  add({ name: 'rosto', bone: BONE.HEAD, f: head, min: [-0.1, -0.0, -0.1], max: [0.1, 0.24, 0.13], mat: MAT.SKIN, spacing: 0.011, flow: [0, 1, 0],
    detail: (p) => (Math.abs(p[1] - 0.06) < 0.008 && Math.abs(p[0]) < 0.03 && p[2] > 0.07 ? { mat: MAT.BLOOD, glyph: '─' } : null),
    decals: [-1, 1].map(s => ({ p: [s * 0.033, 0.135, 0.092], n: [0, 0, 1], glyph: '•', mat: MAT.DARK, size: 0.022 })) });
  if (woman) {
    const scarf = S.intersect(S.shell(S.xf(S.ellipsoid(0.098, 0.12, 0.105), [0, 0.13, 0.0]), 0.012), (x, y, z) => Math.max(z - 0.05 + (0.2 - y) * 0.4, -y + 0.02));
    const tail = S.roundCone([0, 0.1, -0.09], [0, -0.12, -0.12], 0.05, 0.03);
    add({ name: 'lenço', bone: BONE.HEAD, f: S.union(scarf, tail), min: [-0.12, -0.15, -0.16], max: [0.12, 0.26, 0.09], mat: MAT.LINEN, spacing: 0.012, flow: [0, 1, 0] });
  } else {
    const hair = S.intersect(S.shell(S.xf(S.ellipsoid(0.09, 0.112, 0.1), [0, 0.13, 0.008]), 0.012), (x, y, z) => Math.max(0.12 - y - (z < 0 ? 0.08 : 0), z - 0.08));
    add({ name: 'cabelo', bone: BONE.HEAD, f: hair, min: [-0.11, 0.02, -0.12], max: [0.11, 0.25, 0.1], mat: MAT.HAIR, spacing: 0.011, flow: [0, 1, 0] });
    add({ name: 'barba', bone: BONE.HEAD, f: S.intersect(S.shell(S.xf(S.ellipsoid(0.085, 0.1, 0.095), [0, 0.11, 0.012]), 0.012), (x, y, z) => Math.max(y - 0.075, 0.01 - z + Math.abs(x) * 0.2)), min: [-0.1, -0.0, -0.02], max: [0.1, 0.09, 0.12], mat: MAT.HAIR, spacing: 0.011, flow: [0, 1, 0] });
  }
  // quadril: saia longa (mulher) ou barra da túnica e cinto (homem)
  if (woman) add({ name: 'saia', bone: BONE.PELVIS, f: S.shell(S.roundCone([0, 0.08, 0], [0, -0.8, 0.0], 0.155, 0.27), 0.012), min: [-0.3, -0.84, -0.3], max: [0.3, 0.12, 0.3], mat: MAT.WOOL, spacing: 0.024, flow: [0, 1, 0],
    keep: (p) => p[1] > -0.83, detail: (p) => (p[2] > 0.1 && Math.abs(p[0]) < 0.13 && p[1] > -0.55 ? { mat: MAT.LINEN } : seams(p)) });
  else add({ name: 'barra', bone: BONE.PELVIS, f: S.shell(S.roundCone([0, 0.08, 0], [0, -0.26, 0], 0.16, 0.2), 0.01), min: [-0.23, -0.3, -0.23], max: [0.23, 0.12, 0.23], mat: MAT.LINEN, spacing: 0.02, flow: [0, 1, 0],
    detail: (p) => (Math.abs(p[1] - 0.05) < 0.025 ? { mat: MAT.LEATHER } : seams(p)) });
  // braços: manga + mão
  for (const [ua, fa, hd] of [[BONE.UA_L, BONE.FA_L, BONE.HAND_L], [BONE.UA_R, BONE.FA_R, BONE.HAND_R]]) {
    add({ name: 'manga', bone: ua, f: S.roundCone([0, 0.02, 0], [0, -0.31, 0], 0.048, 0.04), min: [-0.07, -0.34, -0.07], max: [0.07, 0.06, 0.07], mat: cloth, spacing: 0.016, flow: [0, 1, 0] });
    add({ name: 'antebraço', bone: fa, f: S.roundCone([0, 0, 0], [0, -0.26, 0], woman ? 0.04 : 0.036, 0.027), min: [-0.06, -0.29, -0.06], max: [0.06, 0.04, 0.06], mat: woman ? MAT.WOOL : MAT.SKIN, spacing: 0.014, flow: [0, 1, 0] });
    add({ name: 'mão', bone: hd, f: S.xf(S.ellipsoid(0.03, 0.06, 0.02), [0, -0.05, 0.005]), min: [-0.045, -0.12, -0.035], max: [0.045, 0.02, 0.04], mat: MAT.SKIN, spacing: 0.01, flow: [0, 1, 0] });
  }
  // pernas (calça e botas de couro)
  for (const [th, sh, ft] of [[BONE.TH_L, BONE.SH_L, BONE.FT_L], [BONE.TH_R, BONE.SH_R, BONE.FT_R]]) {
    if (!woman) add({ name: 'calça', bone: th, f: S.roundCone([0, 0, 0], [0, -0.45, 0], 0.07, 0.05), min: [-0.09, -0.48, -0.09], max: [0.09, 0.06, 0.09], mat: MAT.LEATHER, spacing: 0.018, flow: [0, 1, 0] });
    add({ name: 'canela', bone: sh, f: S.roundCone([0, 0, 0], [0, -0.42, 0], 0.05, 0.04), min: [-0.07, -0.45, -0.07], max: [0.07, 0.05, 0.07], mat: woman ? MAT.WOOL : MAT.LEATHER, spacing: 0.017, flow: [0, 1, 0] });
    add({ name: 'bota', bone: ft, f: S.xf(S.ellipsoid(0.045, 0.04, 0.12), [0, -0.04, 0.05]), min: [-0.06, -0.09, -0.08], max: [0.06, 0.02, 0.18], mat: MAT.LEATHER, spacing: 0.013, flow: [1, 0, 0] });
  }
  return P;
}

/** Morto erguido. skeleton=true → só ossos (para os restos espalhados no chão). */
export function ghoulParts(skeleton = false) {
  const out = [];
  for (const part of bossParts()) {
    if (part.name === 'coroa') continue;
    if (part.name === 'farrapos') { if (skeleton) continue; part.mat = MAT.LINEN; part.detail = (p) => (noise3(p[0] * 20, p[1] * 20, p[2] * 20) > 0.55 ? { mat: MAT.DARK } : null); out.push(part); continue; }
    const d0 = part.detail;
    if (skeleton) {
      part.mat = MAT.BONE;
      part.detail = (p, n, c) => (c > 0.35 || noise3(p[0] * 30, p[1] * 30, p[2] * 30) > 0.7 ? { mat: MAT.DARK, glyph: ['·', ':'][(Math.abs(p[1] * 99) | 0) % 2] } : null);
      part.decals = (part.decals || []).map(d => ({ ...d, mat: MAT.DARK, flags: 0 }));
      part.keep = (p) => noise3(p[0] * 12, p[1] * 12 + 3, p[2] * 12) > 0.3;          // ossos com falhas
    } else {
      // carne podre em manchas; o resto é osso exposto
      part.detail = (p, n, c) => {
        const k = noise3(p[0] * 14 + 3, p[1] * 14, p[2] * 14);
        if (k > 0.5) return { mat: MAT.BONE };
        if (k < 0.2) return { mat: MAT.DARK, glyph: ['%', '&'][(Math.abs(p[0] * 77) | 0) % 2] };
        return d0 ? d0(p, n, c) : null;
      };
    }
    out.push(part);
  }
  return out;
}

export const GSCALE = 0.78;               // ~1,75 m curvados
export const GHOUL_HP = 120;

/** Inimigo fraco e lento: anda até o cavaleiro e dá unhadas (dá para aparar). */
export class Ghoul {
  constructor(id, x, z, yaw = 0) { this.id = id; this.home = { x, z, yaw }; this.reset(); }
  reset() { Object.assign(this, { x: this.home.x, z: this.home.z, yaw: this.home.yaw, hp: GHOUL_HP, phase: Math.random(), blend: 0, t: Math.random() * 9, act: null, at: 0, cool: 1.2 + Math.random(), dead: 0, hurt: 0, state: 'idle', hitDone: false, stagger: 0 }); }
  get alive() { return this.state === 'idle' || this.state === 'fight'; }
  damage(n) { if (!this.alive) return false; this.hp -= n; this.hurt = 1; this.state = 'fight'; if (this.act && this.at < 0.45) { this.act = null; this.cool = 0.9; } if (this.hp <= 0) { this.state = 'dying'; this.act = null; return true; } return false; }
  doStagger() { this.act = 'stagger'; this.at = 0; this.hitDone = true; }
  /** Eventos: { type: 'hit', dmg, from } | { type: 'swing' } */
  update(dt, pl, canHit, aggro = 7) {
    const ev = [];
    this.t += dt; this.hurt = Math.max(0, this.hurt - dt * 4);
    if (this.state === 'dying') { this.dead = Math.min(1, this.dead + dt / 2.4); if (this.dead >= 1) this.state = 'dead'; return ev; }
    if (this.state === 'dead') return ev;
    const dx = pl.x - this.x, dz = pl.z - this.z, d = Math.hypot(dx, dz), want = Math.atan2(dx, dz);
    if (this.state === 'idle') { this.blend *= 0.95; if (d < aggro && canHit) this.state = 'fight'; else return ev; }
    if (this.act) {
      const A = ACTIONS[this.act], prev = this.at;
      this.at += dt * 0.75 / A.dur;
      const turnK = this.at < 0.3 ? 1.8 : 0.3;
      this.yaw += Math.max(-turnK * dt, Math.min(turnK * dt, Math.atan2(Math.sin(want - this.yaw), Math.cos(want - this.yaw))));
      if (this.act === 'swipe') {
        if (prev < 0.4 && this.at >= 0.4) ev.push({ type: 'swing' });
        if (!this.hitDone && this.at > 0.47 && this.at < 0.62) {
          const ang = Math.abs(Math.atan2(Math.sin(want - this.yaw), Math.cos(want - this.yaw)));
          if (d < 1.55 && ang < 1.0 && canHit) { this.hitDone = true; ev.push({ type: 'hit', dmg: 14, from: [this.x, this.z] }); }
        }
        const s0 = Math.min(1, prev), s1 = Math.min(1, this.at);
        if (s1 > 0.5 && s0 < 0.62) { const k = (Math.min(s1, 0.62) - Math.max(s0, 0.5)) / 0.12; this.x += Math.sin(this.yaw) * 0.25 * k; this.z += Math.cos(this.yaw) * 0.25 * k; }
      }
      if (this.at >= 1) { this.act = null; this.cool = 1.4 + Math.random() * 1.2; }
      this.blend += (0 - this.blend) * Math.min(1, dt * 5);
      return ev;
    }
    this.cool -= dt;
    this.yaw += Math.max(-2.2 * dt, Math.min(2.2 * dt, Math.atan2(Math.sin(want - this.yaw), Math.cos(want - this.yaw))));
    if (d > 1.25) {                        // arrasta os pés até o cavaleiro
      const sp = 0.75;
      this.x += Math.sin(this.yaw) * sp * dt; this.z += Math.cos(this.yaw) * sp * dt;
      this.phase = (this.phase + sp * dt / 1.3) % 1;
      this.blend += (1 - this.blend) * Math.min(1, dt * 3);
    } else this.blend += (0 - this.blend) * Math.min(1, dt * 4);
    if (d < 1.6 && this.cool <= 0 && canHit) { this.act = 'swipe'; this.at = 0; this.hitDone = false; }
    return ev;
  }
  pose() { return poseBoss({ phase: this.phase, blend: this.blend, t: this.t, act: this.act, at: this.at, rise: 1, dead: this.dead, hurt: this.hurt }); }
  matrix() { return m4.mul(m4.mul(m4.translate(this.x, 0, this.z), m4.rotY(this.yaw)), m4.scale(GSCALE, GSCALE, GSCALE)); }
}

/** Ossos de um morto deitado no chão (pose fixa). */
export function lyingBones(x, z, yaw, seed) {
  const pose = poseBoss({ phase: 0, blend: 0, t: seed, act: null, at: 0, rise: 1, dead: 1, hurt: 0 });
  const W = m4.mul(m4.mul(m4.mul(m4.translate(x, -0.05, z), m4.rotY(yaw)), m4.rotZ((seed % 3 - 1) * 0.5)), m4.scale(GSCALE, GSCALE, GSCALE));
  const b = pose.map(m => m4.mul(W, m)); b[0] = m4.ident();
  return b;
}
