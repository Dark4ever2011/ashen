// ASHEN 3D — A Lua Sombria (Reino Partido). A cada 10 dias há ~1% de chance; o Sino da Lua Sombria
// (vendido pelo mercador) também a chama. Dura 5 minutos: o céu fica vermelho e crias da lua nascem
// do chão. Depois de 10 crias derrotadas, surge um ogro de 3 m com olhos em brasa. Derrotá-lo dá a
// conquista «Eu não ogro, eu ciclope» e a Coroa do Ogro.

import { enemyState } from '../render3/glb-models.js';
import { m4, v3 } from './math3d.js';
import { MAT } from './glyphs.js';
import { flatBones } from './renderer3d.js';
import { bossParts, poseBoss, Boss } from './boss3d.js';
import { Ghoul } from './npc3d.js';
import { Goblin } from './goblin.js';
import { COMBO, swordSegment } from './knight3d.js';
import { hurtPlayer, DMG_TABLE } from './gameplay.js';
import { registerHit, hitFlash } from './bleed.js';
import { heightAt, blockedAt } from './ow.js';

const $ = id => document.getElementById(id);
const snd = (g, n, k) => g.audio && g.audio.play(n, k);
const I = m4.ident();
const OSCALE = 1.42, OGRE_HP = 1150, DURATION = 300;
const sm = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };

/** Ogro: o esqueleto do rei, mas inchado de músculo, pele grossa e olhos vermelhos acesos. */
export function ogreParts() {
  const out = [];
  for (const q of bossParts()) {
    if (q.name === 'coroa' || q.name === 'farrapos') continue;
    const inflate = q.name === 'tronco' ? 0.09 : q.name === 'crânio' ? 0.035 : q.name === 'quadril' ? 0.07 : /braço|coxa/.test(q.name) ? 0.055 : /antebraço|canela/.test(q.name) ? 0.045 : 0.02;
    const f0 = q.f;
    q.f = (x, y, z) => f0(x, y, z) - inflate;
    q.min = q.min.map(v => v - inflate - 0.01); q.max = q.max.map(v => v + inflate + 0.01);
    q.mat = MAT.LEATHER; q.spacing *= 1.25; q.aoF = q.f;
    q.detail = (p, n, c) => (Math.sin(p[0] * 60 + p[1] * 40) > 0.85 ? { mat: MAT.BLOOD } : c > 0.45 ? { mat: MAT.DARK } : null);
    if (q.name === 'crânio') q.decals = [-1, 1].map(s => ({ p: [s * 0.05, 0.1, 0.17], n: [0, 0, 1], glyph: '●', mat: MAT.EMBER, size: 0.05, flags: 2, clear: 0.03 }));
    else q.decals = [];
    out.push(q);
  }
  // tanga de couro
  out.push({ name: 'tanga', bone: 1, f: (x, y, z) => Math.max(Math.abs(Math.hypot(x, z) - 0.24) - 0.015, y - 0.05, -0.36 - y), min: [-0.3, -0.38, -0.3], max: [0.3, 0.07, 0.3], mat: MAT.WOOD, spacing: 0.024, flow: [0, 1, 0] });
  return out;
}

export function initDarkMoon(g, sets) {
  g.ogreMesh = g.R.addMesh(sets.ogre); g.ogreMesh.area = 'ow'; g.ogreMesh.visible = false;
  g.ogreLight = { name: 'olhos do ogro', pos: [0, -50, 0], col: [1, 0.15, 0.1], radius: 5, base: 1.3, flicker: 0.3, area: 'ow', level: 0 };
  g.lights.push(g.ogreLight);
  // a cada 10 dias, 1% de chance (só conta no Reino Partido)
  g.onNewDay = (day) => { if (g.area === 'ow' && day % 10 === 0 && Math.random() < 0.01) g.dmPending = true; };
  g.ringBell = () => {
    if (g.area !== 'ow') { g.hud.toast('O sino não soa aqui. Só no Reino Partido.', 2500); return false; }
    if (g.darkMoon) return false;
    if (g.hour > 5 && g.hour < 19) g.hour = 22;
    startDarkMoon(g); return true;
  };
}

function startDarkMoon(g) {
  g.darkMoon = { t: DURATION, kills: 0, spawnT: 1.5, crias: [], ogre: null, won: false };
  snd(g, 'bell'); snd(g, 'roar', 0.5); g.shake = 0.15;
  g.hud.showRegion({ region: 'III · O Reino Partido', title: 'A LUA SOMBRIA', subtitle: '暗月' });
  g.hud.toast('A lua sangra. Algo se mexe debaixo da terra…', 4000);
}
function endDarkMoon(g) {
  const D = g.darkMoon;
  for (const c of D.crias) if (c.state !== 'dead') c.state = 'dead';
  g.ow.ghouls = g.ow.ghouls.filter(x => !x.dm);
  g.darkMoon = null; g.ogreMesh.visible = false; g.ogreLight.level = 0; $('boss-bar').classList.add('hidden');
  g.hud.toast(D.won ? 'A lua volta a ser branca.' : 'A Lua Sombria se põe… o ogro não chegou a ser vencido.', 3500);
}

export function darkMoonStep(g, dt) {
  if (g.area !== 'ow') return;
  if (g.dmPending && (g.hour > 20 || g.hour < 4)) { g.dmPending = false; startDarkMoon(g); }
  const D = g.darkMoon; if (!D) return;
  const p = g.player;
  D.t -= dt;
  if (D.t <= 0) { endDarkMoon(g); return; }
  // crias nascem do chão perto do cavaleiro (até 4 vivas de cada vez)
  if (!D.ogre && D.kills < 10) {
    D.spawnT -= dt;
    const alive = D.crias.filter(c => c.state !== 'dead' && c.state !== 'dying').length;
    if (D.spawnT <= 0 && alive < 4) {
      D.spawnT = 2.5 + Math.random() * 2;
      const a = Math.random() * 6.28, r = 6 + Math.random() * 4, x = p.x + Math.cos(a) * r, z = p.z + Math.sin(a) * r;
      if (!blockedAt(x, z)) {
        const c = new (Math.random() < 0.4 ? Goblin : Ghoul)('dm' + Math.random().toString(36).slice(2, 7), x, z, a + Math.PI);
        c.dm = true; c.state = 'fight'; c.hp *= 1.2; c.y = heightAt(x, z);
        D.crias.push(c); g.ow.ghouls.push(c);
        g.fx.dirt([x, c.y + 0.1, z], 50, 1.6); snd(g, 'quake', 0.35);
      }
    }
    for (const c of D.crias) if ((c.state === 'dying' || c.state === 'dead') && !c.counted) { c.counted = true; D.kills++; g.hud.toast(`Crias da lua: ${D.kills}/10`, 1500); }
  }
  if (!D.ogre && D.kills >= 10) spawnOgre(g);
  if (D.ogre) ogreStep(g, dt);
}
function spawnOgre(g) {
  const D = g.darkMoon, p = g.player;
  const a = p.yaw, x = p.x + Math.sin(a) * 8, z = p.z + Math.cos(a) * 8;
  const O = new Boss({ x, z }); O.sc = OSCALE; O.reset(); O.x = x; O.z = z - 0.9; O.hp = OGRE_HP; O.state = 'rising'; O.rise = 0.3;
  D.ogre = O;
  g.fx.dirt([x, heightAt(x, z) + 0.1, z], 140, 2.6); g.shake = 0.3; snd(g, 'roar', 0.55); snd(g, 'quake');
  $('boss-name').textContent = 'O OGRO DA LUA SOMBRIA'; $('boss-bar').classList.remove('hidden');
}
function ogreStep(g, dt) {
  const D = g.darkMoon, O = D.ogre, p = g.player;
  if (p.atk >= 0 && g.knightBones && O.state === 'fight') {
    const C = COMBO[p.combo];
    if (p.atk > C.hit[0] - 0.03 && p.atk < C.hit[1] + 0.04 && !p.hitSet.has('ogre')) {
      const [a, b] = swordSegment(g.knightBones);
      for (const k of [0.3, 0.6, 0.95]) { const q = v3.lerp(a, b, k); if (Math.hypot(q[0] - O.x, q[2] - O.z) < 0.8 && q[1] < heightAt(O.x, O.z) + 3.2) {
        p.hitSet.add('ogre'); const crit = p.riposte > 0 ? 3 : 1; p.riposte = 0; g.critHit = crit > 1;
        O.damage(DMG_TABLE[p.combo] * crit * g.dmgMul()); O.y = heightAt(O.x, O.z); registerHit(g, O);
        snd(g, crit > 1 ? 'crit' : 'hit'); g.fx.sparks(q, 16, [0.9, 0.3, 0.2]); break;
      } }
    }
  }
  O.y = heightAt(O.x, O.z);
  const ev = O.update(dt * g.diffK.speed, p, p.dead <= 0);
  for (const e of ev) {
    if (e.type === 'hit') hurtPlayer(g, e.dmg * 1.25, e.from, O);
    else if (e.type === 'slam') { snd(g, 'slam'); g.shake = 0.25; g.fx.dirt([e.x, heightAt(e.x, e.z) + 0.1, e.z], 80, 2.2); if (Math.hypot(p.x - e.x, p.z - e.z) < 2.6) hurtPlayer(g, 30, [e.x, e.z], O); }
    else if (e.type === 'roar') { snd(g, 'roar', 0.55); g.shake = 0.2; }
  }
  if (O.state === 'fight') { const dx = p.x - O.x, dz = p.z - O.z, d = Math.hypot(dx, dz), rr = 0.65 * OSCALE + 0.3; if (d < rr && d > 1e-4) { p.x = O.x + dx / d * rr; p.z = O.z + dz / d * rr; } }
  g.hud.bossHp(Math.max(0, O.hp) / OGRE_HP);
  if ((O.state === 'dying' || O.state === 'dead') && !D.won) {
    D.won = true; snd(g, 'victory'); g.addGold(800);
    g.achieve('Eu não ogro, eu ciclope');
    if (!g.hasItem('crown')) { g.addItem('crown'); setTimeout(() => g.hud.message('Ouro bruto, grande demais para uma cabeça humana — mas serve por cima do elmo. Equipe pelo inventário.', 'Coroa do Ogro', null), 2500); }
    g.save();
    D.t = Math.min(D.t, 20);
  }
}
export function darkMoonRespawn(g) { if (g.darkMoon) endDarkMoon(g); }

export function darkMoonRender(g) {
  const D = g.darkMoon, O = D && D.ogre;
  g.darkMoonOn = !!D;
  g.ogreMesh.visible = !!O && g.area === 'ow' && O.dead < 1;
  if (!g.ogreMesh.visible) { g.ogreLight.level = 0; return; }
  const W = m4.mul(m4.mul(m4.translate(O.x, heightAt(O.x, O.z) - (1 - O.rise) * 2.2, O.z), m4.rotY(O.yaw)), m4.scale(OSCALE, OSCALE, OSCALE));
  const pose = poseBoss({ phase: O.phase, blend: O.blend, t: O.t, act: O.act, at: O.at, rise: O.rise, dead: O.dead, hurt: O.hurt });
  const b = pose.map(m => m4.mul(W, m)); b[0] = I;
  g.ogreMesh.boneData = flatBones(b, g.ogreMesh.boneData); g.ogreMesh.flash = hitFlash(g, O);
  g.ogreMesh.modelMatrix = W; g.ogreMesh.animState = O.rise < 1 ? 'idle' : enemyState(O);
  g.ogreMesh.drawCount = Math.round(g.ogreMesh.n * (1 - sm((O.dead - 0.5) / 0.5)));
  g.ogreLight.pos = m4.point(b[3], [0, 0.15, 0.2]); g.ogreLight.level = O.dead > 0.5 ? 0 : 1;
}
