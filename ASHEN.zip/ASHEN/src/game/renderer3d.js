// ASHEN 3D — Renderizador tipográfico em WebGL2.
// A tela só recebe caracteres. A geometria existe como pontos de superfície (com normal e
// tangente) que viram "carimbos" de caracteres instanciados na GPU.
// Passes: (1) sombra do luar, (2) oclusão invisível (só profundidade), (3) caracteres, (4) partículas.

import { m4 } from './math3d.js';
import { MATERIALS, VEG, GLINT, MAT } from './glyphs.js';
import { VSTRIDE } from './solid.js';

const MAX_BONES = 18, MAX_LIGHTS = 6, MAX_TRAIL = 8;
const NMAT = MATERIALS.length;
const NO_TORCH = [0, -100, 0, 0];

const VS = `#version 300 es
precision highp float;
precision highp int;
precision highp sampler2DShadow;
layout(location=0) in vec2 aCorner;
layout(location=1) in vec3 iPos;
layout(location=2) in vec3 iNrm;
layout(location=3) in vec3 iTan;
layout(location=4) in vec4 iAttr;   // material, glifo fixo, osso, flags
layout(location=5) in vec2 iExtra;  // tamanho, semente
uniform mat4 uVP, uLightVP;
uniform mat4 uBones[${MAX_BONES}];
uniform vec4 uBoneVel[${MAX_BONES}];   // velocidade linear da origem do osso (m/s)
uniform vec4 uBoneAng[${MAX_BONES}];   // velocidade angular (rad/s, mundo)
uniform float uSizeMul;                // densidade por zoom: menos caracteres → maiores
uniform vec4 uTrail[${MAX_TRAIL}];     // pegadas: x, z, instante
uniform vec3 uCam;
uniform vec2 uViewport;
uniform float uPxScale, uGlyph, uBias, uTime, uShadowSize, uExposure;
uniform int uPass;
uniform vec3 uMoonDir, uMoonCol, uSky, uGround;
uniform vec4 uLightPos[${MAX_LIGHTS}];   // xyz, raio
uniform vec4 uLightCol[${MAX_LIGHTS}];   // rgb * intensidade (com tremulação)
uniform vec4 uLightBase[${MAX_LIGHTS}];  // rgb * intensidade média (estável: escolhe o caractere)
uniform int uNumLights;
uniform vec3 uMatColor[${NMAT}];
uniform vec3 uMatProps[${NMAT}];        // especular, emissivo, brilho (expoente)
uniform ivec4 uRamp[${(NMAT + 1) * 2}];   // 8 caracteres por material, empacotados
int ramp(int i) { ivec4 v = uRamp[i / 4]; int k = i - (i / 4) * 4; return k == 0 ? v.x : k == 1 ? v.y : k == 2 ? v.z : v.w; }
uniform ivec4 uRim;
uniform ivec4 uVeg[4];
uniform ivec4 uGlint;
uniform vec4 uWind;    // direção xz, força, -
uniform vec3 uPlayer;
uniform vec4 uTorch;                    // chama da tocha: xyz, força (já pesada pela escuridão do ambiente)
uniform vec2 uTorchR;                   // raio da luz (oscila com a chama), quanto destacar os personagens (0 de dia → 1 no escuro)
uniform vec3 uRimDir, uRimCol;          // luz lateral/de recorte (fria, de trás)
uniform float uWet, uRain, uFlash;      // clima: superfícies molhadas, intensidade da chuva, relâmpago
uniform ivec4 uWaterG, uFoamG;
uniform int uPCF;
uniform ivec4 uRipple;                  // caracteres da água das poças
uniform vec4 uArena;                    // terremoto do chefe: centro xz, raio, quanto afundou (0..1)
uniform vec3 uArenaKeep;                // o que fica: túmulo real (xz, raio)
int pick(ivec4 v, int k) { return k == 0 ? v.x : k == 1 ? v.y : k == 2 ? v.z : v.w; }
int veg(int i) { return pick(uVeg[i / 4], i - (i / 4) * 4); }
uniform float uAtlasCols, uAtlasRows;
uniform vec4 uFog;                      // rgb, densidade
uniform vec3 uFocus;
uniform sampler2DShadow uShadow;
out vec2 vUV;
out vec4 vColor;
out float vDisc;

float h1(float n) { return fract(sin(n * 12.9898) * 43758.5453); }
float vn(vec2 p) {
  vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
  float a = h1(i.x + i.y * 57.0), b = h1(i.x + 1.0 + i.y * 57.0), c = h1(i.x + (i.y + 1.0) * 57.0), d = h1(i.x + 1.0 + (i.y + 1.0) * 57.0);
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

void main() {
  mat4 B = uBones[int(iAttr.z)];
  int flags = int(iAttr.w);
  bool isVeg = (flags & 8) != 0;
  vec3 wp, wn, wt;
  float leafFl = 0.0, waterA = 1.0, waterPh = 0.0, waterFoam = 0.0;
  bool isWater = (flags & 256) != 0;
  vec2 wd = uWind.xy;
  float ws = uWind.z;
  if (isVeg) {
    // ── Talo de grama dobrado pelo vento (rajadas que viajam + tremulação própria + cavaleiro) ──
    float f = iTan.x, h = iTan.y, nat = iTan.z;
    vec3 root = iPos;
    float g1 = sin(dot(root.xz, wd) * 0.55 - uTime * 1.6);
    float g2 = sin(dot(root.xz, vec2(-wd.y, wd.x)) * 0.31 + uTime * 0.53 + g1 * 0.6);
    float gust = 0.5 + 0.32 * g1 + 0.18 * g2;
    float fl = sin(uTime * (4.5 + fract(iExtra.y * 0.131) * 4.0) + iExtra.y) * 0.2 + sin(uTime * 11.3 + iExtra.y * 2.1) * 0.06;
    bool plant = (flags & 32) != 0;
    vec2 bend = wd * ws * (gust + fl) * (plant ? 0.35 : 1.0) + vec2(cos(nat), sin(nat)) * 0.22;
    vec2 pd = root.xz - uPlayer.xz;
    float pdl = length(pd);
    if (pdl < 0.75) bend += pd / max(pdl, 0.05) * (0.75 - pdl) * 2.4;
    // pegadas: a grama fica deitada onde ele pisou e levanta devagar
    float flatK = 0.0;
    for (int i = 0; i < ${MAX_TRAIL}; i++) {
      vec2 dt = root.xz - uTrail[i].xy;
      float dd = length(dt), age = uTime - uTrail[i].z;
      if (dd < 0.32 && age > 0.0) {
        float k = (1.0 - dd / 0.32) * exp(-age / 3.5);
        bend += dt / max(dd, 0.04) * k * 1.3;
        flatK = max(flatK, k);
      }
    }
    float bl = length(bend);
    if (bl > 1.5) bend *= 1.5 / bl;
    float k = pow(f, 1.6);
    float droop = min(length(bend), 1.3);
    if (plant) {
      vec2 o = vec2(cos(nat), sin(nat)) * (0.03 + f * 0.09);
      wp = root + vec3(o.x, h * (0.4 + 0.6 * (1.0 - f)), o.y) + vec3(bend.x, 0.0, bend.y) * h * 0.25;
    } else {
      wp = root + vec3(0.0, h * f * (1.0 - 0.3 * droop * droop * f) * (1.0 - 0.75 * flatK), 0.0) + vec3(bend.x, 0.0, bend.y) * h * k * 0.8;
    }
    wn = normalize(vec3(bend.x * 0.6, 1.0, bend.y * 0.6));
    wt = normalize(vec3(bend.x * 1.7 * k, 1.0, bend.y * 1.7 * k));
  } else {
    wp = (B * vec4(iPos, 1.0)).xyz;
    wn = normalize(mat3(B) * iNrm);
    wt = normalize(mat3(B) * iTan);
    if ((flags & 16) != 0) {
      // ── Galhos: balanço sutil, maior nas pontas e no alto ──
      float amt = pow(clamp((wp.y - 0.8) / 4.5, 0.0, 1.0), 2.0);
      float ph = uTime * 1.25 + wp.x * 0.6 + wp.z * 0.45;
      vec2 sw = wd * ws * (0.55 + 0.45 * sin(ph)) * 0.22 + vec2(sin(uTime * 3.7 + iExtra.y), cos(uTime * 3.1 + iExtra.y)) * 0.025;
      wp += vec3(sw.x, -0.02 * length(sw), sw.y) * amt;
    }
    if (isWater) {
      // ── Rio: a superfície corre (cada caractere desliza com a corrente, some e renasce),
      //    ondas que viajam, espuma onde a água bate nas pedras ──
      vec2 fl = iTan.xz; float spd = max(length(fl), 0.05); vec2 fd = fl / spd;
      waterFoam = iTan.y;
      float life = fract(uTime * spd * 0.55 + h1(iExtra.y));
      wp.xz += fd * (life - 0.5) * 0.5 + vec2(-fd.y, fd.x) * sin(uTime * 1.7 + iExtra.y) * 0.03 * (0.4 + waterFoam);
      waterA = sin(3.14159 * life);
      waterPh = dot(wp.xz, fd) * 4.2 - uTime * spd * 4.0 + sin(dot(wp.xz, vec2(-fd.y, fd.x)) * 1.7 + uTime * 0.8) * 1.4;
      float wave = sin(waterPh) * 0.5 + sin(waterPh * 2.3 + iExtra.y) * 0.2;
      wp.y += wave * 0.035 + waterFoam * 0.03 * sin(uTime * 9.0 + iExtra.y * 3.0);
      wn = normalize(vec3(-cos(waterPh) * fd.x * 0.35, 1.0, -cos(waterPh) * fd.y * 0.35));
      wt = vec3(fd.x, 0.0, fd.y);
    }
    if ((flags & 128) != 0) {
      // folha: tremula no próprio ritmo; mais vento → mais movimento; chuva pesa e abaixa
      float sp = 2.2 + fract(iExtra.y * 0.131) * 3.8;
      leafFl = sin(uTime * sp * (0.6 + ws) + iExtra.y) + 0.4 * sin(uTime * sp * 2.3 + iExtra.y * 1.7);
      float a = (0.25 + ws) * 0.022;
      wp += vec3(wd.x * ws * 0.05 + leafFl * a, leafFl * a * 0.5 - uWet * 0.035, wd.y * ws * 0.05 + cos(uTime * sp + iExtra.y) * a);
    }
  }
  // ── terremoto: o que está dentro da arena treme e afunda na terra (e volta depois) ──
  if (uArena.w > 0.001 && int(iAttr.z) == 0) {
    int m0 = int(iAttr.x);
    bool ground = !isVeg && iPos.y < 0.12 && (m0 == 8 || m0 == 16 || m0 == 13 || m0 == 15);
    float d = length(iPos.xz - uArena.xy);
    if (!ground && d < uArena.z && length(iPos.xz - uArenaKeep.xy) > uArenaKeep.z && iPos.z > -3.85) {
      float k = uArena.w * smoothstep(uArena.z, uArena.z - 0.8, d);
      float shake = clamp(uArena.w * (1.0 - uArena.w) * 4.0, 0.0, 1.0);
      wp.xz += vec2(sin(uTime * 47.0 + iExtra.y), cos(uTime * 53.0 + iExtra.y * 1.3)) * 0.05 * shake;
      wp.y -= k * (max(iPos.y, 0.3) + 0.4) * 1.4 * (0.85 + 0.3 * fract(iExtra.y * 0.37));
      if (wp.y < -0.03) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return; }
    }
  }
  float size = iExtra.x, ao = 1.0;
  bool hasAO = (flags & 64) != 0;
  if (hasAO) { size = floor(iExtra.x) / 2000.0; ao = fract(iExtra.x) / 0.99; }
  size *= uSizeMul;
  // velocidade do ponto no mundo (osso: linear + giro) → caracteres só mudam quando há movimento
  int bi = int(iAttr.z);
  vec3 vel = (bi > 0 && !isVeg) ? uBoneVel[bi].xyz + cross(uBoneAng[bi].xyz, wp - B[3].xyz) : vec3(0.0);
  vDisc = 0.0;
  if (uPass == 2) {                       // sombra: discos virados para a lua
    vec4 c = uLightVP * vec4(wp, 1.0);
    gl_Position = c + vec4(aCorner * uShadowSize * size, 0.0, 0.0);
    vUV = aCorner; vDisc = 1.0; vColor = vec4(1.0);
    return;
  }
  vec3 V = normalize(uCam - wp);
  float ndv = dot(wn, V);
  bool emissive = (flags & 2) != 0;
  if (isVeg) ndv = abs(ndv) + 0.4;          // talos são finos: vistos dos dois lados
  if (ndv < -0.08 && !emissive) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return; }
  vec4 clip = uVP * vec4(wp, 1.0);
  float px = size * uGlyph * uPxScale / clip.w;
  if (uPass == 1) {                       // oclusão: disco invisível, um pouco atrás da superfície
    if (distance(uCam, wp) < 3.4) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return; }   // o que some perto da câmera não esconde nada
    vec3 pc = uPlayer + vec3(0.0, 0.9, 0.0);
    if (!hasAO && distance(uCam, wp) < distance(uCam, pc) - 0.7) {                   // nem o que está na frente do cavaleiro
      vec4 pp = uVP * vec4(pc, 1.0), cc = uVP * vec4(wp, 1.0);
      if (length((cc.xy / cc.w - pp.xy / pp.w) * vec2(uViewport.x / uViewport.y, 1.0)) < 0.5) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return; }
    }
    vec4 cb = uVP * vec4(wp - V * 0.012, 1.0);
    gl_Position = cb + vec4(aCorner * px * 0.9 / uViewport * cb.w, 0.0, 0.0);
    vUV = aCorner; vDisc = 1.0; vColor = vec4(1.0);
    return;
  }
  // ── Iluminação por caractere ──
  int mat = int(iAttr.x);
  vec3 base = uMatColor[mat];
  vec3 props = uMatProps[mat];
  float sh = 1.0;
  vec4 lc = uLightVP * vec4(wp + wn * 0.03, 1.0);
  vec3 lp = lc.xyz / lc.w * 0.5 + 0.5;
  if (lp.x > 0.0 && lp.x < 1.0 && lp.y > 0.0 && lp.y < 1.0) {
    float o = 1.0 / 2048.0;
    sh = 0.0;
    if (uPCF >= 2) {                    // Extremo: penumbra larga (5×5)
      for (int i = -2; i <= 2; i++) for (int j = -2; j <= 2; j++)
        sh += texture(uShadow, vec3(lp.xy + vec2(float(i), float(j)) * o * 1.1, lp.z - 0.0015));
      sh /= 25.0;
    } else {
      for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++)
        sh += texture(uShadow, vec3(lp.xy + vec2(float(i), float(j)) * o * 1.5, lp.z - 0.0015));
      sh /= 9.0;
    }
  }
  float aoD = mix(1.0, ao, 0.75);                       // a luz direta também sofre nas frestas
  vec3 amb = mix(uGround, uSky, wn.y * 0.5 + 0.5) * ao;
  float dm = max(dot(wn, uMoonDir), 0.0);
  vec3 diff = uMoonCol * dm * sh * aoD;
  vec3 diffS = vec3(0.0), specS = vec3(0.0);   // parte das chamas sem tremulação
  // ── Clima ──
  bool groundPt = !hasAO && !isVeg && (((flags & 512) != 0) || (wp.y < 0.3 && (mat == 8 || mat == 16 || mat == 13)));
  float puddle = 0.0;
  if (groundPt && uWet > 0.05) {
    float nz = vn(wp.xz * 0.55) * 0.7 + vn(wp.xz * 1.9 + 7.0) * 0.3;
    puddle = smoothstep(0.62, 0.66, nz + uWet * 0.1) * smoothstep(0.25, 0.7, uWet);
  }
  float wetK = uWet * (isVeg || (flags & 128) != 0 ? 0.25 : 1.0);
  if (mat == 3 || mat == 14) base *= 1.0 - 0.38 * uWet;            // tecido encharcado escurece
  else if (groundPt) base *= 1.0 - 0.4 * uWet;                      // terra molhada
  if (puddle > 0.5) { base = uMatColor[26]; props = uMatProps[26]; }
  if (props.x > 0.5 || groundPt) { props.x *= 1.0 + 0.8 * wetK; props.z *= 1.0 + 1.2 * wetK; }
  if (groundPt && props.x < 0.5) { props.x += 0.5 * uWet; props.z = 50.0; }
  // relâmpago: clarão frio na direção do luar (usa a mesma sombra) + céu inteiro aceso
  diff += vec3(0.78, 0.84, 1.0) * uFlash * 3.2 * dm * sh + vec3(0.25, 0.27, 0.34) * uFlash * ao;
  vec3 H = normalize(uMoonDir + V);
  float gls = props.z, gn = (gls + 8.0) / 32.0;           // brilho: metal polido = ponto pequeno e forte
  vec3 spec = uMoonCol * pow(max(dot(wn, H), 0.0), gls) * gn * props.x * sh * ao;
  vec3 specD = spec;
  float fres = pow(1.0 - clamp(ndv, 0.0, 1.0), 4.0);
  if (props.x > 0.5) {                                  // metais refletem o céu e o chão
    vec3 Rf = reflect(-V, wn);
    spec += mix(uGround * 1.5, uSky * 3.2, smoothstep(-0.3, 0.6, Rf.y)) * (0.25 + 0.75 * fres) * props.x * 0.55 * ao;
  }
  if (puddle > 0.5) spec += uSky * 2.4 * (0.4 + fres) + uFlash * vec3(1.2, 1.3, 1.5);
  // luz lateral de recorte: separa o volume do fundo
  float rimL = pow(1.0 - clamp(abs(ndv), 0.0, 1.0), 2.2) * max(dot(wn, uRimDir), 0.0);
  diff += uRimCol * rimL * ao * (hasAO ? 1.0 : 0.35) * (0.6 + props.x * 0.6);
  float lk = 0.0;                           // quanto as luzes de fogo (não a lua) alcançam este ponto
  for (int i = 0; i < ${MAX_LIGHTS}; i++) {
    if (i >= uNumLights) break;
    vec3 Lv = uLightPos[i].xyz - wp;
    float d = length(Lv);
    float att = clamp(1.0 - d / uLightPos[i].w, 0.0, 1.0);
    att *= att;
    vec3 L = Lv / d;
    float nl = isVeg ? (dot(wn, L) * 0.5 + 0.5) : max(dot(wn, L), 0.0);   // grama translúcida
    float kd = att * (nl * 0.95 + 0.12 * ao) * aoD;
    float ks = att * pow(max(dot(wn, normalize(L + V)), 0.0), gls) * gn * props.x * ao;
    diff += uLightCol[i].rgb * kd; spec += uLightCol[i].rgb * ks;
    lk += att * dot(uLightBase[i].rgb, vec3(0.33));
    diffS += (uLightBase[i].rgb - uLightCol[i].rgb) * kd; specS += (uLightBase[i].rgb - uLightCol[i].rgb) * ks;
    specD += uLightBase[i].rgb * ks;
  }
  vec3 col = base * (amb + diff) + spec;
  if (isVeg) col *= 1.55 * ((flags & 32) != 0 ? 1.0 : mix(0.42, 1.3, iTan.x));   // talos finos: base escura, ponta clara (volume)
  if (groundPt && puddle < 0.5) col = col * 1.75 + base * 0.07;   // chão mais visível à noite
  if (bi == 0 && !emissive) { float l0 = dot(col, vec3(0.3, 0.5, 0.2)); col = max(mix(vec3(l0), col, 1.35), 0.0) * 1.08; }   // mundo com cores mais vivas
  if (wp.y - uPlayer.y < 0.35 && !hasAO) {              // sombra de contato sob o cavaleiro
    vec2 dp = wp.xz - uPlayer.xz;
    col *= 1.0 - 0.6 * exp(-dot(dp, dp) / 0.1);
  }
  if (hasAO && (flags & 1) != 0 && props.x > 0.5) col += base * 0.12 * (0.5 + sh);   // aresta gasta: metal mais claro
  float lum = dot(col, vec3(0.3, 0.5, 0.2));
  float lumS = lum + dot(base * diffS + specS, vec3(0.3, 0.5, 0.2));   // luminância estável → caractere
  float glint = dot(specD, vec3(0.333));   // estável: não pisca com a chama
  // ── Escolha do caractere ──
  float seed = iExtra.y;
  float dither = (h1(seed) - 0.5) * (hasAO ? 0.35 : 0.9);
  float distK = clamp((distance(wp.xz, uFocus.xz) - 5.0) / 10.0, 0.0, 1.0);
  // movimento na tela (px por 1/20 s): só ele faz os caracteres trocarem/se arrastarem
  vec2 mv = vec2(0.0); float mspeed = 0.0;
  if (bi > 0 && !isVeg) {
    vec4 cv = uVP * vec4(wp + vel * 0.05, 1.0);
    mv = (cv.xy / cv.w - clip.xy / clip.w) * uViewport * 0.5;
    mspeed = length(mv);
  }
  float mk = clamp((mspeed - 1.5) / 14.0, 0.0, 1.0);
  dither += (h1(seed + floor(uTime * 20.0)) - 0.5) * mk * 1.6;   // cintila com o movimento, para quando ele para
  if ((flags & 128) != 0) dither += leafFl * (0.2 + ws) * 0.75;
  int level = clamp(int(lumS * uExposure + dither + 0.5 + distK * 2.0), 0, 7);   // longe = traço mais leve
  int g = int(iAttr.y);
  bool fixedG = g >= 0;
  float rim = 1.0 - abs(ndv);
  vec2 sp = clip.xy / clip.w;
  vec4 ct = uVP * vec4(wp + wt * 0.05, 1.0);
  vec2 dir = (ct.xy / ct.w - sp) * uViewport;
  float dl = length(dir);
  dir = dl > 1e-4 ? dir / dl : vec2(1.0, 0.0);
  float squash = 1.0;
  if (isWater) {
    float crest = sin(waterPh) * 0.5 + 0.5;
    float fk = clamp(waterFoam * 1.2 + smoothstep(0.82, 1.0, crest) * (0.25 + waterFoam), 0.0, 1.0);
    vec4 cf = uVP * vec4(wp + wt * 0.1, 1.0);
    vec2 fdir = (cf.xy / cf.w - sp) * uViewport; float fll = length(fdir);
    dir = fll > 1e-4 ? fdir / fll : vec2(1.0, 0.0);
    if (fk > h1(seed * 1.31 + floor(uTime * 3.0 + seed))) {
      g = pick(uFoamG, int(mod(seed + floor(uTime * 4.0), 4.0)));
      col = vec3(0.82, 0.9, 0.95) * (amb * 1.6 + diff + 0.15) + spec * 0.5;
      squash = 1.0;
    } else {
      g = pick(uWaterG, int(mod(floor(waterPh * 0.64) + seed, 4.0)));
      col = col * (0.8 + 0.45 * crest) + uSky * 0.6 * fres;
      squash = 0.75;
    }
  } else if (emissive) {
    col = base * (1.4 + 0.5 * sin(uTime * 9.0 + seed));
    level = 7;
    if (!fixedG) g = ramp(mat * 8 + int(mod(seed + uTime * 6.0, 8.0)));
  } else if (isVeg) {
    // caractere pela inclinação real do talo na tela
    vec4 ct2 = uVP * vec4(wp + wt * 0.12, 1.0);
    vec2 v = (ct2.xy / ct2.w - sp) * uViewport;
    float a = atan(v.x, max(abs(v.y), 1e-3) * sign(v.y + 1e-6));
    float aa = abs(a);
    if (fixedG) {}
    else if ((flags & 32) != 0) g = veg(10 + int(mod(seed, 4.0)));
    else if (iTan.x > 0.7) g = fract(seed * 0.37) < 0.12 ? veg(9) : (aa < 0.35 ? veg(6) : (a > 0.0 ? veg(8) : veg(7)));
    else g = aa < 0.22 ? veg(0) : aa < 0.6 ? (a > 0.0 ? veg(1) : veg(2)) : aa < 1.15 ? (a > 0.0 ? veg(3) : veg(4)) : veg(5);
    dir = vec2(1.0, 0.0);
  } else if (!fixedG) {
    if (glint > 0.5 && props.x > 0.4 && fract(seed * 0.618) < 0.4) {
      // reflexo metálico: troca o caractere e acende conforme luz e câmera se movem
      g = pick(uGlint, clamp(int((glint - 0.5) * 5.0), 0, 3));
      col += spec * 0.6;
    } else
    if ((flags & 1) != 0) g = ramp(${NMAT} * 8 + level);
    else g = ramp(mat * 8 + level);
    // silhueta: traço perpendicular à normal projetada, mais claro (contorno)
    if (rim > 0.74) {
      vec4 cn = uVP * vec4(wp + wn * 0.05, 1.0);
      vec2 nd = (cn.xy / cn.w - sp) * uViewport;
      float nl = length(nd);
      if (nl > 1e-4) dir = vec2(-nd.y, nd.x) / nl;
      g = pick(uRim, int(mod(seed, 4.0)));
      col = col * 1.15 + base * 0.18;
    } else {
      squash = mix(0.8, 1.0, clamp(abs(ndv) * 1.6, 0.0, 1.0));
    }
  }
  if (puddle > 0.5) {
    g = pick(uRipple, int(mod(seed + floor(uTime * (1.0 + uRain * 9.0) + h1(seed) * 4.0), 4.0)));
    dir = vec2(1.0, 0.0); squash = 1.0;
  }
  if ((flags & 128) != 0) { float a = leafFl * 0.45; dir = vec2(dir.x * cos(a) - dir.y * sin(a), dir.x * sin(a) + dir.y * cos(a)); }
  if (hasAO && uWet > 0.15 && props.x > 0.5) {
    // gotas escorrendo: uma faixa brilhante desce pela placa
    float rv = fract(h1(seed * 1.7) + wp.y * 1.6 + uTime * (0.5 + uRain));
    if (rv < 0.035 * uWet * (0.4 + uRain)) { g = pick(uGlint, 0); col += vec3(0.5, 0.55, 0.65) * uWet; }
  }
  if (mk > 0.0 && !emissive && !fixedG && fract(seed * 0.7131) < mk * 0.55) {
    g = pick(uRim, int(mod(seed, 4.0)));
    dir = mv / max(mspeed, 1e-3);
    squash = 0.7;
    wp -= vel * 0.03 * fract(seed * 3.17);
  }
  // ── Tocha: densidade de caracteres. Perto da chama, todos; longe, vão rareando (limiar fixo por caractere:
  //    nada cintila quando a câmera se move). Só no escuro (uTorch.w já vem pesado pela luz do ambiente),
  //    e o que outra luz ilumina não some.
  float torchNear = 0.0;
  if (uTorch.w > 0.01 && bi == 0 && !emissive && !isWater) {
    float td = distance(wp, uTorch.xyz);
    float fall = smoothstep(uTorchR.x * 0.45, uTorchR.x * 1.75, td);
    float lit = clamp(lk * 1.6, 0.0, 1.0);
    float keep = 1.0 - uTorch.w * fall * 0.72 * (1.0 - lit);
    if (h1(iExtra.y * 0.7311 + 3.7) > keep) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return; }
    torchNear = uTorch.w * (1.0 - smoothstep(0.0, uTorchR.x, td));
    col += base * torchNear * 0.22;
  }
  // ── Personagens: contorno frio sutil e brilho mínimo no escuro/neblina (some de dia) ──
  bool actor = bi > 0 && !emissive && !isVeg;
  if (actor && uTorchR.y > 0.01) {
    float edge = pow(1.0 - clamp(abs(ndv), 0.0, 1.0), 2.6);
    col += vec3(0.42, 0.48, 0.62) * edge * 0.32 * uTorchR.y;
    col = max(col, base * 0.16 * uTorchR.y);
  }
  if (g < 0) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return; }
  // ── Névoa de distância e de chão ──
  float dist = distance(wp.xz, uFocus.xz);
  float fogA = 1.0 - exp(-max(dist - 4.0, 0.0) * uFog.a);
  fogA = clamp(fogA + clamp(0.35 - (wp.y - uFocus.y), 0.0, 0.35) * 0.35, 0.0, 0.9);
  if (actor) fogA *= 1.0 - 0.45 * uTorchR.y;          // a neblina não engole quem luta
  col = mix(col, uFog.rgb, fogA * 0.65);
  float alpha = (1.0 - fogA * 0.55) * mix(hasAO ? 0.82 : 0.62, 1.0, clamp(lum * 2.2, 0.0, 1.0));
  alpha = max(alpha, torchNear * 0.92);
  if (bi == 0 && !isWater) alpha = max(alpha, (isVeg ? 0.9 : 0.8) * (1.0 - fogA * 0.6));   // caracteres nítidos sobre o chão sólido
  float dcam = distance(uCam, wp);
  alpha *= smoothstep(2.2, 4.2, dcam) * waterA;
  // recorte: o que está entre a câmera e o cavaleiro fica translúcido em volta dele
  if (!hasAO && !(bi > 0)) {
    vec3 pc = uPlayer + vec3(0.0, 0.9, 0.0);
    vec4 pp = uVP * vec4(pc, 1.0);
    float dp = distance(uCam, pc);
    vec2 sd = (clip.xy / clip.w - pp.xy / pp.w) * vec2(uViewport.x / uViewport.y, 1.0);
    if (dcam < dp - 0.7) alpha *= mix(0.12, 1.0, smoothstep(0.22, 0.5, length(sd)));
  }
  if (alpha < 0.02) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return; }   // sombras mais translúcidas
  // ── Quad girado na direção da superfície ──
  vec4 cb = uVP * vec4(wp + V * uBias, 1.0);
  vec2 corner = vec2(aCorner.x, aCorner.y * squash) * px * 0.5;
  vec2 r = vec2(dir.x * corner.x - dir.y * corner.y, dir.y * corner.x + dir.x * corner.y);
  gl_Position = cb + vec4(r * 2.0 / uViewport * cb.w, 0.0, 0.0);
  vec2 cell = vec2(mod(float(g), uAtlasCols), floor(float(g) / uAtlasCols));
  vUV = (cell + (aCorner * vec2(0.5, -0.5) + 0.5)) / vec2(uAtlasCols, uAtlasRows);
  vColor = vec4(col * 1.35, alpha);
}`;

const FS = `#version 300 es
precision mediump float;
in vec2 vUV;
in vec4 vColor;
in float vDisc;
uniform sampler2D uAtlas;
uniform highp int uPass;
out vec4 o;
void main() {
  if (vDisc > 0.5) { if (dot(vUV, vUV) > 1.0) discard; o = vec4(0.0); return; }
  float a = texture(uAtlas, vUV).a * vColor.a;
  if (a < 0.03) discard;
  o = vec4(vColor.rgb * a, a);
}`;

// Partículas (fogo, brasas, cinzas, névoa): caracteres soltos no espaço, sem iluminação.
const PVS = `#version 300 es
precision highp float;
layout(location=0) in vec2 aCorner;
layout(location=1) in vec4 iPos;    // xyz, tamanho (m)
layout(location=2) in vec4 iCol;    // rgb, alfa
layout(location=3) in vec2 iGlyph;  // glifo, rotação
uniform mat4 uVP;
uniform vec2 uViewport;
uniform float uPxScale, uAtlasCols, uAtlasRows;
uniform vec4 uLightPos[${MAX_LIGHTS}];
uniform vec4 uLightCol[${MAX_LIGHTS}];
uniform int uNumLights, uLit;
uniform vec3 uAmbP;
out vec2 vUV; out vec4 vColor;
void main() {
  vec4 c = uVP * vec4(iPos.xyz, 1.0);
  float px = iPos.w * uPxScale / c.w;
  float cs = cos(iGlyph.y), sn = sin(iGlyph.y);
  vec2 k = aCorner * px * 0.5;
  vec2 r = vec2(cs * k.x - sn * k.y, sn * k.x + cs * k.y);
  gl_Position = c + vec4(r * 2.0 / uViewport * c.w, 0.0, 0.0);
  float g = iGlyph.x;
  vec2 cell = vec2(mod(g, uAtlasCols), floor(g / uAtlasCols));
  vUV = (cell + (aCorner * vec2(0.5, -0.5) + 0.5)) / vec2(uAtlasCols, uAtlasRows);
  vec3 c3 = iCol.rgb;
  if (uLit == 1) {               // cinzas, névoa e fumaça recebem a luz do fogo
    vec3 l = uAmbP;
    for (int i = 0; i < ${MAX_LIGHTS}; i++) {
      if (i >= uNumLights) break;
      float d = distance(uLightPos[i].xyz, iPos.xyz);
      float a = clamp(1.0 - d / uLightPos[i].w, 0.0, 1.0);
      l += uLightCol[i].rgb * a * a * 1.6;
    }
    c3 *= l;
  }
  vColor = vec4(c3, iCol.a);
}`;
const PFS = `#version 300 es
precision mediump float;
in vec2 vUV; in vec4 vColor;
uniform sampler2D uAtlas;
out vec4 o;
void main() {
  float a = texture(uAtlas, vUV).a * vColor.a;
  if (a < 0.01) discard;
  o = vec4(vColor.rgb * a, a);
}`;

// ─────────────── Sólidos: chão e construções (malhas sombreadas, texturas geradas aqui) ───────────────
const SVS = `#version 300 es
precision highp float;
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNrm;
layout(location=2) in float aMat;
layout(location=3) in vec3 aTint;
layout(location=4) in vec4 aW;
uniform mat4 uVP;
uniform vec3 uFocus;
uniform vec4 uWind;
uniform float uTime, uSinkR;
uniform highp int uPass;
uniform mat4 uLightVP;
uniform mat4 uBones[${MAX_BONES}];
out vec3 vPos; out vec3 vNrm; out vec3 vTint; out vec4 vW; flat out float vMat;
void main() {
  vec3 p = aPos, nn = aNrm;
  if (aMat >= 0.0 && aW.z > 0.5) {            // corpo de personagem: anda com o osso
    mat4 B = uBones[int(aW.y + 0.5)];
    p = (B * vec4(p, 1.0)).xyz; nn = normalize(mat3(B) * aNrm);
  }
  if (aMat < -1.5) {                          // terreno longe: afunda onde o perto já cobre
    float d = max(abs(p.x - uFocus.x), abs(p.z - uFocus.z));
    p.y -= 2.5 * (1.0 - smoothstep(uSinkR * 0.8, uSinkR, d)) + 0.15;
  }
  if (aMat >= 0.0 && aW.w > 0.5) {            // galhos balançam como as folhas
    float amt = pow(clamp((p.y - 0.8) / 4.5, 0.0, 1.0), 2.0);
    float ph = uTime * 1.25 + p.x * 0.6 + p.z * 0.45;
    vec2 sw = uWind.xy * uWind.z * (0.55 + 0.45 * sin(ph)) * 0.22;
    p += vec3(sw.x, -0.02 * length(sw), sw.y) * amt;
  }
  vPos = p; vNrm = nn; vTint = aTint; vW = aW; vMat = aMat;
  gl_Position = (uPass == 2 ? uLightVP : uVP) * vec4(p, 1.0);
}`;

const SFS = `#version 300 es
precision highp float;
precision highp sampler2DShadow;
in vec3 vPos; in vec3 vNrm; in vec3 vTint; in vec4 vW; flat in float vMat;
uniform highp int uPass;
uniform mat4 uVP, uLightVP;
uniform vec3 uCam, uFocus, uPlayer, uMoonDir, uMoonCol, uSky, uGround, uRimDir, uRimCol, uClear;
uniform vec4 uLightPos[${MAX_LIGHTS}];
uniform vec4 uLightCol[${MAX_LIGHTS}];
uniform int uNumLights, uPCF, uSQ;
uniform vec3 uMatColor[${NMAT}];
uniform vec3 uMatProps[${NMAT}];
uniform float uSClass[${NMAT}];
uniform vec4 uFog;
uniform vec2 uViewport;
uniform float uWet, uRain, uFlash, uTime, uSolidK, uWL;
uniform vec2 uTorchR;
uniform float uFade;
uniform sampler2DShadow uShadow;
out vec4 o;

float hs(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float hs3(vec3 p) { return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453); }
float vn2(vec2 p) { vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hs(i), hs(i + vec2(1, 0)), f.x), mix(hs(i + vec2(0, 1)), hs(i + vec2(1, 1)), f.x), f.y); }
float fbm(vec2 p) { float a = 0.5, s = 0.0; for (int i = 0; i < 4; i++) { if (i >= 2 + uSQ) break; s += a * vn2(p); p = p * 2.03 + 7.1; a *= 0.5; } return s; }
// células (pedras do chão, blocos): distância à borda mais próxima
vec3 cells(vec2 p) { vec2 i = floor(p), f = fract(p); float d1 = 9.0, d2 = 9.0; float id = 0.0;
  for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) { vec2 g = vec2(x, y), o = vec2(hs(i + g), hs(i + g + 3.1)); float d = length(g + o - f);
    if (d < d1) { d2 = d1; d1 = d; id = hs(i + g + 9.7); } else if (d < d2) d2 = d; }
  return vec3(d2 - d1, id, d1); }
// matriz de Bayer 4×4: recortes pontilhados estáveis (sem chuvisco)
float bayer(vec2 fc) { ivec2 p = ivec2(mod(fc, 4.0)); int i = p.x + p.y * 4;
  int b[16] = int[16](0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5); return (float(b[i]) + 0.5) / 16.0; }
// projeção triplanar: escolhe o plano pela normal
vec2 tri(vec3 p, vec3 n) { vec3 a = abs(n); return a.y > a.x && a.y > a.z ? p.xz : (a.x > a.z ? p.zy : p.xy); }

void main() {
  float bz = bayer(gl_FragCoord.xy);
  if (uFade < 0.999 && bz > uFade) discard;                                // morrendo: some junto com os caracteres
  if (uPass == 2) { o = vec4(1.0); return; }
  float dcam = distance(uCam, vPos);
  if (dcam < 3.0 && bz > smoothstep(1.4, 3.0, dcam)) discard;               // perto da câmera: some pontilhado
  bool terrain = vMat < -0.5;
  bool actor = !terrain && vW.z > 0.5;
  if (!terrain && !actor) {                                                // entre a câmera e o cavaleiro: janela pontilhada
    vec3 pc = uPlayer + vec3(0.0, 0.9, 0.0);
    if (dcam < distance(uCam, pc) - 0.7) {
      vec4 pp = uVP * vec4(pc, 1.0), cc = uVP * vec4(vPos, 1.0);
      float k = smoothstep(0.2, 0.48, length((cc.xy / cc.w - pp.xy / pp.w) * vec2(uViewport.x / uViewport.y, 1.0)));
      if (bz > max(k, 0.1)) discard;
    }
  }
  vec3 nV = normalize(vNrm);
  vec3 nF = normalize(cross(dFdx(vPos), dFdy(vPos))); if (dot(nF, nV) < 0.0) nF = -nF;
  vec3 n; vec3 base; float spec = 0.08, gloss = 18.0, wetMul = 1.0;
  bool groundLike = terrain;
  vec2 xz = vPos.xz;
  if (terrain) {
    // ── terreno: bioma (tom do vértice) + manchas de grama/terra + cascalho + rocha nas encostas + trilhas ──
    n = nV;
    float slope = 1.0 - n.y;
    float big = fbm(xz * 0.07), mid = vn2(xz * 0.9), fine = vn2(xz * 7.0), micro = vn2(xz * 23.0);
    // solo: terra batida com variações sutis (sem células), musgo escuro nas baixadas
    vec3 soil = mix(vec3(0.2, 0.16, 0.12), vec3(0.27, 0.21, 0.15), fbm(xz * 0.35));
    soil = mix(soil, vec3(0.16, 0.2, 0.11), smoothstep(0.55, 0.8, fbm(xz * 0.18 + 9.0)) * 0.6);
    // grama cobre quase tudo; a terra aparece em clareiras e trilhas
    float grassK = smoothstep(0.16, 0.4, big + (mid - 0.5) * 0.3);
    vec3 grass = vTint * (0.7 + 0.32 * mid) * (0.88 + 0.2 * fbm(xz * 1.3));
    grass = mix(grass, grass * vec3(1.12, 1.05, 0.7), smoothstep(0.6, 0.85, vn2(xz * 0.21)) * 0.5);   // tufos secos
    base = mix(soil, grass, grassK);
    base *= (0.86 + 0.18 * fine) * (0.93 + 0.12 * micro);
    base *= 0.8;                                                          // mais escuro (dark fantasy): os caracteres saltam
    // trilhas sinuosas (sobem menos nas encostas)
    float tr = abs(fbm(xz * 0.006 + 3.3) - 0.5);
    float path = smoothstep(0.016, 0.006, tr) * smoothstep(0.35, 0.15, slope);
    base = mix(base, vec3(0.3, 0.25, 0.18) * (0.85 + 0.25 * fine), path * 0.85);
    // rocha nas encostas e onde o bioma pede (triplanar)
    float rockK = clamp(max(vW.x, smoothstep(0.38, 0.62, slope + (mid - 0.5) * 0.2)), 0.0, 1.0);
    vec2 rp = tri(vPos, n) * 0.55;
    vec3 rock = vec3(0.34, 0.33, 0.35) * (0.72 + 0.32 * fbm(rp * 2.0)) * (0.88 + 0.18 * vn2(rp * 9.0));
    rock *= 0.85 + 0.15 * smoothstep(0.02, 0.1, abs(fbm(rp * 1.3 + 4.0) - 0.5));   // veios suaves
    base = mix(base, rock, rockK);
    base = mix(base, vec3(0.7, 0.62, 0.45) * (0.9 + 0.15 * sin(xz.x * 3.0 + vn2(xz * 0.5) * 6.0)), vW.y);   // areia
    base = mix(base, vec3(0.86, 0.9, 0.96) * (0.92 + 0.08 * fine), vW.z);                                    // neve
    base = mix(base, vec3(0.16, 0.13, 0.1) * (0.8 + 0.3 * mid), vW.w);                                      // lama
    spec = mix(0.05, 0.35, vW.w) + vW.z * 0.2; gloss = 20.0;
    if (vPos.y < uWL + 0.1) { base *= 0.55; spec = 0.3; }                // margem/fundo molhado
    // micro-relevo
    n = normalize(n + vec3(vn2(xz * 3.1) - 0.5, 0.0, vn2(xz * 3.1 + 5.0) - 0.5) * 0.25 * (1.0 - rockK * 0.5));
    if (abs(vPos.y - uWL) < 0.02) {                                       // lâmina d'água dos lagos
      base = vTint * (0.75 + 0.3 * vn2(xz * 0.6 + uTime * 0.05)); spec = 0.9; gloss = 90.0;
      n = normalize(vec3((vn2(xz * 1.3 + uTime * 0.3) - 0.5) * 0.14, 1.0, (vn2(xz * 1.3 + 5.0 - uTime * 0.25) - 0.5) * 0.14));
    }
  } else {
    int m = int(vMat + 0.5);
    base = uMatColor[m] * vTint;
    vec3 pr = uMatProps[m];
    spec = pr.x * 0.6 + 0.04; gloss = pr.z;
    int cls = int(uSClass[m] + 0.5);
    n = normalize(mix(nV, nF, cls == 4 || cls == 6 ? 0.2 : 0.65));       // construções: arestas mais secas
    vec2 t = tri(vPos, n);
    float fine = vn2(t * 9.0), mid = vn2(t * 1.7);
    if (cls == 1) {                // alvenaria: blocos em fiadas (paredes) / lajes (chão)
      bool flat_ = abs(n.y) > 0.7;
      vec2 q = flat_ ? t / vec2(0.7, 0.7) : vec2(t.x / 0.62, t.y / 0.31);
      q.x += flat_ ? 0.0 : floor(q.y) * 0.5;
      vec2 fq = fract(q), iq = floor(q);
      float mortar = min(min(fq.x, 1.0 - fq.x) * (flat_ ? 0.7 : 0.62), min(fq.y, 1.0 - fq.y) * (flat_ ? 0.7 : 0.31));
      float h = hs(iq);
      base *= (0.78 + 0.32 * h) * (0.85 + 0.25 * fine);
      base *= mix(0.45, 1.0, smoothstep(0.008, 0.03, mortar));
      base = mix(base, base * vec3(0.7, 0.9, 0.6), smoothstep(0.62, 0.8, fbm(vPos.xz * 0.8 + vPos.y)) * 0.5 * smoothstep(1.5, 0.0, vPos.y - uFocus.y + 1.0));   // musgo baixo
      groundLike = flat_ && n.y > 0.7;
    } else if (cls == 2) {         // madeira: tábuas e veios
      vec2 q = vec2(t.x * 5.0, t.y * 0.6);
      float plank = hs(vec2(floor(q.x), 1.0));
      float grain = sin((t.y * 18.0 + vn2(t * vec2(2.0, 14.0)) * 6.0)) * 0.5 + 0.5;
      base *= (0.75 + 0.3 * plank) * (0.82 + 0.22 * grain);
      base *= mix(0.6, 1.0, smoothstep(0.0, 0.06, min(fract(q.x), 1.0 - fract(q.x))));
    } else if (cls == 3) {         // metal: liso, gasto, com reflexo
      base *= 0.85 + 0.2 * fine;
      spec = max(spec, 0.6);
    } else if (cls == 4) {         // osso: poroso
      base *= 0.82 + 0.25 * vn2(t * 14.0);
    } else if (cls == 5) {         // tecido: trama
      base *= 0.85 + 0.15 * (sin(t.x * 160.0) * sin(t.y * 160.0) * 0.5 + 0.5);
    } else if (cls == 6) {         // chão de pedra solta / cascalho / terra
      vec3 cl = cells(t * 2.2);
      base *= (0.82 + 0.22 * cl.y) * (0.86 + 0.2 * fine) * (0.9 + 0.15 * fbm(t * 0.6));
      base *= mix(0.84, 1.0, smoothstep(0.0, 0.06, cl.x + (vn2(t * 9.0) - 0.5) * 0.06));   // juntas bem sutis
      base *= 0.85;
      groundLike = n.y > 0.7;
    } else if (cls == 8) {         // terra/areia/musgo: manchas, grãos e seixos (sem lajes)
      base *= (0.76 + 0.32 * fbm(vPos.xz * 0.45)) * (0.86 + 0.2 * fine) * (0.93 + 0.12 * vn2(t * 23.0));
      base = mix(base, base * vec3(0.7, 0.85, 0.6), smoothstep(0.55, 0.8, fbm(vPos.xz * 0.22 + 9.0)) * 0.45);   // musgo
      base *= 0.82;
      groundLike = n.y > 0.7;
    } else if (cls == 7) {         // palha
      base *= 0.7 + 0.4 * vn2(vec2(t.x * 40.0, t.y * 3.0));
    } else {
      base *= 0.85 + 0.2 * fine * mid + 0.1 * mid;
    }
  }
  // ── chuva: escurece, brilha e junta poças no chão ──
  float puddle = 0.0;
  if (uWet > 0.05) {
    if (groundLike) {
      float pz = vn2(xz * 0.55) * 0.7 + vn2(xz * 1.9 + 7.0) * 0.3;
      puddle = smoothstep(0.6, 0.66, pz + uWet * 0.1) * smoothstep(0.25, 0.7, uWet) * step(0.85, n.y);
    }
    base *= 1.0 - 0.35 * uWet;
    spec += 0.35 * uWet; gloss = max(gloss, 40.0 * uWet);
  }
  if (puddle > 0.0) { base = mix(base, vec3(0.05, 0.06, 0.08), puddle); spec = mix(spec, 1.0, puddle); gloss = mix(gloss, 120.0, puddle); n = normalize(mix(n, vec3(0.0, 1.0, 0.0), puddle)); }
  // ── luz (mesmo modelo dos caracteres) ──
  float sh = 1.0;
  vec4 lc = uLightVP * vec4(vPos + nV * 0.06, 1.0);
  vec3 lp = lc.xyz / lc.w * 0.5 + 0.5;
  if (lp.x > 0.0 && lp.x < 1.0 && lp.y > 0.0 && lp.y < 1.0) {
    float of = 1.0 / 2048.0; sh = 0.0;
    if (uPCF >= 2) { for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++) sh += texture(uShadow, vec3(lp.xy + vec2(float(i), float(j)) * of * 1.5, lp.z - 0.002)); sh /= 9.0; }
    else { for (int i = 0; i < 4; i++) sh += texture(uShadow, vec3(lp.xy + (vec2(i & 1, i >> 1) - 0.5) * of * 1.5, lp.z - 0.002)); sh /= 4.0; }
  }
  vec3 V = normalize(uCam - vPos);
  vec3 amb = mix(uGround, uSky, n.y * 0.5 + 0.5);
  float dm = max(dot(n, uMoonDir), 0.0);
  vec3 diff = uMoonCol * dm * sh;
  diff += vec3(0.78, 0.84, 1.0) * uFlash * 3.2 * dm * sh + vec3(0.25, 0.27, 0.34) * uFlash;
  vec3 H = normalize(uMoonDir + V);
  float gn = (gloss + 8.0) / 32.0;
  vec3 sp = uMoonCol * pow(max(dot(n, H), 0.0), gloss) * gn * spec * sh;
  float fres = pow(1.0 - clamp(dot(n, V), 0.0, 1.0), 4.0);
  sp += mix(uGround, uSky * 1.6, 0.6) * fres * spec * 0.35;
  if (puddle > 0.0) sp += uSky * 2.0 * (0.4 + fres) * puddle + uFlash * vec3(1.2, 1.3, 1.5) * puddle;
  diff += uRimCol * pow(1.0 - clamp(abs(dot(n, V)), 0.0, 1.0), 2.2) * max(dot(n, uRimDir), 0.0) * 0.35;
  for (int i = 0; i < ${MAX_LIGHTS}; i++) {
    if (i >= uNumLights) break;
    vec3 Lv = uLightPos[i].xyz - vPos;
    float d = length(Lv);
    float att = clamp(1.0 - d / uLightPos[i].w, 0.0, 1.0); att *= att;
    if (att <= 0.0) continue;
    vec3 L = Lv / d;
    diff += uLightCol[i].rgb * att * (max(dot(n, L), 0.0) * 0.95 + 0.1);
    sp += uLightCol[i].rgb * att * pow(max(dot(n, normalize(L + V)), 0.0), gloss) * gn * spec;
  }
  vec3 col = base * (amb + diff) + sp;
  // sombra de contato sob o cavaleiro
  if (vPos.y - uPlayer.y < 0.35) { vec2 dp = vPos.xz - uPlayer.xz; col *= 1.0 - 0.55 * exp(-dot(dp, dp) / 0.12); }
  col *= uSolidK;
  if (actor && uTorchR.y > 0.01) {                                         // personagem no escuro: contorno frio sutil
    float edge = pow(1.0 - clamp(abs(dot(n, V)), 0.0, 1.0), 2.6);
    col += vec3(0.42, 0.48, 0.62) * edge * 0.25 * uTorchR.y; col = max(col, base * 0.1 * uTorchR.y);
  }
  // ── névoa (igual aos caracteres) e o fundo ao longe ──
  float dist = distance(vPos.xz, uFocus.xz);
  float fogA = 1.0 - exp(-max(dist - 4.0, 0.0) * uFog.a);
  fogA = clamp(fogA + clamp(0.35 - (vPos.y - uFocus.y), 0.0, 0.35) * 0.3, 0.0, 0.92);
  col = mix(col, uFog.rgb * 0.9, fogA * 0.65);
  col = mix(col, uClear, fogA * 0.5);
  o = vec4(col, 1.0);
}`;

function compile(gl, type, src) {
  const s = gl.createShader(type);
  gl.shaderSource(s, src); gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) + '\n' + src.split('\n').map((l, i) => i + 1 + ': ' + l).join('\n').slice(0, 4000));
  return s;
}
function program(gl, vs, fs) {
  const p = gl.createProgram();
  gl.attachShader(p, compile(gl, gl.VERTEX_SHADER, vs)); gl.attachShader(p, compile(gl, gl.FRAGMENT_SHADER, fs));
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  const u = {}, n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
  for (let i = 0; i < n; i++) { const info = gl.getActiveUniform(p, i); const name = info.name.replace(/\[0\]$/, ''); u[name] = gl.getUniformLocation(p, info.name); }
  return { p, u };
}

export class GlyphRenderer {
  constructor(canvas, atlas) {
    const gl = canvas.getContext('webgl2', { antialias: false, alpha: false, premultipliedAlpha: true, powerPreference: 'high-performance', depth: true });
    if (!gl) throw new Error('WebGL2 indisponível');
    this.gl = gl; this.canvas = canvas; this.atlas = atlas;
    this.prog = program(gl, VS, FS);
    this.pprog = program(gl, PVS, PFS);
    // quad base
    this.quad = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    // atlas
    this.tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.tex);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, atlas.canvas);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    // sombra
    this.shadowSize = 2048;
    this.shadowTex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.shadowTex);
    gl.texStorage2D(gl.TEXTURE_2D, 1, gl.DEPTH_COMPONENT24, this.shadowSize, this.shadowSize);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_MODE, gl.COMPARE_REF_TO_TEXTURE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_FUNC, gl.LEQUAL);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    this.shadowFB = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.shadowFB);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, this.shadowTex, 0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    this.meshes = [];
    this.solids = [];
    this.sprog = program(gl, SVS, SFS);
    this.solidK = 0.74; this.solidQ = 1; this.sinkR = 60;
    this.lodNear = 4.5;          // até essa distância do cavaleiro, densidade total
    this.particles = null;
    this.stats = { glyphs: 0, particles: 0 };
  }

  /** Tira uma malha (blocos do mundo aberto que ficaram longe) — e o sólido preso a ela. */
  removeMesh(mesh) { const gl = this.gl; const i = this.meshes.indexOf(mesh); if (i >= 0) this.meshes.splice(i, 1); gl.deleteBuffer(mesh.buf); gl.deleteVertexArray(mesh.vao); mesh.data = null; if (mesh.solid) { this.removeSolid(mesh.solid); mesh.solid = null; } }

  /** Malha sólida (SolidGeom ou {v, idx, nv, ni}) → VAO com índices, em blocos espaciais (só os visíveis são desenhados). */
  addSolid(geom, { chunk = 16, castShadow = true, parent = null } = {}) {
    const gl = this.gl, v = geom.v, nv = geom.nv, ni = geom.ni;
    if (!nv || !ni) return null;
    // a mesma malha em vários personagens (mortos, goblins, aldeões): buffers na GPU compartilhados
    this._gpu = this._gpu || new Map();
    const shared = this._gpu.get(geom);
    if (shared) { shared.refs++; const s = { ...shared.s, visible: true, castShadow, parent, area: null, gpu: shared }; this.solids.push(s); return s; }
    // ordena os triângulos por bloco (pelo centro) → cada bloco é um intervalo do índice
    const nt = ni / 3, key = new Float64Array(nt), order = new Uint32Array(nt);
    for (let t = 0; t < nt; t++) {
      const a = geom.idx[t * 3] * VSTRIDE, b = geom.idx[t * 3 + 1] * VSTRIDE, c = geom.idx[t * 3 + 2] * VSTRIDE;
      const cx = (v[a] + v[b] + v[c]) / 3, cz = (v[a + 2] + v[b + 2] + v[c + 2]) / 3;
      key[t] = Math.floor(cx / chunk) * 100000 + Math.floor(cz / chunk); order[t] = t;
    }
    order.sort((x, y) => key[x] - key[y]);
    const idx = new Uint32Array(ni), chunks = [];
    let start = 0;
    for (let k = 0; k <= nt; k++) {
      if (k < nt) { const t = order[k]; idx[k * 3] = geom.idx[t * 3]; idx[k * 3 + 1] = geom.idx[t * 3 + 1]; idx[k * 3 + 2] = geom.idx[t * 3 + 2]; }
      if (k === nt || (k > start && key[order[k]] !== key[order[start]])) {
        const b = [1e9, 1e9, 1e9, -1e9, -1e9, -1e9];
        for (let q = start * 3; q < k * 3; q++) { const o = idx[q] * VSTRIDE; for (let a = 0; a < 3; a++) { const x = v[o + a]; if (x < b[a]) b[a] = x; if (x > b[a + 3]) b[a + 3] = x; } }
        if (geom.far) { b[1] -= 3; }
        chunks.push({ off: start * 3, count: (k - start) * 3, box: b });
        start = k;
      }
    }
    const vao = gl.createVertexArray(); gl.bindVertexArray(vao);
    const vbuf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, vbuf); gl.bufferData(gl.ARRAY_BUFFER, v.subarray(0, nv * VSTRIDE), gl.STATIC_DRAW);
    const B = VSTRIDE * 4, at = (loc, size, off) => { gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, size, gl.FLOAT, false, B, off * 4); };
    at(0, 3, 0); at(1, 3, 3); at(2, 1, 6); at(3, 3, 7); at(4, 4, 10);
    const ibuf = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ibuf); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, idx, gl.STATIC_DRAW);
    gl.bindVertexArray(null);
    const s = { vao, vbuf, ibuf, chunks, tris: nt, visible: true, castShadow, parent, area: null, skinned: !!geom.skinned };
    s.gpu = { refs: 1, s: { vao, vbuf, ibuf, chunks, tris: nt, skinned: s.skinned }, geom };
    this._gpu.set(geom, s.gpu);
    this.solids.push(s);
    return s;
  }
  removeSolid(s) {
    if (!s) return; const gl = this.gl, i = this.solids.indexOf(s); if (i >= 0) this.solids.splice(i, 1);
    if (s.gpu && --s.gpu.refs > 0) return;
    if (s.gpu) this._gpu.delete(s.gpu.geom);
    gl.deleteBuffer(s.vbuf); gl.deleteBuffer(s.ibuf); gl.deleteVertexArray(s.vao);
  }
  addMesh(ps, { dynamic = false, bones = null, occlude = true, chunk = 0 } = {}) {
    const gl = this.gl;
    const n = ps.n, stride = 15;
    let data = new Float32Array(n * stride);
    this._fill(ps, data);
    let chunks = null;
    if (chunk > 0) {
      // ordena os pontos por bloco espacial → cada bloco é um intervalo contínuo no buffer
      const keyOf = i => Math.floor(data[i * 15] / chunk) * 1000 + Math.floor(data[i * 15 + 2] / chunk);
      const idx = Array.from({ length: n }, (_, i) => i).sort((a, b) => keyOf(a) - keyOf(b) || a - b);
      const sorted = new Float32Array(n * stride);
      idx.forEach((src, dst) => sorted.set(data.subarray(src * 15, src * 15 + 15), dst * 15));
      data = sorted;
      // dentro de cada bloco: ordem aleatória por grupos (os segmentos de um talo ficam juntos)
      const shuffleRange = (s0, s1) => {
        const groups = [];
        let k = s0;
        while (k < s1) {
          let e = k + 1;
          if (data[k * 15 + 12] & 8) while (e < s1 && (data[e * 15 + 12] & 8) && data[e * 15] === data[k * 15] && data[e * 15 + 2] === data[k * 15 + 2]) e++;
          groups.push([k, e]); k = e;
        }
        for (let i = groups.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [groups[i], groups[j]] = [groups[j], groups[i]]; }
        const tmp = new Float32Array((s1 - s0) * 15);
        let o = 0;
        for (const [a, b] of groups) { tmp.set(data.subarray(a * 15, b * 15), o); o += (b - a) * 15; }
        data.set(tmp, s0 * 15);
      };
      chunks = [];
      let start = 0;
      for (let i = 1; i <= n; i++) {
        if (i === n || keyOf(i) !== keyOf(start)) {
          const b = [1e9, 1e9, 1e9, -1e9, -1e9, -1e9];
          for (let k = start; k < i; k++) for (let a = 0; a < 3; a++) { const v = data[k * 15 + a]; if (v < b[a]) b[a] = v; if (v > b[a + 3]) b[a + 3] = v; }
          shuffleRange(start, i);
          chunks.push({ start, count: i - start, box: b });
          start = i;
        }
      }
    }
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, data, dynamic ? gl.DYNAMIC_DRAW : gl.STATIC_DRAW);
    const B = 4 * stride;
    const at = (loc, size, off) => { gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, size, gl.FLOAT, false, B, off * 4); gl.vertexAttribDivisor(loc, 1); };
    at(1, 3, 0); at(2, 3, 3); at(3, 3, 6); at(4, 4, 9); at(5, 2, 13);
    gl.bindVertexArray(null);
    const mesh = { vao, buf, n, data, dynamic, bones: bones || [m4.ident()], visible: true, castShadow: occlude, occlude, chunks };
    this.meshes.push(mesh);
    if (ps.solid && ps.solid.nv) mesh.solid = this.addSolid(ps.solid, { parent: mesh, chunk: ps.solid.skinned ? 1e6 : 16 });
    return mesh;
  }

  _fill(ps, data) {
    for (let i = 0; i < ps.n; i++) {
      const o = i * 15;
      data[o] = ps.pos[i * 3]; data[o + 1] = ps.pos[i * 3 + 1]; data[o + 2] = ps.pos[i * 3 + 2];
      data[o + 3] = ps.nrm[i * 3]; data[o + 4] = ps.nrm[i * 3 + 1]; data[o + 5] = ps.nrm[i * 3 + 2];
      data[o + 6] = ps.tan[i * 3]; data[o + 7] = ps.tan[i * 3 + 1]; data[o + 8] = ps.tan[i * 3 + 2];
      data[o + 9] = ps.attr[i * 4]; data[o + 10] = ps.attr[i * 4 + 1]; data[o + 11] = ps.attr[i * 4 + 2]; data[o + 12] = ps.attr[i * 4 + 3];
      data[o + 13] = ps.extra[i * 2]; data[o + 14] = ps.extra[i * 2 + 1];
    }
  }

  /** Atualiza posições/normais de uma malha dinâmica (capa). */
  updateMesh(mesh, ps) {
    this._fill(ps, mesh.data);
    const gl = this.gl;
    gl.bindBuffer(gl.ARRAY_BUFFER, mesh.buf);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, mesh.data, 0, ps.n * 15);
  }

  setupParticles(max = 3000) {
    const gl = this.gl;
    this.pmax = max;
    this.pdata = new Float32Array(max * 10);
    this.pvao = gl.createVertexArray();
    gl.bindVertexArray(this.pvao);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    this.pbuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.pbuf);
    gl.bufferData(gl.ARRAY_BUFFER, this.pdata.byteLength, gl.DYNAMIC_DRAW);
    const at = (loc, size, off) => { gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 40, off * 4); gl.vertexAttribDivisor(loc, 1); };
    at(1, 4, 0); at(2, 4, 4); at(3, 2, 8);
    gl.bindVertexArray(null);
  }

  resize(scale = 1) {
    const dpr = Math.min(window.devicePixelRatio || 1, 3) * scale;
    const w = Math.round(window.innerWidth * dpr), h = Math.round(window.innerHeight * dpr);
    if (this.canvas.width !== w || this.canvas.height !== h) { this.canvas.width = w; this.canvas.height = h; }
    this.canvas.style.width = window.innerWidth + 'px'; this.canvas.style.height = window.innerHeight + 'px';
    this.W = w; this.H = h; this.dpr = dpr;
  }

  _common(u, f) {
    const gl = this.gl;
    gl.uniformMatrix4fv(u.uVP, false, f.vp);
    gl.uniform2f(u.uViewport, this.W, this.H);
    gl.uniform1f(u.uPxScale, f.pxScale);
    gl.uniform1f(u.uAtlasCols, this.atlas.cols);
    gl.uniform1f(u.uAtlasRows, this.atlas.rows);
  }

  /** Desenha um quadro. f = parâmetros da cena (câmera, luzes, névoa...). */
  frame(f) {
    const gl = this.gl, { p, u } = this.prog;
    gl.useProgram(p);
    this._common(u, f);
    // sombra: pode ser refeita só a cada N quadros (o mapa antigo continua valendo com a matriz dele)
    const shadowRefresh = f.shadowRefresh !== false || !this.shadowVP;
    if (shadowRefresh) this.shadowVP = f.lightVP;
    gl.uniformMatrix4fv(u.uLightVP, false, this.shadowVP);
    gl.uniform3fv(u.uCam, f.cam);
    gl.uniform3fv(u.uFocus, f.focus);
    gl.uniform1f(u.uGlyph, f.glyphScale);
    gl.uniform1f(u.uExposure, f.exposure || 10);
    gl.uniform1f(u.uTime, f.time);
    gl.uniform1f(u.uShadowSize, f.shadowSize);
    gl.uniform3fv(u.uMoonDir, f.moonDir); gl.uniform3fv(u.uMoonCol, f.moonCol);
    gl.uniform3fv(u.uSky, f.sky); gl.uniform3fv(u.uGround, f.ground);
    gl.uniform3fv(u.uRimDir, f.rimDir || [0, 0.3, -1]); gl.uniform3fv(u.uRimCol, f.rimCol || [0, 0, 0]);
    gl.uniform4fv(u.uArena, f.arena || [0, 0, 0, 0]); gl.uniform3fv(u.uArenaKeep, f.arenaKeep || [0, 0, 0]);
    gl.uniform1f(u.uWet, f.wet || 0); gl.uniform1f(u.uRain, f.rain || 0); gl.uniform1f(u.uFlash, f.flash || 0);
    // blocos de uniformes reaproveitados a cada quadro (zerados antes de preencher: nada sobra do quadro/lugar anterior)
    const B = this._ub || (this._ub = { lp: new Float32Array(MAX_LIGHTS * 4), lc: new Float32Array(MAX_LIGHTS * 4), lb: new Float32Array(MAX_LIGHTS * 4), tr: new Float32Array(MAX_TRAIL * 4) });
    const lp = B.lp, lc = B.lc, lb = B.lb, tr = B.tr;
    lp.fill(0); lc.fill(0); lb.fill(0); tr.fill(-100);
    const nl = Math.min(MAX_LIGHTS, f.lights.length);
    for (let i = 0; i < nl; i++) {
      const l = f.lights[i], o = i * 4;
      lp[o] = l.pos[0]; lp[o + 1] = l.pos[1]; lp[o + 2] = l.pos[2]; lp[o + 3] = l.radius;
      lc[o] = l.col[0] * l.value; lc[o + 1] = l.col[1] * l.value; lc[o + 2] = l.col[2] * l.value; lc[o + 3] = 1;
      lb[o] = l.col[0] * l.base; lb[o + 1] = l.col[1] * l.base; lb[o + 2] = l.col[2] * l.base; lb[o + 3] = 1;
    }
    gl.uniform4fv(u.uLightPos, lp); gl.uniform4fv(u.uLightCol, lc); gl.uniform4fv(u.uLightBase, lb);
    const trail = f.trail || [], nt = Math.min(MAX_TRAIL, trail.length);
    for (let i = 0; i < nt; i++) { const t = trail[i], o = i * 4; tr[o] = t[0]; tr[o + 1] = t[1]; tr[o + 2] = t[2]; tr[o + 3] = 0; }
    gl.uniform4fv(u.uTrail, tr);
    gl.uniform1i(u.uNumLights, Math.min(MAX_LIGHTS, f.lights.length));
    if (!this._matSet) {
      gl.uniform3fv(u.uMatColor, new Float32Array(MATERIALS.flatMap(m => m.c)));
      gl.uniform3fv(u.uMatProps, new Float32Array(MATERIALS.flatMap(m => [m.spec || 0, m.emissive || 0, m.gloss || 24])));
      gl.uniform4iv(u.uRamp, new Int32Array(this.atlas.rampTable()));
      gl.uniform4iv(u.uRim, new Int32Array(['─', '━', '─', '═'].map(c => this.atlas.get(c))));
      gl.uniform4iv(u.uVeg, new Int32Array(VEG.map(c => this.atlas.get(c))));
      gl.uniform4iv(u.uGlint, new Int32Array(GLINT.map(c => this.atlas.get(c))));
      gl.uniform4iv(u.uRipple, new Int32Array(['≈', '~', '-', '·'].map(c => this.atlas.get(c))));
      gl.uniform4iv(u.uWaterG, new Int32Array(['~', '≈', '∼', '~'].map(c => this.atlas.get(c))));
      gl.uniform4iv(u.uFoamG, new Int32Array(['°', '*', '·', '⁎'].map(c => this.atlas.get(c))));
      this._matSet = true;
    }
    gl.uniform4f(u.uFog, f.fog[0], f.fog[1], f.fog[2], f.fog[3]);
    gl.uniform1i(u.uPCF, this.pcf || 1);
    gl.uniform4f(u.uWind, f.wind[0], f.wind[1], f.wind[2], 0);
    gl.uniform3fv(u.uPlayer, f.focus);
    const tc = f.torch || NO_TORCH; gl.uniform4f(u.uTorch, tc[0], tc[1], tc[2], tc[3]); gl.uniform2f(u.uTorchR, f.torchR || 5, f.actorLift || 0);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.tex); gl.uniform1i(u.uAtlas, 0);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, null);
    gl.uniform1i(u.uShadow, 1);
    let drawn = 0;
    const draw = (mesh, M) => {
      gl.uniformMatrix4fv(u.uBones, false, mesh.boneData || (mesh.boneData = flatBones(mesh.bones, mesh.boneData)));
      gl.uniform4fv(u.uBoneVel, mesh.velData || ZERO_V); gl.uniform4fv(u.uBoneAng, mesh.angData || ZERO_V);
      gl.uniform1f(u.uSizeMul, mesh.sizeMul || 1);
      gl.bindVertexArray(mesh.vao);
      if (!mesh.chunks) { const c = Math.min(mesh.n, mesh.drawCount || mesh.n); gl.drawArraysInstanced(gl.TRIANGLE_STRIP, 0, 4, c); drawn += c; mesh.lastDrawn = c; return; }
      mesh.lastDrawn = 0;
      // só os blocos dentro do volume de visão (da câmera ou da luz)
      gl.bindBuffer(gl.ARRAY_BUFFER, mesh.buf);
      for (const c of mesh.chunks) {
        if (!boxVisible(M, c.box, 0.6)) continue;
        const cx = (c.box[0] + c.box[3]) / 2, cz = (c.box[2] + c.box[5]) / 2;
        const dd = Math.max(0.1, Math.hypot(cx - f.focus[0], cz - f.focus[2]) - 1.5);
        const frac = mesh.noLod ? 1 : Math.max(this.lodMin || 0.2, Math.min(1, Math.pow(this.lodNear / dd, 1.8))) * (this.densK || 1);
        const cnt = Math.max(1, Math.round(c.count * frac));
        gl.uniform1f(u.uSizeMul, (mesh.sizeMul || 1) * Math.min(1.9, 1 / Math.sqrt(frac)));
        const o = c.start * 60;
        gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 60, o); gl.vertexAttribPointer(2, 3, gl.FLOAT, false, 60, o + 12);
        gl.vertexAttribPointer(3, 3, gl.FLOAT, false, 60, o + 24); gl.vertexAttribPointer(4, 4, gl.FLOAT, false, 60, o + 36);
        gl.vertexAttribPointer(5, 2, gl.FLOAT, false, 60, o + 52);
        gl.drawArraysInstanced(gl.TRIANGLE_STRIP, 0, 4, cnt);
        drawn += cnt; mesh.lastDrawn += cnt;
      }
    };
    // 1) sombra do luar
    if (shadowRefresh) {
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.shadowFB);
    gl.viewport(0, 0, this.shadowSize, this.shadowSize);
    gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LESS); gl.depthMask(true); gl.colorMask(false, false, false, false);
    gl.clear(gl.DEPTH_BUFFER_BIT);
    gl.disable(gl.BLEND);
    gl.uniform1i(u.uPass, 2);
    if (f.shadows) for (const m of this.meshes) if (m.visible && (!m.area || m.area === this.area) && m.castShadow) draw(m, f.lightVP);
    if (f.shadows && this.solids.length) { this._solids(f, 2, lp, lc); gl.useProgram(p); }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    }
    gl.viewport(0, 0, this.W, this.H);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, this.shadowTex);
    // 2) oclusão invisível
    gl.clearColor(f.clear[0], f.clear[1], f.clear[2], 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    // 1b) sólidos: chão e construções (opacos, gravam profundidade; os caracteres vêm por cima)
    this.stats.tris = 0;
    if (this.solids.length) { this._solids(f, 0, lp, lc); gl.useProgram(p); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.tex); gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, this.shadowTex); }
    gl.uniform1i(u.uPass, 1);
    for (const m of this.meshes) if (m.visible && (!m.area || m.area === this.area) && m.occlude) draw(m, f.vp);
    // 3) caracteres
    gl.colorMask(true, true, true, true);
    gl.depthMask(false); gl.depthFunc(gl.LEQUAL);
    gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    gl.uniform1i(u.uPass, 0);
    gl.uniform1f(u.uBias, f.bias);
    drawn = 0;
    for (const m of this.meshes) if (m.visible && (!m.area || m.area === this.area)) draw(m, f.vp);
    this.stats.glyphs = drawn;
    // 4) partículas
    if (f.particles && f.particles.count) {
      const P = this.pprog;
      gl.useProgram(P.p);
      this._common(P.u, f);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.tex); gl.uniform1i(P.u.uAtlas, 0);
      gl.bindVertexArray(this.pvao);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.pbuf);
      const ps = f.particles;
      gl.uniform4fv(P.u.uLightPos, lp); gl.uniform4fv(P.u.uLightCol, lc);
      gl.uniform1i(P.u.uNumLights, Math.min(MAX_LIGHTS, f.lights.length));
      gl.uniform3f(P.u.uAmbP, 0.55, 0.58, 0.72);
      gl.uniform1i(P.u.uLit, 1);
      // névoa/cinzas: alfa normal; fogo/brasas: aditivo
      gl.bufferSubData(gl.ARRAY_BUFFER, 0, ps.data, 0, ps.count * 10);
      gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
      gl.drawArraysInstanced(gl.TRIANGLE_STRIP, 0, 4, ps.normalCount);
      if (ps.count > ps.normalCount) {
        gl.uniform1i(P.u.uLit, 0);
        gl.blendFunc(gl.ONE, gl.ONE);
        gl.vertexAttribPointer(1, 4, gl.FLOAT, false, 40, ps.normalCount * 40);
        gl.vertexAttribPointer(2, 4, gl.FLOAT, false, 40, ps.normalCount * 40 + 16);
        gl.vertexAttribPointer(3, 2, gl.FLOAT, false, 40, ps.normalCount * 40 + 32);
        gl.drawArraysInstanced(gl.TRIANGLE_STRIP, 0, 4, ps.count - ps.normalCount);
        gl.vertexAttribPointer(1, 4, gl.FLOAT, false, 40, 0);
        gl.vertexAttribPointer(2, 4, gl.FLOAT, false, 40, 16);
        gl.vertexAttribPointer(3, 2, gl.FLOAT, false, 40, 32);
      }
      this.stats.particles = ps.count;
    }
    gl.depthMask(true);
    gl.bindVertexArray(null);
  }
}

GlyphRenderer.prototype._solids = function (f, pass, lp, lc) {
  const gl = this.gl, { p, u } = this.sprog;
  gl.useProgram(p);
  if (!this._smatSet) {
    gl.uniform3fv(u.uMatColor, new Float32Array(MATERIALS.flatMap(m => m.c)));
    gl.uniform3fv(u.uMatProps, new Float32Array(MATERIALS.flatMap(m => [m.spec || 0, m.emissive || 0, m.gloss || 24])));
    const cls = new Float32Array(NMAT);
    const set = (k, ids) => { for (const i of ids) if (i != null) cls[i] = k; };
    set(1, [MAT.STONE, MAT.MARBLE]); set(2, [MAT.WOOD]); set(3, [MAT.STEEL, MAT.SILVER, MAT.GOLD, MAT.BLADE, MAT.IRON, MAT.MAIL, MAT.BRONZE, MAT.BLUE]);
    set(4, [MAT.BONE]); set(5, [MAT.CLOTH, MAT.CLOTH_IN, MAT.ROYAL, MAT.LINEN, MAT.WOOL, MAT.LEATHER]); set(6, [MAT.GRAVEL]); set(8, [MAT.GROUND, MAT.SAND, MAT.SNOW, MAT.MOSS, MAT.DARK]); set(7, [MAT.THATCH]);
    gl.uniform1fv(u.uSClass, cls);
    this._smatSet = true;
  }
  gl.uniform1i(u.uPass, pass); gl.uniform1i(u.uShadow, 1);
  gl.uniformMatrix4fv(u.uVP, false, f.vp); gl.uniformMatrix4fv(u.uLightVP, false, pass === 2 ? f.lightVP : this.shadowVP);
  gl.uniform3fv(u.uFocus, f.focus); gl.uniform4f(u.uWind, f.wind[0], f.wind[1], f.wind[2], 0); gl.uniform1f(u.uTime, f.time); gl.uniform1f(u.uSinkR, this.sinkR);
  if (pass === 0) {
    gl.uniform3fv(u.uCam, f.cam); gl.uniform3fv(u.uPlayer, f.focus);
    gl.uniform3fv(u.uMoonDir, f.moonDir); gl.uniform3fv(u.uMoonCol, f.moonCol); gl.uniform3fv(u.uSky, f.sky); gl.uniform3fv(u.uGround, f.ground);
    gl.uniform3fv(u.uRimDir, f.rimDir || [0, 0.3, -1]); gl.uniform3fv(u.uRimCol, f.rimCol || [0, 0, 0]); gl.uniform3f(u.uClear, f.clear[0], f.clear[1], f.clear[2]);
    gl.uniform4fv(u.uLightPos, lp); gl.uniform4fv(u.uLightCol, lc); gl.uniform1i(u.uNumLights, Math.min(MAX_LIGHTS, f.lights.length));
    gl.uniform1i(u.uPCF, this.pcf || 1); gl.uniform1i(u.uSQ, this.solidQ);
    gl.uniform4f(u.uFog, f.fog[0], f.fog[1], f.fog[2], f.fog[3]); gl.uniform2f(u.uViewport, this.W, this.H);
    gl.uniform1f(u.uWet, f.wet || 0); gl.uniform1f(u.uRain, f.rain || 0); gl.uniform1f(u.uFlash, f.flash || 0);
    gl.uniform1f(u.uSolidK, this.solidK); gl.uniform1f(u.uWL, f.waterLevel != null ? f.waterLevel : -1000);
    gl.uniform2f(u.uTorchR, f.torchR || 5, f.actorLift || 0);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, this.shadowTex); gl.uniform1i(u.uShadow, 1);
    gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LESS); gl.depthMask(true); gl.colorMask(true, true, true, true); gl.disable(gl.BLEND);
    gl.enable(gl.POLYGON_OFFSET_FILL); gl.polygonOffset(1.0, 2.0);
  }
  const M = pass === 2 ? f.lightVP : f.vp;
  let lastFade = -1;
  for (const s of this.solids) {
    const P = s.parent, on = P ? P.visible && (!P.area || P.area === this.area) : s.visible && (!s.area || s.area === this.area);
    if (!on || (pass === 2 && !s.castShadow)) continue;
    if (s.skinned) {
      gl.uniformMatrix4fv(u.uBones, false, P.boneData || (P.boneData = flatBones(P.bones, P.boneData)));
      const fade = !P.lodDraw && P.drawCount != null && P.n ? Math.min(1, P.drawCount / P.n) : 1;
      if (fade !== lastFade) { gl.uniform1f(u.uFade, fade); lastFade = fade; }
      if (fade <= 0.001) continue;
      if (!s.skinBox) { gl.bindVertexArray(s.vao); for (const c of s.chunks) gl.drawElements(gl.TRIANGLES, c.count, gl.UNSIGNED_INT, c.off * 4); if (pass === 0) this.stats.tris += s.tris; continue; }
    } else if (lastFade !== 1) { gl.uniform1f(u.uFade, 1); lastFade = 1; }
    gl.bindVertexArray(s.vao);
    for (const c of s.chunks) {
      if (!boxVisible(M, c.box, 0.5)) continue;
      gl.drawElements(gl.TRIANGLES, c.count, gl.UNSIGNED_INT, c.off * 4);
      if (pass === 0) this.stats.tris += c.count / 3;
    }
  }
  gl.bindVertexArray(null);
  if (pass === 0) { gl.disable(gl.POLYGON_OFFSET_FILL); gl.colorMask(false, false, false, false); }
};

/** Caixa (min/max no mundo) toca o volume de visão da matriz M? */
function boxVisible(M, b, pad) {
  let l = 0, r = 0, d = 0, t = 0, nn = 0, ff = 0;
  for (let i = 0; i < 8; i++) {
    const x = (i & 1 ? b[3] + pad : b[0] - pad), y = (i & 2 ? b[4] + pad : b[1] - pad), z = (i & 4 ? b[5] + pad : b[2] - pad);
    const cx = M[0] * x + M[4] * y + M[8] * z + M[12], cy = M[1] * x + M[5] * y + M[9] * z + M[13];
    const cz = M[2] * x + M[6] * y + M[10] * z + M[14], cw = M[3] * x + M[7] * y + M[11] * z + M[15];
    if (cx < -cw) l++; if (cx > cw) r++; if (cy < -cw) d++; if (cy > cw) t++; if (cz < -cw) nn++; if (cz > cw) ff++;
  }
  return !(l === 8 || r === 8 || d === 8 || t === 8 || nn === 8 || ff === 8);
}

const ZERO_V = new Float32Array(MAX_BONES * 4);
/** Junta as matrizes dos ossos num bloco só. Com `out` (o bloco do quadro anterior), reaproveita a memória. */
export function flatBones(bones, out) {
  const d = out && out.length === MAX_BONES * 16 ? out : new Float32Array(MAX_BONES * 16);
  for (let i = 0; i < MAX_BONES; i++) d.set(bones[i] || bones[0], i * 16);
  return d;
}
export { MAX_BONES };
