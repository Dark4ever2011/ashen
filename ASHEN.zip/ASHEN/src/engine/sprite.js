// ASHEN — Sprites tipográficos
// Uma "arte" é uma lista de células {col,row,ch,w,fg,bg}. Pode vir de:
//  - parseArt(): texto + grade de materiais (arte desenhada à mão, fácil de editar no celular)
//  - TypoGrid: pintura procedural (arquitetura, árvores, rochas)
// composeParts() junta várias artes com deslocamentos fracionários num canvas em cache.

import { layoutRow, charWidth } from './typography.js';
import { matColor, MATERIALS, resolveShade } from './palette.js';
import { makeCanvas, canvasBytes } from './canvas.js';


const MIRROR_PAIRS = ['/\\', '()', '[]', '{}', '<>', '╱╲', '┌┐', '└┘', '├┤', '╔╗', '╚╝', '╠╣', '▌▐', '▖▗', '▘▝',
  '▙▟', '▛▜', '◢◣', '◤◥', '◀▶', '«»', '⌐¬', '╭╮', '╰╯', '╒╕', '╘╛', '╓╖', '╙╜', '▏▕', '◜◝', '◟◞', '⟨⟩',
  '┍┑', '┕┙', '┎┒', '┖┚', '╞╡', '╟╢', '┝┥', '◖◗', '⌜⌝', '⌞⌟', '▞▚', '⸌⸍', 'ˎˏ', '‹›', '⁅⁆', '╲╱', '╭╮'];
const MIRROR = {};
for (const p of MIRROR_PAIRS) { const [a, b] = [...p]; MIRROR[a] = b; MIRROR[b] = a; }

export function mirrorChar(ch) { return MIRROR[ch] || ch; }

/**
 * Converte arte textual em células.
 * def = { g: [linhas de glifos], m: [linhas de materiais], b: [linhas de fundo opcionais],
 *         fg: material padrão, bg: material de fundo padrão (ou null), ox, oy }
 * Material '.' = célula transparente. Fundo ' ' = automático (usa def.bg), '.' = sem fundo.
 */
// Regras do fundo automático: o glifo só ganha fundo se a parte "vazia" dele
// estiver dentro da silhueta (há vizinhos daquele lado). Assim as bordas continuam recortadas.
const NEED = {};
for (const c of '▄▂▃▁▅▆▇▖▗') NEED[c] = 'A';
for (const c of '▀▔▘▝') NEED[c] = 'B';
for (const c of '▌▏▎▍▋▊▉') NEED[c] = 'R';
for (const c of '▐▕') NEED[c] = 'L';
NEED['▟'] = 'LA'; NEED['▙'] = 'RA'; NEED['▛'] = 'RB'; NEED['▜'] = 'LB';
NEED['▚'] = 'X'; NEED['▞'] = 'X';
for (const c of '╱╲/\\◢◣◤◥()<>') NEED[c] = 'LR';

export function parseArt(def) {
  const cells = [];
  const g = def.g, m = def.m || [], b = def.b || [];
  let w = 0;
  const errors = [];
  const rows = g.map(s => layoutRow(s));
  for (const r of rows) w = Math.max(w, r.width);
  const occ = rows.map(r => { const a = new Uint8Array(w + 2); for (const c of r.cells) if (c.ch !== ' ') { a[c.col] = 1; if (c.w === 2) a[c.col + 1] = 1; } return a; });
  const at = (r, c) => r >= 0 && r < rows.length && c >= 0 && c < w && occ[r][c] === 1;
  for (let r = 0; r < rows.length; r++) {
    const row = rows[r];
    const mr = m[r] || '', br = b[r] || '';
    for (const c of row.cells) {
      // Dígitos = sombreamento de gravura (ver SHADE_STYLES).
      if (def.style && c.ch >= '0' && c.ch <= '5') {
        let lv = +c.ch;
        if (def.invert && lv) lv = 6 - lv;
        const sh = resolveShade(def.style, lv, c.col + (def.shadeShift || 0), r);
        if (sh) { cells.push({ col: c.col, row: r, ch: sh.ch, w: 1, fg: matColor(sh.fg), bg: matColor(sh.bg) }); continue; }
      }
      let code = mr[c.col];
      if (!code || code === ' ') code = def.fg || 'k';
      if (code === '.') continue;
      if (!MATERIALS[code]) { errors.push(`material '${code}' inválido em (${c.col},${r})`); code = 'k'; }
      const bgc = br[c.col];
      let bg = null;
      if (bgc === '.') bg = null;
      else if (bgc && bgc !== ' ') { if (MATERIALS[bgc]) bg = matColor(bgc); else errors.push(`fundo '${bgc}' inválido em (${c.col},${r})`); }
      else if (def.bg) {
        const L = at(r, c.col - 1), Rr = at(r, c.col + c.w), Ab = at(r - 1, c.col), Be = at(r + 1, c.col);
        let ok;
        if (c.ch === ' ') {
          let l = false, rr = false;
          for (let q = c.col - 1; q >= 0; q--) if (occ[r][q]) { l = true; break; }
          for (let q = c.col + 1; q < w; q++) if (occ[r][q]) { rr = true; break; }
          ok = l && rr;
        } else {
          const need = NEED[c.ch];
          if (!need) ok = (L && Rr) || (Ab && Be);
          else if (need === 'X') ok = false;
          else ok = [...need].every(k => k === 'L' ? L : k === 'R' ? Rr : k === 'A' ? Ab : Be);
        }
        if (ok) bg = matColor(def.bg);
      }
      if (c.ch === ' ' && !bg) continue;
      cells.push({ col: c.col, row: r, ch: c.ch, w: c.w, fg: matColor(code), bg });
    }
  }
  if (errors.length && typeof console !== 'undefined') console.warn('[ASHEN] arte', def.name || '', errors.slice(0, 5));
  return { cells, w, h: g.length, ox: def.ox || 0, oy: def.oy || 0, name: def.name || '', errors };
}

/** Grade tipográfica para pintura procedural. Cada célula: glifo, cor de frente, cor de fundo. */
export class TypoGrid {
  constructor(w, h) {
    this.w = w; this.h = h;
    this.chs = new Array(w * h).fill(' ');
    this.fg = new Array(w * h).fill(null);
    this.bg = new Array(w * h).fill(null);
    this.cont = new Uint8Array(w * h); // 1 = continuação de glifo largo
  }
  inside(x, y) { return x >= 0 && y >= 0 && x < this.w && y < this.h; }
  _clearWideAt(i, x) {
    if (this.cont[i]) { this.cont[i] = 0; if (x > 0) { this.chs[i - 1] = ' '; } }
    else if (x + 1 < this.w && this.cont[i + 1]) { this.cont[i + 1] = 0; }
  }
  set(x, y, ch, fg, bg) {
    x |= 0; y |= 0;
    if (!this.inside(x, y)) return;
    const i = y * this.w + x;
    const wide = charWidth(ch.codePointAt(0)) === 2;
    this._clearWideAt(i, x);
    this.chs[i] = ch;
    if (fg !== undefined) this.fg[i] = fg;
    if (bg !== undefined) this.bg[i] = bg;
    if (wide && x + 1 < this.w) {
      const j = i + 1;
      this._clearWideAt(j, x + 1);
      this.chs[j] = ''; this.cont[j] = 1;
      if (bg !== undefined) this.bg[j] = bg;
    }
  }
  setBg(x, y, bg) { x |= 0; y |= 0; if (this.inside(x, y)) this.bg[y * this.w + x] = bg; }
  setFg(x, y, fg) { x |= 0; y |= 0; if (this.inside(x, y)) this.fg[y * this.w + x] = fg; }
  get(x, y) { x |= 0; y |= 0; return this.inside(x, y) ? this.chs[y * this.w + x] : null; }
  getBg(x, y) { x |= 0; y |= 0; return this.inside(x, y) ? this.bg[y * this.w + x] : null; }
  isEmpty(x, y) { const i = (y | 0) * this.w + (x | 0); return !this.inside(x, y) || (this.chs[i] === ' ' && !this.bg[i] && !this.cont[i]); }
  text(x, y, str, fg, bg) {
    let cx = x;
    for (const ch of str) { const w = charWidth(ch.codePointAt(0)); if (ch !== ' ') this.set(cx, y, ch, fg, bg); cx += w; }
  }
  toArt(ox = 0, oy = 0) {
    const cells = [];
    for (let y = 0; y < this.h; y++) for (let x = 0; x < this.w; x++) {
      const i = y * this.w + x;
      if (this.cont[i]) continue;
      const ch = this.chs[i];
      const bg = this.bg[i];
      if (ch === ' ' && !bg) continue;
      const w = ch && charWidth(ch.codePointAt(0)) === 2 ? 2 : 1;
      cells.push({ col: x, row: y, ch: ch || ' ', w, fg: this.fg[i] || '#888', bg });
    }
    return { cells, w: this.w, h: this.h, ox, oy };
  }
}

/** Pinta uma arte num contexto. (px,py) = canto da célula (0,0) em pixels. */
export function paintArt(ctx, painter, art, px, py, opts = {}) {
  const cw = painter.cw, ch = painter.ch;
  const mirror = !!opts.mirror;
  const W = opts.mirrorW ?? art.w;
  const tone = opts.tone ?? 1;
  const tint = tone === 1 ? null : tone;
  let n = 0;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  for (const c of art.cells) {
    if (!c.bg) continue;
    const col = mirror ? W - c.col - c.w : c.col;
    const x0 = Math.round(px + col * cw), y0 = Math.round(py + c.row * ch);
    const x1 = Math.round(px + (col + c.w) * cw), y1 = Math.round(py + (c.row + 1) * ch);
    ctx.fillStyle = tint ? toneHex(c.bg, tint) : c.bg;
    ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
  }
  for (const c of art.cells) {
    if (c.ch === ' ' || c.ch === '') continue;
    const col = mirror ? W - c.col - c.w : c.col;
    const g = mirror ? mirrorChar(c.ch) : c.ch;
    painter.paint(ctx, g, c.w, px + col * cw, py + c.row * ch, tint ? toneHex(c.fg, tint) : c.fg);
    n++;
  }
  painter.end(ctx);
  return n;
}

/**
 * Pinta uma arte girada em torno de um pivô (em células da arte). Cada glifo gira junto.
 * (cx,cy) = posição do pivô em pixels. sy = escorço ao longo do eixo vertical da arte.
 */
export function paintArtRotated(ctx, painter, art, cx, cy, pivotCol, pivotRow, angle, opts = {}) {
  const cw = painter.cw, ch = painter.ch;
  const sy = opts.sy ?? 1;
  const tone = opts.tone ?? 1;
  const cos = Math.cos(angle), sin = Math.sin(angle);
  for (const pass of [0, 1]) {
    for (const c of art.cells) {
      const u = (c.col + c.w / 2 - pivotCol) * cw;
      const v = (c.row + 0.5 - pivotRow) * ch * sy;
      const x = cx + u * cos - v * sin;
      const y = cy + u * sin + v * cos;
      if (pass === 0) {
        if (c.bg) painter.paintRotated(ctx, '█', c.w, x, y, angle, tone === 1 ? c.bg : toneHex(c.bg, tone), sy);
      } else if (c.ch !== ' ' && c.ch !== '') {
        painter.paintRotated(ctx, c.ch, c.w, x, y, angle, tone === 1 ? c.fg : toneHex(c.fg, tone), sy);
      }
    }
  }
  painter.end(ctx);
}

const toneCache = new Map();
export function toneHex(hex, t) {
  const k = hex + t;
  let v = toneCache.get(k);
  if (v) return v;
  const n = parseInt(hex.slice(1), 16);
  const f = x => Math.max(0, Math.min(255, Math.round(x * t))).toString(16).padStart(2, '0');
  v = '#' + f((n >> 16) & 255) + f((n >> 8) & 255) + f(n & 255);
  toneCache.set(k, v);
  return v;
}

/**
 * Compõe várias partes num canvas. Coordenadas em células, fracionárias permitidas.
 * parts: [{ art, x, y, mirror?, tone? } | { draw(ctx, toPx) }]
 * bounds: {x0,y0,x1,y1} em células relativas à âncora (0,0 = pés).
 * Retorna { canvas, ax, ay, w, h } onde (ax,ay) é a âncora em pixels dentro do canvas.
 */
export function composeParts(painter, parts, bounds) {
  const cw = painter.cw, ch = painter.ch;
  const pad = 2;
  const w = Math.ceil((bounds.x1 - bounds.x0) * cw) + pad * 2;
  const h = Math.ceil((bounds.y1 - bounds.y0) * ch) + pad * 2;
  const canvas = makeCanvas(w, h);
  const ctx = canvas.getContext('2d');
  const ax = pad - bounds.x0 * cw, ay = pad - bounds.y0 * ch;
  const toPx = (cx, cy) => [ax + cx * cw, ay + cy * ch];
  let glyphs = 0;
  for (const p of parts) {
    if (!p) continue;
    if (p.draw) { glyphs += p.draw(ctx, toPx, painter) || 0; continue; }
    const art = p.art;
    const [px, py] = toPx(p.x + (art.ox || 0), p.y + (art.oy || 0));
    glyphs += paintArt(ctx, painter, art, px, py, { mirror: p.mirror, tone: p.tone });
  }
  painter.end(ctx);
  return { canvas, ax, ay, w, h, glyphs };
}

/** Renderiza uma arte inteira num canvas próprio (âncora definida em células). */
export function renderArt(painter, art, anchorCol, anchorRow, opts = {}) {
  // Recorta ao conteúdo real (árvores e rochas têm muita margem vazia na grade).
  let c0 = 1e9, r0 = 1e9, c1 = -1e9, r1 = -1e9;
  for (const c of art.cells) { if (c.col < c0) c0 = c.col; if (c.row < r0) r0 = c.row; if (c.col + c.w > c1) c1 = c.col + c.w; if (c.row + 1 > r1) r1 = c.row + 1; }
  if (c1 < c0) { c0 = 0; r0 = 0; c1 = 1; r1 = 1; }
  return composeParts(painter, [{ art, x: -anchorCol, y: -anchorRow, mirror: opts.mirror, tone: opts.tone }],
    { x0: c0 - anchorCol - 0.5, y0: r0 - anchorRow - 0.5, x1: c1 - anchorCol + 0.5, y1: Math.max(r1, anchorRow) - anchorRow + 0.5 });
}

/** Silhueta preta (para sombras projetadas). */
export function makeSilhouette(sprite, color = '#000') {
  const c = makeCanvas(sprite.w, sprite.h);
  const x = c.getContext('2d');
  x.drawImage(sprite.canvas, 0, 0);
  x.globalCompositeOperation = 'source-in';
  x.fillStyle = color;
  x.fillRect(0, 0, sprite.w, sprite.h);
  return { canvas: c, ax: sprite.ax, ay: sprite.ay, w: sprite.w, h: sprite.h };
}

/** Cache LRU de composições, invalidado quando a escala de renderização muda. */
export class SpriteCache {
  constructor(limit = 96) { this.limit = limit; this.map = new Map(); this.version = -1; this.hits = 0; this.misses = 0; }
  sync(version) { if (version !== this.version) { this.map.clear(); this.version = version; } }
  get(key, build) {
    let v = this.map.get(key);
    if (v) { this.map.delete(key); this.map.set(key, v); this.hits++; return v; }
    this.misses++;
    v = build();
    this.map.set(key, v);
    if (this.map.size > this.limit) this.map.delete(this.map.keys().next().value);
    return v;
  }
  bytes() { let b = 0; for (const v of this.map.values()) b += canvasBytes(v.canvas) + (v.over ? canvasBytes(v.over.canvas) : 0); return b; }
}
