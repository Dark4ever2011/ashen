// Close do protagonista: frente, 3/4, lado e costas (para comparar com a folha de referência).
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await browser.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 2.625, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
page.on('pageerror', e => console.log('[pageerror]', e.message));
await page.goto('http://localhost:8123/prototipo3d.html');
await page.waitForFunction(() => window.__ASHEN3D && window.__ASHEN3D.ready, null, { timeout: 120000 });
await page.evaluate(() => { const g = window.__ASHEN3D; g.CAM.dist = 4.6; g.CAM.pitch = 0.22; document.querySelectorAll('#p3-top,#touch,#btn-run').forEach(e => e.style.display = 'none'); const p = g.player; p.x = 1.6; p.z = 1.5; g.cam.x = 1.6; g.cam.z = 1.5; document.querySelector('#p3-perf').style.display = 'none'; });
for (const [name, yaw] of [['frente', 0.27], ['tres-quartos', 0.27 + 0.7], ['lado', 0.27 + 1.57], ['costas', 0.27 + 3.14]]) {
  await page.evaluate(y => { window.__ASHEN3D.player.yaw = y; }, yaw);
  await page.waitForTimeout(1800);
  await page.screenshot({ path: `/tmp/k-${name}.png`, clip: { x: 300, y: 0, width: 315, height: 412 } });
}
await browser.close();
// golpe: quadros do preparo, do corte e da recuperação
const b2 = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const pg = await (await b2.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 2.625, isMobile: true, hasTouch: true })).newPage();
pg.on('pageerror', e => console.log('[pageerror]', e.message));
await pg.goto('http://localhost:8123/prototipo3d.html');
await pg.waitForFunction(() => window.__ASHEN3D && window.__ASHEN3D.ready, null, { timeout: 120000 });
await pg.evaluate(() => { const g = window.__ASHEN3D; g.CAM.dist = 4.6; g.CAM.pitch = 0.22; const p = g.player; p.x = 1.6; p.z = 1.5; g.cam.x = 1.6; g.cam.z = 1.5; p.yaw = 0.9; document.querySelectorAll('#p3-top,#touch,#btn-run,#p3-perf').forEach(e => e.style.display = 'none'); });
await pg.waitForTimeout(1500);
for (const [n, t] of [['preparo', 0.3], ['corte', 0.5], ['fim', 0.68]]) {
  // congela o golpe num instante (o passo do jogo avança atk; fixamos a cada quadro)
  await pg.evaluate(t => { const g = window.__ASHEN3D; clearInterval(g._hold); g._hold = setInterval(() => { g.player.atk = t; }, 1); }, t);
  await pg.waitForTimeout(900);
  await pg.screenshot({ path: `/tmp/k-atk-${n}.png`, clip: { x: 300, y: 0, width: 315, height: 412 } });
}
await b2.close();
