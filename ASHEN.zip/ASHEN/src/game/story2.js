// ASHEN — Região II · Vale de Orvalho: falas, retratos em caracteres e a cena das ruínas.
// A vila viva é uma lembrança que a Chama mostra ao cavaleiro; o presente é cinza.

/** Retratos (rosto em caracteres). Cada linha tem a mesma largura. */
const F = s => s.replace(/^\n/, '').replace(/\n$/, '');
export const FACES = {
  bram: F(`
      _.--""""--._
    .'  ;;;;;;;;  '.
   /  ;;;;;;;;;;;;  \\
  |  ;;'        ';;  |
  | ;'  _      _  '; |
  | |  (o)    (o)  | |
  | |      /\\      | |
  |  \\    (__)    /  |
   \\  \\ ######## /  /
    '. ##########  .'
      '-.######.-'
        /|____|\\    `),
  oswin: F(`
       .-~~~~~~-.
     .'  ~~~~~~  '.
    /  .--------.  \\
   |  /          \\  |
   | |  -.    .-  | |
   | |  (•)  (•)  | |
   | |     ||     | |
   |  \\   ‿‿‿    /  |
    \\  '.______.'  /
     '.  ||||||  .'
       '-.||||.-'
        _/    \\_    `),
  maren: F(`
       .-''''''-.
     .' .------. '.
    / .'        '. \\
   | /  ~~    ~~  \\ |
   | |  (◦)  (◦)  | |
   | |     ¸      | |
   | |    ‿‿‿     | |
   |  \\          /  |
   |   '.______.'   |
    \\    |    |    /
     '.  |    |  .'
       '-|____|-'   `),
  ilsa: F(`
      .~~~~~~~~~~.
    .' ~~~~~~~~~~ '.
   / ~~.--------.~~ \\
  | ~ /          \\ ~ |
  | ~|  ‾‾    ‾‾  |~ |
  | ~|  (•)  (•)  |~ |
  | ~|     ¸      |~ |
  | ~|    ---     |~ |
   \\~ \\        / ~/
    '.~'.____.'~.'
      '-.|  |.-'
        _|  |_      `),
  pip: F(`

        ,;;;;;,
      ,;;;;;;;;;,
     ;;' .---. ';;
     ;  /     \\  ;
     | | o   o | |
     |  \\  ^  /  |
      \\  '-‿-'  /
       '-.___.-'
         /   \\
        /|   |\\
                    `),
  caedmon: F(`
     _______________
    /  ___________  \\
   |  |   _____   |  |
   |  |  | 誓  |  |  |
   |  |__|_____|__|  |
   |   ===========   |
   |   ‾‾‾‾‾‾‾‾‾‾‾   |
   |  ,   ‿‿‿   ,   |
    \\  '.  ,,  .'  /
     \\  ''''''''  /
      '-._ %% _.-'
       //  %%  \\\\   `),
  you: F(`
     _______________
    /   _________   \\
   |   /         \\   |
   |  |  ═══════  |  |
   |  |  ───────  |  |
   |  |    誓     |  |
   |   \\_________/   |
   |    |||||||||    |
    \\   |||||||||   /
     '._|||||||||_.'
        |=======|
       /|       |\\  `),
};
export const PEOPLE = {
  bram: { name: 'Bram, o ferreiro', face: 'bram', cls: 'p-bram' },
  oswin: { name: 'Oswin, o pastor', face: 'oswin', cls: 'p-oswin' },
  maren: { name: 'Maren, a tecelã', face: 'maren', cls: 'p-maren' },
  ilsa: { name: 'Ilsa', face: 'ilsa', cls: 'p-ilsa' },
  pip: { name: 'Pip', face: 'pip', cls: 'p-pip' },
  caedmon: { name: 'Ser Caedmon, da Ordem do Juramento', face: 'caedmon', cls: 'p-caedmon' },
  you: { name: 'Você', face: 'you', cls: 'p-you' },
};

/** Conversas dos aldeões (vila viva). */
export const TALKS = {
  bram: [
    ['bram', 'Um cavaleiro da Ordem! Faz tempo que ninguém atravessa o Portão do Rei.'],
    ['bram', 'Forjo ferraduras e pregos, nada que mate. Mas a sua espada… essa já viu guerra.'],
    ['bram', 'Dizem que o rei anda estranho, trancado com a Chama no alto da fortaleza. Bobagem, eu digo.'],
    ['bram', 'Enquanto a fogueira do vale arder, Orvalho não tem o que temer.'],
  ],
  oswin: [
    ['oswin', 'Calma, calma… as ovelhas se assustam com armadura.'],
    ['oswin', 'Ontem à noite os cães uivaram para o cemitério. A noite toda. Nunca fizeram isso.'],
    ['you', '…'],
    ['oswin', 'Deve ser lobo. Só pode ser lobo. Não é?'],
  ],
  maren: [
    ['maren', 'Que capa bonita, mesmo rasgada. Se quiser, eu remendo. Vinho é a cor da Ordem, não é?'],
    ['maren', 'Tecemos o estandarte do Juramento aqui mesmo, neste vale. O 誓 em fio de ouro.'],
    ['maren', 'Fique para o jantar. O pão sai quando o sino da igreja tocar.'],
  ],
  ilsa: [
    ['ilsa', 'Viu um menino de cabelo bagunçado por aí? É o Pip. Ele nunca para quieto.'],
    ['ilsa', 'O pai dele foi chamado para a fortaleza há três luas. Disse que voltava com a colheita.'],
    ['ilsa', 'Se o encontrar perto do poço, mande ele para casa. Por favor.'],
  ],
  pip: [
    ['pip', 'Uau! Você é um cavaleiro de verdade? Posso segurar a espada? Só um pouquinho?'],
    ['pip', 'Quando eu crescer vou entrar na Ordem. Vou jurar e nunca, nunca quebrar o juramento!'],
    ['pip', 'Mamãe diz que quem quebra a palavra vira cinza. Ela tá brava comigo de novo?'],
  ],
};
export const VILLAGERS = ['bram', 'oswin', 'maren', 'ilsa', 'pip'];

/** O cavaleiro ferido na igreja. */
export const KNIGHT_TALK = {
  first: [
    ['caedmon', '…Outro de nós? Achei que todos os Apagados tinham virado pó nos portões.'],
    ['caedmon', 'Sou Caedmon, da Ordem do Juramento. Guardei esta porta enquanto a vila morria.'],
    ['caedmon', 'Os mortos vieram do cemitério na noite em que o rei roubou a Chama. Eu não consegui salvar quase ninguém.'],
    ['caedmon', 'O menino, Pip… eu o mandei fugir pelo vale. Rezo para que tenha conseguido.'],
    ['caedmon', 'Minha ferida não fecha. Nas casas da vila deve haver alguma atadura de linho. Maren guardava panos em cestos.'],
    ['caedmon', 'Cuidado. Os mortos ainda se escondem lá dentro. Traga a atadura, e eu lhe darei o que me resta.'],
  ],
  waiting: [
    ['caedmon', 'As casas… procure nos cestos de pano. E não confie no escuro.'],
  ],
  done: [
    ['you', '(Você entrega a atadura de linho.)'],
    ['caedmon', 'Linho de Orvalho… ainda cheira à lã de Maren. Obrigado, irmão de juramento.'],
    ['caedmon', 'Tome. É o meu trevo de ferro. Minha mãe dizia que ele acha o que está perdido.'],
    ['caedmon', 'Com ele você vai encontrar mais coisas nos destroços. Vá. Eu vou descansar um pouco.'],
  ],
  after: [
    ['caedmon', 'Ainda estou aqui. Ainda respiro. Que o seu juramento queime mais que o meu.'],
  ],
};

export const PALACE = {
  name: 'Palácio da Vigília',
  wake: 'Mármore frio sob as costas. Nenhum som, nenhuma poeira. Como se o tempo tivesse parado aqui dentro.',
  rooms: { hall: 'Grande Salão', chapel: 'Capela da Rainha', treasure: 'Sala do Tesouro', throne: 'Sala do Trono' },
  throne: 'O trono da Rainha Ysolde. O assento ainda guarda um calor que não vem de lugar nenhum.',
  chapel: 'Sobre o altar, uma coroa de flores de ferro. Nenhuma pétala caiu.',
  treasure: 'Ouro, cálices e coroas, tudo intocado. Ninguém saqueou o palácio. Ninguém sequer entrou.',
  hall: 'As velas dos lustres queimam sem diminuir. A cera nunca escorre.',
};
export const VALLEY = {
  faint: ['A vista escurece. Os rostos se desfazem em cinza…', 'Quando os olhos se abrem, Orvalho não existe mais. Só restaram ruínas e silêncio.'],
  ruin: [
    'Esta era Orvalho, a última vila fiel ao Juramento. Aqui a Chama ainda aquecia as casas.',
    'Quando o Primeiro Rei roubou a Chama, os mortos do vale deixaram de descansar.',
    'Numa única noite, eles vieram do cemitério. Os aldeões correram para a igreja. Nem todos chegaram.',
    'Os que caíram se levantaram de novo. Foram eles que você acabou de libertar.',
    'Mas alguém ainda guarda a porta da igreja. Uma respiração fraca ecoa lá dentro.',
  ],
  door: 'A porta está emperrada. Ouve-se, lá dentro, só o vento.',
  churchLocked: 'As portas de carvalho estão trancadas. Lá dentro, alguém canta baixinho.',
  churchBarred: 'Algo se move entre as ruínas. Não é hora de rezar.',
  basketEmpty: 'Panos podres, cinzas e ossinhos de rato. Nenhuma atadura aqui.',
  basketTaken: 'O cesto está vazio.',
  bandage: 'Atadura de Linho — um rolo limpo, guardado com cuidado no fundo do cesto.',
  amulet: 'Trevo de Ferro — amuleto da sorte: +5% de chance de achar itens nos destroços.',
  key: 'Chave do Portão do Rei — fria e pesada. O selo 王 do rei está gravado no cabo.',
  gateOpen: 'O Portão do Rei está aberto.',
  spider: ['Algo desce do alto da noite, preso a um único fio de teia…'],
  kidnap: [
    'A Tecelã se desfaz em cinza. Por um instante, o vale inteiro fica em silêncio.',
    'Atrás de você, um vulto sem rosto: «Ainda carrega o juramento… então ela vai querer vê-lo.»',
    'O chão some. Mãos frias, um cheiro de cera e mármore… e depois, nada.',
  ],
  throne: [
    'Este é o Palácio da Vigília. Aqui vivia Ysolde, a rainha do Primeiro Rei.',
    'Quando o rei roubou a Chama, a rainha entendeu antes de todos: o juramento estava quebrado.',
    'Ela acendeu a própria brasa e selou o palácio. Lá dentro, o tempo parou: nada apodrece, nada envelhece.',
    'Depois saiu sozinha pelo reino em pedaços, atrás das brasas da Chama. Nunca voltou. Só o vulto guarda a porta.',
    'Lá fora, o Reino Partido se estende até as montanhas. As brasas esperam. O seu juramento também.',
  ],
  fireText: 'Uma fogueira de viajantes, ainda viva. Aqui você pode descansar — e é aqui que despertará se cair no vale.',
  quest: 'Missão: encontre uma atadura de linho nas casas abandonadas.',
  questDone: 'Leve a atadura a Ser Caedmon, na igreja.',
};
