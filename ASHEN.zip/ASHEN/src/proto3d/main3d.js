// ASHEN 3D — Protótipo da Etapa A.
// Mundo 3D real (pátio + cavaleiro), câmera fixa 3/4 que acompanha o cavaleiro,
// renderização exclusivamente tipográfica em WebGL2. Física em passo fixo (60 Hz).

import { loadFonts } from '../engine/typography.js';
import { Input } from '../engine/input.js';
import { m4, v3 } from './math3d.js';
import { GlyphAtlas } from './glyphs.js';
import { GlyphRenderer, flatBones } from './renderer3d.js';
import { buildParts } from './sampler.js';
import { knightParts, poseKnight, Cape } from './knight3d.js';
import { sceneParts, groundParts, COLLIDERS, BOUNDS, LIGHTS, WALL_Z } from './scene3d.js';
import { FX } from './fx3d.js';
import { buildVegetation } from './veg3d.js';
import { isPath } from './scene3d.js';

const $ = id => document.getElementById(id);
const STEP = 1 / 60;
const CAM = { yaw: 0.27, pitch: 0.74, dist: 7.0, fov: 32 * Math.PI / 180 };
const QUALITY = { alta: { dpr: 2.75, fx: 1 }, eq: { dpr: 2.0, fx: 0.8 }, des: { dpr: 1.5, fx: 0.55 } };

const game = window.__ASHEN3D = {
  ready: false, t: 0, quality: 'alta', showPerf: true,
  player: { x: 0.4, z: 2.4, vx: 0, vz: 0, yaw: 0.35, phase: 0, blend: 0, run: 0, breath: 0 },
  cam: { x: 0.4, z: 2.4 },
};

function setStep(p, text) { $('bar').firstElementChild.style.width = Math.round(p * 100) + '%'; if (text) $('p3-step').textContent = text; }

async function boot() {
  await loadFonts('assets/fonts/');
  setStep(0.05, 'gerando o atlas de caracteres…');
  const atlas = new GlyphAtlas(64, 32);
  // garante que todo caractere usado nas peças esteja no atlas antes de enviar para a GPU
  const sParts = sceneParts(), gParts = groundParts(), kParts = knightParts();
  for (const p of [...sParts, ...kParts]) for (const d of p.decals || []) atlas.get(d.glyph);
  ['│', '─', '╲', '∴', '•', '◆', '§'].forEach(c => atlas.get(c));
  const fx = new FX(atlas);
  atlas.build();
  const canvas = $('gl');
  let R;
  try { R = new GlyphRenderer(canvas, atlas); } catch (e) { throw new Error('Este navegador não oferece WebGL2: ' + e.message); }
  game.R = R; game.atlas = atlas; game.fx = fx;
  setStep(0.1, 'esculpindo o pátio em caracteres…');
  const ground = await buildParts(gParts, atlas, { seed: 7, sizeMul: 2.1 });
  const scene = await buildParts(sParts, atlas, { seed: 101, sizeMul: 2.1, onProgress: (f, n) => setStep(0.1 + f * 0.55, `pátio: ${n}`) });
  setStep(0.66, 'forjando a armadura…');
  const knight = await buildParts(kParts, atlas, { seed: 17, sizeMul: 2.2, onProgress: (f, n) => setStep(0.66 + f * 0.26, `cavaleiro: ${n}`) });
  const veg = buildVegetation({ count: 980, avoid: (x, z) => isPath(x, z) || z < WALL_Z + 0.4 || COLLIDERS.some(c => c.type === 'circle' && Math.hypot(x - c.x, z - c.z) < c.r + 0.1) });
  ground.append(veg.ps);
  game.vegInfo = { tufts: veg.tufts, plants: veg.plants, blades: veg.ps.n };
  game.groundMesh = R.addMesh(ground, { occlude: false, chunk: 3 });
  game.sceneMesh = R.addMesh(scene, { chunk: 2.5 });
  game.knightMesh = R.addMesh(knight);
  game.cape = new Cape(atlas);
  game.cape._emit();
  game.capeMesh = R.addMesh(game.cape.ps, { dynamic: true });
  game.counts = { scene: scene.n + ground.n, knight: knight.n, cape: game.cape.ps.n };
  R.setupParticles(2600);
  fx.addFire([-1.45, 1.12, 1.35], 0.3, 170, 0.12);
  fx.addFire([-2.1, 2.3, WALL_Z + 0.3], 0.06, 32);
  fx.addFire([2.1, 2.3, WALL_Z + 0.3], 0.06, 32);
  game.lights = LIGHTS.map(l => ({ ...l, value: l.base }));
  // entrada (a mesma do jogo 2D)
  const input = game.input = new Input(canvas);
  input.attachStick($('stick-zone'), $('stick-base'), $('stick-knob'));
  input.attachButton($('btn-run'), 'run');
  const touch = matchMedia('(pointer: coarse)').matches || navigator.maxTouchPoints > 0;
  $('touch').classList.toggle('hidden', !touch);
  document.body.classList.toggle('touch-ui', touch);
  document.addEventListener('touchmove', e => e.cancelable && e.preventDefault(), { passive: false });
  // qualidade
  const setQ = q => { game.quality = q; for (const [id, k] of [['q-alta', 'alta'], ['q-eq', 'eq'], ['q-des', 'des']]) $(id).setAttribute('aria-pressed', String(k === q)); resize(); fx.density = QUALITY[q].fx; };
  $('q-alta').onclick = () => setQ('alta'); $('q-eq').onclick = () => setQ('eq'); $('q-des').onclick = () => setQ('des');
  $('perf-btn').onclick = () => { game.showPerf = !game.showPerf; $('perf-btn').setAttribute('aria-pressed', String(game.showPerf)); $('p3-perf').classList.toggle('hidden', !game.showPerf); };
  window.addEventListener('resize', resize);
  resize();
  setStep(1, '');
  $('p3-load').classList.add('hidden');
  game.ready = true;
  requestAnimationFrame(frame);
}

function resize() {
  const q = QUALITY[game.quality];
  const dpr = Math.min(window.devicePixelRatio || 1, q.dpr);
  game.R.resize(dpr / (window.devicePixelRatio || 1));
}

// ─────────────── Física e controle ───────────────
function collide(p, r) {
  for (const c of COLLIDERS) {
    if (c.type === 'circle') {
      const dx = p.x - c.x, dz = p.z - c.z, d = Math.hypot(dx, dz), rr = r + c.r;
      if (d < rr && d > 1e-6) { p.x = c.x + dx / d * rr; p.z = c.z + dz / d * rr; }
    } else {
      const qx = Math.max(c.x0, Math.min(p.x, c.x1)), qz = Math.max(c.z0, Math.min(p.z, c.z1));
      const dx = p.x - qx, dz = p.z - qz, d = Math.hypot(dx, dz);
      if (d < r) { if (d > 1e-6) { p.x = qx + dx / d * r; p.z = qz + dz / d * r; } else p.z = c.z1 + r; }
    }
  }
  p.x = Math.max(BOUNDS.x0, Math.min(BOUNDS.x1, p.x)); p.z = Math.max(BOUNDS.z0 + r, Math.min(BOUNDS.z1, p.z));
}

function step(dt) {
  const g = game, p = g.player, st = g.input.poll();
  // direção da tela → direção no mundo (câmera fixa com leve giro)
  const fx = -Math.sin(CAM.yaw), fz = -Math.cos(CAM.yaw), rx = Math.cos(CAM.yaw), rz = -Math.sin(CAM.yaw);
  let wx = rx * st.mx + fx * -st.my, wz = rz * st.mx + fz * -st.my;
  const mag = Math.min(1, Math.hypot(st.mx, st.my));
  const wl = Math.hypot(wx, wz); if (wl > 0) { wx /= wl; wz /= wl; }
  const running = st.run && mag > 0.3;
  p.run += ((running ? 1 : 0) - p.run) * Math.min(1, dt * 4);
  const speed = (1.55 + 2.1 * p.run) * (st.analog ? Math.max(0.35, mag) : (mag > 0 ? 1 : 0));
  const tvx = wx * speed, tvz = wz * speed;
  const acc = mag > 0 ? 5.5 : 8;
  const dvx = tvx - p.vx, dvz = tvz - p.vz, dl = Math.hypot(dvx, dvz);
  if (dl > 0) { const k = Math.min(1, acc * dt / dl); p.vx += dvx * k; p.vz += dvz * k; }
  const ox = p.x, oz = p.z;
  p.x += p.vx * dt; p.z += p.vz * dt;
  collide(p, 0.34);
  const rvx = (p.x - ox) / dt, rvz = (p.z - oz) / dt, sp = Math.hypot(rvx, rvz);
  const moving = sp > 0.12;
  p.blend += ((moving ? 1 : 0) - p.blend) * Math.min(1, dt * (moving ? 6 : 4));
  if (p.blend < 0.01) p.blend = 0;
  // giro com peso: a armadura não vira instantaneamente
  if (moving) {
    const target = Math.atan2(rvx, rvz);
    let d = target - p.yaw; d = Math.atan2(Math.sin(d), Math.cos(d));
    p.yaw += d * Math.min(1, dt * 7);
  }
  const stride = 4 * (0.3 + 0.18 * p.run);
  if (moving) p.phase = (p.phase + sp * dt / stride) % 1;
  p.breath = (p.breath + dt / 3.6) % 1;
  // câmera: acompanha com suavização e antecipação
  const la = 0.35;
  const k = 1 - Math.exp(-dt * 4.5);
  g.cam.x += (p.x + rvx * la - g.cam.x) * k;
  g.cam.z += (p.z + rvz * la - g.cam.z) * k;
  g.t += dt;
  // luz do fogo: três frequências fora de fase + estalos aleatórios suavizados
  for (const l of g.lights) {
    const s = l.pos[0] * 3.1 + l.pos[2];
    const n = 0.5 + 0.25 * Math.sin(g.t * 9.7 + s) + 0.15 * Math.sin(g.t * 23.1 + s * 2) + 0.1 * Math.sin(g.t * 3.3 + s * 0.5);
    l.pop = (l.pop || 0) * 0.9 + (Math.random() < 0.02 ? 0.35 : 0);
    l.value = l.base * (1 - l.flicker * n + l.pop * 0.25);
  }
  // vento: direção que gira devagar e força em rajadas
  const wa = 0.35 + 0.5 * Math.sin(g.t * 0.05) + 0.15 * Math.sin(g.t * 0.21);
  const wsd = 0.55 + 0.3 * Math.sin(g.t * 0.17) + 0.15 * Math.sin(g.t * 0.53 + 1.3);
  g.wind = [Math.cos(wa), Math.sin(wa), wsd];
  g.fx.wind = [g.wind[0] * wsd * 0.7, 0, g.wind[1] * wsd * 0.7];
  g.fx.update(dt, g.t, [g.cam.x, 0, g.cam.z]);
  g.moving = sp;
}

// ─────────────── Quadro ───────────────
let last = 0, acc = 0, fps = 60, frameMs = 16, cpuMs = 0, perfT = 0;
function frame(now) {
  requestAnimationFrame(frame);
  if (last && now - last < 1000 / 60 - 2) return;           // limite de 60 FPS (tela de 120 Hz do A56)
  const dt = last ? Math.min(0.1, (now - last) / 1000) : STEP;
  if (last) { frameMs += ((now - last) - frameMs) * 0.08; fps = 1000 / frameMs; }
  last = now;
  const t0 = performance.now();
  acc += dt;
  let n = 0;
  while (acc >= STEP && n < 4) { step(STEP); acc -= STEP; n++; }
  if (n >= 4) acc = 0;
  render(dt);
  cpuMs += (performance.now() - t0 - cpuMs) * 0.1;
  if (game.showPerf && now - perfT > 300) {
    perfT = now;
    const R = game.R, c = game.counts;
    $('p3-perf').textContent = `FPS ${Math.round(fps)} · CPU ${cpuMs.toFixed(1)} ms · na tela ${R.stats.glyphs.toLocaleString('pt-BR')}
caracteres: ${(c.scene + c.knight + c.cape).toLocaleString('pt-BR')} (pátio ${c.scene.toLocaleString('pt-BR')} · cavaleiro ${c.knight.toLocaleString('pt-BR')} · capa ${c.cape})
vegetação: ${game.vegInfo.tufts} tufos · ${game.vegInfo.plants} plantas · ${game.vegInfo.blades} segmentos
partículas ${R.stats.particles} · ${R.W}×${R.H} px`;
  }
}

function render(dtFrame = 1 / 60) {
  const g = game, R = g.R, p = g.player;
  // cavaleiro: pose → ossos no mundo
  const W = m4.mul(m4.translate(p.x, 0, p.z), m4.rotY(p.yaw));
  const pose = poseKnight(p);
  const bones = pose.map(b => m4.mul(W, b));
  bones[0] = m4.ident();
  g.knightMesh.boneData = flatBones(bones);
  // capa: presa ao peito, colide com o corpo
  const chestW = bones[2];
  const spheres = [
    { c: m4.point(chestW, [0, 0.18, -0.02]), r: 0.25 }, { c: m4.point(chestW, [0, -0.02, -0.02]), r: 0.22 },
    { c: m4.point(bones[1], [0, -0.1, -0.02]), r: 0.22 },
    { c: m4.point(bones[10], [0, -0.2, 0]), r: 0.12 }, { c: m4.point(bones[13], [0, -0.2, 0]), r: 0.12 },
    { c: m4.point(bones[11], [0, -0.2, 0]), r: 0.09 }, { c: m4.point(bones[14], [0, -0.2, 0]), r: 0.09 },
  ];
  const sub = Math.min(4, Math.max(1, Math.round(dtFrame * 60)));
  for (let i = 0; i < sub; i++) g.cape.update(dtFrame / sub, chestW, spheres, [g.fx.wind[0] * 2.2 - p.vx * 0.9, 0, g.fx.wind[2] - p.vz * 0.9]);
  R.updateMesh(g.capeMesh, g.cape.ps);
  // câmera fixa 3/4
  const target = [g.cam.x, 0.95, g.cam.z - 0.2];
  const eye = [target[0] + Math.sin(CAM.yaw) * Math.cos(CAM.pitch) * CAM.dist, target[1] + Math.sin(CAM.pitch) * CAM.dist, target[2] + Math.cos(CAM.yaw) * Math.cos(CAM.pitch) * CAM.dist];
  const view = m4.lookAt(eye, target, [0, 1, 0]);
  const proj = m4.perspective(CAM.fov, R.W / R.H, 1, 60);
  const vp = m4.mul(proj, view);
  // luar: sombra ortográfica em volta do cavaleiro
  const moonDir = v3.norm([-0.5, 0.78, 0.38]);
  const half = 11;
  const lc = [g.cam.x, 0, g.cam.z - 1];
  const lightView = m4.lookAt(v3.add(lc, v3.mul(moonDir, 25)), lc, [0, 1, 0]);
  const lightVP = m4.mul(m4.ortho(-half, half, -half, half, 1, 60), lightView);
  const parts = g.fx.fill();
  R.frame({
    vp, lightVP, cam: eye, focus: [p.x, 0, p.z], time: g.t,
    pxScale: proj[5] * R.H / 2, glyphScale: 1, bias: 0.06, exposure: 11, shadowSize: 0.55 / half, shadows: true,
    moonDir, moonCol: [0.62, 0.68, 0.9], sky: [0.16, 0.17, 0.23], ground: [0.07, 0.06, 0.06],
    lights: g.lights, wind: g.wind || [1, 0, 0.5], fog: [0.05, 0.05, 0.07, 0.07], clear: [0.022, 0.019, 0.028], particles: parts,
  });
}

boot().catch(e => { console.error(e); $('p3-err').textContent = 'Erro: ' + e.message; });
