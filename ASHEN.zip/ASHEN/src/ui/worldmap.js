// ASHEN — Mapa do mundo (Reino Partido), desenhado em caracteres.
// Relevo sombreado, água, florestas, montanhas; névoa de guerra (128×128, salva no save) que se abre
// conforme o cavaleiro explora; fogueiras e lugares só aparecem depois de vistos; corcel e jogador (com
// a direção do olhar). Arrastar com um dedo, pinça para zoom, duplo toque para centralizar.

import { heightAt, biome, OWO, OW_HALF, OW_WL, OW_FIRE, LANDMARKS, SITES } from '../game/ow.js';

const N = 128;                       // névoa: células de (2·HALF / N) m
const CELLS = 170;                   // mapa: CELLS × CELLS caracteres
const PX = 10;                       // px por caractere no mapa base
const REVEAL = 70;                   // raio revelado em volta do cavaleiro (m)
const SITE_NAMES = { church: 'Igreja do Profano', village: 'Vau do Moinho', her: 'Casa de Elowen', crypt: 'Mausoléu da Cripta' };

const b64e = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 4096) s += String.fromCharCode.apply(null, u8.subarray(i, i + 4096)); return btoa(s); };
const b64d = s => { const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };

export class WorldMap {
  constructor(g) {
    this.g = g; this.open = false;
    this.fog = new Uint8Array(N * N);
    const sv = g.savedData && g.savedData.mapFog;
    if (sv) try { const u = b64d(sv); if (u.length === N * N) this.fog = u; } catch (e) { /* save antigo */ }
    this.seen = new Set((g.savedData && g.savedData.mapSeen) || []);
    (g.saveHooks = g.saveHooks || []).push(() => ({ mapFog: b64e(this.fog), mapSeen: [...this.seen] }));
    this.zoom = 1; this.cx = 0; this.cz = 0; this.t = 0;
    this._dom();
  }
  _dom() {
    const d = this.el = document.createElement('div');
    d.id = 'worldmap'; d.className = 'hidden';
    d.innerHTML = `<canvas></canvas>
      <div class="wm-head"><b>O Reino Partido</b><span>割れた王国</span></div>
      <div class="wm-btns"><button data-a="in" type="button">+</button><button data-a="out" type="button">−</button><button data-a="me" type="button">◎</button><button data-a="close" type="button">✕</button></div>
      <div class="wm-leg"><i style="color:#ff9a3c">火</i> fogueira · <i style="color:#e8e2d0">◆</i> lugar · <i style="color:#c9d2e6">♞</i> corcel · <i style="color:#fff">▲</i> você</div>`;
    document.body.appendChild(d);
    const st = document.createElement('style');
    st.textContent = `#worldmap{position:fixed;inset:0;z-index:40;background:#000;touch-action:none;font-family:ui-monospace,Menlo,Consolas,monospace}
      #worldmap.hidden{display:none}#worldmap canvas{position:absolute;inset:0;width:100%;height:100%}
      #worldmap .wm-head{position:absolute;left:16px;top:10px;color:#d8cfb8;letter-spacing:.12em;pointer-events:none}#worldmap .wm-head span{margin-left:10px;color:#a8873f}
      #worldmap .wm-btns{position:absolute;right:12px;top:10px;display:flex;gap:8px}
      #worldmap .wm-btns button{min-width:44px;min-height:44px;background:rgba(10,9,12,.8);border:1px solid #3b3228;color:#e8dcc0;font-size:20px}
      #worldmap .wm-leg{position:absolute;left:16px;bottom:10px;color:#8d8576;font-size:13px;pointer-events:none}`;
    document.head.appendChild(st);
    this.cv = d.querySelector('canvas');
    d.querySelector('.wm-btns').addEventListener('pointerdown', e => {
      const a = e.target.closest('button') && e.target.closest('button').dataset.a; if (!a) return;
      e.preventDefault(); e.stopPropagation();
      if (a === 'close') this.hide(); else if (a === 'in') this.zoomBy(1.4); else if (a === 'out') this.zoomBy(1 / 1.4); else this.center();
    });
    // toque: arrastar, pinça, duplo toque; mouse: arrastar e roda
    const pts = new Map(); let pinch = null, lastTap = 0;
    this.cv.addEventListener('pointerdown', e => {
      this.cv.setPointerCapture(e.pointerId); pts.set(e.pointerId, [e.clientX, e.clientY]);
      if (pts.size === 2) { const [a, b] = [...pts.values()]; pinch = { d: Math.hypot(a[0] - b[0], a[1] - b[1]), z: this.zoom }; }
      const now = performance.now(); if (pts.size === 1 && now - lastTap < 300) this.center(); lastTap = now;
    });
    this.cv.addEventListener('pointermove', e => {
      const p = pts.get(e.pointerId); if (!p) return;
      const dx = e.clientX - p[0], dy = e.clientY - p[1]; pts.set(e.pointerId, [e.clientX, e.clientY]);
      if (pts.size === 1) { const k = this._mpp(); this.cx -= dx * k; this.cz -= dy * k; this.draw(); }
      else if (pts.size === 2 && pinch) { const [a, b] = [...pts.values()]; this.zoom = Math.max(0.6, Math.min(8, pinch.z * Math.hypot(a[0] - b[0], a[1] - b[1]) / pinch.d)); this.draw(); }
    });
    const up = e => { pts.delete(e.pointerId); if (pts.size < 2) pinch = null; };
    this.cv.addEventListener('pointerup', up); this.cv.addEventListener('pointercancel', up);
    this.cv.addEventListener('wheel', e => { e.preventDefault(); this.zoomBy(e.deltaY < 0 ? 1.15 : 1 / 1.15); }, { passive: false });
  }
  /** metros por px CSS no zoom atual */
  _mpp() { const r = this.cv.getBoundingClientRect(); return (2 * OW_HALF) / (Math.min(r.width, r.height) * 0.92 * this.zoom); }
  zoomBy(k) { this.zoom = Math.max(0.6, Math.min(8, this.zoom * k)); this.draw(); }
  center() { const p = this.g.player; if (this.g.area === 'ow') { this.cx = p.x - OWO.x; this.cz = p.z - OWO.z; } else { this.cx = 0; this.cz = 0; } this.draw(); }
  show() { this.open = true; this.el.classList.remove('hidden'); if (!this.base) this._buildBase(); this.zoom = 2.2; this.center(); this.g.audio && this.g.audio.play('ui'); }
  hide() { this.open = false; this.el.classList.add('hidden'); }
  toggle() { if (this.open) this.hide(); else this.show(); }

  /** Abre a névoa em volta do cavaleiro e marca lugares vistos (chamado ~3×/s). */
  update(dt) {
    const g = this.g; if (g.area !== 'ow') return;
    this.t -= dt; if (this.t > 0) return; this.t = 0.35;
    const p = g.player, cs = (2 * OW_HALF) / N;
    const ci = (p.x - OWO.x + OW_HALF) / cs, cj = (p.z - OWO.z + OW_HALF) / cs, r = REVEAL / cs;
    for (let j = Math.floor(cj - r); j <= Math.ceil(cj + r); j++) for (let i = Math.floor(ci - r); i <= Math.ceil(ci + r); i++) {
      if (i < 0 || j < 0 || i >= N || j >= N) continue;
      const d = Math.hypot(i + 0.5 - ci, j + 0.5 - cj) / r; if (d > 1) continue;
      const v = Math.round(255 * Math.min(1, (1 - d) * 2.2)); if (v > this.fog[j * N + i]) this.fog[j * N + i] = v;
    }
    const near = (x, z, R) => Math.hypot(p.x - x, p.z - z) < R;
    if (near(OW_FIRE.x, OW_FIRE.z, 25)) this.seen.add('fire');
    for (const L of LANDMARKS) if (L.seen || near(L.x, L.z, 70)) this.seen.add(L.id);
    for (const [k, s] of Object.entries(SITES)) if (near(s.x, s.z, 60)) this.seen.add(k);
    if (g.profRewardAt && near(g.profRewardAt.x, g.profRewardAt.z, 25)) this.seen.add('fire:church');
    if (g.elowenRest && near(g.elowenRest.x, g.elowenRest.z, 25)) this.seen.add('fire:elowen');
    if (this.open) this.draw();
  }

  /** Mapa base em caracteres (uma vez): relevo sombreado × bioma. */
  _buildBase() {
    const c = document.createElement('canvas'); c.width = c.height = CELLS * PX;
    const x = c.getContext('2d'); x.fillStyle = '#000'; x.fillRect(0, 0, c.width, c.height);
    x.font = `bold ${PX * 1.15}px ui-monospace, Menlo, Consolas, monospace`; x.textAlign = 'center'; x.textBaseline = 'middle';
    const step = (2 * OW_HALF) / CELLS, e = step * 0.6;
    for (let j = 0; j < CELLS; j++) for (let i = 0; i < CELLS; i++) {
      const wx = OWO.x - OW_HALF + (i + 0.5) * step, wz = OWO.z - OW_HALF + (j + 0.5) * step, h = heightAt(wx, wz);
      const hx = heightAt(wx + e, wz) - heightAt(wx - e, wz), hz = heightAt(wx, wz + e) - heightAt(wx, wz - e);
      const slope = Math.hypot(hx, hz) / (2 * e);
      const shade = Math.max(0.15, Math.min(1.25, 0.72 + (-hx + -hz * 0.7) / (2 * e) * 0.9));   // luz vindo do noroeste
      const hsh = ((i * 73856093) ^ (j * 19349663)) >>> 0, r = (hsh % 1000) / 1000;
      let ch, col;
      if (h < OW_WL) { ch = r < 0.5 ? '~' : r < 0.8 ? '≈' : '-'; col = [40, 62, 110]; }
      else {
        const b = biome(wx, wz, h, slope);
        if (b === 'snow') { ch = r < 0.6 ? '^' : '*'; col = [210, 215, 225]; }
        else if (b === 'rock' || h > 40) { ch = slope > 1.4 ? (r < 0.5 ? '/' : '\\') : '^'; col = [120, 120, 128]; }
        else if (b === 'shore') { ch = r < 0.5 ? ':' : '.'; col = [150, 135, 95]; }
        else if (b === 'ash') { ch = r < 0.5 ? '.' : ','; col = [110, 100, 90]; }
        else if (b === 'swamp') { ch = r < 0.5 ? '%' : '"'; col = [70, 95, 70]; }
        else if (b === 'forest') { ch = r < 0.4 ? '&' : r < 0.7 ? '♣' : 'Y'; col = [45, 105, 70]; }
        else { ch = r < 0.4 ? '"' : r < 0.7 ? ',' : '\''; col = [95, 120, 60]; }
      }
      const k = shade * (0.85 + 0.3 * r) * 1.6;
      x.fillStyle = `rgb(${Math.min(255, col[0] * k) | 0},${Math.min(255, col[1] * k) | 0},${Math.min(255, col[2] * k) | 0})`;
      x.fillText(ch, (i + 0.5) * PX, (j + 0.5) * PX);
    }
    this.base = c;
    this.fogC = document.createElement('canvas'); this.fogC.width = this.fogC.height = N;
  }
  draw() {
    if (!this.open || !this.base) return;
    const g = this.g, cv = this.cv, r = cv.getBoundingClientRect(), dpr = Math.min(2, window.devicePixelRatio || 1);
    const W = Math.round(r.width * dpr), H = Math.round(r.height * dpr);
    if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
    const x = cv.getContext('2d');
    x.setTransform(1, 0, 0, 1, 0, 0); x.fillStyle = '#000'; x.fillRect(0, 0, W, H);
    const mpp = this._mpp() / dpr;                         // metros por px do canvas
    const S = (2 * OW_HALF) / mpp;                          // tamanho do mapa inteiro em px
    const ox = W / 2 - (this.cx + OW_HALF) / mpp, oy = H / 2 - (this.cz + OW_HALF) / mpp;
    const toPx = (wx, wz) => [ox + (wx - OWO.x + OW_HALF) / mpp, oy + (wz - OWO.z + OW_HALF) / mpp];
    x.imageSmoothingEnabled = true;
    x.drawImage(this.base, ox, oy, S, S);
    // névoa de guerra: preto onde ainda não foi visto (borda suave)
    const fx = this.fogC.getContext('2d'), im = fx.createImageData(N, N);
    for (let k = 0; k < N * N; k++) { im.data[k * 4 + 3] = 255 - this.fog[k]; }
    fx.putImageData(im, 0, 0);
    x.drawImage(this.fogC, ox, oy, S, S);
    // moldura do reino
    x.strokeStyle = '#3b3228'; x.lineWidth = 2 * dpr; x.strokeRect(ox, oy, S, S);
    const fogAt = (wx, wz) => { const i = Math.floor((wx - OWO.x + OW_HALF) / (2 * OW_HALF) * N), j = Math.floor((wz - OWO.z + OW_HALF) / (2 * OW_HALF) * N); return i >= 0 && j >= 0 && i < N && j < N ? this.fog[j * N + i] : 0; };
    const label = (wx, wz, ch, col, name, size = 18) => {
      const [px, py] = toPx(wx, wz);
      x.font = `bold ${size * dpr}px ui-monospace, Menlo, Consolas, monospace`; x.textAlign = 'center'; x.textBaseline = 'middle';
      x.fillStyle = '#000'; x.fillText(ch, px + dpr, py + dpr); x.fillStyle = col; x.fillText(ch, px, py);
      if (name && this.zoom > 1.2) { x.font = `${12 * dpr}px ui-monospace, Menlo, Consolas, monospace`; x.fillStyle = '#d8cfb8'; x.fillText(name, px, py + 16 * dpr); }
    };
    // lugares importantes e fogueiras: só depois de vistos
    for (const L of LANDMARKS) if (this.seen.has(L.id)) label(L.x, L.z, '◆', '#e8e2d0', L.name);
    for (const [k, s] of Object.entries(SITES)) if (this.seen.has(k)) label(s.x, s.z, '◆', '#cdb98a', SITE_NAMES[k]);
    if (this.seen.has('fire')) label(OW_FIRE.x, OW_FIRE.z, '火', '#ff9a3c', 'Fogueira do Reino Partido');
    if (this.seen.has('fire:church') && g.profRewardAt) label(g.profRewardAt.x, g.profRewardAt.z, '火', '#ff9a3c', 'Fogueira da Igreja');
    if (this.seen.has('fire:elowen') && g.elowenRest) label(g.elowenRest.x, g.elowenRest.z, '火', '#ff9a3c', 'Fogueira de Elowen');
    // corcel
    const h = g.horse;
    if (h && h.met && !g.player.mounted && fogAt(h.x, h.z) > 40) label(h.x, h.z, '♞', '#c9d2e6', null, 20);
    // jogador com a direção do olhar
    if (g.area === 'ow') {
      const p = g.player, [px, py] = toPx(p.x, p.z), a = Math.atan2(Math.sin(p.yaw), Math.cos(p.yaw));
      x.save(); x.translate(px, py); x.rotate(Math.PI - a);
      x.fillStyle = '#fff'; x.strokeStyle = '#000'; x.lineWidth = 2 * dpr;
      x.beginPath(); x.moveTo(0, -11 * dpr); x.lineTo(7 * dpr, 8 * dpr); x.lineTo(0, 4 * dpr); x.lineTo(-7 * dpr, 8 * dpr); x.closePath(); x.stroke(); x.fill();
      x.restore();
    } else {
      x.font = `${14 * dpr}px ui-monospace, Menlo, Consolas, monospace`; x.fillStyle = '#a89f8c'; x.textAlign = 'center';
      x.fillText('Você está fora do Reino Partido.', W / 2, H - 40 * dpr);
    }
  }
}
