// ASHEN — Modelos .glb (Fase 3).
//
// Para cada personagem do jogo existe um nome: knight, samurai (jogador), ghoul, skeleton, goblin, goblinKing,
// boss, profano, ogre, spider, hood, man, woman, lady… Se existir assets/models/<nome>.glb, TODA malha desse
// personagem passa a ser desenhada pelo modelo (cada uma com sua cópia do esqueleto e seu AnimationMixer).
// Sem o arquivo — ou se ele falhar — nada muda: fica o corpo atual.
//
// • Os materiais do .glb viram o material do ASHEN: cor/textura do arquivo + caracteres gravados em relevo
//   com brilho que reage à luz (o mesmo dos outros objetos). O tipo de caractere sai do nome/cor do material.
// • Posição e direção vêm do jogo (mesh.modelMatrix); a altura do modelo é ajustada à do corpo atual.
// • Animação: mesh.animState (o combate decide) ou, sem ele, parado/andando/correndo pela velocidade.
//
// Contrato do arquivo: veja README → "Modelos .glb".

import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { clone as cloneSkinned } from 'three/addons/utils/SkeletonUtils.js';
import { ANIM_NAMES, SWORD_BONES, pickClip } from './animation-names.js';

/** Nomes de personagem procurados em assets/models/. */
/** Altura (m) quando o esqueleto do jogo não é humano (chefes flutuantes, aranha). */
export const DEFAULT_HEIGHT = { profano: 2.3, spider: 1.3, hood: 1.8 };

export const MODEL_NAMES = ['knight', 'samurai', 'ghoul', 'skeleton', 'goblin', 'goblinKing', 'boss', 'profano', 'ogre', 'spider', 'hood', 'man', 'woman', 'lady'];

const ONCE = ['attack1', 'attack2', 'attack3', 'roll', 'hit', 'death', 'heal'];

/** Carrega o arquivo de um personagem (uma vez). Devolve null se não existir. */
export async function loadTemplate(name, base = 'assets/models/') {
  let gltf;
  try { gltf = await new GLTFLoader().loadAsync(`${base}${name}.glb`); } catch (e) { return null; }
  const root = gltf.scene;
  root.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(root), size = box.getSize(new THREE.Vector3());
  return { name, root, clips: gltf.animations, height: size.y || 1, minY: box.min.y };
}

/** Cópia independente (esqueleto + mixer) para uma malha do jogo. matFn converte os materiais. */
export function instantiate(tpl, matFn) {
  const root = cloneSkinned(tpl.root);
  const inner = new THREE.Group(); inner.scale.setScalar(1 / tpl.height); inner.position.y = -tpl.minY / tpl.height;   // altura 1, pés no chão
  inner.add(root);
  const holder = new THREE.Group(); holder.add(inner); holder.matrixAutoUpdate = false;
  let sword = null, tip = null, handL = null, handR = null;
  const meshes = [];
  root.traverse(o => {
    if (o.isMesh) {
      o.castShadow = true; o.receiveShadow = true; o.frustumCulled = false;
      if (matFn) o.material = Array.isArray(o.material) ? o.material.map(m => matFn(m, o)) : matFn(o.material, o);
      meshes.push(o);
    }
    const nn = String(o.name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    if (!handL && /(lefthand|handl|lhand)$/.test(nn)) handL = o;
    if (!handR && /(righthand|handr|rhand)$/.test(nn)) handR = o;
    if (!sword && /^(sword|weapon|espada|katana)/.test(nn)) sword = o;
    if (!tip && SWORD_BONES.tip.includes(o.name)) tip = o;
  });
  const mixer = new THREE.AnimationMixer(root);
  const actions = {};
  for (const state of Object.keys(ANIM_NAMES)) {
    const clip = pickClip(tpl.clips, state, tpl.name);
    if (!clip) continue;
    const a = mixer.clipAction(clip);
    if (ONCE.includes(state)) { a.setLoop(THREE.LoopOnce, 1); a.clampWhenFinished = true; }
    actions[state] = a;
  }
  const pos = (o) => { if (!o) return null; const v = new THREE.Vector3(); o.getWorldPosition(v); return [v.x, v.y, v.z]; };
  return { name: tpl.name, holder, root, meshes, mixer, actions, sword, tip, handL, handR, ownSword: !!sword,
    /** posição no mundo da mão do modelo ('L' ou 'R'), do último quadro desenhado */
    hand: (side) => pos(side === 'L' ? handL : handR),
    state: null, current: null, hLocal: 0, last: null, speed: 0 };
}

/** Estado do jogador (mesmos campos que o combate usa). */
export function stateOf(p, combo = 0) {
  if (p.dead >= 0 && p.dead < 99) return 'death';
  if (p.atk >= 0) return 'attack' + (Math.min(2, combo | 0) + 1);
  if (p.roll >= 0) return 'roll';
  if (p.heal >= 0) return 'heal';
  if (p.stun > 0) return 'hit';
  if (p.block) return 'block';
  const sp = p.speed || 0;
  return sp > 3.2 ? 'run' : sp > 0.25 ? 'walk' : 'idle';
}

/** Estado de um inimigo (mortos, esqueletos, goblins, chefes): morte, golpe, ataque; o resto vem da velocidade. */
export function enemyState(e) {
  if (!e) return null;
  if (e.state === 'dying' || e.state === 'dead') return 'death';
  if (e.hurt > 0.6) return 'hit';
  if (e.act) { const a = String(e.act); return 'attack' + (1 + ((a.charCodeAt(0) + a.length) % 3)); }
  return null;
}

/** Troca de animação com crossfade; sem o clipe, fica no anterior (nunca trava por faltar animação). */
export function playState(model, state, fade = 0.18) {
  if (model.state === state) return;
  const next = model.actions[state] || (state.startsWith('attack') && model.actions.attack1) || (state === 'run' && model.actions.walk) || null;
  model.state = state;
  if (!next || next === model.current) return;
  next.reset().setEffectiveWeight(1).fadeIn(fade).play();
  if (model.current) model.current.fadeOut(fade);
  model.current = next;
}
