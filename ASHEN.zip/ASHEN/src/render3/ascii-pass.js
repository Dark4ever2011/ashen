// ASHEN — Composição ASCII (direção visual "ASCII artístico de alta densidade", Fase 1).
//
// Fundo preto puro. Os OBJETOS (personagens, construções, pedras, árvores) são desenhados antes num alvo de
// baixa resolução (2×2 amostras por célula): cor iluminada + código do material no alfa + profundidade.
// Aqui cada célula de uma grade fina vira UM caractere nítido sobre preto: a densidade do traço sai da luz,
// a família de caracteres sai do material (metal @#MW%&+:., pedra @#B8Q o=-, madeira, folhagem, pano…).
// O chão não é desenhado: onde só há piso, aparece no máximo um "." ou ":" apagado, e só onde a luz de
// tocha, fogueira ou lustre bate. A composição também grava a profundidade dos objetos, para a grama
// (traços desenhados depois, direto na tela) passar na frente/atrás deles certinho.

import * as THREE from 'three';
import { MATERIALS, MAT } from '../game/glyphs.js';
import { charWidth } from '../engine/typography.js';

const FAM = {
  metal: ['.', ':', '+', '%', '&', '#', 'W', 'M', '@'],
  cloth: ['.', ',', ':', ';', 'o', 'x', '%', '&', '@'],
  stone: ['.', '-', '=', 'o', 'Q', '8', 'B', '#', '@'],
  brick: ['.', '-', '=', 'o', 'm', '8', 'B', '#', '@'],
  wood: ['.', '\'', ':', '!', 'l', 'I', '8', '#', '@'],
  leaf: ['.', ',', '\'', '"', 'v', 'w', '%', '&', '@'],
  flesh: ['.', ':', '-', '=', 'o', 'O', '0', '&', '@'],
  water: ['.', '-', '~', '~', '=', '≈', '≈', '#', '@'],
  fire: ['·', '·', '•', '*', '✶', '✦', '火', '炎', '火'],
};
const FAMILY = {};
for (const [f, ids] of Object.entries({
  metal: [MAT.STEEL, MAT.SILVER, MAT.GOLD, MAT.BLADE, MAT.IRON, MAT.MAIL, MAT.BRONZE, MAT.CHITIN],
  cloth: [MAT.CLOTH, MAT.CLOTH_IN, MAT.ROYAL, MAT.LINEN, MAT.WOOL, MAT.LEATHER, MAT.BLOOD],
  stone: [MAT.STONE, MAT.MARBLE, MAT.GRAVEL, MAT.BONE, MAT.DARK, MAT.SNOW, MAT.SAND, MAT.GROUND],
  brick: [MAT.PLASTER],
  wood: [MAT.WOOD, MAT.THATCH],
  leaf: [MAT.LEAF, MAT.LEAF_G, MAT.LEAF_R, MAT.LEAF_Y, MAT.MOSS, MAT.GRASS, MAT.GRASS2, MAT.GRASS3, MAT.FLOWER, MAT.FLOWER_R, MAT.FLOWER_Y, MAT.FLOWER_W, MAT.FLOWER_B, MAT.PETAL_P],
  flesh: [MAT.FLESH, MAT.SKIN, MAT.HAIR, MAT.GOBLIN],
  water: [MAT.WATER, MAT.RIVER],
  fire: [MAT.EMBER, MAT.SPIRIT, MAT.BLUE],
})) for (const id of ids) if (id != null) FAMILY[id] = f;

/** Linha = código (material+1), 9 colunas do escuro ao claro → índice no atlas. */
function rampTex(atlas) {
  const data = new Uint8Array(9 * 256 * 4);
  for (let code = 1; code < 256; code++) {
    const m = code - 1, fam = FAM[FAMILY[m] || (m < MATERIALS.length ? 'stone' : 'metal')];
    for (let x = 0; x < 9; x++) {
      const ch = fam[x], g = atlas.get(ch), o = (code * 9 + x) * 4;
      data[o] = g & 255; data[o + 1] = g >> 8; data[o + 2] = charWidth(ch.codePointAt(0)) === 2 ? 255 : 0; data[o + 3] = 255;
    }
  }
  const t = new THREE.DataTexture(data, 9, 256, THREE.RGBAFormat, THREE.UnsignedByteType);
  t.minFilter = t.magFilter = THREE.NearestFilter; t.needsUpdate = true;
  return t;
}
// família de cada código numa textura 256×1 (uniformes em array estouram o limite de alguns celulares)
const FAM_ID = { metal: 1, cloth: 2, stone: 3, brick: 4, wood: 5, leaf: 6, flesh: 7, water: 8, fire: 9 };
function famTex() {
  const d = new Uint8Array(256 * 4);
  for (let c = 1; c < 256; c++) d[c * 4] = FAM_ID[FAMILY[c - 1]] || 3;
  const t = new THREE.DataTexture(d, 256, 1, THREE.RGBAFormat, THREE.UnsignedByteType);
  t.minFilter = t.magFilter = THREE.NearestFilter; t.needsUpdate = true; return t;
}

const VS = 'varying vec2 vUv; void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }';
const FS = `
precision highp float;
uniform sampler2D tObj, tDepth, tAtlas, tRamp;
uniform vec2 uCell, uObjSize;
uniform float uAtlasCols, uAtlasRows, uExposure;
uniform sampler2D tFam, tRefl;
uniform float uWaterY, uRainK;
uniform vec3 uCamPos, uMoonDir, uPlayer, uMoonTint;
uniform vec2 uWind;
uniform mat4 uInvVP;
uniform vec4 uLightPos[6], uLightCol[6];
uniform float uTime;
// paleta sóbria por família (escuro → claro); a sombra vai sumindo no preto
vec3 palette(float fam, float lum, vec3 hue) {
  if (fam < 1.5) return mix(vec3(0.07, 0.075, 0.09), vec3(0.93, 0.95, 1.0), lum);                    // metal: prata
  if (fam < 2.5) return hue * mix(0.06, 0.92, lum);                                                   // pano: a cor (capa vinho)
  if (fam < 3.5) return mix(vec3(0.035, 0.035, 0.045), vec3(0.56, 0.56, 0.6), lum);                  // pedra cinza profunda
  if (fam < 4.5) return mix(vec3(0.07, 0.022, 0.012), vec3(0.7, 0.32, 0.2), lum);                    // tijolo/terracota escuro
  if (fam < 5.5) return mix(vec3(0.045, 0.028, 0.015), vec3(0.52, 0.36, 0.22), lum);                 // madeira
  if (fam < 6.5) return hue.r > hue.g * 1.05 ? mix(vec3(0.07, 0.018, 0.008), vec3(0.74, 0.27, 0.11), lum)   // copa ferrugem
                                             : mix(vec3(0.015, 0.05, 0.03), vec3(0.2, 0.47, 0.28), lum);    // copa verde-escuro
  if (fam < 7.5) return mix(hue * 0.05, mix(hue, vec3(0.85), 0.35), lum);                             // pele/carne
  if (fam < 8.5) return mix(vec3(0.015, 0.03, 0.05), vec3(0.6, 0.74, 0.88), lum);                    // água
  return hue * (0.3 + 1.2 * lum);                                                                     // fogo/magia
}
float hs2(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vn(vec2 p) { vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hs2(i), hs2(i + vec2(1, 0)), f.x), mix(hs2(i + vec2(0, 1)), hs2(i + vec2(1, 1)), f.x), f.y); }
float hs(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float glyph(float g, float wide, vec2 lc) {
  float sx = wide > 0.5 ? 0.88 : 0.58, sy = 0.9;
  vec2 a = vec2(0.5 + (lc.x - 0.5) * sx, 0.5 + (lc.y - 0.5) * sy);
  vec2 cg = vec2(mod(g, uAtlasCols), floor(g / uAtlasCols));
  vec2 auv = vec2((cg.x + a.x) / uAtlasCols, 1.0 - (cg.y + 1.0 - a.y) / uAtlasRows);
  return texture2D(tAtlas, auv).a;
}
void main() {
  vec2 fc = gl_FragCoord.xy;
  vec2 cell = floor(fc / uCell), lc = fract(fc / uCell);
  // 4 amostras da célula no alvo dos objetos
  vec3 acc = vec3(0.0); float n = 0.0, code = 0.0, dmin = 1.0, floorD = 1.0, best = 9.0;
  for (int j = 0; j < 2; j++) for (int i = 0; i < 2; i++) {
    ivec2 t = ivec2(cell * 2.0) + ivec2(i, j);
    vec4 s = texelFetch(tObj, t, 0);
    float d = texelFetch(tDepth, t, 0).x;
    if (d >= 1.0) continue;
    float k = floor(s.a * 255.0 + 0.5);
    if (k < 0.5) { floorD = min(floorD, d); continue; }
    n += 1.0; acc += s.rgb; dmin = min(dmin, d);
    float pr = length(vec2(float(i), float(j)) - 0.5) + (k > 239.5 ? -1.0 : 0.0);
    if (pr < best) { best = pr; code = k; }
  }
  if (n > 0.5) {
    vec3 c = acc / n;
    // personagens (código + 100): mais exposição e um piso de brilho — saltam do escuro, como nas referências
    bool actor = code > 100.5 && code < 200.5;
    if (actor) code -= 100.0;
    float L = dot(c, vec3(0.3, 0.59, 0.11));
    float lum = pow(1.0 - exp(-L * uExposure * (actor ? 2.2 : 1.0)), 0.8);
    float fam = texelFetch(tFam, ivec2(int(code), 0), 0).r * 255.0;
    if (fam > 7.5 && fam < 8.5 && uWaterY > -999.0) {
      // ── água negra espelhada: reflexo do mundo, da lua gigante e das nuvens, ondulando ──
      vec2 uvc = (cell + 0.5) / uObjSize;
      vec4 cp = uInvVP * vec4(uvc * 2.0 - 1.0, dmin * 2.0 - 1.0, 1.0);
      vec3 wp = cp.xyz / cp.w;
      vec3 vd = normalize(wp - uCamPos);
      // ondas: correnteza + anéis onde o jogador pisa
      float t = uTime;
      vec2 wv = vec2(sin(wp.z * 2.3 + t * 1.7) + sin(wp.x * 1.1 - t * 1.1), cos(wp.x * 2.0 - t * 1.4)) * 0.018;
      float pdist = length(wp.xz - uPlayer.xz);
      vec2 pdir = (wp.xz - uPlayer.xz) / max(pdist, 0.01);
      float ring = sin(pdist * 14.0 - t * 7.0) * exp(-pdist * 1.6) * smoothstep(0.35, -0.1, abs(uPlayer.y - uWaterY) - 0.2);
      wv += pdir * ring * 0.03;
      wv += vec2(vn(wp.xz * 3.0 + t), vn(wp.xz * 3.0 - t)) * 0.02 * uRainK;
      vec3 rd = reflect(vd, normalize(vec3(wv.x * 2.2, 1.0, wv.y * 2.2)));
      // 1) o que está acima da água (personagem, muros, árvores), do alvo espelhado
      vec4 rc = texture2D(tRefl, uvc + wv * vec2(1.0, 2.2));
      float rl = dot(rc.rgb, vec3(0.3, 0.59, 0.11));
      vec3 col = vec3(0.0); float L2 = 0.0; float wfam = 3.0;
      if (rc.a < 0.5 / 255.0 && rl > 0.002) {
        L2 = 0.0;                                     // margem/chão refletido: escuro
      } else if (rc.a > 0.5 / 255.0 && rl > 0.004) {
        L2 = pow(1.0 - exp(-rl * uExposure * 1.6), 0.8) * 0.8;
        col = mix(rc.rgb / max(max(rc.r, rc.g), max(rc.b, 1e-4)), vec3(0.6, 0.72, 0.9), 0.45);
      } else {
        // 2) céu refletido: lua cheia gigante (com crateras) e nuvens que correm
        float ang = acos(clamp(dot(rd, uMoonDir), -1.0, 1.0)), R0 = 0.13;
        vec2 mq = vec2(dot(rd, normalize(cross(uMoonDir, vec3(0.0, 1.0, 0.0)))), rd.y - uMoonDir.y) / R0;
        float moon = smoothstep(R0, R0 * 0.96, ang);
        float crater = vn(mq * 4.0 + 3.0) * 0.6 + vn(mq * 9.0) * 0.4;
        float mL = moon * (0.55 + 0.45 * smoothstep(0.35, 0.75, crater)) * (0.75 + 0.25 * (1.0 - length(mq)));
        vec2 cq = rd.xz / max(rd.y, 0.08) * 0.9 + uWind * t * 0.03 + vec2(t * 0.01, 0.0);
        float cl = vn(cq * 1.2) * 0.6 + vn(cq * 2.7 + 5.0) * 0.4;
        float cloud = smoothstep(0.5, 0.78, cl);
        float glow = exp(-max(ang - R0, 0.0) * 9.0) * 0.18;
        L2 = max(mL, cloud * (0.32 + 0.4 * glow * 5.0) * (1.0 - moon * 0.7)) + glow;
        col = mix(vec3(0.72, 0.74, 0.78), uMoonTint, moon);
        if (mL > 0.01) L2 = max(L2, mL);
      }
      // espuma onde o jogador pisa
      float foam = smoothstep(0.75, 0.95, ring) * 0.8;
      L2 = max(L2, foam); col = mix(col, vec3(0.9, 0.95, 1.0), foam);
      if (L2 < 0.06) { gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0); gl_FragDepth = dmin; return; }
      float k2 = floor(clamp(L2 + (hs(cell * 1.7) - 0.5) * 0.1, 0.0, 0.999) * 9.0);
      vec4 rr = texelFetch(tRamp, ivec2(int(k2), int(1.0 + ${MAT.STONE}.0)), 0);
      float ink2 = glyph(rr.r * 255.0 + rr.g * 65280.0, rr.b, lc);
      gl_FragColor = vec4(col * (0.15 + 0.95 * L2) * ink2, 1.0);
      gl_FragDepth = dmin;
      return;
    }
    if (actor) {
      // contorno: célula de personagem com vizinho vazio (ou de outra coisa) → traço aceso, silhueta legível na grama
      float rim = 0.0;
      for (int q = 0; q < 4; q++) {
        ivec2 o = q == 0 ? ivec2(2, 0) : q == 1 ? ivec2(-2, 0) : q == 2 ? ivec2(0, 2) : ivec2(0, -2);
        ivec2 t = ivec2(cell * 2.0) + o;
        float kk = floor(texelFetch(tObj, t, 0).a * 255.0 + 0.5);
        if (texelFetch(tDepth, t, 0).x >= 1.0 || kk < 100.5 || kk > 200.5) rim = 1.0;
      }
      lum = 0.24 + 0.76 * lum;
      lum = max(lum, rim * 0.72);
    } else {
      if (lum < 0.07 && fam < 8.5) { gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0); gl_FragDepth = dmin; return; }   // sombra: preto
    }
    float lj = actor ? lum : clamp(lum + (hs(cell * 1.37 + code) - 0.5) * 0.16, 0.0, 1.0);   // variação de caractere entre células vizinhas
    float k = floor(clamp(lj, 0.0, 0.999) * 9.0);
    vec4 r = texelFetch(tRamp, ivec2(int(k), int(code)), 0);
    float ink = glyph(r.r * 255.0 + r.g * 65280.0, r.b, lc);
    float mx = max(max(c.r, c.g), max(c.b, 1e-4));
    vec3 hue = c / mx;
    float shade = actor ? 1.0 : smoothstep(0.07, 0.4, lum);              // estruturas: a sombra dissolve no preto
    vec3 col = palette(fam, lum, hue) * shade;
    if (actor && fam > 1.5 && fam < 2.5) col *= 1.15;                    // capa: vermelho-escuro vivo
    gl_FragColor = vec4(col * ink, 1.0);
    gl_FragDepth = dmin;
    return;
  }
  // só piso: "." ou ":" apagado onde a luz de tocha/fogueira/lustre bate
  gl_FragDepth = 1.0;
  if (floorD < 1.0 && hs(cell) < 0.6) {
    vec2 uv = (cell + 0.5) / uObjSize;                      // espaço da grade (a projeção dos objetos cobre a grade)
    vec4 cp = uInvVP * vec4(uv * 2.0 - 1.0, floorD * 2.0 - 1.0, 1.0);
    vec3 wp = cp.xyz / cp.w;
    vec3 I = vec3(0.0);
    for (int i = 0; i < 6; i++) { float r = uLightPos[i].w; if (r <= 0.0) continue; float d = distance(wp, uLightPos[i].xyz); float a = clamp(1.0 - d / r, 0.0, 1.0); I += uLightCol[i].rgb * a * a; }
    float e = dot(I, vec3(0.3, 0.59, 0.11));
    if (e > 0.04) {
      float g = e > 0.35 ? 1.0 : 0.0;
      vec4 r = texelFetch(tRamp, ivec2(int(g), 1 + ${MAT.STONE}), 0);
      float ink = glyph(r.r * 255.0 + r.g * 65280.0, 0.0, lc);
      gl_FragColor = vec4(I / max(max(I.r, I.g), max(I.b, 1e-4)) * min(0.55, e * 0.9) * ink, 1.0);
      return;
    }
  }
  gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
}`;

export class AsciiPass {
  constructor(renderer, atlas, atlasTex) {
    this.r = renderer;
    this.objRT = new THREE.WebGLRenderTarget(4, 4, { type: THREE.UnsignedByteType, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter, depthBuffer: true, colorSpace: THREE.NoColorSpace });
    this.objRT.depthTexture = new THREE.DepthTexture(4, 4, THREE.UnsignedIntType);
    // reflexo (mundo espelhado no plano da água), 1 amostra por célula
    this.reflRT = new THREE.WebGLRenderTarget(4, 4, { type: THREE.UnsignedByteType, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: true, colorSpace: THREE.NoColorSpace });
    this.mat = new THREE.ShaderMaterial({
      vertexShader: VS, fragmentShader: FS, depthTest: true, depthFunc: THREE.AlwaysDepth, depthWrite: true,
      uniforms: {
        tObj: { value: this.objRT.texture }, tDepth: { value: this.objRT.depthTexture }, tAtlas: { value: atlasTex }, tRamp: { value: rampTex(atlas) },
        uCell: { value: new THREE.Vector2(6, 10) }, uObjSize: { value: new THREE.Vector2(4, 4) }, uAtlasCols: { value: atlas.cols }, uAtlasRows: { value: atlas.rows },
        uExposure: { value: 9.0 }, tFam: { value: famTex() }, uInvVP: { value: new THREE.Matrix4() },
        tRefl: { value: this.reflRT.texture }, uWaterY: { value: -1000 }, uCamPos: { value: new THREE.Vector3() }, uMoonDir: { value: new THREE.Vector3(0.4, 0.75, -0.5) },
        uWind: { value: new THREE.Vector2(1, 0) }, uMoonTint: { value: new THREE.Vector3(0.95, 0.96, 1) }, uPlayer: { value: new THREE.Vector3() }, uRainK: { value: 0 },
        uLightPos: { value: Array.from({ length: 6 }, () => new THREE.Vector4()) }, uLightCol: { value: Array.from({ length: 6 }, () => new THREE.Vector4()) }, uTime: { value: 0 },
      },
    });
    this.scene = new THREE.Scene();
    const q = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.mat); q.frustumCulled = false; this.scene.add(q);
    this.cam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    this.cols = 0; this.rows = 0;
  }
  setSize(w, h, cellH) {
    const ch = Math.max(5, Math.round(cellH)), cw = Math.max(3, Math.round(ch * 0.6));
    this.cols = Math.ceil(w / cw); this.rows = Math.ceil(h / ch);
    this.objRT.setSize(this.cols * 2, this.rows * 2);
    this.reflRT.setSize(this.cols, this.rows);
    this.mat.uniforms.uCell.value.set(cw, ch); this.mat.uniforms.uObjSize.value.set(this.cols, this.rows);
  }
  /** Ajusta a projeção para o alvo dos objetos cobrir exatamente a grade (cols×cell pode passar da tela). */
  gridScale(w, h) { const c = this.mat.uniforms.uCell.value; return [this.cols * c.x / w, this.rows * c.y / h]; }
  setFrame(cam, lights, time) {
    const u = this.mat.uniforms;
    u.uInvVP.value.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse).invert();
    u.uTime.value = time;
    for (let i = 0; i < 6; i++) {
      const l = lights[i];
      if (!l) { u.uLightPos.value[i].set(0, 0, 0, 0); continue; }
      u.uLightPos.value[i].set(l.pos[0], l.pos[1], l.pos[2], l.radius * 1.2);
      const v = l.value != null ? l.value : 1;
      u.uLightCol.value[i].set(l.col[0] * v, l.col[1] * v, l.col[2] * v, 1);
    }
  }
  /** Plano da água do quadro (null = sem água visível), câmera, lua, vento e jogador (ondas onde ele pisa). */
  setWater(y, f) {
    const u = this.mat.uniforms;
    u.uWaterY.value = y == null ? -1000 : y;
    u.uCamPos.value.fromArray(f.cam); u.uPlayer.value.fromArray(f.focus);
    // a lua gigante fica onde o reflexo do olhar da câmera alcança (um pouco acima e à esquerda do centro da água)
    // (a lua está no infinito: o reflexo dela fica parado na tela enquanto a câmera anda — fixamos esse ponto)
    const iv = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().fromArray(f.proj), new THREE.Matrix4().fromArray(f.view)).invert();
    const a = new THREE.Vector3(-0.42, -0.3, -1).applyMatrix4(iv), b = new THREE.Vector3(-0.42, -0.3, 1).applyMatrix4(iv);
    const d = b.sub(a).normalize();
    u.uMoonDir.value.set(d.x, -d.y, d.z).normalize();
    const mc = f.moonCol || [1, 1, 1], mm = Math.max(mc[0], mc[1], mc[2], 1e-3);
    u.uMoonTint.value.set(mc[0] / mm, mc[1] / mm, mc[2] / mm).lerp(new THREE.Vector3(1, 1, 1), mc[1] / mm > 0.5 ? 0.6 : 0.1);   // Lua Sombria: lua vermelha no reflexo
    u.uWind.value.set((f.wind && f.wind[0]) || 0.6, (f.wind && f.wind[2]) || 0.2); u.uRainK.value = f.rain || 0;
  }
  render() { this.r.render(this.scene, this.cam); }
}
