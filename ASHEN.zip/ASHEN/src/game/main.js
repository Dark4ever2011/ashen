// ASHEN — The Last Oath · jogo principal (mundo 3D tipográfico)
// Geometria 3D invisível → tudo o que aparece na tela é letra, número ou símbolo.
// Física em passo fixo (60 Hz); limite de quadros configurável (o A56 tem tela de 120 Hz).

import { loadFonts } from '../engine/typography.js';
import { Input } from '../engine/input.js';
import { m4, v3 } from './math3d.js';
import { GlyphAtlas } from './glyphs.js';
import { GlyphRenderer, flatBones } from './renderer3d.js';
import { ThreeRenderer } from '../render3/three-renderer.js';
import { MODEL_NAMES, stateOf } from '../render3/glb-models.js';
import { buildParts, lodOrder, PointSet } from './sampler.js';
import { BONE } from './knight3d.js';
import { knightParts, poseKnight, poseFallen, makeCape, makeTabard, makeBanner, COMBO } from './knight3d.js';
import { torchParts, shieldParts, crateParts, debrisParts, shrineParts } from './props3d.js';
import { Audio, Narrator } from './audio.js';
import { bossParts } from './boss3d.js';
import { initGameplay, combatPre, combatPost, gameplayRender, gameplaySave, rest, playOpening, colliderOff, extraInteract, ARENA } from './gameplay.js';
import { riverWater, wadeDepth, RIVER } from './world3d.js';
import { MAT } from './glyphs.js';
import { DetailRing } from './detail.js';
import { groundHeight, RIVER as RV } from './world3d.js';
import { groundHeight2 } from './region2.js';
import { sceneParts, groundParts, buildTrees, avoidVeg, portcullisParts, COLLIDERS, BOUNDS, LIGHTS, TORCHES, BANNERS, INTERACT, LORE, BRAZIER, FALLEN, SPAWN, WALL_Z } from './world3d.js';
import * as V2 from './region2.js';
import { palaceParts, PALACE_ENTRY } from './region3.js';
import { initPalace, palaceColliders, palaceFocus, palaceInteract, palaceStep } from './palace.js';
import { initOW, owColliders, owStep, owRender, owFocus, owInteract, owRespawn } from './owplay.js';
import { spiderParts, hoodParts } from './spider3d.js';
import { poseSeated } from './knight3d.js';
import { villagerParts, ghoulParts } from './npc3d.js';
import { setArea as setAreaV, initVillage, villageStep, villageRender, villageFocus, villageInteract, villageRespawn, villageSave, areaColliders, dynamicColliders } from './village.js';
import { FX } from './fx3d.js';
import { buildVegetation } from './veg3d.js';
import { Weather } from './weather.js';
import { loadWorld, saveWorld } from './cache.js';
import { hullFromPoints, partsMesh } from './solid.js';
import { Hud } from '../ui/hud.js';
import { Menu } from '../ui/menus.js';
import { setupControls, updateInteractButton } from '../ui/controls.js';
import { DEFAULT_SETTINGS, effective } from '../ui/settings.js';
import { buildLogo } from '../ui/logo.js';
import { Save, DIFFICULTY, CLASSES } from '../systems/save.js';
import { samuraiParts, SAMURAI_COMBO, ENGRAVE } from './samurai3d.js';
import { setStance, KNIGHT_COMBO } from './knight3d.js';
import { initBleed, bleedStep } from './bleed.js';
import { initItems, crownRender, crownParts } from './items.js';
import { profanoParts } from './profano.js';
import { SITES } from './ow.js';
import { ogreParts } from './darkmoon.js';
import { goblinParts } from './goblin.js';
import { setTellHook } from './tell.js';
import { initDungeon, dungeonStep, dungeonRender, dungeonFocus, dungeonInteract, dungeonColliders, dungeonRespawn, dungeonReady } from './dungeon.js';
import './story3.js';
import { advanceTime, skipHours, skyAt, clockText } from './daynight.js';

const $ = id => document.getElementById(id);
const STEP = 1 / 60;
const CAM = { yaw: 0.27, pitch: 0.74, dist: 6.5, fov: 32 * Math.PI / 180, min: 3.7, max: 10 };
const KSCALE = 0.955;                 // ~1,75 m de corpo, ~1,78 m com o elmo
const REGION = { region: 'I · Reino das Cinzas', title: 'O Portão do Rei', subtitle: '灰の王国' };
// todo caractere que pode aparecer precisa estar no atlas antes de ele ir para a GPU
const EXTRA_GLYPHS = '│─╲∴•◆§‹›°⁎✶✦|¦¤†·,\'~≈∼-*+✻═━▼ʌ⁞盾薬‡/\\=#';

const game = window.__ASHEN = window.__ASHEN3D = {
  CAM, state: 'loading', ready: false, t: 0, settings: null,
  player: { y: 0, x: SPAWN.x, z: SPAWN.z, vx: 0, vz: 0, yaw: 0.3, phase: 0, blend: 0, run: 0, breath: 0, time: 0, atk: -1, combo: 0, queued: false, accel: 0, turn: 0, look: 0, speed: 0 },
  cam: { x: SPAWN.x, z: SPAWN.z }, trail: [], trailAcc: 0, brazierLit: false, focus: null, wind: [1, 0, 0.5],
};

function setLoad(p, text) { $('bar').firstElementChild.style.width = Math.round(p * 100) + '%'; if (text) $('load-text').textContent = text; }
const hashStr = s => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); };

async function boot() {
  $('logo').innerHTML = buildLogo();
  setLoad(0.03, 'carregando a fonte tipográfica…');
  await loadFonts('assets/fonts/');
  game.settings = { ...DEFAULT_SETTINGS, ...(Save.loadSettings() || {}) };
  // v0.7: o jogo passa a abrir no modo Equilibrado (bem mais leve no celular); dá para voltar ao Alto no menu
  if (game.settings.opt !== 7) { game.settings.opt = 7; if (game.settings.preset === 'ALTA') game.settings.preset = 'EQUILIBRADA'; Save.saveSettings(game.settings); }
  const saved = Save.loadGame();
  // classe e dificuldade deste save
  game.loadedSlot = Save.active();
  game.cls = (saved && saved.cls) || 'knight';
  game.diffKey = (saved && saved.diff) || 'hard';
  game.diffK = DIFFICULTY[game.diffKey] || DIFFICULTY.hard;
  game.playTime = (saved && saved.playTime) || 0;
  game.hour = saved && saved.hour != null ? saved.hour : 21; game.day = (saved && saved.day) || 0;
  setStance(game.cls, game.cls === 'samurai' ? SAMURAI_COMBO : KNIGHT_COMBO);
  game.dmgMul = () => (game.blueSword ? 1.25 : 1) * (game.inv && game.inv.sword ? 1.35 : 1) * (game.strK || 1) * (1 + 0.1 * (game.sharpen || 0)) * game.diffK.dealt;
  if (saved && Number.isFinite(saved.x) && Number.isFinite(saved.z)) { game.player.x = game.cam.x = saved.x; game.player.z = game.cam.z = saved.z; }
  game.brazierLit = !!(saved && saved.brazierLit);

  // ── atlas: todos os caracteres do mundo ──
  setLoad(0.06, 'gravando o alfabeto das cinzas…');
  const atlas = new GlyphAtlas(64, 32);
  const sParts = sceneParts(), gParts = groundParts(), kParts = knightParts();
  const xParts = { torch: torchParts(), shield: shieldParts(), crate: crateParts(), debris: debrisParts(), boss: bossParts(), shrine: shrineParts(),
    blueBlade: knightParts().filter(q => q.name === 'lâmina').map(q => ({ ...q, mat: MAT.BLUE, detail: null, decals: [], pointFlags: 2, spacing: q.spacing * 1.3, size: 1.15 })),
    spider: spiderParts(), hood: hoodParts(), crown: crownParts(),
    portcullis: portcullisParts(), ghoul: ghoulParts(false), skeleton: ghoulParts(true), man: villagerParts('man'), woman: villagerParts('woman'), lady: villagerParts('lady'), goblin: goblinParts(false), goblinKing: goblinParts(true), profano: profanoParts(), ogre: ogreParts() };
  const vParts = { ground2: V2.ground2Parts(), valleyLush: V2.valleyParts(false), valleyRuin: V2.valleyParts(true), room: V2.roomParts(), nave: V2.naveParts(), chest: V2.chestParts(), palace: palaceParts() };
  for (const p of [...sParts, ...kParts, ...Object.values(xParts).flat(), ...Object.values(vParts).flat()]) for (const d of p.decals || []) atlas.get(d.glyph);
  for (const c of EXTRA_GLYPHS + '誓獅最後の灰王国約眠墓鍵✠門┼:●o•°∼≈~⁎()‹›\'"' + ENGRAVE + '菊×⁞◆§☠墓小鬼王所∴⁖ɅʌΨ呪魔死冥闇骨虚冒涜者暗月水車浅瀬❀○¦│─═≡=♥') atlas.get(c);
  const fx = new FX(atlas, 3800);
  atlas.build();
  const atlasN = atlas.list.length;
  const canvas = $('gl');
  let R;
  // motor: Three.js (3D sólido + pós-processamento em caracteres) ou o clássico; se o Three falhar, cai no clássico
  // v0.19: o visual ASCII vira o padrão (quem estava no 3D gravado passa para ele; o clássico continua se escolhido)
  if (game.settings.opt2 !== 19) { game.settings.opt2 = 19; if (game.settings.engine === 'three' || !game.settings.engine) game.settings.engine = 'ascii'; Save.saveSettings(game.settings); }
  if (game.settings.engine !== 'classico') {
    try { R = new ThreeRenderer(canvas, atlas, { mode: game.settings.engine === 'three' ? 'gravado' : 'ascii' }); const e0 = effective(game.settings); R.grassMul = (R.ascii ? e0.strokes : e0.grass) || 1.5; R.cellCss = e0.cell || 12; if (e0.shadowMap) R.moon.shadow.mapSize.set(e0.shadowMap, e0.shadowMap); }
    catch (e) { console.warn('[ASHEN] Three.js indisponível, usando o motor clássico:', e); R = null; }
  }
  if (!R) { try { R = new GlyphRenderer(canvas, atlas); R.engine = 'classico'; } catch (e) { throw new Error('Este navegador não oferece WebGL2: ' + e.message); } }
  Object.assign(game, { R, atlas, fx });

  // ── mundo: do cache local ou esculpido agora ──
  // o motor Three.js guarda corpos feitos das formas modeladas; o clássico, a casca dos pontos
  const key = hashStr(atlas.list.join('') + (R.engine === 'three' || R.engine === 'ascii' ? '|corpos-sdf-1' : ''));
  let sets = await loadWorld(key);
  const trees = buildTrees();
  if (!sets) {
    $('load-note').textContent = 'Primeira abertura: o mundo é esculpido uma vez e guardado no aparelho.';
    setLoad(0.08, 'esculpindo o chão…');
    const ground = await buildParts(gParts, atlas, { seed: 7, sizeMul: 2.1 });
    const veg = buildVegetation({ count: 9000, area: [BOUNDS.x0 - 1.5, WALL_Z + 0.3, BOUNDS.x1 + 1.5, 23], avoid: avoidVeg, atlas });
    ground.append(veg.ps);
    const scene = await buildParts(sParts, atlas, { seed: 101, sizeMul: 2.1, onProgress: (f, n) => setLoad(0.1 + f * 0.62, `erguendo o Reino das Cinzas: ${n}`) });
    for (const t of trees) { scene.append(t.wood); scene.append(t.leaves); }
    setLoad(0.74, 'forjando a armadura…');
    const kraw = await buildParts(kParts, atlas, { seed: 17, sizeMul: 2.2, spacingMul: 0.8, onProgress: (f, n) => setLoad(0.74 + f * 0.2, `cavaleiro: ${n}`) });
    const lod = lodOrder(kraw);
    setLoad(0.84, 'forjando a armadura do samurai…');
    const sraw = await buildParts(samuraiParts(), atlas, { seed: 19, sizeMul: 2.2, spacingMul: 0.8, onProgress: (f, n) => setLoad(0.84 + f * 0.1, `samurai: ${n}`) });
    sets = { ground, scene, knight: lod.ps, samurai: lodOrder(sraw).ps, meta: { levels: lod.levels, veg: [veg.tufts, veg.plants, veg.ps.n] } };
    setLoad(0.94, 'erguendo o rei do túmulo…');
    for (const [k, parts] of Object.entries(xParts)) {
      if (k === 'boss' || k === 'ogre' || k === 'goblin' || k === 'goblinKing') for (const q of parts) q.aoF = q.aoF || q.f;
      sets[k] = await buildParts(parts, atlas, { seed: 31, sizeMul: k === 'boss' || k === 'ghoul' || k === 'skeleton' ? 2.15 : 2.1, spacingMul: k === 'ghoul' || k === 'skeleton' ? 1.15 : 1 });
    }
    // Região II: o vale de Orvalho (vivo e em ruínas) e os interiores
    let vi = 0; const vn = Object.keys(vParts).length;
    for (const [k, parts] of Object.entries(vParts)) {
      sets[k] = await buildParts(parts, atlas, { seed: 211 + vi * 13, sizeMul: 2.1, onProgress: (f, n) => setLoad(0.95 + (vi + f) / vn * 0.035, `o vale de Orvalho: ${n}`) });
      vi++;
    }
    for (const t of V2.valleyTrees(false)) { sets.valleyLush.append(t.wood); sets.valleyLush.append(t.leaves); }
    for (const t of V2.valleyTrees(true)) { sets.valleyRuin.append(t.wood); sets.valleyRuin.append(t.leaves); }
    sets.river = riverWater(atlas);
    sets.vegLush = V2.buildMeadow({ lush: true, atlas, seed: 9 });
    sets.vegDead = V2.buildMeadow({ lush: false, atlas, seed: 19 });
    if (atlas.list.length !== atlasN) console.warn('[ASHEN] caracteres novos depois do atlas:', atlas.list.slice(atlasN).join(''));
    setLoad(0.95, 'dando corpo aos personagens…');
    // corpo sólido por baixo dos caracteres de cada personagem (anda com os ossos)
    for (const k of ['knight', 'samurai', 'boss', 'ghoul', 'skeleton', 'man', 'woman', 'lady', 'goblin', 'goblinKing', 'profano', 'ogre', 'spider', 'hood']) {
      if (!sets[k]) continue;
      try {
        const parts = k === 'knight' ? kParts : k === 'samurai' ? samuraiParts() : xParts[k];
        if ((R.engine === 'three' || R.engine === 'ascii') && parts) { setLoad(0.95, `dando corpo: ${k}…`); sets[k].solid = partsMesh(parts, { res: k === 'knight' || k === 'samurai' ? 0.014 : 0.018 }); }
        else sets[k].solid = hullFromPoints(sets[k], { skipBones: k === 'knight' || k === 'samurai' ? [16] : [] });
      } catch (e) { console.warn('corpo', k, e); }
      await new Promise(r => setTimeout(r, 0));
    }
    setLoad(0.96, 'guardando o mundo no aparelho…');
    await saveWorld(key, sets);
  } else setLoad(0.9, 'o mundo já estava guardado no aparelho…');
  const { ground, scene, knight } = sets;
  // Fase 3: cada conjunto de personagem leva o nome do seu .glb (assets/models/<nome>.glb)
  for (const k of MODEL_NAMES) if (sets[k]) sets[k].modelName = k;
  game.vegInfo = sets.meta.veg;

  // ── malhas ──
  game.groundMesh = R.addMesh(ground, { occlude: false, chunk: 3 });
  game.sceneMesh = R.addMesh(scene, { chunk: 2.5 });
  game.bodyPS = game.cls === 'samurai' ? sets.samurai : knight;
  game.knightMesh = R.addMesh(game.bodyPS);
  // espada avulsa: aparece na mão direita de um modelo .glb que não traga a sua (osso/objeto "Sword")
  if (R.loadModels) {
    const swPS = new PointSet(1);
    swPS.solid = partsMesh((game.cls === 'samurai' ? samuraiParts() : kParts).filter(q => q.bone === BONE.SWORD), { res: 0.01 });
    game.swordMesh = R.addMesh(swPS, { occlude: true }); game.swordMesh.visible = false;
  }

  game.blueMesh = R.addMesh(sets.blueBlade, { occlude: false }); game.blueMesh.visible = false;
  game.riverMesh = R.addMesh(sets.river, { occlude: false, chunk: 3 });
  // cavaleiro caído: a mesma armadura, numa pose fixa, encostado na muralha
  const fallenW = m4.mul(m4.mul(m4.translate(FALLEN.x, 0, FALLEN.z), m4.rotY(0.15)), m4.scale(KSCALE, KSCALE, KSCALE));
  const fallenBones = poseFallen().map(b => m4.mul(fallenW, b)); fallenBones[0] = m4.ident();
  game.fallenMesh = R.addMesh(knight, { bones: fallenBones });
  game.fallenMesh.noModel = true;    // cadáver encostado na muralha: fica com o corpo atual
  const fcape = makeCape(atlas);
  for (let i = 0; i < 260; i++) fcape.update(1 / 60, fallenBones[2], [{ c: m4.point(fallenBones[2], [0, 0.18, -0.02]), r: 0.25 * KSCALE }], [0, 0, 0]);
  game.fcapeMesh = R.addMesh(fcape.ps);
  // brasas do braseiro (só aparecem acesas)
  const coals = new PointSet(32);
  for (let i = 0; i < 22; i++) { const a = i * 2.4, r = 0.08 + (i % 5) * 0.06; coals.push([BRAZIER.x + Math.cos(a) * r, 1.15, BRAZIER.z + Math.sin(a) * r], [0, 1, 0], [1, 0, 0], 11, atlas.get(['•', '*', '·', '✶'][i % 4]), 0, 2 | 4, 0.07, i * 7); }
  game.coalMesh = R.addMesh(coals, { occlude: false });
  game.cape = makeCape(atlas); game.cape._emit(); game.capeMesh = R.addMesh(game.cape.ps, { dynamic: true });
  game.tabard = makeTabard(atlas); game.tabard._emit(); game.tabardMesh = R.addMesh(game.tabard.ps, { dynamic: true });
  game.banners = BANNERS.map(b => { const c = makeBanner(atlas, b.x, b.top, b.z); c._emit(); return { c, mesh: R.addMesh(c.ps, { dynamic: true }) }; });
  game.counts = { scene: scene.n + ground.n, knight: knight.n, total: scene.n + ground.n + knight.n * 2 + game.cape.ps.n };
  R.setupParticles(3800);

  // ── fogo, luz, clima ──
  game.fires = { brazier: fx.addFire([BRAZIER.x, 1.12, BRAZIER.z], 0.3, 170, 0.12), torches: TORCHES.map(t => fx.addFire([t[0], t[1], t[2]], 0.06, 32)) };
  fx.trees = trees.filter(t => t.kind === 'autumn').flatMap(t => t.canopy.map(c => [...c, [0.62, 0.24 + Math.random() * 0.25, 0.1]]));
  game.lights = LIGHTS.map(l => ({ ...l, value: l.base, level: l.name === 'braseiro' ? (game.brazierLit ? 1 : 0) : 1 }));
  game.weather = new Weather(game.settings.weather);
  game.weather.onChange = s => showWeather();
  setBrazier(game.brazierLit, false);
  game.audio = new Audio(); game.narrator = new Narrator();
  initGameplay(game, sets, atlas, saved);
  if (game.cls === 'samurai') { game.player.offhand = 'none'; game.tabardMesh.visible = false; }
  initBleed(game, atlas);
  initItems(game, sets, saved);
  // tudo o que é da Região I só aparece lá
  game.bladeLight = { name: 'lâmina azul', pos: [0, -5, 0], col: [0.35, 0.62, 1.0], radius: 3.6, base: 0.95, flicker: 0.12, level: 0 };
  game.lights.push(game.bladeLight);
  for (const m of [game.riverMesh, game.groundMesh, game.sceneMesh, game.fallenMesh, game.fcapeMesh, game.coalMesh, game.bossMesh, game.mantleMesh, game.shrineMesh, ...game.banners.map(b => b.mesh), ...game.breakables.map(b => b.mesh)]) m.area = 'r1';
  for (const f of [game.fires.brazier, ...game.fires.torches, game.shrineFire]) f.area = 'r1';
  for (const l of game.lights) if (l.name !== 'tocha do cavaleiro' && l.name !== 'lâmina azul') l.area = 'r1';
  game.setArea = (a) => setAreaV(game, a);
  if (R.loadModels) R.loadModels(MODEL_NAMES).then(f => { if (f.length) console.info('[ASHEN] modelos .glb:', f.join(', ')); });
  initVillage(game, sets, atlas, saved);
  initPalace(game, sets);
  initDungeon(game, sets, atlas);
  initOW(game, sets, atlas);
  if (saved && saved.area === 'palace') game.setArea('palace');
  if (saved && (saved.area === 'dungeon' || saved.lastRest === 'dungeon')) { await dungeonReady(game); if (saved.area === 'dungeon') game.setArea('dungeon'); }
  if (saved && saved.area === 'ow') {      // voltou ao jogo no Reino Partido: ergue o mundo antes de começar
    $('loading').classList.remove('hidden');
    await game.buildOpenWorld(f => setLoad(0.9 + f * 0.1, 'erguendo o Reino Partido…'));
    game.enterOpenWorld(true);
  }
  game.ring = new DetailRing(R);

  // ── interface ──
  const input = game.input = new Input(canvas);
  if (game.settings.bindings) input.setBindings(game.settings.bindings);
  game.hud = new Hud();
  game.menu = new Menu(game);
  setupControls(game);
  setupZoom(canvas);
  applySettings(false);
  window.addEventListener('resize', onResize);
  window.visualViewport && window.visualViewport.addEventListener('resize', onResize);
  window.addEventListener('orientationchange', () => setTimeout(onResize, 200));
  document.addEventListener('visibilitychange', () => { if (document.hidden && game.state === 'play') game.save(); });
  $('rotate-ok').onclick = () => { game.rotateDismissed = true; checkRotate(); };

  setLoad(1, '');
  $('load-text').textContent = ''; $('load-note').textContent = '';
  game.state = 'title'; game.ready = true;
  document.body.classList.add('title');
  $('loading').classList.add('overlay');
  $('bar').classList.add('hidden');
  const start = $('start');
  start.classList.remove('hidden');
  const touch = matchMedia('(pointer: coarse)').matches;
  $('start-hint').textContent = touch
    ? 'Joystick à esquerda · » corre · ⚔ ataca (toque de novo para o combo) · ◈ interage · dois dedos dão zoom · ≡ menu'
    : 'WASD/setas andam · Shift corre · J ou espaço ataca (combo) · E interage · roda do mouse dá zoom · Esc menu · F3 desempenho';
  start.onclick = () => { game.audio.unlock(); showSlots(touch); };
  if (sessionStorage.getItem('ashen.autostart')) { sessionStorage.removeItem('ashen.autostart'); setTimeout(() => beginPlay(false), 60); }
  window.addEventListener('pointerdown', () => game.audio.unlock(), { capture: true });
  window.addEventListener('keydown', function k(e) { game.audio.unlock(); if (game.state === 'title' && (e.code === 'Enter' || e.code === 'Space') && $('slots').classList.contains('hidden') && $('newgame').classList.contains('hidden')) { window.removeEventListener('keydown', k); showSlots(false); } });
  requestAnimationFrame(frame);
}

/** Os 3 saves: onde parou, classe, dificuldade, tempo de jogo. */
function showSlots(touch) {
  $('start').classList.add('hidden'); $('start-hint').classList.add('hidden'); $('newgame').classList.add('hidden');
  const box = $('slots'), list = $('slot-list'); box.classList.remove('hidden'); list.innerHTML = '';
  const fmt = s => { const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60); return h + 'h' + String(m).padStart(2, '0'); };
  Save.slots().forEach((d, i) => {
    const n = i + 1, el = document.createElement('div');
    el.className = 'slot' + (d ? '' : ' empty'); el.tabIndex = 0;
    if (d) {
      const C = CLASSES[d.cls] || CLASSES.knight, D = DIFFICULTY[d.diff] || DIFFICULTY.hard;
      el.innerHTML = `<span class="k">${C.kanji}</span><b>SAVE ${n}</b><span class="where"></span><small>${C.label} · ${D.label}</small><small>tempo ${fmt(d.playTime || 0)}${d.savedAt ? ' · ' + new Date(d.savedAt).toLocaleDateString('pt-BR') : ''}</small><button class="del" type="button">apagar</button>`;
      el.querySelector('.where').textContent = d.where || 'Início da jornada';
      el.querySelector('.del').onclick = (e) => { e.stopPropagation(); if (confirm(`Apagar o Save ${n} para sempre?`)) { Save.deleteSlot(n); showSlots(touch); } };
      el.onclick = () => {
        if (n === game.loadedSlot) { box.classList.add('hidden'); beginPlay(touch); return; }
        Save.setActive(n); sessionStorage.setItem('ashen.autostart', '1'); location.reload();
      };
    } else { el.innerHTML = `<b>SAVE ${n}</b><span>— vazio —</span><small>toque para começar uma nova jornada</small>`; el.onclick = () => showNewGame(n, touch); }
    list.appendChild(el);
  });
}
function showNewGame(n, touch) {
  $('slots').classList.add('hidden'); const box = $('newgame'); box.classList.remove('hidden');
  let cls = 'knight', diff = 'hard';
  const draw = () => {
    $('ng-class').innerHTML = Object.entries(CLASSES).map(([k, c]) => `<button type="button" data-c="${k}" class="${k === cls ? 'on' : ''}"><span class="k">${c.kanji}</span>${c.label}</button>`).join('');
    $('ng-diff').innerHTML = Object.entries(DIFFICULTY).map(([k, d]) => `<button type="button" data-d="${k}" class="${k === diff ? 'on' : ''}">${d.label}</button>`).join('');
    $('ng-desc').textContent = CLASSES[cls].desc + ' — ' + DIFFICULTY[diff].label + ': ' + DIFFICULTY[diff].desc;
    box.querySelectorAll('[data-c]').forEach(b => { b.onclick = () => { cls = b.dataset.c; draw(); }; });
    box.querySelectorAll('[data-d]').forEach(b => { b.onclick = () => { diff = b.dataset.d; draw(); }; });
  };
  draw();
  $('ng-back').onclick = () => showSlots(touch);
  $('ng-go').onclick = () => { Save.newGame(n, cls, diff); sessionStorage.setItem('ashen.autostart', '1'); location.reload(); };
}

function beginPlay(touch) {
  if (game.state !== 'title') return;
  if (touch) game.fullscreen();
  $('loading').classList.add('fade');
  setTimeout(() => $('loading').classList.add('hidden'), 950);
  game.state = 'play';
  document.body.classList.remove('title');
  game.input.clearAll();
  const region = () => { game.hud.showRegion(game.area === 'r1' ? REGION : (game.vs.phase === 'lush' ? V2.R2 : { region: V2.R2.region, title: 'Ruínas de Orvalho', subtitle: '灰の村' })); setTimeout(showWeather, 6500); };
  if (!game.introSeen) playOpening(game, region); else region();
  checkRotate();
}

function setupZoom(canvas) {
  const pts = new Map(); let pinch = null;
  const span = () => { const a = [...pts.values()]; return Math.hypot(a[0][0] - a[1][0], a[0][1] - a[1][1]); };
  const zoomTo = d => { CAM.dist = Math.max(CAM.min, Math.min(CAM.max, d)); };
  canvas.addEventListener('touchstart', e => { for (const t of e.changedTouches) pts.set(t.identifier, [t.clientX, t.clientY]); if (pts.size === 2) pinch = { s: span(), d: CAM.dist }; }, { passive: true });
  canvas.addEventListener('touchmove', e => { for (const t of e.changedTouches) if (pts.has(t.identifier)) pts.set(t.identifier, [t.clientX, t.clientY]); if (pinch && pts.size === 2) { e.preventDefault(); zoomTo(pinch.d * pinch.s / Math.max(20, span())); } }, { passive: false });
  const endT = e => { for (const t of e.changedTouches) pts.delete(t.identifier); if (pts.size < 2) pinch = null; };
  canvas.addEventListener('touchend', endT); canvas.addEventListener('touchcancel', endT);
  canvas.addEventListener('wheel', e => { e.preventDefault(); zoomTo(CAM.dist * Math.exp(e.deltaY * 0.0012)); }, { passive: false });
}

function applySettings(save = true) {
  const g = game, s = g.settings, eff = effective(s);
  const dpr = Math.min(window.devicePixelRatio || 1, eff.dpr);
  g.R.resize(dpr / (window.devicePixelRatio || 1));
  g.fx.density = eff.fx;
  g.shadowHalf = eff.shadow; g.shadowEvery = eff.shadowEvery || 1; g.far = eff.far || 50;
  g.R.lodNear = eff.lodNear || 4.5; g.R.lodMin = eff.lodMin || 0.2; g.R.pcf = eff.pcf || 1; g.R.solidQ = eff.solidQ != null ? eff.solidQ : 1; g.R.densK = eff.dens || 0.75; g.ringOn = !!eff.ring;
  if (g.R.setCell) g.R.setCell(eff.cell || 12);
  g.R.reflEvery = eff.reflEvery || 1;
  g.input.haptics = s.haptics;
  if (g.audio) g.audio.setVolume(s.sound !== false, s.volume == null ? 0.8 : s.volume, s.music == null ? 0.6 : s.music);
  if (g.narrator) { g.narrator.on = s.narration !== false; if (!g.narrator.on) g.narrator.stop(); }
  if (g.weather && g.weather.mode !== s.weather) { g.weather.setMode(s.weather); }
  document.documentElement.style.setProperty('--ctrl', s.controlScale);
  g.hud.showPerf(s.showPerf);
  if (save) Save.saveSettings(s);
}
game.applySettings = applySettings;

let resizeT = 0;
function onResize() { clearTimeout(resizeT); resizeT = setTimeout(() => { applySettings(false); checkRotate(); }, 120); }
function checkRotate() {
  const portrait = window.innerHeight > window.innerWidth * 1.05;
  const touch = matchMedia('(pointer: coarse)').matches;
  $('rotate').classList.toggle('hidden', !(portrait && touch && game.state === 'play' && !game.rotateDismissed));
}
game.fullscreen = () => {
  try {
    const el = document.documentElement;
    const p = el.requestFullscreen ? el.requestFullscreen({ navigationUI: 'hide' }) : null;
    if (p && p.then) p.then(() => { try { screen.orientation.lock('landscape').catch(() => {}); } catch (e) { /* ok */ } }).catch(() => {});
  } catch (e) { /* sem tela cheia */ }
};
function showWeather() {
  const el = $('weather-tag');
  el.textContent = '☁︎ ' + game.weather.label;
  el.classList.remove('hidden'); el.style.opacity = 1;
  clearTimeout(showWeather.t);
  showWeather.t = setTimeout(() => { el.style.opacity = 0; }, 3500);
}

// ─────────────── Progresso ───────────────
/** Onde o jogador parou (aparece no cartão do save). */
function whereLabel() {
  const g = game;
  if (g.area === 'r1') return g.bossDefeated ? 'Reino das Cinzas — Cemitério Real' : g.brazierLit ? 'Reino das Cinzas — Braseiro do Portão' : 'Reino das Cinzas — o despertar';
  if (g.area === 'r2' || g.area === 'house' || g.area === 'church') return g.vs && g.vs.phase === 'lush' ? 'Vale de Orvalho — a vila viva' : 'Vale de Orvalho — Ruínas';
  if (g.area === 'palace') return 'Palácio da Vigília';
  if (g.area === 'dungeon') return 'A Cripta dos Goblins';
  if (g.area === 'ow') return g.owWhere ? 'Reino Partido — ' + g.owWhere() : 'O Reino Partido';
  return 'Em algum lugar';
}
game.save = () => { const p = game.player; Save.saveGame({ x: +p.x.toFixed(2), z: +p.z.toFixed(2), brazierLit: game.brazierLit, cls: game.cls, diff: game.diffKey, playTime: Math.round(game.playTime), hour: +game.hour.toFixed(2), day: game.day, where: whereLabel(), ...gameplaySave(game), ...villageSave(game), ...(game.extraSave ? game.extraSave() : {}) }); };
game.replayIntro = () => { if (game.state === 'play' && !game.fight && game.area === 'r1') playOpening(game, null); };
game.restAt = (where) => rest(game, where);
// aviso de golpe: brilho nos olhos/arma do inimigo + som curto (mais alto quanto mais perto)
setTellHook((e, kind, h) => {
  const g = game, p = g.player, d = Math.hypot(e.x - p.x, e.z - p.z);
  if (d > 22 || g.state !== 'play') return;
  const y = (e.y != null ? e.y : groundY(e.x, e.z)) + h, f = [Math.sin(e.yaw || 0) * 0.18, Math.cos(e.yaw || 0) * 0.18];
  const col = kind === 'magic' ? [0.75, 0.45, 1] : kind === 'heavy' ? [1, 0.25, 0.12] : [1, 0.55, 0.2];
  g.fx.sparks([e.x + f[0], y, e.z + f[1]], kind === 'heavy' ? 26 : 14, col);
  g.audio.lastTellKind = kind; g.audio.play('tell', Math.max(0.25, 1 - d / 22));
});
game.skipHours = (h) => skipHours(game, h);
game.clockText = () => clockText(game);
game.doInteract = () => { const f = findFocus(game.player); if (f) interact(f); return f && f.id; };
game.respawn = () => {
  const p = game.player;
  const vat = dungeonRespawn(game) || owRespawn(game) || (game.lastRest === 'palace' ? (game.setArea('palace'), { x: PALACE_ENTRY.x, z: PALACE_ENTRY.z }) : null) || villageRespawn(game);
  const at = vat ? vat : game.lastRest === 'shrine' && game.shrine ? { x: game.shrine.x + 0.9, z: game.shrine.z + 1.0 } : game.brazierLit ? { x: BRAZIER.x + 0.9, z: BRAZIER.z + 1.1 } : SPAWN;
  Object.assign(p, { x: at.x, z: at.z, vx: 0, vz: 0, atk: -1, speed: 0 });
  game.cam.x = p.x; game.cam.z = p.z;
  game.teleported();
};
/** Depois de um salto de posição, os tecidos renascem pendurados no lugar. */
game.teleported = () => { game.cape.inited = false; game.tabard.inited = false; game.prevBones = null; const p = game.player; p.y = groundY(p.x, p.z); game.camY = p.y; };
game.resetProgress = () => { Save.clearGame(); game.hud.toast('Progresso apagado. Recarregue a página para recomeçar do início.'); };

function setBrazier(on, animate = true) {
  game.brazierLit = on;
  game.fires.brazier.off = !on;
  game.coalMesh.visible = on;
  if (on && animate) { game.fx.burst([BRAZIER.x, 1.2, BRAZIER.z], 80); game.audio && game.audio.play('ignite'); }
}

function interact(it) {
  const hud = game.hud;
  if (dungeonInteract(game, it) || villageInteract(game, it) || palaceInteract(game, it) || owInteract(game, it)) return;
  if (it.id === 'shrine') { rest(game, 'shrine'); hud.message(it.text, it.title, it); game.save(); hud.toast('Você descansa na Brasa do Rei: vida e frascos renovados. Progresso salvo.'); return; }
  if (it.id === 'brazier') {
    if (!game.brazierLit) { setBrazier(true); rest(game, 'brazier'); hud.message(LORE.brazierUnlit, it.title, it); game.save(); }
    else { rest(game, 'brazier'); hud.message(LORE.brazierLit, it.title, it); game.save(); hud.toast('Você descansa: vida e frascos renovados. Progresso salvo.'); }
    return;
  }
  hud.message(it.text, it.title, it);
}
function findFocus(p) {
  if (game.area === 'palace') return palaceFocus(p, game);
  if (game.area === 'dungeon') return dungeonFocus(p, game);
  if (game.area === 'ow') return dungeonFocus(p, game) || owFocus(p, game);
  if (game.area !== 'r1') return villageFocus(p, game);
  let best = null, bd = 1e9;
  for (const it of INTERACT) {
    const d = Math.hypot(p.x - it.x, p.z - it.z);
    if (d < it.r && d < bd) { bd = d; best = it; }
  }
  const ex = extraInteract(p, game);
  if (ex && ex.d < bd) best = ex;
  if (best && best.id === 'gate') best = { ...best, prompt: game.gateOpen ? 'olhar o portão aberto' : game.hasKey ? 'usar a chave do portão' : 'examinar o portão' };
  if (best && best.id === 'brazier') best.prompt = game.brazierLit ? 'descansar junto à chama' : 'acender o braseiro';
  return best;
}

// ─────────────── Física e controle ───────────────
/** Altura do chão onde o cavaleiro pisa (no mundo aberto o terreno tem relevo). */
function groundY(x, z) { return game.area === 'ow' && game.heightAt ? game.heightAt(x, z) : 0; }
function collide(p, r) {
  collideXZ(p, r);
  p.y = groundY(p.x, p.z);
}
function pushCol(p, r, c, circle) {
  if (circle) { const dx = p.x - c.x, dz = p.z - c.z, d = Math.hypot(dx, dz), rr = r + c.r; if (d < rr && d > 1e-6) { p.x = c.x + dx / d * rr; p.z = c.z + dz / d * rr; } }
  else { const qx = Math.max(c.x0, Math.min(p.x, c.x1)), qz = Math.max(c.z0, Math.min(p.z, c.z1)), dx = p.x - qx, dz = p.z - qz, d = Math.hypot(dx, dz); if (d < r) { if (d > 1e-6) { p.x = qx + dx / d * r; p.z = qz + dz / d * r; } else p.z = c.z1 + r; } }
}
function collideXZ(p, r) {
  const ac = dungeonColliders(game) || areaColliders(game) || palaceColliders(game) || owColliders(game);
  if (ac) {
    const [cols, B] = ac;
    // sem listas novas por quadro: percorre os colisores fixos do lugar atual e depois os móveis
    for (const c of cols) pushCol(p, r, c, c.type === 'circle');
    for (const d of dynamicColliders(game)) pushCol(p, r, d, true);
    p.x = Math.max(B.x0, Math.min(B.x1, p.x)); p.z = Math.max(B.z0, Math.min(B.z1, p.z));
    return;
  }
  for (const c of COLLIDERS) {
    if (colliderOff(game, c)) continue;              // a arena do chefe está limpa
    if (c.type === 'circle') {
      const dx = p.x - c.x, dz = p.z - c.z, d = Math.hypot(dx, dz), rr = r + c.r;
      if (d < rr && d > 1e-6) { p.x = c.x + dx / d * rr; p.z = c.z + dz / d * rr; }
    } else {
      const qx = Math.max(c.x0, Math.min(p.x, c.x1)), qz = Math.max(c.z0, Math.min(p.z, c.z1));
      const dx = p.x - qx, dz = p.z - qz, d = Math.hypot(dx, dz);
      if (d < r) { if (d > 1e-6) { p.x = qx + dx / d * r; p.z = qz + dz / d * r; } else p.z = c.z1 + r; }
    }
  }
  for (const o of game.breakables || []) {
    if (!o.alive) continue;
    const dx = p.x - o.x, dz = p.z - o.z, d = Math.hypot(dx, dz), rr = r + 0.45;
    if (d < rr && d > 1e-6) { p.x = o.x + dx / d * rr; p.z = o.z + dz / d * rr; }
  }
  p.x = Math.max(BOUNDS.x0, Math.min(BOUNDS.x1, p.x)); p.z = Math.max(BOUNDS.z0 + r, Math.min(BOUNDS.z1, p.z));
}
const angDiff = (a, b) => Math.atan2(Math.sin(a - b), Math.cos(a - b));

function step(dt) {
  const g = game, p = g.player, input = g.input, st = input.poll();
  if (input.take('menu')) { g.menu.toggle(); return; }
  if (input.take('debug')) { g.settings.showPerf = !g.settings.showPerf; applySettings(); }
  if (p.sitting) { p.speed = 0; p.time = g.t; world(dt); g.hud.update(dt, p); return; }
  if (g.traveling || g.dialog.open) {
    if (input.take('interact') || input.take('attack')) g.dialog.advance();
    p.speed = 0; p.blend += (0 - p.blend) * Math.min(1, dt * 4); p.time = g.t; p.breath = (p.breath + dt / 3.8) % 1;
    world(dt); g.hud.update(dt, p); g.focus = null; return;
  }
  g.focus = findFocus(p);
  if (input.take('interact')) { if (g.hud.msgOpen) g.hud.advance(); else if (g.focus) interact(g.focus); }
  // ── movimento com peso: acelera e freia aos poucos, gira com limite ──
  const fx = -Math.sin(CAM.yaw), fz = -Math.cos(CAM.yaw), rx = Math.cos(CAM.yaw), rz = -Math.sin(CAM.yaw);
  let wx = rx * st.mx + fx * -st.my, wz = rz * st.mx + fz * -st.my;
  const mag = Math.min(1, Math.hypot(st.mx, st.my));
  const wl = Math.hypot(wx, wz); if (wl > 0) { wx /= wl; wz /= wl; }
  if (g.cinema.active) {
    p.speed = 0; p.blend += (0 - p.blend) * Math.min(1, dt * 4); p.time = g.t;
    if (p.wake > 0) { p.wake = Math.max(0, p.wake - dt / 4); p.dead = p.wake; }
    combatPost(g, dt); villageStep(g, dt); palaceStep(g); owStep(g, dt); dungeonStep(g, dt); world(dt); g.hud.update(dt, p); return;
  }
  const C = combatPre(g, dt, input, st, mag > 0.05 ? Math.atan2(wx, wz) : null);
  if (C.lock) {
    const ox = p.x, oz = p.z;
    if (C.vel) { p.x += C.vel[0] * dt; p.z += C.vel[1] * dt; collide(p, 0.32); }
    p.speed = 0; p.vx = (p.x - ox) / dt; p.vz = (p.z - oz) / dt;
    p.blend += (0 - p.blend) * Math.min(1, dt * 5); p.time = g.t;
    p.breath = (p.breath + dt / 3.0) % 1;
    const k = 1 - Math.exp(-dt * 4.5);
    g.cam.x += (p.x - g.cam.x) * k; g.cam.z += (p.z - g.cam.z) * k;
    combatPost(g, dt); villageStep(g, dt); palaceStep(g); owStep(g, dt); dungeonStep(g, dt); world(dt); g.hud.update(dt, p);
    return;
  }
  const attacking = p.atk >= 0;
  const running = st.run && mag > 0.3 && !attacking && p.sta > 0 && p.block < 0.5;
  p.run += ((running ? 1 : 0) - p.run) * Math.min(1, dt * 3);
  let target = (1.55 + 2.1 * p.run) * (g.agiK || 1) * (st.analog ? Math.max(0.35, mag) : (mag > 0 ? 1 : 0));
  if (attacking) target *= 0.15;
  const wade = g.area === 'r1' ? wadeDepth(p.x, p.z) : 0;
  p.wade = wade;
  if (wade > 0.02) target *= 1 - Math.min(0.5, wade * 1.6);
  if (p.webbed > 0) target *= 0.42;
  target *= C.speedMul == null ? 1 : C.speedMul;
  if (running) { p.sta -= dt * 9; p.staWait = 0.4; }
  let look = 0;
  if (mag > 0.05) {
    const want = Math.atan2(wx, wz), d = angDiff(want, p.yaw);
    look = d;
    // virada grande parado: gira primeiro (com passinhos), depois anda
    if (Math.abs(d) > 1.6 && p.speed < 0.6) target *= 0.2;
    const rate = attacking ? (p.atk < 0.25 ? 6 : 0.8) : (5.5 - 2.2 * p.run);
    const turn = Math.max(-rate * dt, Math.min(rate * dt, d));
    p.yaw += turn;
    p.turn += (turn / dt - p.turn) * Math.min(1, dt * 8);
    if (p.speed < 0.4) p.phase = (p.phase + Math.abs(turn) * 0.16) % 1;
  } else p.turn *= 1 - Math.min(1, dt * 6);
  p.look += (look - p.look) * Math.min(1, dt * 10);
  const accel = target > p.speed ? 3.6 + 1.5 * p.run : 6.5;
  const prevSpeed = p.speed;
  p.speed += Math.max(-accel * dt, Math.min(accel * dt, target - p.speed));
  p.accel += ((p.speed - prevSpeed) / dt - p.accel) * Math.min(1, dt * 10);
  const ox = p.x, oz = p.z;
  p.x += Math.sin(p.yaw) * p.speed * dt; p.z += Math.cos(p.yaw) * p.speed * dt;
  if (C.vel) { p.x += C.vel[0] * dt; p.z += C.vel[1] * dt; }
  collide(p, 0.32);
  const rvx = (p.x - ox) / dt, rvz = (p.z - oz) / dt, sp = Math.hypot(rvx, rvz);
  p.vx = rvx; p.vz = rvz;
  const moving = sp > 0.1;
  p.blend += ((moving ? 1 : 0) - p.blend) * Math.min(1, dt * (moving ? 6 : 3.2));
  if (p.blend < 0.01) p.blend = 0;
  const stride = 4 * (0.3 + 0.2 * p.run);
  const ph0 = p.phase;
  if (moving) p.phase = (p.phase + sp * dt / stride) % 1;
  if (moving && p.blend > 0.3 && (Math.floor(ph0 * 2) !== Math.floor(p.phase * 2))) {
    if (p.wade > 0.02) { g.audio.play('wade', 0.6 + p.wade * 2); g.fx.splash([p.x, RIVER.y + 0.02, p.z], 6 + (p.run * 6 | 0)); } else g.audio.play('step', 0.7 + 0.5 * p.run);
  }
  else if (p.blend > 0.02) {             // ao parar, termina o passo e assenta o pé
    const tgt = p.phase < 0.5 ? 0.5 : 1;
    p.phase = Math.min(tgt, p.phase + dt * 0.9) % 1;
  }
  p.breath = (p.breath + dt / (3.8 - 1.4 * p.blend - 0.9 * p.run)) % 1;
  p.time = g.t;
  if (moving) { g.trailAcc += sp * dt; if (g.trailAcc > 0.33) { g.trailAcc = 0; g.footSide = -(g.footSide || 1); const r = 0.11 * g.footSide; g.trail.unshift([p.x + Math.cos(p.yaw) * r, p.z - Math.sin(p.yaw) * r, g.t]); g.trail.length = Math.min(g.trail.length, 8); } }
  // câmera: acompanha com suavização e antecipação
  const k = 1 - Math.exp(-dt * 4.5);
  // na luta, a câmera enquadra o cavaleiro e o chefe
  const fb = g.fight && g.boss ? 0.38 : 0;
  const fx_ = p.x + rvx * 0.35 + (fb ? (g.boss.x - p.x) * fb : 0), fz_ = p.z + rvz * 0.35 + (fb ? (g.boss.z - p.z) * fb : 0);
  g.cam.x += (fx_ - g.cam.x) * k;
  g.cam.z += (fz_ - g.cam.z) * k;
  g.fightZoom = (g.fightZoom || 0) + ((g.fight ? 1 : 0) - (g.fightZoom || 0)) * Math.min(1, dt * 1.5);
  combatPost(g, dt);
  villageStep(g, dt); palaceStep(g); owStep(g, dt); dungeonStep(g, dt); bleedStep(g, dt);
  if (g.pendingLevel && !g.hud.msgOpen && !g.dialog.open) { g.pendingLevel = false; g.openLevel(); }
  g.playTime += dt;
  advanceTime(g, dt);
  if ((g.clockT = (g.clockT || 0) - dt) <= 0) { g.clockT = 1; const c = $('clock'); c.classList.remove('hidden'); c.textContent = (g.hour >= 6 && g.hour < 18 ? '☀ ' : '☾ ') + clockText(g) + ' · dia ' + ((g.day || 0) + 1) + (g.darkMoon ? ' · LUA SOMBRIA' : ''); }
  world(dt);
  g.hud.update(dt, p);
  g.autosave = (g.autosave || 0) + dt;
  if (g.autosave > 25) { g.autosave = 0; g.save(); }
}

/** Ambiente: clima, vento, fogo e partículas (roda também na tela de título). */
function world(dt) {
  const g = game;
  g.t += dt;
  const W = g.weather;
  const hadBolt = !!W.bolt;
  W.update(dt);
  if (W.bolt && !hadBolt) g.audio.thunder(W.bolt.dist, (0.6 + 0.4 * W.rain) * (g.indoor ? 0.55 : 1));
  const damp = W.fireDamp;
  for (const l of g.lights) {
    if (l.name === 'braseiro') l.level += ((g.brazierLit ? 1 : 0) - l.level) * Math.min(1, dt * 1.5);
    const s = l.pos[0] * 3.1 + l.pos[2];
    const n = 0.5 + 0.25 * Math.sin(g.t * 9.7 + s) + 0.15 * Math.sin(g.t * 23.1 + s * 2) + 0.1 * Math.sin(g.t * 3.3 + s * 0.5);
    l.pop = (l.pop || 0) * 0.9 + (Math.random() < 0.02 + damp * 0.05 ? 0.35 : 0);
    const base = l.base0 || (l.base0 = l.base);
    l.lvS = l.lvS == null ? (l.level == null ? 1 : l.level) : l.lvS + ((l.level == null ? 1 : l.level) - l.lvS) * Math.min(1, dt * 2.2);   // acende/apaga devagar
    l.base = base * l.lvS * (1 - damp);                       // a chuva abafa a chama
    l.value = l.base * (1 - (l.flicker + damp * 0.3) * n + l.pop * 0.25);
  }
  const wa = 0.35 + 0.5 * Math.sin(g.t * 0.05) + 0.15 * Math.sin(g.t * 0.21);
  const wsd = (0.55 + 0.3 * Math.sin(g.t * 0.17) + 0.15 * Math.sin(g.t * 0.53 + 1.3)) * (1 + W.rain * 0.6);
  g.wind = [Math.cos(wa), Math.sin(wa), wsd];
  g.fx.wind = [g.wind[0] * wsd * 0.7, 0, g.wind[1] * wsd * 0.7];
  g.fx.rain = g.indoor ? 0 : W.rain;
  g.fx.leafRate = 0.05 + wsd * 0.12;
  g.fx.update(dt, g.t, [g.cam.x, g.camY || 0, g.cam.z]);
  // som ambiente: vento, chuva, fogo perto, tremor
  const p = g.player;
  let fire = g.player.offhand === 'torch' && g.torchFire && !g.torchFire.off ? 0.25 : 0;
  for (const l of g.lights) { if (l.name === 'tocha do cavaleiro' || (l.area && l.area !== g.area)) continue; const d = Math.hypot(l.pos[0] - p.x, l.pos[2] - p.z); fire = Math.max(fire, (l.level == null ? 1 : l.level) * Math.max(0, 1 - d / 6) * (l.name === 'chama roubada' && !g.shrine ? 0 : 1)); }
  const river = g.area === 'r1' ? Math.max(0, 1 - Math.max(0, RIVER.z0 - p.z) / 9) : 0;
  const fwd = [-Math.sin(CAM.yaw), -Math.cos(CAM.yaw)];
  g.audio.listen(p.x, (p.y || 0) + 1.5, p.z, fwd[0], fwd[1]);
  const fires = g._fires || (g._fires = []); fires.length = 0; g.fireRefs = g.fireRefs || new Map();
  for (const s of g.fx.sources) { if (s.off || s.radius < 0.1 || (s.area && s.area !== g.area)) continue; let r = g.fireRefs.get(s); if (!r) g.fireRefs.set(s, r = { level: 1 }); r.x = s.pos[0]; r.y = s.pos[1]; r.z = s.pos[2]; fires.push(r); }
  g.audio.ambient({ dt, wind: Math.min(1, wsd / 1.4), rain: g.indoor ? W.rain * 0.6 : W.rain, fire: Math.min(1, fire), quake: g.quakeLvl || 0, river, fires, windDir: [Math.cos(wa), Math.sin(wa)], fwd, storm: W.state === 'tempestade', indoor: !!g.indoor, leafy: g.area === 'ow' || g.area === 'r2' });
  g.audio.music(pickMusic(g));
}

/** Trilha por lugar: Cold Journey no Reino Partido, Oppressive Gloom nos lugares sombrios e nas lutas,
 *  Mourning Song nas vilas, junto ao fogo e nas cenas tristes. */
function pickMusic(g) {
  if (g.state === 'title') return 'luto';
  if (g.cinema.active) return (g.cinema.cur && g.cinema.cur.music) || 'luto';
  const p = g.player;
  if (g.profFight || g.spiderFight || g.darkMoon || g.goblinKingFight || (g.boss && g.boss.alive && g.area === 'r1')) return 'sombra';
  if (p.sitting) return 'luto';
  if (g.area === 'r2' || g.area === 'house') return 'luto';
  if (g.area === 'ow') {
    for (const s of [SITES.village, SITES.her]) if (Math.hypot(p.x - s.x, p.z - s.z) < 60) return 'luto';
    return 'jornada';
  }
  return 'sombra';
}

// ─────────────── Desenho ───────────────
function render(dtFrame = 1 / 60) {
  const g = game, R = g.R, p = g.player, W = g.weather;
  const sink = g.area === 'r1' ? -Math.min(0.3, wadeDepth(p.x, p.z) + (wadeDepth(p.x, p.z) > 0 ? 0.12 : 0)) : 0;
  const Wm = m4.mul(m4.mul(m4.translate(p.x, (p.sitting ? 0.42 : (p.y || 0)) + sink, p.z), m4.rotY(p.yaw)), m4.scale(KSCALE, KSCALE, KSCALE));
  const pose = p.sitting ? poseSeated(g.t) : poseKnight(p);
  const bones = pose.map(b => m4.mul(Wm, b));
  bones[0] = m4.ident();
  bones.torch = pose.torch; bones.shield = pose.shield;
  gameplayRender(g, Wm, bones, dtFrame);
  // modelo .glb do jogador: posição do jogo, estado do combate; capa e tabardo do jogo saem (o .glb traz a roupa)
  g.knightMesh.modelMatrix = Wm; g.knightMesh.animState = p.sitting ? 'idle' : stateOf(p, p.combo);
  const glbOn = !!g.knightMesh.model;
  if (glbOn) { g.capeMesh.visible = false; g.tabardMesh.visible = false; }
  else if (g._glbWas) { g.capeMesh.visible = true; g.tabardMesh.visible = g.cls !== 'samurai'; }
  g._glbWas = glbOn;
  if (g.ring) {
    const hf = g.area === 'r1' ? groundHeight : g.area === 'r2' ? groundHeight2 : g.area === 'ow' ? g.heightAt : null;
    g.ring.update(!!g.ringOn, p.x, p.z, hf, g.area === 'r1' ? (x, z) => z > RV.z0 + 0.1 && z < RV.z1 : g.ringSkip || null);
  }
  villageRender(g, dtFrame);
  owRender(g); dungeonRender(g);
  g.dialog.update(dtFrame);
  g.knightMesh.boneData = flatBones(bones, g.knightMesh.boneData);
  if (g.swordMesh) {
    const md = g.knightMesh._modelOn && g.knightMesh.model, hr = md && md.hand('R');
    g.swordMesh.visible = !!md && !md.ownSword && p.dead < 0.6;
    if (g.swordMesh.visible) {
      const bd = g.swordMesh.boneData && g.swordMesh.boneData.length === g.knightMesh.boneData.length ? g.swordMesh.boneData : new Float32Array(g.knightMesh.boneData.length);
      bd.set(g.knightMesh.boneData);
      if (hr && bones[9]) { const o = BONE.SWORD * 16; bd[o + 12] += hr[0] - bones[9][12]; bd[o + 13] += hr[1] - bones[9][13]; bd[o + 14] += hr[2] - bones[9][14]; }
      g.swordMesh.boneData = bd;
    }
  }
  crownRender(g, bones);
  // espada azul: a lâmina brilha, ilumina em volta e solta faíscas frias
  g.blueMesh.visible = !!g.blueSword && p.dead < 0.6;
  if (g.blueMesh.visible) {
    g.blueMesh.boneData = g.knightMesh.boneData;
    const mid = m4.point(bones[16], [0, 0.7, 0]);
    g.bladeLight.pos = mid; g.bladeLight.level = 1;
    if (Math.random() < 0.25) g.fx.sparks(m4.point(bones[16], [0, 0.3 + Math.random() * 0.8, 0]), 1, [0.45, 0.75, 1]);
  } else g.bladeLight.level = 0;
  boneVelocities(g, bones, dtFrame);
  const frac = Math.max(0.24, Math.min(1, Math.pow(3.6 / CAM.dist, 1.5)));
  g.fallenMesh.visible = Math.hypot(g.cam.x - FALLEN.x, g.cam.z - FALLEN.z) < 12;
  for (const m of [g.knightMesh, g.fallenMesh]) { m.lodDraw = true; m.drawCount = Math.round(m.n * frac); m.sizeMul = Math.min(1.9, Math.pow(1 / frac, 0.5) * 0.97); }
  // rastro da lâmina no corte
  if (p.atk >= 0) {
    const C = COMBO[p.combo];
    if (p.atk > C.hit[0] - 0.04 && p.atk < C.hit[1] + 0.06) g.fx.slash(m4.point(bones[16], [0, 0.45, 0]), m4.point(bones[16], [0, 1.1, 0]), !!g.blueSword);
  }
  // tecidos
  const chestW = bones[2];
  const spheres = [
    { c: m4.point(chestW, [0, 0.18, -0.02]), r: 0.25 }, { c: m4.point(chestW, [0.2, 0.27, -0.02]), r: 0.15 }, { c: m4.point(chestW, [-0.2, 0.27, -0.02]), r: 0.15 }, { c: m4.point(chestW, [0, -0.02, -0.02]), r: 0.22 },
    { c: m4.point(bones[1], [0, -0.1, -0.02]), r: 0.22 },
    { c: m4.point(bones[10], [0, -0.2, 0]), r: 0.12 }, { c: m4.point(bones[13], [0, -0.2, 0]), r: 0.12 },
    { c: m4.point(bones[11], [0, -0.2, 0]), r: 0.09 }, { c: m4.point(bones[14], [0, -0.2, 0]), r: 0.09 },
  ];
  for (const q of spheres) q.r *= KSCALE;
  const wind = [g.fx.wind[0] * 1.1 - p.vx * 0.9, 0, g.fx.wind[2] * 0.8 - p.vz * 0.9];
  const legs = spheres.slice(5).map(s => ({ c: s.c, r: s.r + 0.03 }));
  const sub = Math.min(4, Math.max(1, Math.round(dtFrame * 60)));
  g.cape.wet = g.tabard.wet = W.wet;
  g.cape.floor = g.tabard.floor = p.y || 0;
  for (let i = 0; i < sub; i++) { g.cape.update(dtFrame / sub, chestW, spheres, wind); g.tabard.update(dtFrame / sub, bones[1], legs, wind); }
  R.updateMesh(g.capeMesh, g.cape.ps);
  R.updateMesh(g.tabardMesh, g.tabard.ps);
  const I = m4.ident(), bw = [g.fx.wind[0] * 2.4, 0, g.fx.wind[2] * 2.4];
  if (g.area === 'r1') for (const b of g.banners) { b.c.wet = W.wet; b.c.update(dtFrame, I, [], bw); R.updateMesh(b.mesh, b.c.ps); }
  // câmera: de perto mais baixa (foto de corpo inteiro), de longe mais alta
  const dist = CAM.dist + (g.fightZoom || 0) * Math.max(0, 7.5 - CAM.dist);
  const zk = (dist - CAM.min) / (CAM.max - CAM.min);
  CAM.pitch = R.ascii ? 0.98 + 0.13 * zk : g.area === 'ow' ? 0.13 + 0.3 * zk : 0.3 + 0.44 * zk;   // ASCII: câmera elevada, 56°–63°
  CAM.max = g.area === 'ow' ? 18 : 10;
  g.camY = (g.camY == null ? p.y : g.camY) + ((p.y || 0) - (g.camY || 0)) * Math.min(1, dtFrame * 5);
  const target = [g.cam.x, g.camY + 0.9 + 0.05 * zk, g.cam.z - 0.2 * zk];
  const eye = [target[0] + Math.sin(CAM.yaw) * Math.cos(CAM.pitch) * dist, target[1] + Math.sin(CAM.pitch) * dist, target[2] + Math.cos(CAM.yaw) * Math.cos(CAM.pitch) * dist];
  const cine = g.cinema.update(g.state === 'play' ? dtFrame : 0);
  if (cine) { eye.splice(0, 3, ...cine.eye); target.splice(0, 3, ...cine.target); }
  g.shake = Math.max(0, (g.shake || 0) - dtFrame * 0.5);
  const sk = (g.shake || 0) + (cine ? cine.shake : 0);
  if (sk > 0) for (const v of [eye, target]) { v[0] += (Math.random() - 0.5) * sk; v[1] += (Math.random() - 0.5) * sk; }
  const view = m4.lookAt(eye, target, [0, 1, 0]);
  const proj = m4.perspective(CAM.fov, R.W / R.H, 1, g.area === 'ow' ? 560 : (g.far || 50));
  g.frameN = (g.frameN || 0) + 1;
  const vp = m4.mul(proj, view);
  const moonDir = v3.norm([-0.5, 0.78, 0.38]);
  const half = g.shadowHalf || 11;
  const lc = cine ? [cine.target[0], cine.target[1] - 1, cine.target[2]] : [g.cam.x, g.camY, g.cam.z - 1];
  const lightView = m4.lookAt(v3.add(lc, v3.mul(moonDir, 25)), lc, [0, 1, 0]);
  const lightVP = m4.mul(m4.ortho(-half, half, -half, half, 1, 70), lightView);
  const cloud = 1 - 0.4 * W.rain, fl = W.flash;
  const night = {
    moonDir, moonCol: g.area === 'ow' ? [1.05 * cloud, 1.1 * cloud, 1.35 * cloud] : [0.7 * cloud, 0.76 * cloud, 0.98 * cloud], sky: [0.16 * cloud + 0.02 * W.rain, 0.17 * cloud + 0.02 * W.rain, 0.23 * cloud + 0.03 * W.rain], ground: [0.07, 0.06, 0.06],
    rimCol: [0.3 * cloud, 0.36 * cloud, 0.52 * cloud],
    fog: g.area === 'ow' ? [0.16 + 0.03 * W.rain, 0.18 + 0.03 * W.rain, 0.25 + 0.03 * W.rain, 0.0045 * (1 + W.rain * 0.9)] : [0.05 + 0.03 * W.rain, 0.05 + 0.035 * W.rain, 0.07 + 0.04 * W.rain, 0.07 * (1 + W.rain * 0.9)],
    clear: g.area === 'ow' ? [0.06 + fl * 0.25, 0.07 + fl * 0.27, 0.11 + fl * 0.34] : [0.022 + fl * 0.25, 0.019 + fl * 0.27, 0.028 + fl * 0.34],
  };
  if (g.darkMoon) { night.moonCol = [1.1 * cloud, 0.18, 0.15]; night.fog = [0.16, 0.02, 0.03, night.fog[3] * 1.4]; night.clear = [0.12, 0.01, 0.02]; night.sky = [0.2, 0.03, 0.04]; }
  const L = skyAt(g, night, cloud, W.rain);
  g.dayK = L.day;
  // escuridão do lugar (0 = dia aberto, 1 = breu): decide a força da tocha e o destaque dos personagens
  const darkBase = g.area === 'ow' ? 1 - L.day : g.area === 'dungeon' ? 1 : g.area === 'r1' ? 0.85 : g.area === 'palace' ? 0.35 : 0.6;
  const dark = Math.min(1, darkBase + (g.indoor ? 0 : W.rain * 0.3) + (g.darkMoon ? 0.4 : 0));
  g.darkLvl = g.darkLvl == null ? dark : g.darkLvl + (dark - g.darkLvl) * Math.min(1, dtFrame * 1.5);   // transição suave
  const TL = g.torchLight, tv = TL ? (TL.value || TL.base) / (TL.base0 || TL.base || 1) : 1;
  const torchW = TL ? Math.min(1, TL.level) * Math.max(0, (g.darkLvl - 0.15) / 0.85) : 0;
  // água à vista no mundo aberto? (o reflexo só é desenhado quando há lago perto da câmera)
  let owWater = null;
  if (g.area === 'ow' && g.heightAt) { g._wq = (g._wq || 0) + 1; if (g._wq % 15 === 1) { g._wNear = false; for (let i = -2; i <= 2 && !g._wNear; i++) for (let j = -2; j <= 2; j++) if (g.heightAt(g.cam.x + i * 7, g.cam.z + j * 6) < -5.9) { g._wNear = true; break; } } if (g._wNear) owWater = -6; }
  R.frame({ waterLevel: g.area === 'ow' ? -6 : null, reflWater: g.area === 'ow' ? owWater : undefined,
    torch: TL && torchW > 0.01 ? [TL.pos[0], TL.pos[1], TL.pos[2], torchW] : null, torchR: 5.2 * (0.94 + 0.06 * Math.max(0, Math.min(2, tv))), actorLift: Math.max(0, (g.darkLvl - 0.25) / 0.75),
    dt: dtFrame, vp, view, proj, lightVP, cam: eye, shadowRefresh: (g.frameN % (g.shadowEvery || 1)) === 0 || !!cine, focus: [p.x, p.y || 0, p.z], time: g.t,
    pxScale: proj[5] * R.H / 2, glyphScale: 1, bias: 0.06, exposure: L.exposure || 12, shadowSize: 0.55 / half, shadows: true,
    moonDir: L.moonDir, moonCol: L.moonCol, sky: L.sky, ground: L.ground,
    rimDir: v3.norm([0.55, 0.35, -0.75]), rimCol: L.rimCol,
    wet: g.indoor ? 0 : W.wet, rain: g.indoor ? 0 : W.rain, flash: g.indoor ? 0 : fl,
    arena: [ARENA.x, ARENA.z, ARENA.r, g.arenaK || 0], arenaKeep: [game.boss ? game.boss.home.x : 0, game.boss ? game.boss.home.z + 0.4 : 0, 1.3],
    trail: g.trail, lights: nearLights(g, eye), wind: g.wind,
    fog: L.fog, clear: [L.clear[0] + fl * 0.25, L.clear[1] + fl * 0.27, L.clear[2] + fl * 0.34], particles: g.fx.fill(),
  });
}

/** As 6 luzes mais perto da câmera, só as do lugar onde o cavaleiro está. */
function nearLights(g, eye) {
  const L = g._nearL || (g._nearL = []);
  L.length = 0;                                              // zera a lista do quadro anterior
  for (const l of g.lights) if ((!l.area || l.area === g.area) && ((l.lvS != null ? l.lvS : l.level == null ? 1 : l.level) > 0.01)) { const dx = l.pos[0] - eye[0], dz = l.pos[2] - eye[2]; l._d2 = dx * dx + dz * dz; L.push(l); }
  L.sort((a, b) => a._d2 - b._d2);
  return L;
}

/** Velocidade linear e angular de cada osso (para os caracteres reagirem ao movimento). */
function boneVelocities(g, bones, dt) {
  const vel = g.velData || (g.velData = new Float32Array(18 * 4)), ang = g.angData || (g.angData = new Float32Array(18 * 4));
  const prev = g.prevBones;
  if (prev && dt > 0) {
    for (let i = 1; i < Math.min(18, bones.length); i++) {
      const a = bones[i], b = prev[i];
      for (let k = 0; k < 3; k++) vel[i * 4 + k] = vel[i * 4 + k] * 0.4 + 0.6 * (a[12 + k] - b[12 + k]) / dt;
      const r = (row, col) => a[0 + row] * b[0 + col] + a[4 + row] * b[4 + col] + a[8 + row] * b[8 + col];
      const tr = r(0, 0) + r(1, 1) + r(2, 2), s = 1 / (KSCALE * KSCALE);
      const c = Math.max(-1, Math.min(1, (tr * s - 1) / 2)), th = Math.acos(c);
      const w = [r(2, 1) - r(1, 2), r(0, 2) - r(2, 0), r(1, 0) - r(0, 1)], wl = Math.hypot(w[0], w[1], w[2]);
      for (let k = 0; k < 3; k++) ang[i * 4 + k] = ang[i * 4 + k] * 0.4 + 0.6 * (wl > 1e-6 ? w[k] / wl * th / dt : 0);
    }
  }
  g.prevBones = bones.map(m => m.slice());
  g.knightMesh.velData = vel; g.knightMesh.angData = ang;
}

// ─────────────── Laço ───────────────
let last = 0, acc = 0, fps = 60, frameMs = 16, cpuMs = 0, perfT = 0;
function frame(now) {
  requestAnimationFrame(frame);
  const cap = game.settings.fpsCap;
  if (cap && last && now - last < 1000 / cap - 2) return;
  const dt = last ? Math.min(0.1, (now - last) / 1000) : STEP;
  if (last) { frameMs += ((now - last) - frameMs) * 0.08; fps = 1000 / frameMs; }
  last = now;
  const t0 = performance.now();
  if (game.state === 'play' && !game.menu.open && game.hitstop > 0) {
    // hitstop: congela só a lógica do jogo (combate, física, animação); o áudio segue e os toques ficam no buffer
    game.hitstop = Math.max(0, game.hitstop - dt); acc = 0;
  } else if (game.state === 'play' && !game.menu.open) {
    acc += dt;
    let n = 0;
    while (acc >= STEP && n < 4) { step(STEP); acc -= STEP; n++; }
    if (n >= 4) acc = 0;
  } else { world(dt); game.player.breath = (game.player.breath + dt / 3.8) % 1; game.player.time = game.t; acc = 0; }
  render(dt);
  cpuMs += (performance.now() - t0 - cpuMs) * 0.1;
  const f = game.focus, touch = game.input.lastDevice === 'touch';
  game.hud.setPrompt(game.state === 'play' && !game.menu.open && f ? f.prompt : '', (game.input.bindings.interact[0] || 'E').replace(/^Key/, ''), touch);
  updateInteractButton(f);
  if (game.settings.showPerf && now - perfT > 300) {
    perfT = now;
    const R = game.R, c = game.counts, v = game.vegInfo || [0, 0, 0];
    game.hud.perfText(`FPS ${Math.round(fps)} · CPU ${cpuMs.toFixed(1)} ms · na tela ${R.stats.glyphs.toLocaleString('pt-BR')}
mundo ${c.scene.toLocaleString('pt-BR')} · cavaleiro ${(game.knightMesh.drawCount || c.knight).toLocaleString('pt-BR')}/${c.knight.toLocaleString('pt-BR')}
vegetação ${v[0]} tufos · ${v[1]} plantas · ${v[2]} segmentos
clima ${game.weather.label} · chuva ${(game.weather.rain * 100) | 0}% · molhado ${(game.weather.wet * 100) | 0}%
partículas ${R.stats.particles} · ${R.W}×${R.H} px · ${game.settings.preset}${R.engine === 'ascii' ? `\nASCII · ${R.asciiPass.cols}×${R.asciiPass.rows} células · ${R.stats.calls} desenhos · ${(R.stats.instances || 0).toLocaleString('pt-BR')} traços/objetos` : ''}${R.engine === 'three' ? `\nThree.js · caracteres nos materiais · ${(R.stats.tris || 0).toLocaleString('pt-BR')} triângulos · ${R.stats.calls} desenhos · ${(R.stats.instances || 0).toLocaleString('pt-BR')} instâncias 3D` : ''}`);
  }
}

function registerSW() {
  try {
    // no aplicativo Android os arquivos já estão no aparelho: sem service worker
    if (/ASHENApp/.test(navigator.userAgent)) return;
    if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./service-worker.js').catch(e => console.info('[ASHEN] SW indisponível:', e.message));
  } catch (e) { /* ok */ }
}
registerSW();

boot().catch(err => { console.error(err); $('load-text').textContent = 'Erro ao iniciar: ' + err.message; });
