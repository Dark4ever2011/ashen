// ASHEN — Logotipo em blocos (letras desenhadas para o jogo, não é fonte de terceiros).
const L = {
  A: [' ▄██▄ ', '██  ██', '██████', '██  ██', '██  ██', '▀▀  ▀▀'],
  S: ['▄█████', '██    ', '▀████▄', '    ██', '█████▀', '▀▀▀▀▀ '],
  H: ['██  ██', '██  ██', '██████', '██  ██', '██  ██', '▀▀  ▀▀'],
  E: ['██████', '██    ', '█████ ', '██    ', '██████', '▀▀▀▀▀▀'],
  N: ['███  ██', '████ ██', '██ ████', '██  ███', '██   ██', '▀▀   ▀▀'],
};

export function buildLogo(word = 'ASHEN') {
  const rows = [];
  for (let r = 0; r < 6; r++) rows.push([...word].map(c => L[c][r]).join('  '));
  const w = [...rows[0]].length;
  const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
  // Linha de "cinzas escorrendo" e uma espada sob o título
  const drip = [...rows[5]].map((c, i) => (c === '▀' && (i * 7) % 5 === 0 ? '▘' : c === '▀' && (i * 3) % 7 === 0 ? '·' : ' ')).join('');
  const sword = '◆' + '━'.repeat(Math.max(4, w - 6)) + '╋═●';
  return rows.slice(0, 5).map(esc).join('\n') + '\n' + `<span class="w">${esc(rows[5])}</span>` + '\n' + `<span class="w">${esc(drip)}</span>` + '\n' + `<span class="a">${esc(sword)}</span>`;
}
