// ASHEN — Chão tipográfico em blocos (chunks) pré-renderizados
// Cada célula tem fundo (como ANSI) e glifo. Zonas: terra com cinzas, grama morta,
// calçamento de pedra, lajes da praça, terra de cemitério, queimado perto do fogo.
// Os chunks são gerados sob demanda, com orçamento por quadro, e guardados num cache LRU.

import { CONFIG } from '../config.js';
import { GlyphPainter } from '../engine/typography.js';
import { makeCanvas } from '../engine/canvas.js';
import { fbm, hash2, noise2 } from '../engine/animation.js';
import { mixHex, scaleHex } from '../engine/palette.js';

const GCW = CONFIG.GROUND_CW, GCH = CONFIG.GROUND_CH;
// Canvas com suporte a ctx.filter (Chrome/Android sim): sombras sem canvas extra de silhueta.
const FILTER_OK = (() => { try { const c = document.createElement('canvas').getContext('2d'); c.filter = 'brightness(0)'; return c.filter === 'brightness(0)'; } catch (e) { return false; } })();
const CHUNK_C = 40, CHUNK_R = 24;

const DIRT = ['#1c191e', '#252023', '#2e2725', '#372f2a'];
const GRASS = ['#3b3d2c', '#4b4a34', '#5c573b', '#353a2a', '#6a6244'];
const ASHC = ['#3a3739', '#4b484a', '#5e5a5b'];

function ramp(arr, t) {
  const i = Math.max(0, Math.min(arr.length - 1.001, t * (arr.length - 1)));
  const k = Math.floor(i);
  return mixHex(arr[k], arr[k + 1], i - k);
}

export class Terrain {
  constructor(map) {
    this.map = map;
    this.painter = new GlyphPainter();
    this.cache = new Map();
    this.version = -1;
    this.limit = 56;
    this.built = 0;
    this.pending = 0;
  }

  /** Distância de um ponto (mundo) ao caminho (polilinha). */
  _pathDist(x, y) {
    const p = this.map.path;
    let best = 1e9;
    for (let i = 0; i < p.length - 1; i++) {
      const [ax, ay] = p[i], [bx, by] = p[i + 1];
      const dx = bx - ax, dy = by - ay;
      const t = Math.max(0, Math.min(1, ((x - ax) * dx + (y - ay) * dy) / (dx * dx + dy * dy)));
      const d = Math.hypot(x - ax - dx * t, y - ay - dy * t);
      if (d < best) best = d;
    }
    return best;
  }

  /** Célula do chão em índices (gx, gy) da grade projetada → {bg, ch, fg}. */
  cell(gx, gy) {
    const m = this.map;
    const x = (gx + 0.5) * GCW, y = (gy + 0.5) * GCH / CONFIG.TILT;
    const n = fbm(x * 0.004, y * 0.004, 3);
    const n2 = noise2(x * 0.02, y * 0.02, 9);
    const h = hash2(gx, gy, 77);
    // Escurece perto das bordas do mapa (abismo / floresta)
    const edge = Math.min(x - m.bounds.x0, m.bounds.x1 - x, m.bounds.y1 - y) / 260;
    const edgeK = Math.max(0, Math.min(1, edge));
    let bg = ramp(DIRT, n * 0.9 + n2 * 0.2);
    let ch = ' ', fg = '#3a332d';
    // Base: terra com cinzas e cascalho
    if (h < 0.06) { ch = '.'; fg = '#4a4038'; }
    else if (h < 0.1) { ch = ','; fg = '#40382f'; }
    else if (h < 0.13) { ch = '·'; fg = '#57504a'; }
    else if (h < 0.145) { ch = '`'; fg = '#4a4038'; }
    else if (h < 0.155) { ch = '∙'; fg = '#615851'; }
    // Manchas de cinzas
    const ash = fbm(x * 0.0065, y * 0.0065, 41);
    if (ash > 0.58) {
      bg = mixHex(bg, '#2a2829', Math.min(1, (ash - 0.58) * 4));
      if (h > 0.5 && h < 0.62) { ch = '░'; fg = ramp(ASHC, (h - 0.5) * 8); }
      else if (h > 0.9) { ch = '·'; fg = '#6d6869'; }
    }
    // Grama morta
    const grass = fbm(x * 0.008 + 50, y * 0.008, 13);
    if (grass > 0.56 && ash < 0.6) {
      const k = (grass - 0.56) * 5;
      if (h > 0.55 && h < 0.55 + k * 0.4) {
        const opts = ['"', 'ʷ', ',', '\'', 'ᵥ', 'ⁿ', '᾿', '⸗'];
        ch = opts[Math.floor(hash2(gx, gy, 5) * opts.length)];
        fg = ramp(GRASS, hash2(gx, gy, 6));
      } else if (h > 0.985) { ch = '艹'; fg = GRASS[2]; }
      bg = mixHex(bg, '#1d1f17', Math.min(0.6, k));
    }
    // Cemitério: terra mais escura e revolta
    const gy0 = m.graveyard;
    if (gy0 && x > gy0.x0 && x < gy0.x1 && y > gy0.y0 && y < gy0.y1) {
      bg = scaleHex(bg, 0.85);
      if (h > 0.4 && h < 0.46) { ch = '∴'; fg = '#3d342d'; }
    }
    // Caminho de calçamento
    const pd = this._pathDist(x, y);
    const pw = m.pathWidth + (n2 - 0.5) * 30;
    if (pd < pw) {
      const row = gy, off = (row % 2) * 1.5;
      const sid = Math.floor((gx + off) / 3);
      const u = Math.floor(gx + off) % 3;
      const sh = hash2(sid, row, 21);
      const worn = pd > pw * 0.72 ? (pd - pw * 0.72) / (pw * 0.28) : 0;
      if (sh > 0.12 + worn * 0.8) {
        bg = mixHex('#2a2830', '#3a3740', sh);
        bg = mixHex(bg, '#1a1719', worn * 0.6);
        if (u === 0) { ch = '▏'; fg = '#0f0d10'; }
        else if (u === 1 && sh > 0.5) { ch = '▔'; fg = scaleHex(bg, 1.45); }
        else if (h < 0.08) { ch = '·'; fg = '#3c4a2c'; }
        else ch = ' ';
      }
    }
    // Praça de lajes diante do portão
    const pl = m.plaza;
    if (pl && x > pl.x0 && x < pl.x1 && y > pl.y0 && y < pl.y1) {
      const sx = Math.floor(gx / 6), sy = Math.floor(gy / 2);
      const sh = hash2(sx, sy, 31);
      const crack = noise2(x * 0.05, y * 0.05, 4);
      if (sh > 0.08) {
        bg = mixHex('#2c2a31', '#423f48', sh * 0.8 + n * 0.2);
        if (gx % 6 === 0) { ch = '▏'; fg = '#0e0c10'; }
        else if (gy % 2 === 1) { ch = '▁'; fg = '#141217'; }
        else if (crack > 0.78) { ch = hash2(gx, gy, 2) < 0.5 ? '╱' : '╲'; fg = '#141217'; }
        else if (h < 0.06) { ch = '·'; fg = '#3c4a2c'; }
        else ch = ' ';
      }
    }
    // Chamuscado em volta do braseiro
    for (const s of m.scorch || []) {
      const d = Math.hypot(x - s.x, (y - s.y));
      if (d < s.r) {
        const k = 1 - d / s.r;
        bg = mixHex(bg, '#0d0a0a', k * 0.7);
        if (h > 0.3 && h < 0.3 + k * 0.25) { ch = '·'; fg = k > 0.6 ? '#5a2a18' : '#3a2a22'; }
      }
    }
    if (edgeK < 1) { bg = mixHex('#050406', bg, edgeK); fg = mixHex('#050406', fg, edgeK); }
    const wallK = (y - m.walk.y0) / 110;
    if (wallK < 1) bg = mixHex('#08070a', bg, Math.max(0.25, wallK));
    return { bg, ch, fg };
  }

  _build(cx, cy, S) {
    const p = this.painter;
    const cw = GCW * S, chh = GCH * S;
    p.setCell(cw, chh);
    const W = Math.ceil(CHUNK_C * cw), H = Math.ceil(CHUNK_R * chh);
    const c = makeCanvas(W, H);
    const ctx = c.getContext('2d');
    const glyphs = [];
    for (let r = 0; r < CHUNK_R; r++) {
      for (let q = 0; q < CHUNK_C; q++) {
        const gx = cx * CHUNK_C + q, gy = cy * CHUNK_R + r;
        const cell = this.cell(gx, gy);
        const x0 = Math.floor(q * cw), y0 = Math.floor(r * chh);
        ctx.fillStyle = cell.bg;
        ctx.fillRect(x0, y0, Math.floor((q + 1) * cw) - x0, Math.floor((r + 1) * chh) - y0);
        if (cell.ch !== ' ') glyphs.push(cell.ch, q * cw, r * chh, cell.fg);
      }
    }
    for (let i = 0; i < glyphs.length; i += 4) {
      const ch = glyphs[i];
      const w = ch === '艹' ? 2 : 1;
      p.paint(ctx, ch, w, glyphs[i + 1], glyphs[i + 2], glyphs[i + 3]);
    }
    p.end(ctx);
    this._bakeShadows(ctx, cx * CHUNK_C * GCW * S, cy * CHUNK_R * GCH * S, W, H, S);
    this.built++;
    return { canvas: c, w: W, h: H };
  }

  /** Sombras estáticas (contato + luar) dos objetos ficam gravadas no chão: custo zero por quadro. */
  _bakeShadows(ctx, X0, Y0, W, H, S) {
    if (!this.world) return;
    const proj = { ctx, S, dx: x => x * S - X0, dy: (y, z = 0) => (y * CONFIG.TILT - z) * S - Y0 };
    const moon = { x: 0, y: 0, z: 900 };
    for (const p of this.world.props) {
      if (!p.sprite || (!p.blob && !p.moonShadow)) continue;
      const px = proj.dx(p.x), py = proj.dy(p.y);
      const reach = (p.heightU * 0.7 + 200) * S;
      if (px < -reach || px > W + reach || py < -reach || py > H + reach) continue;
      if (p.blob) {
        const w = p.blob * 2 * S, h = p.blob * 0.9 * S;
        ctx.drawImage(this.world.blob, px - w / 2, py + 2 * S - h / 2, w, h);
      }
      if (p.moonShadow) {
        moon.x = p.x - 500; moon.y = p.y - 900;
        if (FILTER_OK) this.castShadow(proj, p.sprite, p.x, p.y, moon, 0.32, 0.5, true);
        else this.castShadow(proj, p.silhouette(), p.x, p.y, moon, 0.32, 0.5);
      }
    }
  }

  /** Desenha o chão visível. budget = quantos chunks novos podem ser gerados neste quadro. */
  draw(r, budget = 2) {
    if (this.version !== r.version) { this.cache.clear(); this.version = r.version; }
    const S = r.S;
    const chunkW = CHUNK_C * GCW, chunkH = CHUNK_R * GCH; // unidades projetadas
    const v = r.view;
    const c0 = Math.floor(v.x0 / chunkW), c1 = Math.floor(v.x1 / chunkW);
    const r0 = Math.floor(v.y0 / chunkH), r1 = Math.floor(v.y1 / chunkH);
    const ctx = r.ctx;
    let made = 0;
    this.pending = 0;
    ctx.fillStyle = '#060507';
    ctx.fillRect(0, 0, r.W, r.H);
    if (this.world && !this.world.ready) budget = 0; // espera os objetos próximos (sombras assadas)
    const valid = (cx, cy) => !(cx < 0 || cy < 0 || cx * chunkW > this.map.bounds.x1 + chunkW || cy * chunkH > this.map.bounds.y1 * CONFIG.TILT + chunkH);
    for (let cy = r0; cy <= r1; cy++) for (let cx = c0; cx <= c1; cx++) {
      if (!valid(cx, cy)) continue;
      const key = cx + ',' + cy;
      let ch = this.cache.get(key);
      if (!ch) {
        if (made >= budget) { this.pending++; continue; }
        ch = this._build(cx, cy, S);
        made++;
        this.cache.set(key, ch);
        if (this.cache.size > this.limit) this.cache.delete(this.cache.keys().next().value);
      } else { this.cache.delete(key); this.cache.set(key, ch); }
      ctx.drawImage(ch.canvas, Math.round(cx * chunkW * S + r.ox), Math.round(cy * chunkH * S + r.oy));
    }
    // Pré-gera um anel de chunks em volta da vista (evita "buracos" ao andar).
    if (made === 0) {
      outer: for (let cy = r0 - 1; cy <= r1 + 1; cy++) for (let cx = c0 - 1; cx <= c1 + 1; cx++) {
        if (!valid(cx, cy) || this.cache.has(cx + ',' + cy)) continue;
        this.cache.set(cx + ',' + cy, this._build(cx, cy, S));
        if (this.cache.size > this.limit) this.cache.delete(this.cache.keys().next().value);
        break outer;
      }
    }
    return made;
  }
}
