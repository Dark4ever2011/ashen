// ASHEN — Física
// Colisões reais no plano do chão: corpos circulares contra círculos e caixas estáticas.
// Grade espacial para consultar só o que está perto. Passo fixo (ver main.js).

export class Physics {
  constructor(cell = 160) {
    this.cell = cell;
    this.grid = new Map();
    this.statics = [];
    this.bounds = null; // {x0,y0,x1,y1}
  }

  _key(cx, cy) { return cx * 73856093 ^ cy * 19349663; }

  /** Colisor estático: {type:'circle', x,y,r} ou {type:'box', x0,y0,x1,y1}. */
  addStatic(col) {
    this.statics.push(col);
    const [x0, y0, x1, y1] = col.type === 'circle'
      ? [col.x - col.r, col.y - col.r, col.x + col.r, col.y + col.r]
      : [col.x0, col.y0, col.x1, col.y1];
    for (let cx = Math.floor(x0 / this.cell); cx <= Math.floor(x1 / this.cell); cx++)
      for (let cy = Math.floor(y0 / this.cell); cy <= Math.floor(y1 / this.cell); cy++) {
        const k = this._key(cx, cy);
        let list = this.grid.get(k);
        if (!list) { list = []; this.grid.set(k, list); }
        list.push(col);
      }
    return col;
  }

  near(x, y, r, out = []) {
    out.length = 0;
    const seen = this._seen || (this._seen = new Set());
    seen.clear();
    for (let cx = Math.floor((x - r) / this.cell); cx <= Math.floor((x + r) / this.cell); cx++)
      for (let cy = Math.floor((y - r) / this.cell); cy <= Math.floor((y + r) / this.cell); cy++) {
        const list = this.grid.get(this._key(cx, cy));
        if (!list) continue;
        for (const c of list) if (!seen.has(c)) { seen.add(c); out.push(c); }
      }
    return out;
  }

  /** Move um corpo {x,y,r} por (dx,dy) resolvendo colisões. Retorna true se colidiu. */
  move(body, dx, dy) {
    const steps = Math.max(1, Math.ceil(Math.hypot(dx, dy) / (body.r * 0.5)));
    let hit = false;
    const list = this._list || (this._list = []);
    for (let s = 0; s < steps; s++) {
      body.x += dx / steps;
      body.y += dy / steps;
      for (let iter = 0; iter < 3; iter++) {
        let any = false;
        this.near(body.x, body.y, body.r + 8, list);
        for (const c of list) if (this._resolve(body, c)) any = true;
        if (this.bounds) {
          const b = this.bounds;
          if (body.x < b.x0 + body.r) { body.x = b.x0 + body.r; any = true; }
          if (body.x > b.x1 - body.r) { body.x = b.x1 - body.r; any = true; }
          if (body.y < b.y0 + body.r) { body.y = b.y0 + body.r; any = true; }
          if (body.y > b.y1 - body.r) { body.y = b.y1 - body.r; any = true; }
        }
        if (!any) break;
        hit = true;
      }
    }
    return hit;
  }

  _resolve(b, c) {
    if (c.type === 'circle') {
      const dx = b.x - c.x, dy = b.y - c.y;
      const rr = b.r + c.r, d2 = dx * dx + dy * dy;
      if (d2 >= rr * rr) return false;
      const d = Math.sqrt(d2) || 0.0001;
      const push = rr - d;
      b.x += dx / d * push; b.y += dy / d * push;
      return true;
    }
    // Caixa: ponto mais próximo
    const px = Math.max(c.x0, Math.min(b.x, c.x1));
    const py = Math.max(c.y0, Math.min(b.y, c.y1));
    let dx = b.x - px, dy = b.y - py;
    const d2 = dx * dx + dy * dy;
    if (d2 >= b.r * b.r) return false;
    if (d2 > 1e-8) {
      const d = Math.sqrt(d2), push = b.r - d;
      b.x += dx / d * push; b.y += dy / d * push;
    } else {
      // Centro dentro da caixa: empurra pelo lado mais próximo.
      const l = b.x - c.x0, r = c.x1 - b.x, t = b.y - c.y0, bo = c.y1 - b.y;
      const m = Math.min(l, r, t, bo);
      if (m === l) b.x = c.x0 - b.r; else if (m === r) b.x = c.x1 + b.r;
      else if (m === t) b.y = c.y0 - b.r; else b.y = c.y1 + b.r;
    }
    return true;
  }

  /** O ponto está livre (para checar spawn e cliques)? */
  isFree(x, y, r) {
    const list = this.near(x, y, r + 8, []);
    const probe = { x, y, r };
    for (const c of list) { const sx = probe.x, sy = probe.y; if (this._resolve(probe, c)) { probe.x = sx; probe.y = sy; return false; } }
    return true;
  }
}
