// ASHEN — Som sintetizado em tempo real (Web Audio). Nenhum arquivo de áudio:
// cada efeito é montado com ruído filtrado, osciladores e envelopes — combina com o mundo feito de símbolos.
// Ambiente contínuo: vento, chuva, fogo (pela distância) e o rumor do terremoto.

/** Quanto o ambiente abaixa (por instantes) em cada som de combate. */
const DUCK = { hit: 0.18, crit: 0.3, parry: 0.3, heavy: 0.15, slam: 0.25, roar: 0.25, hurt: 0.2 };

export class Audio {
  constructor() {
    this.ctx = null; this.on = true; this.vol = 0.8; this.musVol = 0.6;
    this.loops = {}; this.bufs = {}; this.tracks = {}; this.wantMusic = null; this.fires = []; this.em = {};
  }
  /** Precisa de um toque do jogador para começar (regra dos navegadores). */
  unlock() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    const c = this.ctx = new AC();
    // Mixagem: [combate] + [ambiente] → Efeitos (slider) → compressor ─┐
    //          [música] → Música (slider) → limitador suave ─────────────┴→ liga/desliga → saída
    // A música não passa pelo compressor dos efeitos: um golpe não "abaixa" a trilha.
    this.master = c.createGain(); this.master.gain.value = this.on ? 1 : 0; this.master.connect(c.destination);
    const comp = c.createDynamicsCompressor(); comp.threshold.value = -16; comp.knee.value = 12; comp.ratio.value = 3.5; comp.attack.value = 0.006; comp.release.value = 0.25;
    comp.connect(this.master);
    const lim = c.createDynamicsCompressor(); lim.threshold.value = -6; lim.knee.value = 6; lim.ratio.value = 6; lim.attack.value = 0.01; lim.release.value = 0.4;
    lim.connect(this.master);
    this.fxBus = c.createGain(); this.fxBus.gain.value = this.vol; this.fxBus.connect(comp);
    this.musBus = c.createGain(); this.musBus.gain.value = this.musVol * 0.6; this.musBus.connect(lim);
    // grupos dentro de Efeitos: combate na frente, ambiente um pouco atrás (e abaixa de leve nos golpes)
    this.combatBus = c.createGain(); this.combatBus.gain.value = 1.6; this.combatBus.connect(this.fxBus);
    this.ambBus = c.createGain(); this.ambBus.gain.value = 1.0; this.ambBus.connect(this.fxBus);
    // eco de pedra (reverberação curta de pátio)
    this.verb = c.createConvolver(); this.verb.buffer = this._impulse(2.2, 2.6);
    this.verbGain = c.createGain(); this.verbGain.gain.value = 0.28;
    this.verb.connect(this.verbGain); this.verbGain.connect(this.combatBus);
    this.sfx = c.createGain(); this.sfx.connect(this.combatBus); this.sfx.connect(this.verb);
    this.amb = c.createGain(); this.amb.connect(this.ambBus);
    // ambiente gravado (3D): passa por um filtro que abafa o lado de fora quando se está sob um teto
    this.ambMuffle = this._filt('lowpass', 20000, 0.5); this.ambRec = c.createGain(); this.ambRec.gain.value = 0.5; this.ambRec.connect(this.ambMuffle); this.ambMuffle.connect(this.amb);
    this._loadAll();
    this.noise = this._noise(2);
    this.brown = this._noise(4, true);
    this._startLoops();
  }
  setVolume(on, vol, mus) {
    this.on = on; if (vol != null) this.vol = vol; if (mus != null) this.musVol = mus;
    if (!this.master) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.on ? 1 : 0, t, 0.1);
    this.fxBus.gain.setTargetAtTime(this.vol, t, 0.1);
    this.musBus.gain.setTargetAtTime(this.musVol * 0.6, t, 0.1);
  }
  // ── sons gravados ──
  async _loadAll() {
    const base = new URL('../../assets/audio/', import.meta.url).href;
    for (const n of ['fogo', 'vento', 'chuva-leve', 'chuva-folhas', 'tempestade']) {
      try {
        const r = await fetch(base + n + '.mp3'); const ab = await r.arrayBuffer();
        const buf = await new Promise((ok, no) => this.ctx.decodeAudioData(ab, ok, no));
        this.bufs[n] = this._loopify(buf, 1.8);
      } catch (e) { console.warn('áudio', n, e); }
    }
    this._makeEmitters();
    for (const [k, f] of [['jornada', 'musica-jornada'], ['sombra', 'musica-sombra'], ['luto', 'musica-luto']]) {
      const el = document.createElement('audio'); el.src = base + f + '.mp3'; el.preload = k === 'luto' ? 'auto' : 'metadata'; el.loop = false; el.crossOrigin = 'anonymous';
      let node = null; try { node = this.ctx.createMediaElementSource(el); } catch (e) { /* sem Web Audio: volume direto */ }
      const gn = this.ctx.createGain(); gn.gain.value = 0;
      if (node) { node.connect(gn); gn.connect(this.musBus); }
      this.tracks[k] = { el, gn, node, mix: 0, rest: 0 };
    }
  }
  /** Funde o fim no começo (2 s), para o laço não ter emenda nem clique. */
  _loopify(buf, xf) {
    const sr = buf.sampleRate, n = Math.floor(xf * sr);
    if (buf.length < n * 3) return buf;
    const out = this.ctx.createBuffer(buf.numberOfChannels, buf.length - n, sr);
    for (let ch = 0; ch < buf.numberOfChannels; ch++) {
      const s = buf.getChannelData(ch), d = out.getChannelData(ch);
      d.set(s.subarray(0, buf.length - n));
      for (let i = 0; i < n; i++) { const k = i / n; d[i] = s[i] * Math.sin(k * Math.PI / 2) + s[buf.length - n + i] * Math.cos(k * Math.PI / 2); }
    }
    return out;
  }
  /** Fonte em laço posicionada no espaço (HRTF), começando muda. */
  _emitter(name, ref = 2.5, max = 40) {
    const b = this.bufs[name]; if (!b) return null;
    const c = this.ctx, s = this._src(b, true), g = c.createGain(), p = c.createPanner();
    p.panningModel = 'HRTF'; p.distanceModel = 'inverse'; p.refDistance = ref; p.maxDistance = max; p.rolloffFactor = 1.1;
    g.gain.value = 0; s.connect(g); g.connect(p); p.connect(this.ambRec);
    s.start(0, Math.random() * b.duration);
    return { s, g, p, cur: 0, light: null };
  }
  _makeEmitters() {
    this.fires = [0, 1, 2].map(() => this._emitter('fogo', 1.6, 30)).filter(Boolean);
    this.em = { wind: this._emitter('vento', 6, 80), rainL: this._emitter('chuva-leve', 5, 60), rainR: this._emitter('chuva-leve', 5, 60), leaves: this._emitter('chuva-folhas', 5, 60), storm: this._emitter('tempestade', 8, 90) };
    this.recorded = true;
  }
  _place(e, x, y, z) {
    if (!e) return; const p = e.p, t = this.ctx.currentTime;
    if (p.positionX) { p.positionX.setTargetAtTime(x, t, 0.08); p.positionY.setTargetAtTime(y, t, 0.08); p.positionZ.setTargetAtTime(z, t, 0.08); } else p.setPosition(x, y, z);
  }
  _fade(e, v, tc = 0.6) { if (!e) return; e.cur = v; e.g.gain.setTargetAtTime(v, this.ctx.currentTime, tc); }
  /** Troca de lugar: as fogueiras 3D do lugar antigo somem (fade curto) e ficam livres para o novo. */
  resetArea() { for (const e of this.fires || []) { this._fade(e, 0, 0.15); e.light = null; } }
  /** Ouvinte = câmera (posição e para onde olha). */
  listen(x, y, z, fx, fz) {
    if (!this.ctx) return;
    const L = this.ctx.listener, t = this.ctx.currentTime;
    if (L.positionX) { L.positionX.setTargetAtTime(x, t, 0.05); L.positionY.setTargetAtTime(y, t, 0.05); L.positionZ.setTargetAtTime(z, t, 0.05); L.forwardX.setTargetAtTime(fx, t, 0.05); L.forwardY.setTargetAtTime(0, t, 0.05); L.forwardZ.setTargetAtTime(fz, t, 0.05); L.upX.value = 0; L.upY.value = 1; L.upZ.value = 0; }
    else { L.setPosition(x, y, z); L.setOrientation(fx, 0, fz, 0, 1, 0); }
    this.lx = x; this.ly = y; this.lz = z;
  }
  /** Música de fundo por lugar: troca com fade e, no fim de cada faixa, some devagar e volta depois de um silêncio. */
  music(name) { this.wantMusic = name; }
  _musicStep(dt) {
    for (const [k, T] of Object.entries(this.tracks)) {
      const want = this.on && k === this.wantMusic;
      T.mix = Math.max(0, Math.min(1, T.mix + (want ? 1 : -1) * dt / 4));      // crossfade de 4 s (curva de potência igual)
      const el = T.el, d = el.duration;
      if (want && el.paused) {
        T.rest -= dt;
        if (T.rest <= 0 && !T.starting) { if (el.ended || (d && el.currentTime >= d - 0.05)) el.currentTime = 0; T.starting = true; const pr = el.play(); if (pr && pr.then) pr.then(() => { T.starting = false; }, () => { T.starting = false; T.rest = 2; }); else T.starting = false; }
      }
      if (!want && T.mix <= 0 && !el.paused) el.pause();
      if (want && el.ended) T.rest = 4 + Math.random() * 6;           // silêncio entre uma volta e outra
      const t = el.currentTime || 0, edge = d && isFinite(d) ? Math.min(1, t / 3, Math.max(0, (d - t) / 3.5)) : Math.min(1, t / 3);
      const v = Math.sin(T.mix * Math.PI / 2) * edge;
      if (T.node) T.gn.gain.setTargetAtTime(v, this.ctx.currentTime, 0.08); else el.volume = Math.max(0, Math.min(1, v * this.musVol * 0.6 * (this.on ? 1 : 0)));
    }
  }
  _noise(sec, brown = false) {
    const c = this.ctx, b = c.createBuffer(1, c.sampleRate * sec, c.sampleRate), d = b.getChannelData(0);
    let last = 0;
    for (let i = 0; i < d.length; i++) { const w = Math.random() * 2 - 1; if (brown) { last = (last + 0.02 * w) / 1.02; d[i] = last * 3.5; } else d[i] = w; }
    return b;
  }
  _impulse(sec, decay) {
    const c = this.ctx, n = c.sampleRate * sec, b = c.createBuffer(2, n, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = b.getChannelData(ch); for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, decay); }
    return b;
  }
  // ── blocos ──
  _src(buf, loop = false) { const s = this.ctx.createBufferSource(); s.buffer = buf; s.loop = loop; return s; }
  _env(node, t, a, peak, d, out) {
    const g = this.ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(peak, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + a + d);
    node.connect(g); g.connect(out || this.sfx); return g;
  }
  _filt(type, f, q = 1) { const b = this.ctx.createBiquadFilter(); b.type = type; b.frequency.value = f; b.Q.value = q; return b; }
  /** Ruído filtrado com envelope (e varredura opcional de frequência). */
  burst({ type = 'bandpass', f = 1000, f2 = null, q = 1, a = 0.005, d = 0.2, gain = 0.5, delay = 0, rate = 1, brown = false, out }) {
    if (!this.ctx || !this.on) return;
    const t = this.ctx.currentTime + delay;
    const s = this._src(brown ? this.brown : this.noise, true); s.playbackRate.value = rate;   // em laço: sons longos (trovão) não terminam com corte
    const fl = this._filt(type, f, q);
    if (f2) fl.frequency.exponentialRampToValueAtTime(f2, t + a + d);
    s.connect(fl); this._env(fl, t, a, gain, d, out);
    s.start(t, Math.random() * 1.5); s.stop(t + a + d + 0.05);
  }
  /** Tom com envelope (seno, serra…), com deslize opcional. */
  tone({ wave = 'sine', f = 440, f2 = null, a = 0.005, d = 0.3, gain = 0.3, delay = 0, out, filter }) {
    if (!this.ctx || !this.on) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator(); o.type = wave; o.frequency.setValueAtTime(f, t);
    if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + a + d);
    let n = o;
    if (filter) { const fl = this._filt(filter.type || 'lowpass', filter.f, filter.q || 1); o.connect(fl); n = fl; }
    this._env(n, t, a, gain, d, out);
    o.start(t); o.stop(t + a + d + 0.05);
  }
  // ── efeitos do jogo ──
  play(name, k = 1) {
    if (!this.ctx || !this.on) return;
    if (DUCK[name]) { const t = this.ctx.currentTime, gg = this.ambBus.gain; gg.cancelScheduledValues(t); gg.setValueAtTime(gg.value, t); gg.linearRampToValueAtTime(1 - DUCK[name], t + 0.03); gg.setTargetAtTime(1, t + 0.18, 0.35); }
    const r = () => 0.9 + Math.random() * 0.2;
    switch (name) {
      case 'step':      // bota de ferro na terra + tilintar da armadura
        this.burst({ type: 'lowpass', f: 380 * r(), d: 0.09, gain: 0.32 * k, brown: true });
        if (Math.random() < 0.6) this.tone({ wave: 'triangle', f: 1800 * r(), d: 0.06, gain: 0.03 * k, delay: 0.02 });
        break;
      case 'swing':     // a lâmina cortando o ar
        this.burst({ type: 'bandpass', f: 600, f2: 2600 * r(), q: 2.5, a: 0.04, d: 0.18, gain: 0.35 * k });
        break;
      case 'heavy':     // golpe pesado
        this.burst({ type: 'bandpass', f: 300, f2: 1400, q: 1.6, a: 0.08, d: 0.28, gain: 0.45 });
        break;
      case 'hit':       // lâmina na carne morta
        this.burst({ type: 'lowpass', f: 900, d: 0.16, gain: 0.6, brown: true });
        this.burst({ type: 'bandpass', f: 2400 * r(), q: 3, d: 0.07, gain: 0.25 });
        this.tone({ f: 110, f2: 50, d: 0.18, gain: 0.35 });
        break;
      case 'crit':
        this.play('hit'); this.tone({ wave: 'triangle', f: 1320, d: 0.5, gain: 0.12, delay: 0.02 });
        break;
      case 'wood':      // tábua rachando
        for (let i = 0; i < 3; i++) this.burst({ type: 'bandpass', f: 1200 * r() + i * 300, q: 4, d: 0.05, gain: 0.35, delay: i * 0.025 });
        this.burst({ type: 'lowpass', f: 500, d: 0.15, gain: 0.3, brown: true });
        break;
      case 'break':     // caixote em pedaços
        for (let i = 0; i < 7; i++) this.burst({ type: 'bandpass', f: 800 + Math.random() * 2000, q: 3, d: 0.06 + Math.random() * 0.08, gain: 0.3, delay: i * 0.035 });
        this.burst({ type: 'lowpass', f: 300, d: 0.35, gain: 0.5, brown: true });
        break;
      case 'block':     // aço contra escudo
        for (const f of [523, 1307, 2213, 3301]) this.tone({ wave: 'triangle', f: f * r(), d: 0.35, gain: 0.08 });
        this.burst({ type: 'highpass', f: 3000, d: 0.06, gain: 0.25 });
        break;
      case 'parry':     // aparada: anel claro e longo
        for (const f of [880, 1760, 2637, 3520]) this.tone({ wave: 'sine', f, d: 1.1, gain: 0.09 });
        this.burst({ type: 'highpass', f: 4000, d: 0.08, gain: 0.3 });
        break;
      case 'roll':
        this.burst({ type: 'bandpass', f: 400, f2: 900, q: 1, a: 0.05, d: 0.3, gain: 0.25 });
        this.burst({ type: 'lowpass', f: 300, d: 0.12, gain: 0.35, delay: 0.4, brown: true });
        break;
      case 'hurt':      // impacto no cavaleiro
        this.burst({ type: 'lowpass', f: 600, d: 0.22, gain: 0.7, brown: true });
        this.tone({ wave: 'sawtooth', f: 180, f2: 90, d: 0.25, gain: 0.08, filter: { f: 700 } });
        for (const f of [740, 1680]) this.tone({ wave: 'triangle', f, d: 0.25, gain: 0.05 });
        break;
      case 'heal':      // gole e brilho quente
        this.burst({ type: 'bandpass', f: 500, q: 6, d: 0.12, gain: 0.25 }); this.burst({ type: 'bandpass', f: 420, q: 6, d: 0.12, gain: 0.25, delay: 0.18 });
        [523, 659, 784, 1047].forEach((f, i) => this.tone({ f, d: 0.6, gain: 0.07, delay: 0.35 + i * 0.07 }));
        break;
      case 'pickup':
        [659, 880, 1319].forEach((f, i) => this.tone({ wave: 'triangle', f, d: 0.5, gain: 0.1, delay: i * 0.09 }));
        break;
      case 'swap':
        this.burst({ type: 'bandpass', f: 900, q: 2, d: 0.1, gain: 0.2 }); this.tone({ wave: 'triangle', f: 1400, d: 0.12, gain: 0.05, delay: 0.25 });
        break;
      case 'ignite':    // chama acendendo
        this.burst({ type: 'lowpass', f: 200, f2: 2500, a: 0.15, d: 0.8, gain: 0.55, brown: true });
        this.burst({ type: 'highpass', f: 2000, d: 0.6, gain: 0.12, delay: 0.1 });
        break;
      case 'roar':      // o rei grita: serra grave com formantes + ruído rouco
        for (const [f, g] of [[70, 0.25], [104, 0.18], [141, 0.12]]) this.tone({ wave: 'sawtooth', f: f * k, f2: f * 0.7 * k, a: 0.25, d: 1.7, gain: g, filter: { type: 'bandpass', f: 520, q: 1.4 } });
        this.burst({ type: 'bandpass', f: 700, f2: 300, q: 0.8, a: 0.2, d: 1.6, gain: 0.45 });
        break;
      case 'claw':
        this.burst({ type: 'bandpass', f: 1500, f2: 500, q: 2, a: 0.03, d: 0.22, gain: 0.35 });
        break;
      case 'slam':      // garras no chão: estrondo
        this.tone({ f: 60, f2: 28, d: 0.9, gain: 0.7 });
        this.burst({ type: 'lowpass', f: 400, d: 1.0, gain: 0.8, brown: true });
        for (let i = 0; i < 6; i++) this.burst({ type: 'bandpass', f: 600 + Math.random() * 1500, q: 3, d: 0.1, gain: 0.15, delay: 0.05 + i * 0.06 });
        break;
      case 'quake':     // tremor: rumor longo
        this.burst({ type: 'lowpass', f: 140, a: 0.6, d: 3.5 * k, gain: 0.9, brown: true });
        this.tone({ f: 38, a: 0.5, d: 3.2 * k, gain: 0.35 });
        for (let i = 0; i < 10; i++) this.burst({ type: 'bandpass', f: 400 + Math.random() * 900, q: 2, d: 0.2, gain: 0.12, delay: 0.3 + Math.random() * 3 * k });
        break;
      case 'thunder': this.thunder(Math.random(), k); break;
      case 'bell':      // sino de morte
        for (const [f, g] of [[196, 0.2], [392, 0.12], [587, 0.08], [933, 0.05]]) this.tone({ f, d: 3.5, gain: g });
        break;
      case 'victory':   // acorde que se abre
        [[196, 0], [247, 0.15], [294, 0.3], [392, 0.45], [494, 0.6]].forEach(([f, t]) => this.tone({ wave: 'triangle', f, a: 0.3, d: 3.5, gain: 0.08, delay: t }));
        break;
      case 'wade':      // passo na água rasa
        this.burst({ type: 'bandpass', f: 1100, f2: 500, q: 1.2, a: 0.01, d: 0.22, gain: 0.3 * k }); this.burst({ type: 'highpass', f: 3000, d: 0.12, gain: 0.08, delay: 0.05 });
        break;
      case 'chest':     // baú abrindo: dobradiça e tampa
        this.tone({ wave: 'sawtooth', f: 140, f2: 260, a: 0.05, d: 0.7, gain: 0.06, filter: { type: 'bandpass', f: 700, q: 5 } });
        this.burst({ type: 'lowpass', f: 400, d: 0.25, gain: 0.45, delay: 0.75 });
        break;
      case 'blade':     // a espada desperta em azul
        [392, 587, 784, 1175, 1568].forEach((f, i) => this.tone({ wave: 'triangle', f, a: 0.05, d: 1.6, gain: 0.07, delay: i * 0.08 }));
        this.burst({ type: 'highpass', f: 4000, a: 0.2, d: 1.2, gain: 0.1 });
        break;
      case 'ui':
        this.tone({ wave: 'triangle', f: 880, d: 0.06, gain: 0.05 });
        break;
      case 'talk':      // letrinhas da caixa de diálogo
        this.tone({ wave: 'square', f: 300 + Math.random() * 80, d: 0.03, gain: 0.018, filter: { type: 'lowpass', f: 1200 } });
        break;
      case 'key':       // chave girando na fechadura
        this.burst({ type: 'bandpass', f: 2600, q: 8, d: 0.05, gain: 0.3 }); this.burst({ type: 'bandpass', f: 1800, q: 6, d: 0.08, gain: 0.35, delay: 0.25 });
        this.tone({ f: 120, f2: 70, d: 0.25, gain: 0.3, delay: 0.3 });
        break;
      case 'gate':      // grade de ferro subindo: correntes e engrenagens
        this.burst({ type: 'lowpass', f: 180, a: 0.4, d: 5.5, gain: 0.7, brown: true });
        for (let i = 0; i < 28; i++) this.burst({ type: 'bandpass', f: 1400 + Math.random() * 1800, q: 9, d: 0.05, gain: 0.12, delay: 0.3 + i * 0.19 });
        this.tone({ f: 55, a: 0.3, d: 5.2, gain: 0.25 });
        this.tone({ f: 70, f2: 40, d: 1.2, gain: 0.6, delay: 5.6 }); this.burst({ type: 'lowpass', f: 500, d: 0.8, gain: 0.7, delay: 5.6 });
        break;
      case 'door':      // porta velha rangendo
        this.tone({ wave: 'sawtooth', f: 180, f2: 320, a: 0.05, d: 0.5, gain: 0.08, filter: { type: 'bandpass', f: 900, q: 6 } });
        this.burst({ type: 'lowpass', f: 300, d: 0.25, gain: 0.4, delay: 0.5 });
        break;
      case 'spider':    // guincho da aranha
        this.tone({ wave: 'sawtooth', f: 2400, f2: 600, a: 0.01, d: 0.7, gain: 0.35, filter: { type: 'bandpass', f: 2000, q: 2 } });
        this.tone({ wave: 'square', f: 1900, f2: 400, a: 0.01, d: 0.6, gain: 0.12, delay: 0.05 });
        this.burst({ type: 'highpass', f: 3000, a: 0.005, d: 0.6, gain: 0.6 });
        this.tone({ f: 50, d: 0.6, gain: 0.7 });
        break;
      case 'tell':      // aviso de golpe: raspar metálico curto e agudo (light) ou grave (heavy) ou zumbido (magic)
        if (k > 0.8 && this.lastTellKind === 'heavy') { this.tone({ wave: 'sawtooth', f: 120, f2: 70, a: 0.02, d: 0.35, gain: 0.18 * k, filter: { type: 'lowpass', f: 600 } }); this.burst({ type: 'bandpass', f: 1800, q: 6, d: 0.18, gain: 0.18 * k }); }
        else if (this.lastTellKind === 'magic') { this.tone({ wave: 'sine', f: 660, f2: 990, a: 0.05, d: 0.3, gain: 0.07 * k }); this.tone({ wave: 'sine', f: 663, f2: 1000, a: 0.05, d: 0.3, gain: 0.06 * k }); }
        else this.burst({ type: 'bandpass', f: 3200, f2: 5200, q: 5, a: 0.01, d: 0.12, gain: 0.16 * k });
        break;
      case 'gasp':      // sem fôlego
        this.burst({ type: 'bandpass', f: 900, f2: 600, q: 1.5, a: 0.04, d: 0.28, gain: 0.22 }); this.tone({ wave: 'triangle', f: 200, f2: 150, a: 0.02, d: 0.2, gain: 0.05 });
        break;
      case 'dodge':     // passou raspando: sopro rápido
        this.burst({ type: 'bandpass', f: 600, f2: 2400, q: 1.2, a: 0.01, d: 0.18, gain: 0.25 });
        break;
      case 'goblin':    // risadinha aguda de goblin
        for (let i = 0; i < 4; i++) this.tone({ wave: 'sawtooth', f: 520 + Math.random() * 160, f2: 380, a: 0.01, d: 0.09, gain: 0.07 * k, delay: i * 0.11, filter: { type: 'bandpass', f: 1400, q: 3 } });
        break;
      case 'lever':     // alavanca de ferro e correntes
        this.burst({ type: 'bandpass', f: 900, q: 4, d: 0.25, gain: 0.4 }); this.tone({ wave: 'triangle', f: 160, f2: 90, d: 0.4, gain: 0.25, delay: 0.1 });
        for (let i = 0; i < 6; i++) this.tone({ wave: 'triangle', f: 2200 + Math.random() * 900, d: 0.05, gain: 0.05, delay: 0.25 + i * 0.09 });
        break;
      case 'faint':     // zumbido e queda
        this.tone({ f: 600, f2: 90, a: 0.4, d: 2.6, gain: 0.12 }); this.tone({ f: 610, f2: 92, a: 0.4, d: 2.6, gain: 0.1 });
        this.burst({ type: 'lowpass', f: 300, d: 0.6, gain: 0.5, delay: 2.4 });
        break;
    }
  }
  /** Trovão com distância (0 = em cima, 1 = longe): o som chega depois do clarão, mais grave e mais
   *  longo quanto mais longe; tom, duração e "rolar" variam a cada um para não soar repetido. */
  thunder(dist = 0.5, k = 1) {
    if (!this.ctx || !this.on) return;
    const out = this.amb, pitch = 0.8 + Math.random() * 0.45, delay = 0.12 + dist * 2.6 + Math.random() * 0.3;
    if (dist < 0.4) {               // estalo seco de raio perto
      this.burst({ type: 'highpass', f: 1400 * pitch, d: 0.1, gain: 0.45 * k * (1 - dist), delay: delay * 0.3, out });
      this.burst({ type: 'bandpass', f: 500 * pitch, q: 0.8, a: 0.004, d: 0.5, gain: 0.5 * k * (1 - dist), delay: delay * 0.3 + 0.03, out });
    }
    const dur = 2.4 + dist * 2.8 + Math.random() * 1.2, f = (240 - dist * 120) * pitch, g = (0.75 - dist * 0.35) * k;
    this.burst({ type: 'lowpass', f, f2: f * 0.55, a: 0.08 + dist * 0.4, d: dur, gain: g, brown: true, delay, rate: pitch, out });
    // o ronco "rola": 1 a 3 ondas extras, mais fracas, espalhadas
    const n = 1 + ((Math.random() * 3) | 0);
    for (let i = 0; i < n; i++) this.burst({ type: 'lowpass', f: f * (0.7 + Math.random() * 0.4), a: 0.2, d: dur * (0.5 + Math.random() * 0.4), gain: g * (0.35 + Math.random() * 0.3), brown: true, delay: delay + 0.5 + i * (0.5 + Math.random() * 0.9), rate: pitch * (0.9 + Math.random() * 0.2), out });
  }
  // ── ambiente contínuo ──
  _startLoops() {
    const c = this.ctx;
    const loop = (filterType, f, q, gain, brown) => {
      const s = this._src(brown ? this.brown : this.noise, true), fl = this._filt(filterType, f, q), g = c.createGain();
      g.gain.value = 0; s.connect(fl); fl.connect(g); g.connect(this.amb); s.start();
      return { s, fl, g, target: gain };
    };
    this.loops.wind = loop('bandpass', 380, 0.7, 0.18, false);
    this.loops.rain = loop('highpass', 1800, 0.5, 0.0, false);
    this.loops.rainLow = loop('lowpass', 600, 0.5, 0.0, true);
    this.loops.fire = loop('bandpass', 900, 0.6, 0.0, true);
    this.loops.rumble = loop('lowpass', 90, 1, 0.0, true);
    this.loops.river = loop('bandpass', 700, 0.4, 0.0, false);
    this.loops.riverLow = loop('lowpass', 350, 0.6, 0.0, true);
  }
  /** Chamado a cada quadro: vento, chuva, fogo e tremor. */
  ambient(st) {
    if (!this.ctx || !this.on) return;
    const t = this.ctx.currentTime, L = this.loops;
    const set = (l, v, f) => { l.g.gain.setTargetAtTime(v, t, 1.1); if (f) l.fl.frequency.setTargetAtTime(f, t, 1.0); };   // clima muda em ~4 s, sem cortes
    const rec = this.recorded ? 0.25 : 1;           // com os sons gravados, o sintetizado vira só um fundo
    set(L.wind, (0.05 + 0.12 * st.wind) * rec, 250 + 300 * st.wind);
    set(L.rain, 0.22 * st.rain * rec);
    set(L.rainLow, 0.25 * st.rain * rec);
    set(L.fire, 0.35 * st.fire * (this.recorded ? 0 : 1));
    this._musicStep(st.dt || 1 / 60);
    if (this.recorded) this._recorded(st);
    set(L.rumble, 0.8 * st.quake);
    const rv = st.river || 0;
    set(L.river, 0.16 * rv, 600 + 250 * Math.sin(t * 0.7)); set(L.riverLow, 0.3 * rv);
    if (rv > 0.1 && Math.random() < rv * 0.18) this.tone({ f: 500 + Math.random() * 900, f2: 900 + Math.random() * 900, a: 0.01, d: 0.06, gain: 0.025 * rv, out: this.amb });   // borbulhas
    // estalos do fogo
    if (!this.recorded && st.fire > 0.05 && Math.random() < st.fire * 0.25) this.burst({ type: 'highpass', f: 2500 + Math.random() * 3000, d: 0.02, gain: 0.12 * st.fire, out: this.amb });
  }
  _recorded(st) {
    const x = this.lx || 0, y = this.ly || 0, z = this.lz || 0, E = this.em;
    this.ambMuffle.frequency.setTargetAtTime(st.indoor ? 650 : 18000, this.ctx.currentTime, 0.4);
    // fogueiras: as 3 mais perto ganham som de verdade, no lugar delas
    const near = this._near || (this._near = []); near.length = 0;
    for (const f of st.fires || []) { const d = Math.hypot(f.x - x, f.z - z); if (d < 16) { f._d = d; near.push(f); } }
    near.sort((a, b) => a._d - b._d); if (near.length > 3) near.length = 3;
    for (const e of this.fires) if (e.light && !near.includes(e.light)) { this._fade(e, 0, 0.5); if (e.g.gain.value < 0.02) e.light = null; }
    for (const f of near) {
      let e = this.fires.find(q => q.light === f) || this.fires.find(q => !q.light);
      if (!e) continue;
      if (!e.light) { e.light = f; this._place(e, f.x, f.y, f.z); }
      this._place(e, f.x, f.y, f.z); this._fade(e, 0.9 * f.level, 0.5);
    }
    // vento vem do lado de onde sopra; chuva cai em volta; tempestade lá em cima
    const wx = st.windDir ? st.windDir[0] : 1, wz = st.windDir ? st.windDir[1] : 0;
    this._place(E.wind, x - wx * 9, y + 3, z - wz * 9); this._fade(E.wind, (0.12 + 0.45 * st.wind) * (st.indoor ? 0.5 : 1), 1.2);
    const fx = st.fwd ? st.fwd[0] : 0, fz = st.fwd ? st.fwd[1] : 1;
    // tempestade entra/sai num crossfade linear de 4 s com a chuva comum
    const tgt = st.storm ? 1 : 0, s0 = this.stormS || 0, stp = (st.dt || 1 / 60) / 4;
    this.stormS = tgt > s0 ? Math.min(tgt, s0 + stp) : Math.max(tgt, s0 - stp);
    const storm = this.stormS, rain = st.rain;
    this._place(E.rainL, x - fz * 5, y + 3, z + fx * 5); this._place(E.rainR, x + fz * 5, y + 3, z - fx * 5);
    this._fade(E.rainL, 0.55 * rain * (1 - 0.6 * storm), 1.3); this._fade(E.rainR, 0.55 * rain * (1 - 0.6 * storm), 1.3);
    this._place(E.leaves, x + fx * 6, y + 4, z + fz * 6); this._fade(E.leaves, rain * (st.leafy ? 0.75 : 0.3), 1.3);
    this._place(E.storm, x, y + 9, z - 4); this._fade(E.storm, 0.9 * rain * Math.sin(storm * Math.PI / 2), 0.5);
  }
}

/** Narração: voz do aparelho (Android: ponte nativa; navegador: speechSynthesis), em português. */
export class Narrator {
  constructor() { this.on = true; this.voice = null; this._pick(); if ('speechSynthesis' in window) speechSynthesis.onvoiceschanged = () => this._pick(); }
  _pick() {
    if (!('speechSynthesis' in window)) return;
    const vs = speechSynthesis.getVoices();
    this.voice = vs.find(v => /pt[-_]BR/i.test(v.lang) && /male|masculin|Google/i.test(v.name)) || vs.find(v => /pt[-_]BR/i.test(v.lang)) || vs.find(v => /^pt/i.test(v.lang)) || null;
  }
  speak(text) {
    if (!this.on || !text) return;
    const clean = text.replace(/[誓王灰]/g, '').replace(/—/g, ',').replace(/…/g, '...');
    if (window.AndroidTTS) { try { window.AndroidTTS.speak(clean); } catch (e) { /* ok */ } return; }
    if (!('speechSynthesis' in window)) return;
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(clean);
    u.lang = 'pt-BR'; u.rate = 0.92; u.pitch = 0.75; u.volume = 1;
    if (this.voice) u.voice = this.voice;
    speechSynthesis.speak(u);
  }
  stop() {
    if (window.AndroidTTS) { try { window.AndroidTTS.stop(); } catch (e) { /* ok */ } }
    if ('speechSynthesis' in window) speechSynthesis.cancel();
  }
}
