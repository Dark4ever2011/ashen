// ASHEN 3D — Atlas de caracteres e materiais tipográficos.
// O atlas é gerado na hora a partir da própria fonte (texto desenhado num canvas):
// não existe imagem externa — cada célula do atlas é um caractere.
// Proibido: blocos (█▀▄▌▐), sombreados (░▒▓) e quadrados (■□▪).

import { charWidth } from '../engine/typography.js';

export const MONO = '"AshenMono","DejaVu Sans Mono","Noto Sans Mono","Droid Sans Mono",monospace';
export const CJK = '"Noto Serif CJK JP","Noto Serif JP","Hiragino Mincho ProN","Yu Mincho","Noto Sans CJK JP","Droid Sans Fallback",serif';

export const MAT = { STEEL: 0, SILVER: 1, GOLD: 2, CLOTH: 3, LEATHER: 4, BLADE: 5, STONE: 6, WOOD: 7, GROUND: 8, GRASS: 9, IRON: 10, EMBER: 11, BONE: 12, MOSS: 13, CLOTH_IN: 14, DARK: 15, GRAVEL: 16, GRASS2: 17, GRASS3: 18, MAIL: 19, BRONZE: 20, FLOWER: 21, LEAF: 22, LEAF_G: 23, LEAF_R: 24, LEAF_Y: 25, WATER: 26, FLESH: 27, ROYAL: 28, SPIRIT: 29, FLOWER_R: 30, FLOWER_Y: 31, FLOWER_W: 32, FLOWER_B: 33, SKIN: 34, HAIR: 35, LINEN: 36, THATCH: 37, PLASTER: 38, WOOL: 39, BLOOD: 40, RIVER: 41, BLUE: 42, PETAL_P: 43, CHITIN: 44, SNOW: 45, SAND: 46, MARBLE: 47, GOBLIN: 48 };

// cor base (0..1), brilho especular, emissivo, rampa de 8 caracteres.
// A rampa vai da SOMBRA (índice 0, caracteres densos) à LUZ (índice 7, caracteres leves):
// sombras ganham textura de tinta escura; áreas iluminadas ficam leves e brilhantes (a cor dá a luz).
export const MATERIALS = [
  { name: 'aço negro', gloss: 46, c: [0.44, 0.45, 0.5], spec: 1.0, ramp: ['@', '%', '#', '≡', '=', '≈', '-', '·'] },
  { name: 'prata', gloss: 70, c: [0.78, 0.82, 0.88], spec: 1.2, ramp: ['#', 'H', '≡', '=', '+', '-', '*', '✦'] },
  { name: 'ouro velho', gloss: 34, c: [0.86, 0.66, 0.30], spec: 1.0, ramp: ['§', '¤', '◆', '*', '+', ':', '·', '✦'] },
  { name: 'tecido vinho', gloss: 3, c: [0.50, 0.07, 0.11], spec: 0.1, ramp: ['&', '§', '∫', '≀', '}', '(', ')', ':'] },
  { name: 'couro', gloss: 9, c: [0.42, 0.28, 0.18], spec: 0.2, ramp: ['@', '&', '#', '%', 'X', 'x', ':', '.'] },
  { name: 'lâmina', gloss: 90, c: [0.80, 0.86, 0.92], spec: 1.6, ramp: ['‖', 'I', 'ǀ', '|', 'l', '!', '|', '✦'] },
  { name: 'pedra', c: [0.5, 0.47, 0.5], spec: 0.05, ramp: ['&', '%', '#', '≡', '=', '-', ':', '.'] },
  { name: 'madeira morta', c: [0.48, 0.40, 0.32], spec: 0.05, ramp: ['‖', 'I', '¦', 'l', '|', ':', '\'', '.'] },
  { name: 'terra e cinzas', c: [0.36, 0.29, 0.21], spec: 0.0, ramp: ['#', '%', '=', '+', ';', ':', ',', '.'] },
  { name: 'grama morta', c: [0.38, 0.42, 0.18], spec: 0.05, ramp: ['Y', 'ψ', 'w', 'ʷ', 'v', '"', ',', '\''] },
  { name: 'ferro', gloss: 24, c: [0.5, 0.47, 0.45], spec: 0.6, ramp: ['8', '%', '&', '#', 'x', '+', ';', ':'] },
  { name: 'brasa', c: [1.0, 0.42, 0.16], spec: 0, emissive: 1, ramp: ['·', '•', '*', '✶', '✦', '火', '炎', '火'] },
  { name: 'osso/pedra clara', c: [0.68, 0.64, 0.58], spec: 0.1, ramp: ['&', '§', '#', '≡', '=', '-', ':', '.'] },
  { name: 'musgo', c: [0.26, 0.46, 0.16], spec: 0, ramp: ['⁂', '%', '⁎', '*', '+', ';', ',', '.'] },
  { name: 'forro da capa', gloss: 3, c: [0.26, 0.04, 0.06], spec: 0.05, ramp: ['§', '}', '{', ')', '(', ';', ',', '.'] },
  { name: 'vão escuro', c: [0.05, 0.04, 0.06], spec: 0, ramp: [' ', ' ', '.', ' ', '·', ' ', '.', ' '] },
  { name: 'calçamento', c: [0.46, 0.41, 0.36], spec: 0.05, ramp: ['#', '⁙', '∷', '⁘', '∴', ':', ':', '·'] },
  { name: 'grama verde-cinza', c: [0.2, 0.46, 0.17], spec: 0.05, ramp: ['Y', 'ψ', 'w', 'ʷ', 'v', '"', ',', '\''] },
  { name: 'grama seca', c: [0.56, 0.46, 0.2], spec: 0.05, ramp: ['Y', 'ψ', 'w', 'ʷ', 'v', '"', ',', '\''] },
  { name: 'cota de malha', gloss: 18, c: [0.40, 0.40, 0.43], spec: 0.7, ramp: ['8', '#', '∞', '%', '≈', '~', '-', '·'] },
  { name: 'bronze', gloss: 30, c: [0.70, 0.50, 0.27], spec: 1.0, ramp: ['&', '§', '¤', '*', '~', '+', ':', '·'] },
  { name: 'flor murcha', c: [0.66, 0.3, 0.62], spec: 0.05, ramp: ['*', '*', '⁎', '⁎', '✶', '✶', '·', '·'] },
  { name: 'folha seca', c: [0.6, 0.34, 0.12], spec: 0.05, ramp: ['‹', '›', '‹', ',', '›', ',', '.', '.'] },
  { name: 'folhas verdes', gloss: 12, c: [0.18, 0.46, 0.15], spec: 0.2, ramp: ['&', '%', '§', 'ψ', '*', 'ϕ', '‹', '·'] },
  { name: 'folhas vermelhas', gloss: 12, c: [0.78, 0.2, 0.08], spec: 0.2, ramp: ['&', '%', '§', 'ψ', '*', 'ϕ', '‹', '·'] },
  { name: 'folhas douradas', gloss: 12, c: [0.88, 0.6, 0.12], spec: 0.2, ramp: ['&', '%', '§', 'ψ', '*', 'ϕ', '‹', '·'] },
  { name: 'água', gloss: 140, c: [0.1, 0.12, 0.16], spec: 1.6, ramp: ['≈', '≈', '~', '~', '-', '-', '·', '·'] },
  { name: 'carne morta', gloss: 14, c: [0.64, 0.66, 0.56], spec: 0.25, ramp: ['%', '&', '§', '#', '≈', '~', ':', '·'] },
  { name: 'manto real', gloss: 4, c: [0.32, 0.12, 0.36], spec: 0.1, ramp: ['&', '§', '∫', '≀', '}', '(', ')', ':'] },
  { name: 'espírito', gloss: 10, c: [0.62, 0.48, 1.0], spec: 0, emissive: 1, ramp: ['·', '•', '*', '✶', '✦', '火', '炎', '火'] },
  { name: 'flor vermelha', gloss: 8, c: [1.0, 0.1, 0.12], spec: 0.15, ramp: ['✻', '✻', '✶', '✶', '*', '*', '⁎', '·'] },
  { name: 'flor amarela', gloss: 8, c: [1.0, 0.82, 0.08], spec: 0.15, ramp: ['✻', '✻', '✶', '✶', '*', '*', '⁎', '·'] },
  { name: 'flor branca', gloss: 8, c: [1.0, 0.98, 0.94], spec: 0.15, ramp: ['✻', '✻', '✶', '✶', '*', '*', '⁎', '·'] },
  { name: 'flor azul', gloss: 8, c: [0.3, 0.48, 1.0], spec: 0.15, ramp: ['✻', '✻', '✶', '✶', '*', '*', '⁎', '·'] },
  { name: 'pele', gloss: 16, c: [0.78, 0.56, 0.44], spec: 0.3, ramp: ['%', '&', '§', 'o', '≈', '~', ':', '·'] },
  { name: 'cabelo', gloss: 20, c: [0.3, 0.2, 0.13], spec: 0.4, ramp: ['ʃ', '⁞', '§', '}', ')', '(', ';', '\''] },
  { name: 'linho', gloss: 3, c: [0.62, 0.55, 0.42], spec: 0.08, ramp: ['&', '§', '#', '≀', '}', '(', ':', '.'] },
  { name: 'palha', gloss: 4, c: [0.66, 0.54, 0.3], spec: 0.08, ramp: ['/', '\\', '|', '≀', '\'', '`', ',', '.'] },
  { name: 'reboco', gloss: 2, c: [0.7, 0.66, 0.58], spec: 0.05, ramp: ['&', '%', '#', '=', '-', ':', '.', '·'] },
  { name: 'lã tingida', gloss: 3, c: [0.25, 0.34, 0.48], spec: 0.08, ramp: ['&', '§', '∫', '≀', '}', '(', ')', ':'] },
  { name: 'sangue seco', gloss: 30, c: [0.42, 0.05, 0.05], spec: 0.4, ramp: ['%', '&', '§', '*', '~', ',', '.', '·'] },
  { name: 'rio', gloss: 120, c: [0.1, 0.3, 0.42], spec: 1.4, ramp: ['≈', '≈', '~', '~', '∼', '-', '·', '·'] },
  { name: 'lâmina azul', gloss: 60, c: [0.35, 0.65, 1.0], spec: 0, emissive: 1, ramp: ['|', '‖', '!', '|', 'ǀ', '‖', '✦', '|'] },
  { name: 'flor rosa', gloss: 8, c: [1.0, 0.42, 0.72], spec: 0.15, ramp: ['●', '●', 'o', 'o', '•', '•', '·', '·'] },
  { name: 'quitina', gloss: 45, c: [0.2, 0.15, 0.14], spec: 0.7, ramp: ['@', '%', '&', '#', '8', 'x', ':', '·'] },
  { name: 'neve', gloss: 20, c: [0.86, 0.9, 0.96], spec: 0.35, ramp: ['#', '=', '+', '*', ':', '.', '·', '·'] },
  { name: 'areia', c: [0.72, 0.62, 0.44], spec: 0.05, ramp: ['%', '#', '=', ':', ';', ',', '.', '·'] },
  { name: 'mármore', gloss: 70, c: [0.82, 0.8, 0.76], spec: 0.8, ramp: ['&', '%', '#', '=', '+', '-', ':', '·'] },
  { name: 'pele de goblin', gloss: 20, c: [0.36, 0.5, 0.22], spec: 0.35, ramp: ['%', '&', '§', 'o', '≈', '~', ':', '·'] },
];
// Vegetação: o caractere de cada segmento de talo depende da inclinação REAL na tela.
// 0 '|' 1 '/' 2 '\\' 3 '╱' 4 '╲' 5 '~' 6 "'" 7 '`' 8 '´' 9 '⁎' 10-13 plantas 14 '"' 15 ','
export const VEG = ['|', '/', '\\', '╱', '╲', '~', '\'', '`', '´', '⁎', 'ψ', 'Ψ', 'ϒ', 'ɤ', '"', ','];
// Reflexo metálico: substitui o caractere quando o brilho especular passa do limite.
export const GLINT = ['+', '*', '✶', '✦'];

// Caracteres de contorno (silhueta) e aresta: traços que seguem a forma.
export const EDGE_RAMP = ['━', '━', '═', '═', '─', '─', '-', '-'];
export const RIM_GLYPHS = ['│', '|', '┃', '║'];
export const EXTRA = ['誓', '王', '灰', '国', '門', '眠', '墓', '火', '炎', '•', '◦', '◆', '✦', '✶', '†', '╬', '┼', '╋', '║', '│', '─', '═', '━', '~', '≈', '∼', '˙', '·', '^', '*', '°', '∴', '⁘', 'ˎ', ',', '`', '丫', '个', '▼', '¦', '⌒', '∩', 'Ʌ', 'Λ', 'V', 'ν'];

const FORBIDDEN = /[▀-▟■-▣]/; // blocos e quadrados

export class GlyphAtlas {
  constructor(cell = 64, cols = 32) {
    this.cell = cell; this.cols = cols;
    this.list = []; this.index = new Map();
    const add = ch => { if (ch === ' ' || this.index.has(ch)) return; if (FORBIDDEN.test(ch)) throw new Error('caractere proibido: ' + ch); this.index.set(ch, this.list.length); this.list.push(ch); };
    add('·');
    for (const m of MATERIALS) m.ramp.forEach(add);
    EDGE_RAMP.forEach(add); RIM_GLYPHS.forEach(add); EXTRA.forEach(add); VEG.forEach(add); GLINT.forEach(add);
    for (const ch of '.,:;-=+*#%&@$0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz()[]{}<>/\\|!?\'"`~^_') add(ch);
  }
  get(ch) { if (ch === ' ') return -2; if (!this.index.has(ch)) { this.index.set(ch, this.list.length); this.list.push(ch); } return this.index.get(ch); }

  /** Rampas por material (índices no atlas; -2 = vazio). */
  rampTable() {
    const t = [];
    for (const m of MATERIALS) for (const ch of m.ramp) t.push(ch === ' ' ? -2 : this.get(ch));
    for (const ch of EDGE_RAMP) t.push(this.get(ch));
    return t;
  }

  /** Desenha o atlas (branco sobre transparente). */
  build() {
    const n = this.list.length, rows = Math.ceil(n / this.cols);
    const c = document.createElement('canvas');
    c.width = this.cols * this.cell; c.height = Math.max(1, rows) * this.cell;
    // altura em potência de 2 para mipmaps estáveis
    c.height = Math.pow(2, Math.ceil(Math.log2(c.height)));
    const x = c.getContext('2d');
    x.fillStyle = '#fff'; x.textAlign = 'center'; x.textBaseline = 'middle';
    const S = this.cell;
    this.list.forEach((ch, i) => {
      const cx = (i % this.cols) * S + S / 2, cy = Math.floor(i / this.cols) * S + S / 2;
      const wide = charWidth(ch.codePointAt(0)) === 2;
      x.font = wide ? `bold ${S * 0.78}px ${CJK}` : `bold ${S * 0.8}px ${MONO}`;
      const w = x.measureText(ch).width, max = S * 0.94;
      const k = w > max ? max / w : 1;
      x.save(); x.translate(cx, cy + S * 0.02); x.scale(k, 1); x.fillText(ch, 0, 0); x.restore();
    });
    this.canvas = c;
    this.rows = c.height / S;
    return c;
  }
}
