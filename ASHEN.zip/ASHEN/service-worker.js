// ASHEN — Service Worker: funciona offline depois do primeiro carregamento.
// Ao publicar uma versão nova, aumente CACHE (ex.: ashen-v0.1.1) para os jogadores receberem a atualização.
const CACHE = 'ashen-v0.18.0';
const CORE = [
  './',
  './index.html',
  './src/game/solid.js',
  './src/render3/three-renderer.js', './src/render3/glyph-material.js', './src/render3/animation-names.js', './src/render3/glb-models.js', './src/vendor/three/addons/loaders/GLTFLoader.js', './src/vendor/three/addons/utils/BufferGeometryUtils.js', './src/vendor/three/addons/utils/SkeletonUtils.js',
  './src/vendor/three/three.module.js', './src/vendor/three/three.core.js',
  './src/game/tell.js',
  './src/game/goblin.js',
  './src/game/dungeon.js',
  './src/game/bleed.js',
  './src/game/darkmoon.js',
  './src/game/daynight.js',
  './src/game/farvillage.js',
  './src/game/items.js',
  './src/game/profano.js',
  './src/game/samurai3d.js',
  './src/game/story3.js',
  './manifest.json',
  './styles/main.css',
  './assets/fonts/DejaVuSansMono.ttf',
  './assets/icons/icon-192.png',
  './assets/icons/icon-512.png',
  './assets/icons/maskable-512.png',
  './src/game/boss3d.js',
  './src/game/cache.js',
  './src/game/cinema.js', './src/game/audio.js', './src/game/detail.js', './src/game/owplay.js', './src/game/ow.js', './src/game/palace.js', './src/game/region3.js', './src/game/spider3d.js', './src/game/story2.js', './src/game/village.js', './src/game/npc3d.js', './src/game/region2.js',
  './src/game/fx3d.js',
  './src/game/gameplay.js',
  './src/game/glyphs.js',
  './src/game/knight3d.js',
  './src/game/main.js',
  './src/game/math3d.js',
  './src/game/props3d.js',
  './src/game/renderer3d.js',
  './src/game/sampler.js',
  './src/game/sdf.js',
  './src/game/story.js',
  './src/game/trees3d.js',
  './src/game/veg3d.js',
  './src/game/weather.js',
  './src/game/world3d.js',
  './src/engine/canvas.js',
  './src/engine/input.js',
  './src/engine/typography.js',
  './src/ui/controls.js',
  './src/ui/hud.js', './src/ui/dialog.js', './src/ui/portrait.js',
  './src/ui/logo.js',
  './src/ui/menus.js',
  './src/ui/settings.js',
  './src/systems/save.js',
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

// Rede primeiro: sempre pega a versão publicada mais recente; sem internet, usa a cópia guardada.
self.addEventListener('fetch', e => {
  if (/\/assets\/audio\//.test(e.request.url)) return;          // áudio: o navegador cuida (pedidos parciais)
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  e.respondWith(fetch(req, { cache: 'no-cache' }).then(res => {
    if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); }
    return res;
  }).catch(() => caches.match(req, { ignoreSearch: true }).then(hit => hit || caches.match('./index.html'))));
});
