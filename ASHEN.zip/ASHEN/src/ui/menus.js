// ASHEN — Menu de pausa e configurações (presets, escala, FPS, controles, teclas).

import { PRESETS } from './settings.js';
import { ACTION_LABELS, DEFAULT_BINDINGS } from '../engine/input.js';
import { fontStatus } from '../engine/typography.js';
import { offscreenInUse } from '../engine/canvas.js';
import { CONFIG } from '../config.js';

const $ = id => document.getElementById(id);
const keyName = c => !c ? '—' : c.replace(/^Key/, '').replace(/^Digit/, '').replace('Arrow', '').replace('ShiftLeft', 'Shift').replace('ShiftRight', 'Shift D.').replace('Backquote', '`').replace('Escape', 'Esc');

export class Menu {
  constructor(game) {
    this.g = game;
    this.root = $('menu');
    this.body = $('menu-body');
    this.open = false;
    this.root.addEventListener('pointerdown', e => { if (e.target === this.root) this.hide(); e.stopPropagation(); });
  }

  toggle() { this.open ? this.hide() : this.show(); }

  show() {
    this.open = true;
    this.render();
    this.root.classList.remove('hidden');
    this.g.input.clearAll();
    setTimeout(() => { const b = this.body.querySelector('button'); b && b.focus({ preventScroll: true }); }, 30);
  }

  hide() {
    if (this.g.input.rebinding) return;
    this.open = false;
    this.root.classList.add('hidden');
    this.g.input.clearAll();
  }

  render() {
    const s = this.g.settings;
    const seg = (name, opts, cur) => `<div class="seg" data-k="${name}">${opts.map(([v, l]) => `<button type="button" data-v="${v}" aria-pressed="${String(v) === String(cur)}">${l}</button>`).join('')}</div>`;
    const preset = PRESETS[s.preset];
    const rs = Math.round((s.renderScale ?? preset.renderScale) * 100);
    const b = this.g.input.bindings;
    const r = this.g.renderer;
    this.body.innerHTML = `
      <div class="menu-actions">
        <button class="act primary" id="m-resume" type="button">▸ continuar</button>
        <button class="act" id="m-brazier" type="button">voltar ao braseiro</button>
        <button class="act" id="m-full" type="button">tela cheia</button>
      </div>
      <div class="row"><div><span class="lbl">Qualidade gráfica</span><span class="sub">${preset.desc}</span></div>
        ${seg('preset', Object.keys(PRESETS).map(k => [k, PRESETS[k].label]), s.preset)}</div>
      <div class="row"><label for="m-scale">Resolução interna <span class="sub" id="m-scale-v">${rs}% · ${Math.round(r.W)}×${Math.round(r.H)} px</span></label>
        <input id="m-scale" type="range" min="50" max="100" step="5" value="${rs}"></div>
      <div class="row"><div><span class="lbl">Limite de quadros</span><span class="sub">60 é o ideal; 30 esquenta menos o aparelho.</span></div>
        ${seg('fpsCap', [[30, '30'], [60, '60'], [0, 'livre']], s.fpsCap)}</div>
      <div class="row"><label for="m-perf">Mostrar desempenho (FPS)</label><input id="m-perf" type="checkbox" ${s.showPerf ? 'checked' : ''}></div>
      <div class="row"><label for="m-hapt">Vibração nos botões</label><input id="m-hapt" type="checkbox" ${s.haptics ? 'checked' : ''}></div>
      <div class="row"><label for="m-ctrl">Tamanho dos botões de toque</label><input id="m-ctrl" type="range" min="0.8" max="1.4" step="0.05" value="${s.controlScale}"></div>
      <details ${this.g.input.lastDevice === 'keyboard' || this.g.input.lastDevice === 'mouse' ? 'open' : ''}>
        <summary>Teclas (teclado e mouse)</summary>
        <p class="small">Clique em uma tecla e aperte a nova. Esc cancela. Mouse: segurar o botão esquerdo anda até o cursor; clicar em algo anda até lá e interage.</p>
        <div class="keys">${Object.keys(DEFAULT_BINDINGS).map(a => `
          <span>${ACTION_LABELS[a]}</span>
          <button type="button" data-a="${a}" data-s="0">${keyName(b[a][0])}</button>
          <button type="button" data-a="${a}" data-s="1">${keyName(b[a][1])}</button>`).join('')}</div>
        <div class="menu-actions" style="margin-top:10px"><button class="act" id="m-keys-reset" type="button">restaurar teclas</button></div>
      </details>
      <details><summary>Sobre esta versão</summary>
        <p class="small">ASHEN — The Last Oath · v${CONFIG.VERSION} · ${CONFIG.PHASE}
Fonte: ${fontStatus.mono}
Japonês: ${fontStatus.cjk}
OffscreenCanvas: ${offscreenInUse() ? 'em uso' : 'não (usando <canvas>)'}
Tela: ${r.cssW}×${r.cssH} css · DPR ${r.dpr} · escala ${r.S.toFixed(2)} px/u</p>
        <div class="menu-actions"><button class="act" id="m-reset" type="button">apagar progresso salvo</button></div>
      </details>`;
    this._wire();
  }

  _wire() {
    const g = this.g;
    $('m-resume').onclick = () => this.hide();
    $('m-brazier').onclick = () => { g.respawn(); this.hide(); };
    $('m-full').onclick = () => { g.fullscreen(); };
    this.body.querySelectorAll('.seg').forEach(el => el.querySelectorAll('button').forEach(btn => {
      btn.onclick = () => {
        const k = el.dataset.k;
        let v = btn.dataset.v;
        if (k === 'fpsCap') v = +v;
        g.settings[k] = v;
        if (k === 'preset') g.settings.renderScale = null;
        g.applySettings();
        this.render();
      };
    }));
    const sc = $('m-scale');
    sc.oninput = () => { $('m-scale-v').textContent = sc.value + '%'; };
    sc.onchange = () => { g.settings.renderScale = sc.value / 100; g.applySettings(); this.render(); };
    $('m-perf').onchange = e => { g.settings.showPerf = e.target.checked; g.applySettings(); };
    $('m-hapt').onchange = e => { g.settings.haptics = e.target.checked; g.applySettings(); };
    $('m-ctrl').oninput = e => { g.settings.controlScale = +e.target.value; g.applySettings(); };
    this.body.querySelectorAll('.keys button').forEach(btn => {
      btn.onclick = () => {
        btn.classList.add('wait'); btn.textContent = 'aperte…';
        g.input.startRebind(btn.dataset.a, +btn.dataset.s, binds => { g.settings.bindings = binds; g.applySettings(); this.render(); });
      };
    });
    $('m-keys-reset').onclick = () => { g.input.bindings = structuredClone(DEFAULT_BINDINGS); g.settings.bindings = null; g.applySettings(); this.render(); };
    $('m-reset').onclick = () => { g.resetProgress(); this.hide(); };
  }
}
