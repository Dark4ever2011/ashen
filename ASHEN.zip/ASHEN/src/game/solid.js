// ASHEN 3D — Geometria sólida (estilo híbrido).
// O chão e as construções viram malhas de triângulos sombreadas (texturas geradas no shader);
// os caracteres ficam por cima só nos detalhes (musgo, gravuras, rachaduras, arestas).
//
// Vértice (14 floats): posição(3), normal(3), material(1), tom(3), pesos(4)
//   material ≥ 0  → peça (pedra, madeira…); -1 → terreno perto; -2 → terreno longe (afunda sob o perto)
//   tom           → multiplica a cor do material (terreno: cor do bioma)
//   pesos         → terreno: rocha, areia, neve, lama  |  peça: [0, 0, 0, balança-com-o-vento]

export const VSTRIDE = 14;

export class SolidGeom {
  constructor(cap = 1024) { this.v = new Float32Array(cap * VSTRIDE); this.nv = 0; this.idx = new Uint32Array(cap * 3); this.ni = 0; }
  _grow(nv, ni) {
    if (nv > this.v.length / VSTRIDE) { const a = new Float32Array(Math.max(nv, this.v.length / VSTRIDE * 2) * VSTRIDE); a.set(this.v.subarray(0, this.nv * VSTRIDE)); this.v = a; }
    if (ni > this.idx.length) { const a = new Uint32Array(Math.max(ni, this.idx.length * 2)); a.set(this.idx.subarray(0, this.ni)); this.idx = a; }
  }
  vert(px, py, pz, nx, ny, nz, mat, tr = 1, tg = 1, tb = 1, w0 = 0, w1 = 0, w2 = 0, w3 = 0) {
    if (this.nv + 1 > this.v.length / VSTRIDE) this._grow(this.nv + 1, 0);
    const o = this.nv * VSTRIDE, v = this.v;
    v[o] = px; v[o + 1] = py; v[o + 2] = pz; v[o + 3] = nx; v[o + 4] = ny; v[o + 5] = nz; v[o + 6] = mat;
    v[o + 7] = tr; v[o + 8] = tg; v[o + 9] = tb; v[o + 10] = w0; v[o + 11] = w1; v[o + 12] = w2; v[o + 13] = w3;
    return this.nv++;
  }
  tri(a, b, c) { if (this.ni + 3 > this.idx.length) this._grow(0, this.ni + 3); this.idx[this.ni++] = a; this.idx[this.ni++] = b; this.idx[this.ni++] = c; }
  append(o, xf) {
    if (!o || !o.nv) return;
    this._grow(this.nv + o.nv, this.ni + o.ni);
    const base = this.nv, v = this.v, s = o.v;
    for (let i = 0; i < o.nv; i++) {
      const a = i * VSTRIDE, b = (base + i) * VSTRIDE;
      for (let k = 0; k < VSTRIDE; k++) v[b + k] = s[a + k];
      if (xf) xf(v, b);
    }
    for (let i = 0; i < o.ni; i++) this.idx[this.ni + i] = o.idx[i] + base;
    this.nv += o.nv; this.ni += o.ni;
  }
  area() {
    let A = 0; const v = this.v;
    for (let i = 0; i < this.ni; i += 3) {
      const a = this.idx[i] * VSTRIDE, b = this.idx[i + 1] * VSTRIDE, c = this.idx[i + 2] * VSTRIDE;
      const ux = v[b] - v[a], uy = v[b + 1] - v[a + 1], uz = v[b + 2] - v[a + 2], wx = v[c] - v[a], wy = v[c + 1] - v[a + 1], wz = v[c + 2] - v[a + 2];
      A += 0.5 * Math.hypot(uy * wz - uz * wy, uz * wx - ux * wz, ux * wy - uy * wx);
    }
    return A;
  }
  pack() { return { v: this.v.slice(0, this.nv * VSTRIDE), idx: this.idx.slice(0, this.ni), nv: this.nv, ni: this.ni, skinned: !!this.skinned }; }
  static from(o) { const g = new SolidGeom(1); g.v = o.v; g.idx = o.idx; g.nv = o.nv; g.ni = o.ni; g.skinned = !!o.skinned; return g; }
}

/** Gira (em Y), escala e move uma malha já pronta (cópias de árvores pelo mapa). */
export function xfYaw(x, y, z, ca, sa, sc) {
  return (v, o) => {
    const lx = v[o] * sc, ly = v[o + 1] * sc, lz = v[o + 2] * sc, nx = v[o + 3], nz = v[o + 5];
    v[o] = x + lx * ca - lz * sa; v[o + 1] = y + ly; v[o + 2] = z + lx * sa + lz * ca;
    v[o + 3] = nx * ca - nz * sa; v[o + 5] = nx * sa + nz * ca;
  };
}

/**
 * Superfície de uma SDF em triângulos (surface nets): uma grade com pulo de blocos vazios,
 * vértice por célula que cruza a superfície (projetado de volta nela), quads nas arestas cruzadas.
 * keep(p, n) da peça também recorta a malha (cercas, velas, buracos).
 */
export function surfaceNets(part, res, out = new SolidGeom(2048), tint = [1, 1, 1], w3 = 0) {
  const f = part.f, [x0, y0, z0] = part.min, [x1, y1, z1] = part.max;
  let r = res;
  let nx = Math.ceil((x1 - x0) / r) + 2, ny = Math.ceil((y1 - y0) / r) + 2, nz = Math.ceil((z1 - z0) / r) + 2;
  while (nx * ny * nz > 2.5e6) { r *= 1.25; nx = Math.ceil((x1 - x0) / r) + 2; ny = Math.ceil((y1 - y0) / r) + 2; nz = Math.ceil((z1 - z0) / r) + 2; }
  const ox = x0 - r * 0.5, oy = y0 - r * 0.5, oz = z0 - r * 0.5;
  const N = nx * ny * nz, val = new Float32Array(N).fill(1e9), done = new Uint8Array(N);
  const id = (i, j, k) => (k * ny + j) * nx + i;
  // blocos de 6 células: se o centro está longe da superfície, o bloco inteiro fica de fora
  const BS = 6, diag = part.noSkip ? 1e9 : BS * r * 0.87 + r;
  const active = new Uint8Array(Math.ceil(nx / BS) * Math.ceil(ny / BS) * Math.ceil(nz / BS));
  const bx = Math.ceil(nx / BS), by = Math.ceil(ny / BS), bz = Math.ceil(nz / BS);
  for (let c = 0; c < bz; c++) for (let b = 0; b < by; b++) for (let a = 0; a < bx; a++) {
    const cx = ox + (a * BS + BS / 2) * r, cy = oy + (b * BS + BS / 2) * r, cz = oz + (c * BS + BS / 2) * r;
    if (Math.abs(f(cx, cy, cz)) > diag) continue;
    active[(c * by + b) * bx + a] = 1;
    for (let k = c * BS; k <= Math.min(nz - 1, c * BS + BS); k++) for (let j = b * BS; j <= Math.min(ny - 1, b * BS + BS); j++) for (let i = a * BS; i <= Math.min(nx - 1, a * BS + BS); i++) {
      const q = id(i, j, k); if (done[q]) continue; done[q] = 1;
      val[q] = f(ox + i * r, oy + j * r, oz + k * r);
    }
  }
  const cellV = new Int32Array(N).fill(-1);
  const e = r * 0.3;
  const grad = (x, y, z) => { const gx = f(x + e, y, z) - f(x - e, y, z), gy = f(x, y + e, z) - f(x, y - e, z), gz = f(x, y, z + e) - f(x, y, z - e); const l = Math.hypot(gx, gy, gz) || 1; return [gx / l, gy / l, gz / l]; };
  const keep = part.keep;
  const kept = [];
  const CO = [[0, 0, 0], [1, 0, 0], [0, 1, 0], [1, 1, 0], [0, 0, 1], [1, 0, 1], [0, 1, 1], [1, 1, 1]];
  const ED = [[0, 1], [2, 3], [4, 5], [6, 7], [0, 2], [1, 3], [4, 6], [5, 7], [0, 4], [1, 5], [2, 6], [3, 7]];
  const cv = new Float32Array(8);
  for (let k = 0; k < nz - 1; k++) for (let j = 0; j < ny - 1; j++) for (let i = 0; i < nx - 1; i++) {
    if (!active[((k / BS | 0) * by + (j / BS | 0)) * bx + (i / BS | 0)]) continue;
    let neg = 0;
    for (let c = 0; c < 8; c++) { const d = val[id(i + CO[c][0], j + CO[c][1], k + CO[c][2])]; cv[c] = d; if (d < 0) neg++; }
    if (neg === 0 || neg === 8) continue;
    let sx = 0, sy = 0, sz = 0, cnt = 0;
    for (const [a, b] of ED) {
      const da = cv[a], db = cv[b];
      if ((da < 0) === (db < 0)) continue;
      const t = da / (da - db);
      sx += CO[a][0] + (CO[b][0] - CO[a][0]) * t; sy += CO[a][1] + (CO[b][1] - CO[a][1]) * t; sz += CO[a][2] + (CO[b][2] - CO[a][2]) * t; cnt++;
    }
    let px = ox + (i + sx / cnt) * r, py = oy + (j + sy / cnt) * r, pz = oz + (k + sz / cnt) * r;
    let n = grad(px, py, pz);
    for (let it = 0; it < (part.noSkip ? 0 : 2); it++) { const d = f(px, py, pz); px -= n[0] * d; py -= n[1] * d; pz -= n[2] * d; }
    n = grad(px, py, pz);
    // não deixa o vértice sair da célula (evita pontas em quinas)
    px = Math.min(ox + (i + 1) * r, Math.max(ox + i * r, px)); py = Math.min(oy + (j + 1) * r, Math.max(oy + j * r, py)); pz = Math.min(oz + (k + 1) * r, Math.max(oz + k * r, pz));
    const vi = out.vert(px, py, pz, n[0], n[1], n[2], part.mat, tint[0], tint[1], tint[2], 0, 0, 0, w3);
    kept[vi] = keep ? (keep([px, py, pz], n) ? 1 : 0) : 1;
    cellV[id(i, j, k)] = vi;
  }
  const quad = (a, b, c, d, flip) => {
    if (a < 0 || b < 0 || c < 0 || d < 0) return;
    if (keep && kept[a] + kept[b] + kept[c] + kept[d] < 3) return;
    if (flip) { out.tri(a, c, b); out.tri(a, d, c); } else { out.tri(a, b, c); out.tri(a, c, d); }
  };
  for (let k = 1; k < nz - 1; k++) for (let j = 1; j < ny - 1; j++) for (let i = 1; i < nx - 1; i++) {
    const v0 = val[id(i, j, k)];
    if (v0 >= 1e8) continue;
    const s0 = v0 < 0;
    // aresta +x
    if (i < nx - 1) { const v1 = val[id(i + 1, j, k)]; if (v1 < 1e8 && (v1 < 0) !== s0) quad(cellV[id(i, j - 1, k - 1)], cellV[id(i, j, k - 1)], cellV[id(i, j, k)], cellV[id(i, j - 1, k)], s0); }
    if (j < ny - 1) { const v1 = val[id(i, j + 1, k)]; if (v1 < 1e8 && (v1 < 0) !== s0) quad(cellV[id(i - 1, j, k - 1)], cellV[id(i - 1, j, k)], cellV[id(i, j, k)], cellV[id(i, j, k - 1)], s0); }
    if (k < nz - 1) { const v1 = val[id(i, j, k + 1)]; if (v1 < 1e8 && (v1 < 0) !== s0) quad(cellV[id(i - 1, j - 1, k)], cellV[id(i, j - 1, k)], cellV[id(i, j, k)], cellV[id(i - 1, j, k)], s0); }
  }
  return out;
}

/** Tubo cônico (tronco/galho de árvore) com tampas. */
export function tube(out, a, b, r1, r2, mat, sides = 7, w3 = 1, tint = [1, 1, 1]) {
  const d = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], L = Math.hypot(d[0], d[1], d[2]);
  if (L < 1e-4) return;
  const u = [d[0] / L, d[1] / L, d[2] / L], ref = Math.abs(u[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0];
  let v = [u[1] * ref[2] - u[2] * ref[1], u[2] * ref[0] - u[0] * ref[2], u[0] * ref[1] - u[1] * ref[0]];
  const vl = Math.hypot(...v); v = v.map(q => q / vl);
  const w = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
  const slope = (r1 - r2) / L, base = out.nv;
  for (let ring = 0; ring < 2; ring++) {
    const c = ring ? b : a, r = ring ? r2 : r1;
    for (let s = 0; s < sides; s++) {
      const an = s / sides * Math.PI * 2, ca = Math.cos(an), sa = Math.sin(an);
      const n = [v[0] * ca + w[0] * sa + u[0] * slope, v[1] * ca + w[1] * sa + u[1] * slope, v[2] * ca + w[2] * sa + u[2] * slope], nl = Math.hypot(...n);
      out.vert(c[0] + (v[0] * ca + w[0] * sa) * r, c[1] + (v[1] * ca + w[1] * sa) * r, c[2] + (v[2] * ca + w[2] * sa) * r, n[0] / nl, n[1] / nl, n[2] / nl, mat, tint[0], tint[1], tint[2], 0, 0, 0, w3);
    }
  }
  for (let s = 0; s < sides; s++) { const s1 = (s + 1) % sides; out.tri(base + s, base + s1, base + sides + s1); out.tri(base + s, base + sides + s1, base + sides + s); }
  const cap = out.vert(b[0], b[1], b[2], u[0], u[1], u[2], mat, tint[0], tint[1], tint[2], 0, 0, 0, w3);
  for (let s = 0; s < sides; s++) out.tri(cap, base + sides + s, base + sides + (s + 1) % sides);
}

/** Pedra: esfera achatada e irregular (ruído no raio). */
export function rock(out, x, y, z, rad, seed, noise, mat, mossMat, top = 0.75) {
  const S = 10, T = 7, base = out.nv;
  for (let j = 0; j <= T; j++) {
    const ph = j / T * Math.PI, sy = Math.cos(ph), sr = Math.sin(ph);
    for (let i = 0; i < S; i++) {
      const th = i / S * Math.PI * 2, nx = sr * Math.cos(th), nz = sr * Math.sin(th), ny = sy * top;
      const bump = 1 + 0.22 * (noise(nx * 2.3 + seed, ny * 2.3 + nz * 1.7 - seed) - 0.5);
      const m = ny > 0.5 && noise(nx * 5 + seed, nz * 5) > 0.55 ? mossMat : mat;
      out.vert(x + nx * rad * 1.2 * bump, y + ny * rad * bump, z + nz * rad * bump, nx, sy, nz, m);
    }
  }
  for (let j = 0; j < T; j++) for (let i = 0; i < S; i++) { const a = base + j * S + i, b = base + j * S + (i + 1) % S, c = a + S, d = b + S; out.tri(a, c, b); out.tri(b, c, d); }
}

/** Peças finas e largas (pisos, tapetes, lajes): superfície de cima como campo de alturas. */
export function heightField(part, res, out = new SolidGeom(2048), tint = [1, 1, 1]) {
  const f = part.f, [x0, y0, z0] = part.min, [x1, y1, z1] = part.max;
  let r = res, nx = Math.ceil((x1 - x0) / r) + 1, nz = Math.ceil((z1 - z0) / r) + 1;
  while (nx * nz > 160000) { r *= 1.2; nx = Math.ceil((x1 - x0) / r) + 1; nz = Math.ceil((z1 - z0) / r) + 1; }
  const dy = Math.max(0.004, Math.min(part.spacing * 0.4, (y1 - y0) / 10));
  const idx = new Int32Array(nx * nz).fill(-1), e = Math.min(r * 0.3, 0.02);
  for (let j = 0; j < nz; j++) for (let i = 0; i < nx; i++) {
    const x = Math.min(x1, x0 + i * r), z = Math.min(z1, z0 + j * r);
    let prev = f(x, y1, z), y = y1, hit = NaN;
    if (prev < 0) continue;                                   // já começa dentro: não é topo
    for (y = y1 - dy; y >= y0 - dy; y -= dy) { const d = f(x, y, z); if (d < 0) { let a = y + dy, b = y; for (let k = 0; k < 6; k++) { const m = (a + b) / 2; if (f(x, m, z) < 0) b = m; else a = m; } hit = (a + b) / 2; break; } prev = d; }
    if (hit !== hit) continue;
    const gx = f(x + e, hit, z) - f(x - e, hit, z), gy = f(x, hit + e, z) - f(x, hit - e, z), gz = f(x, hit, z + e) - f(x, hit, z - e), l = Math.hypot(gx, gy, gz) || 1;
    const n = [gx / l, gy / l, gz / l];
    if (n[1] < 0.2) continue;
    if (part.keep && !part.keep([x, hit, z], n)) continue;
    idx[j * nx + i] = out.vert(x, hit + 0.008, z, n[0], n[1], n[2], part.mat, tint[0], tint[1], tint[2], 0, 0, 0, 0);
  }
  for (let j = 0; j < nz - 1; j++) for (let i = 0; i < nx - 1; i++) {
    const a = idx[j * nx + i], b = idx[j * nx + i + 1], c = idx[(j + 1) * nx + i], d = idx[(j + 1) * nx + i + 1];
    if (a >= 0 && b >= 0 && c >= 0 && d >= 0) { out.tri(a, c, b); out.tri(b, c, d); }
  }
  return out;
}

/**
 * Corpo sólido por baixo dos caracteres de um personagem: para cada osso, os pontos viram uma grade
 * ocupada, que é fechada (dilata → preenche o interior → erode) e encolhida um pouco, para ficar
 * logo abaixo da superfície de caracteres. O resultado anda com o osso (vértice "skinned").
 */
export function hullFromPoints(ps, { res = 0.024, shrink = 1, skipBones = [] } = {}) {
  const out = new SolidGeom(4096), byBone = new Map();
  for (let i = 0; i < ps.n; i++) {
    const b = ps.attr[i * 4 + 2], fl = ps.attr[i * 4 + 3];
    if (fl & (2 | 8)) continue;                      // brilho e vegetação não contam
    if (skipBones.includes(b)) continue;
    if (!byBone.has(b)) byBone.set(b, []);
    byBone.get(b).push(i);
  }
  for (const [bone, list] of byBone) {
    if (list.length < 40) continue;
    let mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9];
    for (const i of list) for (let a = 0; a < 3; a++) { const v = ps.pos[i * 3 + a]; if (v < mn[a]) mn[a] = v; if (v > mx[a]) mx[a] = v; }
    const span = Math.max(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]);
    const r = Math.max(res, span / 46), pad = 3;
    const nx = Math.ceil((mx[0] - mn[0]) / r) + pad * 2 + 1, ny = Math.ceil((mx[1] - mn[1]) / r) + pad * 2 + 1, nz = Math.ceil((mx[2] - mn[2]) / r) + pad * 2 + 1;
    const ox = mn[0] - pad * r, oy = mn[1] - pad * r, oz = mn[2] - pad * r;
    const N = nx * ny * nz, id = (i, j, k) => (k * ny + j) * nx + i;
    let occ = new Uint8Array(N); const matC = new Int16Array(N).fill(-1);
    for (const p of list) {
      const x = (ps.pos[p * 3] - ox) / r, y = (ps.pos[p * 3 + 1] - oy) / r, z = (ps.pos[p * 3 + 2] - oz) / r;
      const i = Math.round(x), j = Math.round(y), k = Math.round(z);
      if (i < 0 || j < 0 || k < 0 || i >= nx || j >= ny || k >= nz) continue;
      occ[id(i, j, k)] = 1; matC[id(i, j, k)] = ps.attr[p * 4];
    }
    const morph = (src, grow) => {                    // dilata (grow) ou erode, vizinhança 6
      const dst = new Uint8Array(N);
      for (let k = 1; k < nz - 1; k++) for (let j = 1; j < ny - 1; j++) for (let i = 1; i < nx - 1; i++) {
        const q = id(i, j, k), s = src[q] + src[q - 1] + src[q + 1] + src[q - nx] + src[q + nx] + src[q - nx * ny] + src[q + nx * ny];
        dst[q] = grow ? (s > 0 ? 1 : 0) : (s === 7 ? 1 : 0);
      }
      return dst;
    };
    occ = morph(morph(occ, true), true);
    // fora = alcançável a partir da borda sem atravessar o ocupado
    const outside = new Uint8Array(N), stack = [];
    for (let k = 0; k < nz; k++) for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) if (i === 0 || j === 0 || k === 0 || i === nx - 1 || j === ny - 1 || k === nz - 1) { const q = id(i, j, k); if (!occ[q]) { outside[q] = 1; stack.push(q); } }
    while (stack.length) {
      const q = stack.pop(), k = (q / (nx * ny)) | 0, j = ((q / nx) | 0) % ny, i = q % nx;
      for (const [di, dj, dk] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
        const a = i + di, b = j + dj, c = k + dk; if (a < 0 || b < 0 || c < 0 || a >= nx || b >= ny || c >= nz) continue;
        const w = id(a, b, c); if (outside[w] || occ[w]) continue; outside[w] = 1; stack.push(w);
      }
    }
    let solid = new Uint8Array(N); for (let q = 0; q < N; q++) solid[q] = outside[q] ? 0 : 1;
    for (let s = 0; s < 2 + shrink; s++) solid = morph(solid, false);   // desfaz a dilatação e afunda sob os caracteres
    // campo suave (média 3×3×3) → superfície
    const val = new Float32Array(N);
    for (let k = 1; k < nz - 1; k++) for (let j = 1; j < ny - 1; j++) for (let i = 1; i < nx - 1; i++) {
      let s = 0; for (let c = -1; c <= 1; c++) for (let b = -1; b <= 1; b++) for (let a = -1; a <= 1; a++) s += solid[id(i + a, j + b, k + c)];
      val[id(i, j, k)] = 0.5 - s / 27;
    }
    let any = false; for (let q = 0; q < N; q++) if (val[q] < 0) { any = true; break; }
    if (!any) continue;
    // material do vértice: o ponto mais perto na grade original
    const matAt = (x, y, z) => {
      const i0 = Math.round((x - ox) / r), j0 = Math.round((y - oy) / r), k0 = Math.round((z - oz) / r);
      for (let rad = 0; rad <= 3; rad++) for (let c = -rad; c <= rad; c++) for (let b = -rad; b <= rad; b++) for (let a = -rad; a <= rad; a++) {
        const i = i0 + a, j = j0 + b, k = k0 + c; if (i < 0 || j < 0 || k < 0 || i >= nx || j >= ny || k >= nz) continue;
        const m = matC[id(i, j, k)]; if (m >= 0) return m;
      }
      return 15;
    };
    const f = (x, y, z) => {
      const fx = Math.min(nx - 1.001, Math.max(0, (x - ox) / r)), fy = Math.min(ny - 1.001, Math.max(0, (y - oy) / r)), fz = Math.min(nz - 1.001, Math.max(0, (z - oz) / r));
      const i = fx | 0, j = fy | 0, k = fz | 0, u = fx - i, v = fy - j, w = fz - k;
      const g = (a, b, c) => val[id(i + a, j + b, k + c)];
      return ((g(0, 0, 0) * (1 - u) + g(1, 0, 0) * u) * (1 - v) + (g(0, 1, 0) * (1 - u) + g(1, 1, 0) * u) * v) * (1 - w) + ((g(0, 0, 1) * (1 - u) + g(1, 0, 1) * u) * (1 - v) + (g(0, 1, 1) * (1 - u) + g(1, 1, 1) * u) * v) * w;
    };
    const g = surfaceNets({ f, min: [ox + r, oy + r, oz + r], max: [ox + (nx - 2) * r, oy + (ny - 2) * r, oz + (nz - 2) * r], mat: 15, noSkip: true }, r);
    // osso e material em cada vértice
    for (let vtx = 0; vtx < g.nv; vtx++) { const o = vtx * VSTRIDE; g.v[o + 6] = matAt(g.v[o], g.v[o + 1], g.v[o + 2]); g.v[o + 10] = 0; g.v[o + 11] = bone; g.v[o + 12] = 1; g.v[o + 13] = 0; }
    out.append(g);
  }
  out.skinned = true;
  return out;
}

/**
 * Corpo do personagem direto das formas modeladas (SDF de cada peça → malha), em vez da casca tirada dos
 * pontos. Mantém a anatomia e a silhueta exatas: placas, ombreiras, dedos, elmo. Cada vértice anda com o osso
 * da peça (skinned). As placas finas são engordadas meia célula para a malha não furar.
 * O material de cada vértice segue o detalhe da peça (frisos de bronze, veios, riscos de prata).
 */
export function partsMesh(parts, { res = 0.012, skipBones = [] } = {}) {
  const out = new SolidGeom(8192);
  for (const part of parts) {
    if (!part.f || !part.min || !part.max || skipBones.includes(part.bone || 0)) continue;
    const inflate = res * 0.45, f0 = part.f;
    const p2 = { ...part, f: (x, y, z) => f0(x, y, z) - inflate, min: part.min.map(v => v - inflate * 2), max: part.max.map(v => v + inflate * 2) };
    const v0 = out.nv;
    try { surfaceNets(p2, part.res || res, out); } catch (e) { continue; }
    const bone = part.bone || 0;
    for (let i = v0; i < out.nv; i++) {
      const o = i * VSTRIDE, v = out.v;
      let mat = part.mat;
      if (part.detail) {
        try { const d = part.detail([v[o], v[o + 1], v[o + 2]], [v[o + 3], v[o + 4], v[o + 5]], 0); if (d && d.mat !== undefined) mat = d.mat; } catch (e) { /* detalhe opcional */ }
      }
      v[o + 6] = mat; v[o + 10] = 0; v[o + 11] = bone; v[o + 12] = 1; v[o + 13] = 0;
    }
  }
  out.skinned = true;
  return out;
}
