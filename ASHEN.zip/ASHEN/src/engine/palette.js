// ASHEN — Paleta de materiais
// Cada material é um código de 1 caractere usado nas grades de cor da arte.
// As cores são "albedo": a iluminação global multiplica tudo depois.

export const MATERIALS = {
  // Aço negro
  n: '#0c0e13', k: '#1c2029', K: '#323947', q: '#4f5b75', Q: '#8494b6',
  // Aço polido / prata
  z: '#555c66', s: '#929ba6', S: '#c9d1da', W: '#eef2f6',
  // Ouro envelhecido / bronze
  o: '#553c17', g: '#8f6b2b', G: '#c49a49', Y: '#e6c377',
  // Tecidos (vinho, vermelho escuro)
  v: '#26050b', c: '#4b111c', C: '#721c2a', R: '#96303c',
  // Couro / marrom
  l: '#33221a', L: '#5b402c',
  // Lâmina
  b: '#7b8796', B: '#d7dfe8',
  // Pedra (escura → clara)
  1: '#141318', 2: '#211f26', 3: '#302d35', 4: '#423e48', 5: '#58535e', 6: '#736d79', 7: '#918a96', 8: '#b3acb4',
  // Musgo / natureza
  m: '#222b1c', M: '#38432a', h: '#525b42', H: '#6d7457',
  // Madeira morta
  w: '#271e18', x: '#433629', X: '#665645', j: '#8a7c69',
  // Osso
  u: '#867e71', U: '#c2b8a6',
  // Ferro / ferrugem
  i: '#292726', I: '#4f4b46', J: '#746d65', t: '#552c1a', T: '#844626',
  // Fogo
  f: '#b52d17', F: '#f47021', y: '#ffbe55', Z: '#fff0c2',
  // Brilhos / magia
  e: '#ff5226', E: '#ffcf8a', a: '#6a8dff', A: '#b6caff', p: '#62399c', P: '#9b6ad6',
  // Terra / cinzas
  9: '#26221e', 0: '#37312b',
  // Preto puro
  d: '#000000',
};

// Estilos de sombreamento "de gravura": na arte, os dígitos 0–5 viram hachuras.
// 1 = mais iluminado … 5 = sombra profunda; 0 = só o fundo do material.
// Padrão diagonal por posição: (col+linha) forma riscos ╱ contínuos, como numa gravura.
export const SHADE_STYLES = {
  steel: {
    0: { bg: 'k', g: [[1, ' ']], fg: 'k' },
    1: { bg: 'K', g: [[2, '╱'], [1, ' ']], fg: 'Q' },
    2: { bg: 'K', g: [[3, '╱'], [1, '·', 7]], fg: 'q' },
    3: { bg: 'k', g: [[3, '╱'], [1, ' ']], fg: 'K' },
    4: { bg: 'k', g: [[4, '╳'], [1, ' ']], fg: 'n' },
    5: { bg: 'n', g: [[5, '·'], [1, ' ']], fg: 'k' },
  },
  stone: {
    0: { bg: '3', g: [[1, ' ']], fg: '3' },
    1: { bg: '5', g: [[3, '╱'], [1, ' ']], fg: '7' },
    2: { bg: '4', g: [[4, '╱'], [1, '·', 5]], fg: '6' },
    3: { bg: '3', g: [[4, '╱'], [1, ' ']], fg: '4' },
    4: { bg: '2', g: [[4, '╳'], [1, ' ']], fg: '1' },
    5: { bg: '1', g: [[1, ' ']], fg: '2' },
  },
};

/** Resolve um dígito de sombreamento em {ch, fg, bg} (códigos de material). */
export function resolveShade(style, level, col, row) {
  const st = SHADE_STYLES[style];
  if (!st) return null;
  const s = st[level];
  if (!s) return null;
  let ch = ' ';
  for (const [mod, g, sparse] of s.g) {
    if (mod === 1) {
      // Regra final: glifo esparso (a cada `sparse` células) ou vazio.
      ch = sparse ? (((col * 3 + row * 5) % sparse) === 0 ? g : ' ') : g;
      break;
    }
    const k = g === '╲' || g === '╳' ? (col - row) : (col + row);
    if (((k % mod) + mod) % mod === 0) { ch = g; break; }
  }
  return { ch, fg: s.fg, bg: s.bg };
}

const cache = new Map();

export function hexToRgb(hex) {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function rgbToHex(r, g, b) {
  const c = v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0');
  return '#' + c(r) + c(g) + c(b);
}

/** Cor de um material, opcionalmente escurecida/clareada por `tone` (1 = original). */
export function matColor(code, tone = 1) {
  const key = code + '|' + tone;
  let v = cache.get(key);
  if (v !== undefined) return v;
  const base = MATERIALS[code];
  if (!base) { v = null; }
  else if (tone === 1) { v = base; }
  else { const [r, g, b] = hexToRgb(base); v = rgbToHex(r * tone, g * tone, b * tone); }
  cache.set(key, v);
  return v;
}

export function isMaterial(code) { return Object.prototype.hasOwnProperty.call(MATERIALS, code); }

/** Mistura duas cores hex. */
export function mixHex(a, b, t) {
  const A = hexToRgb(a), B = hexToRgb(b);
  return rgbToHex(A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t);
}

export function scaleHex(a, f) {
  const A = hexToRgb(a);
  return rgbToHex(A[0] * f, A[1] * f, A[2] * f);
}

/** Rampa de cores interpolada (array de hex) → função t∈[0,1] → hex. Quantizada para cache. */
export function makeRamp(stops, steps = 24) {
  const out = [];
  for (let i = 0; i < steps; i++) {
    const t = i / (steps - 1) * (stops.length - 1);
    const k = Math.min(stops.length - 2, Math.floor(t));
    out.push(mixHex(stops[k], stops[k + 1], t - k));
  }
  return t => out[Math.max(0, Math.min(steps - 1, Math.round(t * (steps - 1))))];
}
