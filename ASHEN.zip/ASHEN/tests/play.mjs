// Teste jogável em emulação do Galaxy A56 (915×412 css, DPR 2.625, toque).
// Usa eventos de toque reais (CDP) para o joystick e um segundo dedo no botão "correr".
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const url = process.argv[2] || 'http://localhost:8123/index.html', out = process.argv[3] || '/tmp/p';
const browser = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await browser.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 2.625, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', e => errors.push(e.message));
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
const cdp = await ctx.newCDPSession(page);
const touch = (type, pts) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: pts.map((p, i) => ({ x: p[0], y: p[1], id: p[2] ?? i })) });
const S = () => page.evaluate(() => { const g = window.__ASHEN, p = g.player; return { x: Math.round(p.x), y: Math.round(p.y), view: p.view, run: +p.run.toFixed(2), blend: +p.blend.toFixed(2), focus: g.focus ? g.focus.kind : null, msg: g.hud.msgOpen, lit: !!g.world.state.brazierLit, fps: Math.round(g.perf.fps) }; });
await page.goto(url);
await page.waitForFunction(() => window.__ASHEN && window.__ASHEN.state === 'title', null, { timeout: 60000 });
await page.tap('#start');
await page.waitForTimeout(600);
const r = [];
r.push(['inicio', await S()]);
// Joystick: dedo em (150,280), arrasta para cima-esquerda (rumo ao braseiro)
await touch('touchStart', [[150, 280, 1]]);
await touch('touchMove', [[110, 230, 1]]);
await page.waitForTimeout(900);
r.push(['joystick NO', await S()]);
await touch('touchEnd', []);
await page.waitForTimeout(500);
r.push(['soltou', await S()]);
// Interagir com o braseiro (se estiver em foco)
await page.tap('#btn-interact');
await page.waitForTimeout(900);
r.push(['interagiu', await S()]);
await page.screenshot({ path: `${out}-braseiro.png` });
for (let i = 0; i < 3 && await page.isVisible('#message'); i++) { await page.tap('#message-ok'); await page.waitForTimeout(150); }
r.push(['fechou mensagem', await S()]);
// Multitoque: joystick para cima + segurar correr
await touch('touchStart', [[150, 300, 1]]);
await touch('touchMove', [[152, 230, 1]]);
const rb = await page.locator('#btn-run').boundingBox();
await touch('touchMove', [[152, 230, 1], [rb.x + rb.width / 2, rb.y + rb.height / 2, 2]]);
await page.waitForTimeout(1300);
r.push(['correndo N (2 dedos)', await S()]);
await page.screenshot({ path: `${out}-correndo.png` });
await touch('touchEnd', []);
await page.waitForTimeout(1200);
r.push(['no portão', await S()]);
await page.screenshot({ path: `${out}-portao.png` });
// Andar para a direita (perfil E)
await touch('touchStart', [[150, 300, 1]]);
await touch('touchMove', [[220, 300, 1]]);
await page.waitForTimeout(700);
await page.screenshot({ path: `${out}-leste.png` });
r.push(['leste', await S()]);
await touch('touchEnd', []);
for (const [k, v] of r) console.log(k.padEnd(22), JSON.stringify(v));
console.log('erros:', errors.length ? errors.join('\n') : 'nenhum');
await browser.close();
