// ASHEN — Menu de pausa e configurações (qualidade, clima, FPS, controles, teclas).

import { PRESETS, WEATHER_MODES } from './settings.js';
import { ACTION_LABELS, DEFAULT_BINDINGS } from '../engine/input.js';
import { fontStatus } from '../engine/typography.js';

export const VERSION = { n: '0.11.0', phase: 'Passe de polimento' };

const $ = id => document.getElementById(id);
const keyName = c => !c ? '—' : c.replace(/^Key/, '').replace(/^Digit/, '').replace('Arrow', '').replace('ShiftLeft', 'Shift').replace('ShiftRight', 'Shift D.').replace('Backquote', '`').replace('Escape', 'Esc');

export class Menu {
  constructor(game) {
    this.g = game;
    this.root = $('menu');
    this.body = $('menu-body');
    this.open = false;
    this.root.addEventListener('pointerdown', e => { if (e.target === this.root) this.hide(); e.stopPropagation(); });
  }

  toggle() { this.open ? this.hide() : this.show(); }

  show() {
    this.open = true;
    this.render();
    this.root.classList.remove('hidden'); this.root.classList.add('anim'); clearTimeout(this._at); this._at = setTimeout(() => this.root.classList.remove('anim'), 240);
    this.g.input.clearAll();
    setTimeout(() => { const b = this.body.querySelector('button'); b && b.focus({ preventScroll: true }); }, 30);
  }

  hide() {
    if (this.g.input.rebinding) return;
    this.open = false;
    this.root.classList.add('hidden');
    this.g.input.clearAll();
  }

  render() {
    const s = this.g.settings;
    const seg = (name, opts, cur) => `<div class="seg" data-k="${name}">${opts.map(([v, l]) => `<button type="button" data-v="${v}" aria-pressed="${String(v) === String(cur)}">${l}</button>`).join('')}</div>`;
    const preset = PRESETS[s.preset];
    const b = this.g.input.bindings;
    const r = this.g.R;
    this.body.innerHTML = `
      <div class="menu-actions">
        <button class="act primary" id="m-resume" type="button">▸ continuar</button>
        <button class="act" id="m-brazier" type="button">voltar ao braseiro</button>
        <button class="act" id="m-full" type="button">tela cheia</button>
        <button class="act" id="m-intro" type="button">rever a abertura</button>
        <button class="act" id="m-inv" type="button">inventário</button>
        <button class="act" id="m-audio" type="button">♪ volume</button>
        <button class="act" id="m-slots" type="button">salvar e trocar de save</button>
      </div>
      <div class="row"><div><span class="lbl">Qualidade gráfica</span><span class="sub">${preset.desc}</span></div>
        ${seg('preset', Object.keys(PRESETS).map(k => [k, PRESETS[k].label]), s.preset)}</div>
      <div class="row"><div><span class="lbl">Clima</span><span class="sub">Automático muda sozinho entre limpo, garoa, chuva e tempestade. Agora: ${this.g.weather ? this.g.weather.label : '—'}.</span></div>
        ${seg('weather', WEATHER_MODES, s.weather)}</div>
      <div class="row"><label for="m-sound">Som ligado</label><input id="m-sound" type="checkbox" ${s.sound !== false ? 'checked' : ''}></div>
      <div class="row"><label for="m-vol">Volume dos efeitos sonoros</label><input id="m-vol" type="range" min="0" max="1" step="0.05" value="${s.volume == null ? 0.8 : s.volume}"></div>
      <div class="row"><label for="m-mus">Volume da música de fundo</label><input id="m-mus" type="range" min="0" max="1" step="0.05" value="${s.music == null ? 0.6 : s.music}"></div>
      <div class="row"><div><span class="lbl">Narração das cenas</span><span class="sub">Usa a voz do aparelho em português.</span></div><input id="m-narr" type="checkbox" ${s.narration !== false ? 'checked' : ''}></div>
      <div class="row"><div><span class="lbl">Limite de quadros</span><span class="sub">60 é o ideal; 30 esquenta menos o aparelho.</span></div>
        ${seg('fpsCap', [[30, '30'], [60, '60'], [0, 'livre']], s.fpsCap)}</div>
      <div class="row"><label for="m-perf">Mostrar desempenho (FPS)</label><input id="m-perf" type="checkbox" ${s.showPerf ? 'checked' : ''}></div>
      <div class="row"><label for="m-hapt">Vibração nos botões</label><input id="m-hapt" type="checkbox" ${s.haptics ? 'checked' : ''}></div>
      <div class="row"><label for="m-ctrl">Tamanho dos botões de toque</label><input id="m-ctrl" type="range" min="0.8" max="1.4" step="0.05" value="${s.controlScale}"></div>
      <details ${this.g.input.lastDevice === 'keyboard' || this.g.input.lastDevice === 'mouse' ? 'open' : ''}>
        <summary>Teclas (teclado e mouse)</summary>
        <p class="small">Clique em uma tecla e aperte a nova. Esc cancela. Teclado: WASD/setas andam, Shift corre, J ou espaço ataca, E interage, Esc abre o menu.</p>
        <div class="keys">${Object.keys(DEFAULT_BINDINGS).map(a => `
          <span>${ACTION_LABELS[a]}</span>
          <button type="button" data-a="${a}" data-s="0">${keyName(b[a][0])}</button>
          <button type="button" data-a="${a}" data-s="1">${keyName(b[a][1])}</button>`).join('')}</div>
        <div class="menu-actions" style="margin-top:10px"><button class="act" id="m-keys-reset" type="button">restaurar teclas</button></div>
      </details>
      <details><summary>Sobre esta versão</summary>
        <p class="small">ASHEN — The Last Oath · v${VERSION.n} · ${VERSION.phase}
Fonte: ${fontStatus.mono}
Japonês: ${fontStatus.cjk}
Tela: ${r.W}×${r.H} px · WebGL2 · ${this.g.counts ? this.g.counts.total.toLocaleString('pt-BR') : '—'} caracteres no mundo</p>
        <div class="menu-actions"><button class="act" id="m-reset" type="button">apagar progresso salvo</button></div>
      </details>`;
    this._wire();
  }

  _wire() {
    const g = this.g;
    $('m-resume').onclick = () => this.hide();
    $('m-brazier').onclick = () => { g.respawn(); this.hide(); };
    $('m-full').onclick = () => { g.fullscreen(); };
    $('m-intro').onclick = () => { this.hide(); g.replayIntro(); };
    $('m-inv').onclick = () => { this.hide(); g.openInventory && g.openInventory(); };
    $('m-slots').onclick = () => { g.save(); location.reload(); };
    this.body.querySelectorAll('.seg').forEach(el => el.querySelectorAll('button').forEach(btn => {
      btn.onclick = () => {
        const k = el.dataset.k;
        let v = btn.dataset.v;
        if (k === 'fpsCap') v = +v;
        g.settings[k] = v;
        g.applySettings();
        this.render();
      };
    }));
    $('m-sound').onchange = e => { g.settings.sound = e.target.checked; g.applySettings(); };
    $('m-vol').oninput = e => { g.settings.volume = +e.target.value; g.applySettings(); };
    $('m-audio').onclick = () => { const r = $('m-vol').closest('.row'); r.scrollIntoView({ behavior: 'smooth', block: 'center' }); r.classList.add('flash'); setTimeout(() => r.classList.remove('flash'), 1200); };
    $('m-mus').oninput = e => { g.settings.music = +e.target.value; g.applySettings(); };
    $('m-narr').onchange = e => { g.settings.narration = e.target.checked; g.applySettings(); };
    $('m-perf').onchange = e => { g.settings.showPerf = e.target.checked; g.applySettings(); };
    $('m-hapt').onchange = e => { g.settings.haptics = e.target.checked; g.applySettings(); };
    $('m-ctrl').oninput = e => { g.settings.controlScale = +e.target.value; g.applySettings(); };
    this.body.querySelectorAll('.keys button').forEach(btn => {
      btn.onclick = () => {
        btn.classList.add('wait'); btn.textContent = 'aperte…';
        g.input.startRebind(btn.dataset.a, +btn.dataset.s, binds => { g.settings.bindings = binds; g.applySettings(); this.render(); });
      };
    });
    $('m-keys-reset').onclick = () => { g.input.bindings = structuredClone(DEFAULT_BINDINGS); g.settings.bindings = null; g.applySettings(); this.render(); };
    $('m-reset').onclick = () => { g.resetProgress(); this.hide(); };
  }
}
