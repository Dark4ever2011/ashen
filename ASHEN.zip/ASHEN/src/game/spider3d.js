// ASHEN 3D — Chefe: a Tecelã do Poço, uma aranha gigante.
// Esqueleto próprio: 0 mundo, 1 corpo (cefalotórax + abdome + olhos + quelíceras), 2..17 pernas
// (8 pernas × fêmur e tíbia). Andar em quadrípode alternado, pés plantados, joelhos altos.
// Ataques lentos de médio alcance: estocada das patas da frente, varrida girando e jato de teia.

import { tell } from './tell.js';
import { m4, v3, noise3 } from './math3d.js';
import { MAT } from './glyphs.js';
import * as S from './sdf.js';

export const SPIDER_NAME = 'A Tecelã do Poço';
export const SPIDER_HP = 700;
const LF = 1.35, LT = 1.75;                     // fêmur e tíbia (m)
const HIPS = [];
for (let i = 0; i < 4; i++) for (const s of [1, -1]) HIPS.push({ s, i, hip: [s * 0.32, 0.02, 0.55 - i * 0.3], rest: [s * (1.75 + 0.25 * Math.sin(i * 1.3)), 0, 1.6 - i * 1.05] });

export function spiderParts() {
  const P = [], add = o => P.push(o);
  const hairs = (p) => (noise3(p[0] * 40, p[1] * 40, p[2] * 40) > 0.66 ? { mat: MAT.HAIR, glyph: ['ʃ', '⁞', '\'', '`'][(Math.abs(p[1] * 97) | 0) % 4] } : null);
  // cefalotórax, abdome (com marca de ossos), cintura
  const ceph = S.xf(S.ellipsoid(0.5, 0.3, 0.62), [0, 0.02, 0.32]);
  const abd = S.xf(S.ellipsoid(0.86, 0.72, 1.08), [0, 0.3, -1.12]);
  const waist = S.capsule([0, 0.05, -0.2], [0, 0.15, -0.35], 0.18);
  add({ name: 'corpo', bone: 1, f: S.smooth(0.12, ceph, waist, abd), min: [-0.95, -0.35, -2.25], max: [0.95, 1.05, 0.98], mat: MAT.CHITIN, spacing: 0.045, flow: [0, 0, 1],
    detail: (p, n) => {
      if (p[2] < -0.4 && n[1] > 0.3) {   // a marca no dorso: uma caveira estilizada em osso
        const u = p[0], v = p[2] + 1.05;
        if (Math.hypot(u, v * 0.8) < 0.32 && Math.hypot(u, v * 0.8) > 0.2) return { mat: MAT.BONE };
        if (Math.abs(u) < 0.05 && v > 0.1 && v < 0.55) return { mat: MAT.BONE };
        if (Math.abs(v + 0.35) < 0.05 && Math.abs(u) < 0.4) return { mat: MAT.BLOOD };
      }
      if (Math.abs(((p[2] + 3) * 3.2) % 1 - 0.5) < 0.06 && p[2] < -0.3) return { mat: MAT.BLOOD, size: 0.8 };   // anéis do abdome
      return hairs(p);
    },
    // olhos: 2 grandes + 6 pequenos, vermelhos e acesos
    decals: [[0.1, 0.22, 0.9, 0.07], [-0.1, 0.22, 0.9, 0.07], [0.22, 0.2, 0.82, 0.045], [-0.22, 0.2, 0.82, 0.045], [0.05, 0.3, 0.84, 0.04], [-0.05, 0.3, 0.84, 0.04], [0.3, 0.12, 0.74, 0.035], [-0.3, 0.12, 0.74, 0.035]]
      .map(([x, y, z, s]) => ({ p: [x, y, z], n: [x * 0.6, 0.3, 1], glyph: '●', mat: MAT.EMBER, size: s * 1.7, flags: 2, clear: s * 0.9 })) });
  // quelíceras e presas
  for (const s of [-1, 1]) add({ name: 'presa', bone: 1, f: S.smooth(0.04, S.capsule([s * 0.12, -0.05, 0.85], [s * 0.1, -0.32, 0.98], 0.08), S.roundCone([s * 0.1, -0.32, 0.98], [s * 0.03, -0.55, 0.9], 0.04, 0.008)), min: [s * 0.12 - 0.18, -0.6, 0.72], max: [s * 0.12 + 0.18, 0.05, 1.1], mat: MAT.CHITIN, spacing: 0.02, flow: [0, 1, 0],
    detail: (p) => (p[1] < -0.36 ? { mat: MAT.BONE } : null) });
  add({ name: 'fiandeiras', bone: 1, f: S.xf(S.ellipsoid(0.16, 0.12, 0.18), [0, 0.05, -2.12]), min: [-0.2, -0.1, -2.35], max: [0.2, 0.2, -1.9], mat: MAT.LEATHER, spacing: 0.025, flow: [0, 0, 1] });
  // pernas: cada osso cresce em -y (a partir da articulação)
  for (let k = 0; k < 8; k++) {
    add({ name: 'fêmur', bone: 2 + k * 2, f: S.smooth(0.03, S.roundCone([0, 0, 0], [0, -LF, 0], 0.1, 0.075), S.xf(S.sphere(0.1), [0, -LF, 0])), min: [-0.14, -LF - 0.12, -0.14], max: [0.14, 0.12, 0.14], mat: MAT.CHITIN, spacing: 0.035, flow: [0, 1, 0],
      detail: (p) => ((((p[1] * 4) % 1) + 1) % 1 < 0.1 ? { mat: MAT.BLOOD, size: 0.8 } : hairs(p)) });
    add({ name: 'tíbia', bone: 3 + k * 2, f: S.roundCone([0, 0, 0], [0, -LT, 0], 0.07, 0.018), min: [-0.1, -LT - 0.05, -0.1], max: [0.1, 0.08, 0.1], mat: MAT.CHITIN, spacing: 0.03, flow: [0, 1, 0],
      detail: (p) => (p[1] < -LT + 0.25 ? { mat: MAT.BONE } : hairs(p)) });
  }
  return P;
}

const frame = (origin, yAxis, fwd) => {
  const y = v3.norm(yAxis);
  let x = v3.norm(v3.cross(y, fwd));
  if (!isFinite(x[0])) x = [1, 0, 0];
  const z = v3.cross(x, y), m = m4.ident();
  m[0] = x[0]; m[1] = x[1]; m[2] = x[2]; m[4] = y[0]; m[5] = y[1]; m[6] = y[2]; m[8] = z[0]; m[9] = z[1]; m[10] = z[2];
  m[12] = origin[0]; m[13] = origin[1]; m[14] = origin[2];
  return m;
};
function ik(a, target, l1, l2, pole) {
  let d = v3.sub(target, a), dist = v3.len(d);
  const max = (l1 + l2) * 0.999;
  if (dist > max) { d = v3.mul(d, max / dist); dist = max; }
  const dir = v3.mul(d, 1 / Math.max(dist, 1e-4));
  const x = (l1 * l1 - l2 * l2 + dist * dist) / (2 * dist), h = Math.sqrt(Math.max(0, l1 * l1 - x * x));
  const pv = v3.norm(v3.sub(pole, v3.mul(dir, v3.dot(pole, dir))));
  return { knee: v3.add(v3.add(a, v3.mul(dir, x)), v3.mul(pv, h)), end: v3.add(a, d) };
}
const sm = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };

export const ACTIONS = {
  stab: { dur: 2.2, hit: [0.56, 0.66], dmg: 26, reach: 3.4 },
  sweep: { dur: 2.6, hit: [0.4, 0.75], dmg: 22, reach: 3.3 },
  web: { dur: 2.0, shoot: 0.55 },
  hiss: { dur: 1.8 },
};

/** Pose no espaço do mundo. st: { x, y, z, yaw, phase, blend, t, act, at, drop (0..1 descendo do alto), dead } */
export function poseSpider(st) {
  const b = new Array(18);
  b[0] = m4.ident();
  const A = st.act, at = st.at || 0, dead = st.dead || 0, T = st.t || 0;
  const aw = A ? sm(Math.min(at / 0.12, (1 - at) / 0.15)) : 0;
  let spin = 0, pitch = 0, rise = 0;
  if (A === 'sweep') spin = sm((at - 0.3) / 0.5) * Math.PI * 2;
  if (A === 'web') pitch = -0.5 * aw;                                  // ergue a frente, abdome mira
  if (A === 'stab') { pitch = 0.35 * sm(at / 0.5) * (at < 0.56 ? 1 : 0) - 0.25 * (at >= 0.56 ? aw : 0); rise = 0.25 * sm(at / 0.5) * (at < 0.6 ? 1 : 0); }
  if (A === 'hiss') { pitch = 0.45 * aw; rise = 0.3 * aw; }
  const bob = Math.sin(T * 2.4) * 0.03 + Math.sin((st.phase || 0) * Math.PI * 4) * 0.05 * (st.blend || 0);
  const drop = st.drop == null ? 0 : st.drop;
  const h = 0.95 + bob + rise - dead * 0.75 + drop * 11;
  const W = m4.mul(m4.mul(m4.mul(m4.translate(st.x, (st.y || 0) + h, st.z), m4.rotY(st.yaw + spin)), m4.rotX(-pitch)), m4.rotZ(Math.sin(T * 1.3) * 0.03));
  b[1] = W;
  HIPS.forEach((L, k) => {
    const hip = m4.point(W, L.hip);
    // alvo do pé: posição de descanso + passada em quadrípode alternado
    const grp = (L.i + (L.s > 0 ? 0 : 1)) % 2, ph = ((st.phase || 0) + grp * 0.5) % 1;
    const stride = 0.55 * (st.blend || 0), swing = ph < 0.5;
    const off = swing ? -Math.cos(ph * 2 * Math.PI) * stride : Math.cos((ph - 0.5) * 2 * Math.PI) * stride;
    const lift = swing ? Math.sin(ph * 2 * Math.PI) * 0.45 * (st.blend || 0) : 0;
    let local = [L.rest[0], -h + lift + (st.y || 0) * 0, L.rest[2] + off];
    if (A === 'stab' && L.i === 0) {          // patas da frente: sobem e espetam à frente
      const up = sm(at / 0.5), strike = sm((at - 0.52) / 0.12), back = sm((at - 0.75) / 0.25);
      const raised = [L.s * 0.6, 1.4, 1.2], hit = [L.s * 0.35, -h + 0.1, 3.3];
      local = v3.lerp(v3.lerp(v3.lerp(local, raised, up), hit, strike), local, back);
    }
    if (A === 'sweep') local = [L.rest[0] * (1 + 0.35 * aw), local[1] + 0.25 * aw, L.rest[2] * (1 + 0.2 * aw)];
    if (dead > 0) local = v3.lerp(local, [L.s * 0.55, 0.2, 0.3 - L.i * 0.25], sm(dead));          // morte: as pernas se encolhem
    if (drop > 0) local = v3.lerp(local, [L.s * 0.9, 0.8, 0.9 - L.i * 0.6], Math.min(1, drop * 3));
    // o pé fica no chão do mundo (planta), salvo nas animações
    const footW = m4.point(m4.mul(m4.mul(m4.translate(st.x, (st.y || 0) + h, st.z), m4.rotY(st.yaw + spin)), m4.ident()), local);
    if (!(A === 'stab' && L.i === 0) && dead <= 0 && drop <= 0) footW[1] = (st.y || 0) + lift + 0.02;
    const pole = v3.add([0, 1.6, 0], v3.mul(v3.norm(v3.sub(hip, [st.x, hip[1], st.z])), 0.6));
    const { knee, end } = ik(hip, footW, LF, LT, pole);
    b[2 + k * 2] = frame(hip, v3.sub(hip, knee), [0, 1, 0]);
    b[3 + k * 2] = frame(knee, v3.sub(knee, end), [0, 1, 0]);
  });
  return b;
}

export class Spider {
  constructor(home) { this.home = home; this.reset(); }
  reset() { Object.assign(this, { x: this.home.x, z: this.home.z - 2.5, y: 0, yaw: 0, hp: SPIDER_HP, phase: 0, blend: 0, t: 0, act: null, at: 0, cool: 2, drop: 1, dead: 0, state: 'hidden', hitDone: false, phase2: false, webs: [] }); }
  get alive() { return this.state === 'fight'; }
  damage(n) { if (this.state !== 'fight') return false; this.hp -= n; if (!this.phase2 && this.hp < SPIDER_HP * 0.45) { this.phase2 = true; this.act = 'hiss'; this.at = 0; } if (this.hp <= 0) { this.hp = 0; this.state = 'dying'; this.act = null; return true; } return false; }
  doStagger() { if (this.act === 'stab') { this.act = 'hiss'; this.at = 0.3; } this.cool = 1.8; }
  update(dt, pl, canHit) {
    const ev = [];
    this.t += dt;
    for (const w of this.webs) {                    // jatos de teia voando
      w.t += dt; w.p = v3.add(w.p, v3.mul(w.v, dt)); w.v[1] -= 3 * dt;
      if (!w.done && Math.hypot(w.p[0] - pl.x, w.p[2] - pl.z) < 0.75 && w.p[1] < (pl.y || 0) + 2) { w.done = true; if (canHit) ev.push({ type: 'web', dmg: 10, from: [this.x, this.z] }); }
      if (w.p[1] < (pl.y || 0)) { w.done = true; if (!w.splat) { w.splat = true; ev.push({ type: 'splat', p: w.p.slice() }); } }
    }
    this.webs = this.webs.filter(w => w.t < 3 && !w.splat);
    if (this.state === 'dropping') { this.drop = Math.max(0, this.drop - dt / 3.2); if (this.drop <= 0) { this.state = 'fight'; this.act = 'hiss'; this.at = 0; ev.push({ type: 'land' }); } return ev; }
    if (this.state === 'dying') { this.dead = Math.min(1, this.dead + dt / 3); if (this.dead >= 1) this.state = 'dead'; return ev; }
    if (this.state !== 'fight') return ev;
    const dx = pl.x - this.x, dz = pl.z - this.z, d = Math.hypot(dx, dz), want = Math.atan2(dx, dz);
    const turnTo = (k) => { this.yaw += Math.max(-k * dt, Math.min(k * dt, Math.atan2(Math.sin(want - this.yaw), Math.cos(want - this.yaw)))); };
    const fast = this.phase2 ? 1.15 : 1;
    if (this.act) {
      const A = ACTIONS[this.act], prev = this.at;
      this.at += dt * fast / A.dur;
      if (this.at < 0.35) turnTo(1.4);
      if (A.hit && !this.hitDone && this.at >= A.hit[0] && this.at <= A.hit[1]) {
        const ang = Math.abs(Math.atan2(Math.sin(want - this.yaw), Math.cos(want - this.yaw)));
        const inReach = this.act === 'sweep' ? d < A.reach : d < A.reach && ang < 0.7;
        if (inReach && canHit) { this.hitDone = true; ev.push({ type: 'hit', dmg: A.dmg, from: [this.x, this.z] }); }
      }
      if (this.act === 'stab' && prev < 0.56 && this.at >= 0.56) ev.push({ type: 'stab' });
      if (this.act === 'sweep' && prev < 0.4 && this.at >= 0.4) ev.push({ type: 'sweep' });
      if (this.act === 'hiss' && prev < 0.1 && this.at >= 0.1) ev.push({ type: 'hiss' });
      if (this.act === 'web' && prev < A.shoot && this.at >= A.shoot) {
        const o = [this.x - Math.sin(this.yaw) * 2.0, (this.y || 0) + 1.6, this.z - Math.cos(this.yaw) * 2.0];
        const tgt = [pl.x, (pl.y || 0) + 1.0, pl.z], fl = Math.hypot(tgt[0] - o[0], tgt[2] - o[2]), tt = fl / 7;
        this.webs.push({ p: o, v: [(tgt[0] - o[0]) / tt, (tgt[1] - o[1]) / tt + 1.5 * tt, (tgt[2] - o[2]) / tt], t: 0 });
        ev.push({ type: 'spit' });
      }
      if (this.act === 'web') this.yaw += 0; // mira com o abdome erguido
      if (this.at >= 1) { this.act = null; this.cool = (this.phase2 ? 1.0 : 1.6) + Math.random(); }
      this.blend += (0 - this.blend) * Math.min(1, dt * 4);
      return ev;
    }
    this.cool -= dt;
    turnTo(1.6);
    const keep = 2.6;
    if (d > keep + 0.4) { const sp = 1.4 * fast; this.x += Math.sin(this.yaw) * sp * dt; this.z += Math.cos(this.yaw) * sp * dt; this.phase = (this.phase + sp * dt / 1.6) % 1; this.blend += (1 - this.blend) * Math.min(1, dt * 3); }
    else this.blend += (0 - this.blend) * Math.min(1, dt * 3);
    if (this.cool <= 0) {
      const r = Math.random();
      this.act = d > 5 ? 'web' : d < 2.6 && r < 0.4 ? 'sweep' : r < 0.7 ? 'stab' : 'web';
      this.at = 0; this.hitDone = false; tell(this, this.act === 'web' ? 'magic' : 'light', 1.2);
    }
    return ev;
  }
}

/** O vulto encapuzado (osso 1): manto longo, capuz fundo, dois pontos de brasa no escuro. */
export function hoodParts() {
  const cloak = S.intersect(S.shell(S.roundCone([0, 1.55, 0], [0, 0.0, 0], 0.22, 0.6), 0.03), (x, y, z) => -y);
  const hood = S.subtract(S.xf(S.ellipsoid(0.24, 0.3, 0.26), [0, 1.72, 0.02]), S.xf(S.ellipsoid(0.15, 0.2, 0.2), [0, 1.66, 0.16]));
  return [
    { name: 'manto', bone: 1, f: cloak, min: [-0.66, -0.02, -0.66], max: [0.66, 1.6, 0.66], mat: MAT.CLOTH_IN, spacing: 0.035, flow: [0, 1, 0],
      keep: (p) => !(p[1] < 0.25 && Math.sin(Math.atan2(p[2], p[0]) * 9) > 0.6), detail: (p) => (noise3(p[0] * 9, p[1] * 3, p[2] * 9) > 0.62 ? { mat: MAT.DARK } : null) },
    { name: 'capuz', bone: 1, f: hood, min: [-0.28, 1.4, -0.28], max: [0.28, 2.05, 0.3], mat: MAT.CLOTH_IN, spacing: 0.02, flow: [0, 1, 0],
      decals: [-1, 1].map(s => ({ p: [s * 0.05, 1.7, 0.2], n: [0, 0, 1], glyph: '•', mat: MAT.EMBER, size: 0.045, flags: 2 })) },
  ];
}
