// ASHEN — The Last Oath
// Configuração global. Valores em "unidades de mundo" (u).
// 1 célula tipográfica de personagem = 6u x 10u.

export const CONFIG = {
  VERSION: '0.1.0',
  PHASE: 'Fase 1 — Motor Gráfico',

  // Projeção 3/4: o plano do chão é achatado verticalmente por TILT.
  // tela_y = (mundo_y * TILT - altura_z)
  TILT: 0.72,

  // Quantas linhas de células de personagem cabem na altura da tela.
  // Menor = câmera mais próxima. O cavaleiro tem ~29 linhas.
  VIEW_ROWS: 86,

  // Célula de personagens, objetos e arquitetura.
  CELL_W: 6,
  CELL_H: 10,

  // Célula do chão (em unidades projetadas da tela).
  GROUND_CW: 7.2,
  GROUND_CH: 12,

  // Física em passo fixo, independente do FPS.
  PHYSICS_HZ: 60,

  // Movimento do cavaleiro (u/s no plano do chão).
  WALK_SPEED: 132,
  RUN_SPEED: 228,
  ACCEL: 820,
  DECEL: 1150,

  DEBUG: false,
};

export const DIR = { S: 0, SE: 1, E: 2, NE: 3, N: 4, NW: 5, W: 6, SW: 7 };
