// ASHEN 3D — Modo Extremo: um anel de chão 3x mais denso que acompanha o cavaleiro.
// A grade é presa ao mundo (não "nada" com o jogador): só é refeita quando ele anda ~1 m.

import { PointSet } from './sampler.js';
import { MAT } from './glyphs.js';
import { noise3 } from './math3d.js';

const STEP = 0.075, RADIUS = 6.5, CAP = 26000;
const h1 = (x, z) => { const s = Math.sin(x * 127.1 + z * 311.7) * 43758.5453; return s - Math.floor(s); };

export class DetailRing {
  constructor(R) {
    this.R = R; this.ps = new PointSet(CAP);
    for (let i = 0; i < CAP; i++) this.ps.push([0, -50, 0], [0, 1, 0], [1, 0, 0], 0, -1, 0, 0, 0.01, 0);
    this.mesh = R.addMesh(this.ps, { dynamic: true, occlude: false });
    this.mesh.drawCount = 0; this.at = null; this.on = false;
  }
  /** height(x,z) → y do chão; skip(x,z) → true para não pôr caractere ali (água, paredes). */
  update(on, cx, cz, height, skip) {
    this.on = on;
    this.mesh.visible = on && !!height;
    if (!this.mesh.visible) return;
    if (this.at && Math.hypot(cx - this.at[0], cz - this.at[1]) < 1.0 && this.height === height) return;
    this.at = [cx, cz]; this.height = height;
    const ps = this.ps; ps.n = 0;
    const x0 = Math.floor((cx - RADIUS) / STEP), x1 = Math.ceil((cx + RADIUS) / STEP), z0 = Math.floor((cz - RADIUS) / STEP), z1 = Math.ceil((cz + RADIUS) / STEP);
    for (let i = x0; i <= x1 && ps.n < CAP; i++) for (let j = z0; j <= z1 && ps.n < CAP; j++) {
      const r = h1(i, j), x = (i + r * 0.8) * STEP, z = (j + h1(j, i) * 0.8) * STEP;
      const d = Math.hypot(x - cx, z - cz);
      if (d > RADIUS || r > 0.92 - 0.25 * (d / RADIUS) || (skip && skip(x, z))) continue;
      const y = height(x, z) + 0.004;
      const n = noise3(x * 0.9, 3, z * 0.9), m = n > 0.62 ? MAT.MOSS : n < 0.3 ? MAT.GRAVEL : MAT.GROUND;
      const a = r * 6.283;
      ps.push([x, y, z], [0, 1, 0], [Math.cos(a), 0, Math.sin(a)], m, -1, 0, 0, 0.05 + r * 0.03, r * 1000);
    }
    this.mesh.drawCount = ps.n;
    this.R.updateMesh(this.mesh, ps);
  }
}
