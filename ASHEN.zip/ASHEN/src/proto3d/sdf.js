// ASHEN 3D — Modelagem por campos de distância (SDF).
// A forma 3D é descrita por funções f(x,y,z) = distância até a superfície (negativa dentro).
// Ela NUNCA é desenhada: serve para espalhar caracteres sobre a superfície e calcular luz/oclusão.

export const sphere = r => (x, y, z) => Math.hypot(x, y, z) - r;

export const ellipsoid = (a, b, c) => (x, y, z) => {
  const k0 = Math.hypot(x / a, y / b, z / c);
  const k1 = Math.hypot(x / (a * a), y / (b * b), z / (c * c));
  return k0 < 1e-6 ? -Math.min(a, b, c) : k0 * (k0 - 1) / k1;
};

export const box = (bx, by, bz, r = 0) => (x, y, z) => {
  const qx = Math.abs(x) - bx + r, qy = Math.abs(y) - by + r, qz = Math.abs(z) - bz + r;
  return Math.hypot(Math.max(qx, 0), Math.max(qy, 0), Math.max(qz, 0)) + Math.min(Math.max(qx, qy, qz), 0) - r;
};

/** Cápsula entre a e b. */
export const capsule = (a, b, r) => (x, y, z) => {
  const pax = x - a[0], pay = y - a[1], paz = z - a[2];
  const bax = b[0] - a[0], bay = b[1] - a[1], baz = b[2] - a[2];
  const h = Math.max(0, Math.min(1, (pax * bax + pay * bay + paz * baz) / (bax * bax + bay * bay + baz * baz)));
  return Math.hypot(pax - bax * h, pay - bay * h, paz - baz * h) - r;
};

/** Cone arredondado: esfera r1 em a, esfera r2 em b, ligadas suavemente. */
export const roundCone = (a, b, r1, r2) => (x, y, z) => {
  const bax = b[0] - a[0], bay = b[1] - a[1], baz = b[2] - a[2];
  const l2 = bax * bax + bay * bay + baz * baz, rr = r1 - r2, a2 = l2 - rr * rr, il2 = 1 / l2;
  const pax = x - a[0], pay = y - a[1], paz = z - a[2];
  const yv = pax * bax + pay * bay + paz * baz, z2 = yv - l2;
  const cx = pax * l2 - bax * yv, cy = pay * l2 - bay * yv, cz = paz * l2 - baz * yv;
  const x2 = cx * cx + cy * cy + cz * cz, y2 = yv * yv * l2, zz = z2 * z2 * l2;
  const k = Math.sign(rr) * rr * rr * x2;
  if (Math.sign(z2) * a2 * zz > k) return Math.sqrt(x2 + zz) * il2 - r2;
  if (Math.sign(yv) * a2 * y2 < k) return Math.sqrt(x2 + y2) * il2 - r1;
  return (Math.sqrt(x2 * a2 * il2) + yv * rr) * il2 - r1;
};

/** Toro no plano XZ. */
export const torus = (R, r) => (x, y, z) => Math.hypot(Math.hypot(x, z) - R, y) - r;

/** Cilindro vertical (eixo Y), meia altura h. */
export const cylinder = (r, h, round = 0) => (x, y, z) => {
  const dx = Math.hypot(x, z) - r + round, dy = Math.abs(y) - h + round;
  return Math.min(Math.max(dx, dy), 0) + Math.hypot(Math.max(dx, 0), Math.max(dy, 0)) - round;
};

export const union = (...fs) => (x, y, z) => { let d = 1e9; for (const f of fs) { const v = f(x, y, z); if (v < d) d = v; } return d; };
export const smooth = (k, ...fs) => (x, y, z) => {
  let d = fs[0](x, y, z);
  for (let i = 1; i < fs.length; i++) {
    const b = fs[i](x, y, z), h = Math.max(k - Math.abs(d - b), 0) / k;
    d = Math.min(d, b) - h * h * k * 0.25;
  }
  return d;
};
export const subtract = (a, b) => (x, y, z) => Math.max(a(x, y, z), -b(x, y, z));
export const intersect = (a, b) => (x, y, z) => Math.max(a(x, y, z), b(x, y, z));
/** Casca (placa de armadura) com espessura t. */
export const shell = (f, t) => (x, y, z) => Math.abs(f(x, y, z)) - t;
/** Semi-espaço: y < h (para cortar formas). */
export const below = h => (x, y, z) => y - h;
export const above = h => (x, y, z) => h - y;

/** Move/gira uma forma. rot = [rx, ry, rz] em radianos (ordem X, depois Y, depois Z). */
export const xf = (f, pos = [0, 0, 0], rot = [0, 0, 0], scale = 1) => {
  const [rx, ry, rz] = rot;
  const cx = Math.cos(rx), sx = Math.sin(rx), cy = Math.cos(ry), sy = Math.sin(ry), cz = Math.cos(rz), sz = Math.sin(rz);
  // R = Rz * Ry * Rx ; inversa = transposta
  const m = [
    cz * cy, sz * cy, -sy,
    cz * sy * sx - sz * cx, sz * sy * sx + cz * cx, cy * sx,
    cz * sy * cx + sz * sx, sz * sy * cx - cz * sx, cy * cx,
  ];
  const [px, py, pz] = pos;
  return (x, y, z) => {
    const dx = (x - px) / scale, dy = (y - py) / scale, dz = (z - pz) / scale;
    // multiplicar pela transposta de R (colunas acima são as linhas de R^T)
    const lx = m[0] * dx + m[1] * dy + m[2] * dz;
    const ly = m[3] * dx + m[4] * dy + m[5] * dz;
    const lz = m[6] * dx + m[7] * dy + m[8] * dz;
    return f(lx, ly, lz) * scale;
  };
};

/** Simetria espelhada em X (peças pares: ombreiras, joelheiras). */
export const mirrorX = f => (x, y, z) => f(Math.abs(x), y, z);
/** Repetição em Y (lâminas de armadura sobrepostas). */
export const repeatY = (f, step, n) => (x, y, z) => {
  let d = 1e9;
  for (let i = 0; i < n; i++) { const v = f(x, y + i * step, z); if (v < d) d = v; }
  return d;
};
