# ASHEN — The Last Oath · 最後の誓い

Action RPG Soulslike dark fantasy, em perspectiva 3/4, **desenhado inteiramente com caracteres** (ASCII, blocos e box-drawing Unicode, kanji). Os caracteres são os próprios gráficos: armaduras gravadas em hachura `╱ ╳ ·`, muralhas em cantaria `▏▁`, fogo `^ * § 火`, névoa `░ ~ ≈`, cinzas `· ˙ ∙`.

Roda no Chrome para Android (referência: Galaxy A56 / Exynos 1580), no navegador do computador e como app instalável (PWA, funciona offline). Sem servidor, sem dependências, sem build.

**Estado atual:** Fase 1 — Motor Gráfico (concluída). Veja `PROGRESS.md`.

---

## Jogar

| | Celular (paisagem) | Computador |
|---|---|---|
| Andar | joystick: toque e arraste na metade esquerda | WASD / setas, ou segurar o botão esquerdo do mouse |
| Correr | segurar **»** (dá para usar junto com o joystick) | Shift |
| Interagir | **◈** (acende quando há algo perto) | E, ou clicar no objeto (o cavaleiro anda até ele) |
| Menu / configurações | **≡** ou o gesto "voltar" do Android | Esc |
| Painel de desempenho | menu → *Mostrar desempenho* | F3 |

As teclas podem ser trocadas no menu. Configurações gráficas: **Alta** (padrão), **Equilibrada** e **Desempenho** — as três preservam armaduras, personagens e arquitetura; só mudam resolução interna, mapa de luz e efeitos secundários.

---

## Publicar no GitHub Pages usando só o celular

1. No Chrome do celular, entre em github.com e crie um repositório (ex.: `ashen`), público, com README.
2. No repositório: **Add file → Create new file**. Nome: `.github/workflows/publicar.yml`. Cole o conteúdo do arquivo de mesmo nome que está neste projeto. **Commit changes**.
3. **Settings → Pages → Build and deployment → Source: GitHub Actions**.
4. Volte ao código: **Add file → Upload files** e envie o arquivo **`ASHEN.zip`** inteiro (não precisa extrair). **Commit changes**.
5. Aba **Actions**: o workflow *Publicar ASHEN* extrai o zip, faz o commit dos arquivos e publica. Em ~1 minuto o jogo fica em `https://SEU-USUARIO.github.io/ashen/`.
6. No Chrome, abra o endereço → menu ⋮ → **Adicionar à tela inicial / Instalar app**. Depois do primeiro carregamento, funciona offline.

Para atualizar: envie um `ASHEN.zip` novo (passo 4) — o mesmo workflow cuida do resto. Se quiser editar arquivos direto no celular, o editor web do GitHub (ícone de lápis) funciona bem para arquivos pequenos; para um fluxo com Git completo no Android, o app **Spck Editor** importa zip e faz push.

> Ao publicar uma versão nova, aumente o nome do cache em `service-worker.js` (ex.: `ashen-v0.1.1`) para os aparelhos baixarem os arquivos novos.

---

## Validar no Galaxy A56 (o que ainda depende do aparelho)

1. Abra o jogo, toque em **despertar**, menu **≡ → Mostrar desempenho**.
2. Ande por 5–10 minutos (cemitério, braseiro, portão). O painel mostra FPS, tempo de lógica e de desenho, **custo de cada passe** (chão, sombras, objetos, névoa, luz…), memória de canvas e a média de FPS a cada 10 s. Se o FPS cair com o aparelho esquentando, aparece um aviso sugerindo *Equilibrada* — o jogo nunca reduz a qualidade sozinho.
3. Abra `tools/glyph-test.html`: mede pixel a pixel se cada caractere (inclusive os kanji) cabe na sua célula **com as fontes do seu Android**. Tudo deve ficar verde.
4. `tools/sprite-viewer.html` mostra o cavaleiro em todas as vistas e animações — útil para editar a arte.

---

## Estrutura

```
index.html · manifest.json · service-worker.js · styles/main.css
assets/fonts/      DejaVu Sans Mono (embutida; licença em LICENSE-DejaVu.txt)
assets/icons/      ícones PWA (誓)
src/main.js        laço (rAF + delta time, física em passo fixo 60 Hz, limite de FPS), passes de desenho
src/config.js      constantes (projeção, células, velocidades)
src/engine/        typography (larguras simples/dupla, fontes, encaixe de glifos), renderer, camera,
                   sprite (arte, composição, cache LRU), palette (materiais + hachuras), lighting,
                   particles, atmosphere (névoa), physics, input, animation, perf, canvas
src/art/           knight (peças da armadura por vista), cape, props, architecture
src/entities/      knight-rig (esqueleto tipográfico), player
src/world/         world, maps (Reino das Cinzas — Portão do Rei), objects, terrain
src/ui/            hud, menus, controls, settings, logo
src/systems/       save (localStorage)
tools/             sprite-viewer, glyph-test, make_icons.py
tests/             unit.mjs (Node) + testes de navegador com Playwright
```

Dados de arte ficam em módulos JS (não JSON) para permitir comentários de edição e carregar sem `fetch`.

### Como editar a armadura
Em `src/art/knight.js`, cada peça é uma lista de linhas `[glifos, materiais]`. Dígitos `0–5` nos glifos viram hachura de aço automaticamente (1 = iluminado, 5 = sombra). Códigos de material estão em `src/engine/palette.js`. Abra `tools/sprite-viewer.html` para ver o resultado.

### Testes (num computador, opcional)
```
node tests/unit.mjs                       # 221 verificações, sem navegador
python3 -m http.server 8123               # servidor local
node tests/play.mjs                       # toque real: joystick, multitoque, interação (emulação A56)
node tests/desktop.mjs                    # teclado, mouse, menu, troca de tecla
node tests/offline.mjs                    # PWA offline
node tests/soak.mjs http://localhost:8123/index.html 45   # sessão longa, giro de tela
```
Os testes de navegador usam Playwright.
