// ASHEN — Caixa de diálogo com retrato em caracteres e moldura gótica.
// Uma conversa = lista de [quem, texto]. Toque na caixa (ou ◈ / E) para avançar.

import { FACES, PEOPLE } from '../game/story2.js';

const $ = id => document.getElementById(id);

export class Dialog {
  constructor(audio) {
    this.audio = audio; this.lines = null; this.i = 0; this.shown = 0; this.onEnd = null;
    $('dialog').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); this.advance(); });
  }
  get open() { return !!this.lines; }
  start(lines, onEnd) {
    this.lines = lines; this.i = 0; this.onEnd = onEnd; this._show();
    $('dialog').classList.remove('hidden'); document.body.classList.add('dlg');
  }
  _show() {
    const [who, text] = this.lines[this.i], P = PEOPLE[who];
    $('dialog').className = P.cls;
    $('dlg-face').textContent = FACES[P.face];
    $('dlg-name').textContent = P.name;
    this.full = text; this.shown = 0; $('dlg-text').textContent = '';
    this.blip = 0;
  }
  advance() {
    if (!this.lines) return;
    if (this.shown < this.full.length) { this.shown = this.full.length; $('dlg-text').textContent = this.full; return; }
    this.audio && this.audio.play('ui');
    if (++this.i >= this.lines.length) { const f = this.onEnd; this.close(); f && f(); return; }
    this._show();
  }
  close() { this.lines = null; $('dialog').classList.add('hidden'); document.body.classList.remove('dlg'); }
  update(dt) {
    if (!this.lines || this.shown >= this.full.length) { $('dlg-next').style.visibility = this.lines ? 'visible' : 'hidden'; return; }
    $('dlg-next').style.visibility = 'hidden';
    const n0 = Math.floor(this.shown);
    this.shown = Math.min(this.full.length, this.shown + dt * 42);
    $('dlg-text').textContent = this.full.slice(0, Math.floor(this.shown));
    if (Math.floor(this.shown / 3) !== Math.floor(n0 / 3)) this.audio && this.audio.play('talk');
  }
}

/** Aranha original em caracteres para o susto. */
export const SPIDER = String.raw`
      \    /\  ||  /\    /
       \  /  \ || /  \  /
   .__  \/    \||/    \/  __.
       '-.__  .--.  __.-'
   ____     \/ ▲▲ \/     ____
       '--.( ◉◉◉◉ ).--'
   ___.-'  /'.▼▼.'\  '-.___
     /   _/  /||\  \_   \
    /   /   / || \   \   \
   /   |   |  ||  |   |   \
`.replace(/^\n/, '');
