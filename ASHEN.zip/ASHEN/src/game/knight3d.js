// ASHEN 3D — Cavaleiro de Aço Negro do Juramento
// Anatomia humana (~1,88 m, ~7,5 cabeças), armadura modelada em cascas com espessura.
// Cada peça vive no espaço do seu osso; a superfície vira milhares de caracteres.
// Ossos: 0 mundo, 1 pélvis, 2 peito, 3 cabeça, 4-6 braço esq., 7-9 braço dir.,
//        10-12 perna esq., 13-15 perna dir., 16 espada.
// O cavaleiro olha para +Z. Lado esquerdo dele = +X.

import { m4, v3, noise3 } from './math3d.js';
import { MAT } from './glyphs.js';
import * as S from './sdf.js';
import { PointSet } from './sampler.js';

export const BONE = { WORLD: 0, PELVIS: 1, CHEST: 2, HEAD: 3, UA_L: 4, FA_L: 5, HAND_L: 6, UA_R: 7, FA_R: 8, HAND_R: 9, TH_L: 10, SH_L: 11, FT_L: 12, TH_R: 13, SH_R: 14, FT_R: 15, SWORD: 16 };

// Proporções de um homem médio (~1,75 m; ombro 0,82 da altura, quadril 0,52, ombros 41 cm entre articulações)
const L = { thigh: 0.45, shin: 0.43, upper: 0.31, fore: 0.265 };
const slab = (y0, y1) => (x, y, z) => Math.max(y0 - y, y - y1);

/** Peças da armadura (tudo em metros, no espaço do osso).
 *  Referência: cavaleiro de aço enegrecido com filetes de bronze gravados, leão heráldico no peito,
 *  elmo fechado de viseira com fenda única, ombreiras em lâminas, cintos cruzados, cota de malha,
 *  tabardo e capa vinho esfarrapados, espada longa de guarda curva. */
export function knightParts() {
  const P = [];
  const add = (o) => P.push(o);
  // gravação orgânica: veios de ruído viram filetes de bronze sobre o aço
  const vein = (p, sc = 38, w = 0.03) => {
    const n = noise3(p[0] * sc + 11, p[1] * sc + 3, p[2] * sc) * 0.65 + noise3(p[0] * sc * 2.3, p[1] * sc * 2.3 + 7, p[2] * sc * 2.3 + 5) * 0.35;
    return Math.abs(n - 0.5) < w;
  };
  const trim = (c) => c > 0.3;                       // bordas das placas → friso de bronze
  // arranhões: ruído esticado numa direção → riscos finos de prata gasta
  const scratch = (p) => {
    const a = noise3((p[0] + p[1]) * 140 + 9, (p[0] - p[1]) * 9, p[2] * 30) ;
    return Math.abs(a - 0.5) < 0.014 && noise3(p[0] * 20, p[1] * 20 + 9, p[2] * 20) > 0.55;
  };
  const dent = (p) => noise3(p[0] * 55 + 3, p[1] * 55, p[2] * 55 + 8) > 0.82;   // amassados escurecidos
  const steelDetail = (sc, w) => (p, n, c) => trim(c) ? { mat: MAT.BRONZE } : vein(p, sc, w) ? { mat: MAT.BRONZE, size: 0.8 }
    : scratch(p) ? { mat: MAT.SILVER, size: 0.75 } : dent(p) ? { mat: MAT.IRON } : null;
  const grooves = (ys, w = 0.006) => (p) => ys.some(y => Math.abs(p[1] - y) < w);

  // ── Pélvis: cota de malha, faldas, cintos cruzados, escarcelas ──
  const mail = S.intersect(S.shell(S.roundCone([0, 0.02, 0], [0, -0.27, 0], 0.158, 0.2), 0.006), S.below(0.03));
  add({ name: 'malha', bone: BONE.PELVIS, f: mail, min: [-0.24, -0.32, -0.24], max: [0.24, 0.06, 0.24], mat: MAT.MAIL, spacing: 0.021, flow: [1, 0, 0], size: 0.85,
    keep: (p) => p[1] > -0.25 - 0.03 * Math.abs(Math.sin(p[0] * 60 + p[2] * 40)) });
  const faulds = S.union(...[0, 1, 2].map(i => S.intersect(S.shell(S.xf(S.ellipsoid(0.17 + i * 0.012, 0.4, 0.13 + i * 0.01), [0, 0.05, 0.005]), 0.008), slab(0.04 - i * 0.05, 0.09 - i * 0.05))));
  add({ name: 'faldas', bone: BONE.PELVIS, f: faulds, min: [-0.21, -0.13, -0.17], max: [0.21, 0.11, 0.17], mat: MAT.STEEL, spacing: 0.022, flow: [1, 0, 0], detail: steelDetail(40, 0.025) });
  const beltA = S.intersect(S.shell(S.xf(S.ellipsoid(0.178, 0.4, 0.14), [0, 0.1, 0.005]), 0.011), slab(0.1, 0.13));
  const beltB = S.intersect(S.shell(S.xf(S.ellipsoid(0.19, 0.4, 0.152), [0, 0.06, 0.005]), 0.01), (x, y) => Math.abs(y - 0.055 + 0.28 * x) - 0.014);
  add({ name: 'cintos', bone: BONE.PELVIS, f: S.union(beltA, beltB), min: [-0.22, -0.03, -0.18], max: [0.22, 0.15, 0.18], mat: MAT.LEATHER, spacing: 0.017, flow: [1, 0, 0],
    detail: (p) => (Math.round(p[0] * 40 + p[2] * 40) % 4 === 0 && Math.abs(p[1] - 0.115) < 0.005) ? { mat: MAT.BRONZE, glyph: '•', size: 0.6 } : null,
    decals: [{ p: [0, 0.115, 0.15], n: [0, 0, 1], glyph: '¤', mat: MAT.BRONZE, size: 0.05 },
             { p: [-0.07, 0.075, 0.148], n: [-0.3, 0, 1], glyph: '¤', mat: MAT.BRONZE, size: 0.044 },
             { p: [0.12, 0.025, 0.12], n: [0.7, 0, 0.7], glyph: '•', mat: MAT.BRONZE, size: 0.03 }] });
  const tasset = S.union(...[0, 1, 2, 3].map(i => S.xf(S.box(0.082 - i * 0.004, 0.03, 0.008, 0.006), [0.112, -0.06 - i * 0.046, 0.14 - i * 0.004], [-0.16, 0, -0.16])));
  add({ name: 'escarcelas', bone: BONE.PELVIS, f: S.mirrorX(tasset), min: [-0.22, -0.26, 0.07], max: [0.22, -0.02, 0.18], mat: MAT.STEEL, spacing: 0.019, flow: [1, 0, 0], detail: steelDetail(44, 0.03) });

  // ── Peito: couraça gravada com leão heráldico, plackart em lâminas, gorjal, ombreiras ──
  const chest = S.smooth(0.07, S.xf(S.ellipsoid(0.195, 0.2, 0.138), [0, 0.21, 0.012]), S.xf(S.ellipsoid(0.16, 0.13, 0.118), [0, 0.04, 0.008]));
  const keel = S.capsule([0, 0.1, 0.135], [0, 0.33, 0.142], 0.008);
  const SH = [0.068, 0.2];   // escudo do brasão (x, y)
  const inShield = (x, y, k = 0) => { const u = x - SH[0], w = y - SH[1]; return w < 0.068 - k && w > -0.092 + k && Math.abs(u) < (0.064 - k) * Math.min(1, (w + 0.092) / 0.07 + 0.15); };
  add({ name: 'couraça', bone: BONE.CHEST, f: S.smooth(0.02, chest, keel), min: [-0.23, -0.1, -0.16], max: [0.23, 0.42, 0.17], mat: MAT.STEEL, spacing: 0.024, flow: [0, 1, 0],
    decals: [{ p: [SH[0], SH[1] - 0.008, 0.142], n: [0.25, 0.03, 0.97], glyph: '獅', mat: MAT.GOLD, size: 0.125, clear: 0.058 }]
      .concat([...'最後の誓'].map((ch, i) => { const x = -0.075 + i * 0.05, z = 0.008 + 0.118 * Math.sqrt(Math.max(0, 1 - 0.38 - (x / 0.16) ** 2)); return { p: [x, 0.118, z + 0.004], n: [x * 3, 0.5, 1], glyph: ch, mat: MAT.SILVER, size: 0.034, clear: 0.02 }; })),
    detail: (p, n, c) => {
      if (p[2] > 0.08 && inShield(p[0], p[1]) && !inShield(p[0], p[1], 0.012)) return { mat: MAT.GOLD, glyph: '·', size: 0.9 };
      if (p[2] > 0.08 && inShield(p[0], p[1])) return { mat: MAT.DARK };
      if (Math.abs(p[0]) < 0.011 && p[2] > 0.1 && p[1] > 0.1) return { mat: MAT.BRONZE, glyph: '│' };
      if (p[1] < 0.12 && grooves([0.0, 0.045, 0.09])(p)) return { mat: MAT.DARK };
      return steelDetail(34, 0.03)(p, n, c);
    } });
  add({ name: 'dorsal', bone: BONE.CHEST, f: S.intersect(S.xf(S.ellipsoid(0.19, 0.22, 0.13), [0, 0.2, -0.004]), (x, y, z) => z + 0.02), min: [-0.21, -0.03, -0.15], max: [0.21, 0.43, 0.0], mat: MAT.STEEL, spacing: 0.026, flow: [0, 1, 0],
    detail: (p, n, c) => Math.abs(p[0]) < 0.01 ? { mat: MAT.BRONZE, glyph: '│' } : grooves([0.05, 0.1])(p) ? { mat: MAT.DARK } : steelDetail(30, 0.025)(p, n, c) });
  add({ name: 'gorjal', bone: BONE.CHEST, f: S.union(S.xf(S.cylinder(0.068, 0.035, 0.012), [0, 0.395, 0]), S.xf(S.cylinder(0.096, 0.012, 0.01), [0, 0.365, 0]), S.xf(S.cylinder(0.11, 0.01, 0.008), [0, 0.345, 0])),
    min: [-0.13, 0.32, -0.13], max: [0.13, 0.44, 0.13], mat: MAT.STEEL, spacing: 0.017, flow: [1, 0, 0], detail: (p, n, c) => c > 0.3 ? { mat: MAT.BRONZE } : null });
  const lame = i => S.intersect(S.intersect(S.shell(S.xf(S.sphere(0.122 - i * 0.006), [0.185 + i * 0.014, 0.305 - i * 0.046, -0.004]), 0.009), S.above(0.28 - i * 0.046)), (x) => 0.1 - x);
  const haute = S.intersect(S.intersect(S.xf(S.box(0.006, 0.05, 0.085, 0.004), [0.13, 0.385, -0.004], [0, 0, -0.25]), S.xf(S.sphere(0.13), [0.16, 0.33, 0])), S.above(0.36));
  const pauldron = S.union(lame(0), lame(1), lame(2), lame(3), haute);
  add({ name: 'ombreiras', bone: BONE.CHEST, f: S.mirrorX(pauldron), min: [-0.34, 0.1, -0.15], max: [0.34, 0.45, 0.15], mat: MAT.STEEL, spacing: 0.019, flow: [0, 0, 1],
    detail: (p, n, c) => Math.abs(Math.abs(p[0]) - 0.125) < 0.012 && p[1] > 0.37 ? { mat: MAT.BRONZE } : steelDetail(30, 0.032)(p, n, c),
    decals: [-1, 1].flatMap(s => [[0.24, 0.395, 0.07, 0.4, 0.6, 0.6], [0.29, 0.31, 0.08, 0.6, 0.3, 0.7], [0.3, 0.25, 0.085, 0.7, 0.1, 0.7], [0.3, 0.205, 0.075, 0.8, 0, 0.6]]
      .map(([x, y, z, a, b, c]) => ({ p: [s * x, y, z], n: [s * a, b, c], glyph: '•', mat: MAT.SILVER, size: 0.022 }))) });
  // manto: rolo de tecido amassado em volta da nuca, caindo sobre o ombro direito
  const bunch = (f, amp, sc) => (x, y, z) => f(x, y, z) + (noise3(x * sc, y * sc + 4, z * sc) - 0.5) * amp;
  const roll = S.intersect(S.xf(S.torus(0.155, 0.045), [0, 0.39, -0.02], [0.28, 0, 0]), (x, y, z) => z - 0.03 - 0.25 * Math.max(0, -x));
  const drape = S.xf(S.ellipsoid(0.12, 0.045, 0.12), [-0.19, 0.415, -0.02], [0, 0, 0.35]);
  add({ name: 'manto', bone: BONE.CHEST, f: bunch(S.smooth(0.05, roll, drape), 0.03, 28), min: [-0.36, 0.3, -0.24], max: [0.24, 0.52, 0.16], mat: MAT.CLOTH, spacing: 0.02, flow: [1, 0, 0],
    detail: (p, n, c) => c > 0.25 ? { mat: MAT.CLOTH_IN } : null });

  // ── Elmo fechado (close helm) como na imagem: calota com crista baixa e friso, sobrancelha saliente,
  //    fenda dos olhos, viseira em proa com quilha e facetas, respiros em fendas no lado direito,
  //    bevor em lâminas, rosetas nos pinos da viseira ──
  const skull = S.xf(S.ellipsoid(0.108, 0.135, 0.124), [0, 0.175, -0.008]);
  const comb = S.intersect(S.intersect(S.box(0.0065, 0.3, 0.3), S.xf(S.ellipsoid(0.116, 0.147, 0.134), [0, 0.175, -0.008])), S.above(0.215));
  const brow = S.intersect(S.intersect(S.shell(S.xf(S.ellipsoid(0.118, 0.142, 0.136), [0, 0.172, 0]), 0.0075), slab(0.166, 0.19)), (x, y, z) => 0.02 - z);
  const prow = (zTip, k) => (x, y, z) => z - (zTip - k * Math.abs(x));      // duas facetas que se encontram numa quilha
  const visor = S.intersect(S.intersect(S.xf(S.ellipsoid(0.106, 0.1, 0.17), [0, 0.112, 0.01]), prow(0.16, 0.62)), slab(0.075, 0.152));
  const bevor = S.intersect(S.intersect(S.xf(S.ellipsoid(0.104, 0.075, 0.15), [0, 0.06, 0.008]), prow(0.15, 0.7)), slab(0.0, 0.085));
  const cheeks = S.xf(S.ellipsoid(0.104, 0.09, 0.11), [0, 0.1, 0.0]);
  const slitH = S.xf(S.box(0.09, 0.0065, 0.08), [0, 0.159, 0.09]);
  const helm = S.union(S.subtract(S.smooth(0.03, skull, cheeks), slitH), comb, brow, S.subtract(S.union(visor, bevor), slitH));
  add({ name: 'elmo', bone: BONE.HEAD, f: helm, min: [-0.13, -0.02, -0.15], max: [0.13, 0.33, 0.18], mat: MAT.STEEL, spacing: 0.0135, flow: [0, 1, 0],
    detail: (p, n, c) => {
      if (Math.abs(p[1] - 0.159) < 0.011 && p[2] > 0.05) return { mat: MAT.DARK };
      const xr = -p[0];
      if (xr > 0.025 && xr < 0.085 && p[1] > 0.06 && p[1] < 0.13 && p[2] > 0.03 && ((xr * 95) % 1) < 0.38) return { glyph: '|', mat: MAT.DARK, size: 0.9 };
      if (Math.abs(p[0]) < 0.0075 && (p[1] > 0.2 || p[2] > 0.09)) return { mat: MAT.BRONZE };
      if (p[1] < 0.085 && grooves([0.03, 0.058], 0.004)(p) && p[2] > 0.0) return { mat: MAT.DARK };
      if (Math.abs(p[1] - 0.152) < 0.005 && p[2] > 0.04) return { mat: MAT.BRONZE };
      return steelDetail(52, 0.026)(p, n, c);
    },
    decals: [-1, 1].map(s => ({ p: [s * 0.109, 0.148, 0.0], n: [s, 0, 0], glyph: '✶', mat: MAT.SILVER, size: 0.03 }))
      .concat([-0.8, -0.5, 0.5, 0.8].map(a => ({ p: [Math.sin(a) * 0.12, 0.18, Math.cos(a) * 0.137], n: [Math.sin(a), 0.1, Math.cos(a)], glyph: '•', mat: MAT.SILVER, size: 0.018 }))) });

  // ── Braços (por lado): malha na axila, braçal em lâminas sobre bíceps, cotovelo com aleta e malha
  //    na dobra, antebraço afinando até o pulso, manopla de punho largo e dedos articulados ──
  for (const [ua, fa, hd, side] of [[BONE.UA_L, BONE.FA_L, BONE.HAND_L, 1], [BONE.UA_R, BONE.FA_R, BONE.HAND_R, -1]]) {
    add({ name: 'malha da axila', bone: ua, f: S.roundCone([0, 0.03, 0], [0, -0.09, 0], 0.06, 0.054), min: [-0.08, -0.12, -0.08], max: [0.08, 0.1, 0.08], mat: MAT.MAIL, spacing: 0.02, flow: [1, 0, 0], size: 0.8 });
    const upper = S.smooth(0.03, S.roundCone([0, -0.05, 0], [0, -0.275, 0], 0.056, 0.046), S.xf(S.ellipsoid(0.044, 0.08, 0.047), [0, -0.14, 0.018]));
    add({ name: 'braçal', bone: ua, f: S.intersect(upper, S.below(-0.035)), min: [-0.08, -0.33, -0.08], max: [0.08, 0.0, 0.08], mat: MAT.STEEL, spacing: 0.02, flow: [0, 1, 0],
      detail: (p, n, c) => grooves([-0.09, -0.14, -0.19, -0.24])(p) ? { mat: MAT.DARK } : Math.abs(p[1] + 0.215) < 0.008 ? { mat: MAT.LEATHER } : steelDetail(44, 0.028)(p, n, c) });
    add({ name: 'malha do cotovelo', bone: fa, f: S.xf(S.sphere(0.047), [0, -0.01, 0.012]), min: [-0.07, -0.07, -0.04], max: [0.07, 0.05, 0.07], mat: MAT.MAIL, spacing: 0.016, flow: [1, 0, 0], size: 0.8, keep: (p) => p[2] > 0.02 });
    const couter = S.smooth(0.01, S.xf(S.sphere(0.054), [0, 0, -0.012]), S.xf(S.ellipsoid(0.016, 0.09, 0.075), [side * 0.05, 0.0, -0.016]));
    add({ name: 'cotoveleira', bone: fa, f: S.intersect(couter, (x, y, z) => z - 0.025), min: [-0.09, -0.1, -0.1], max: [0.09, 0.1, 0.04], mat: MAT.STEEL, spacing: 0.014, flow: [0, 1, 0], detail: steelDetail(50, 0.03),
      decals: [{ p: [side * 0.068, 0, -0.016], n: [side, 0, 0], glyph: '◆', mat: MAT.SILVER, size: 0.024 }] });
    const fore = S.smooth(0.02, S.roundCone([0, -0.05, 0], [0, -0.225, 0], 0.05, 0.038), S.xf(S.ellipsoid(0.044, 0.06, 0.042), [0, -0.085, -0.008]),
      S.capsule([0, -0.06, 0.044], [0, -0.21, 0.034], 0.006));
    add({ name: 'antebraço', bone: fa, f: fore, min: [-0.07, -0.26, -0.07], max: [0.07, 0.0, 0.07], mat: MAT.STEEL, spacing: 0.018, flow: [0, 1, 0],
      detail: (p, n, c) => p[1] < -0.205 ? { mat: MAT.BRONZE } : Math.abs(p[0]) < 0.007 && p[2] > 0.03 ? { mat: MAT.SILVER, glyph: '│' } : steelDetail(48, 0.03)(p, n, c) });
    // manopla: punho largo em sino, placa do dorso, palma de couro; dedos em 3 falanges + polegar
    const grip = side < 0;                                   // mão direita fecha no punho da espada
    const cuff = S.intersect(S.shell(S.roundCone([0, 0.035, 0], [0, -0.05, 0], 0.068, 0.046), 0.006), S.above(0.04));
    const back = S.xf(S.ellipsoid(0.046, 0.05, 0.026), [0, -0.075, 0.006]);
    const fingers = [], fp = [];
    for (let i = 0; i < 4; i++) {
      const x = -0.03 + i * 0.02, l = i === 3 || i === 0 ? 0.85 : 1;
      const k = grip ? [[x, -0.1, 0.02], [x, -0.118, 0.05 * l], [x, -0.14, 0.042 * l], [x, -0.146, 0.016]]
                     : [[x, -0.1, 0.018], [x, -0.128 * (0.97 + 0.03 * l), 0.03], [x, -0.152 * (0.95 + 0.05 * l), 0.032], [x, -0.168 * (0.94 + 0.06 * l), 0.024]];
      for (let j = 0; j < 3; j++) { fingers.push(S.capsule(k[j], k[j + 1], 0.0115 - j * 0.0015)); fp.push(k[j + 1]); }
    }
    const tx = -side * 0.042;
    const thumb = grip ? S.union(S.capsule([tx, -0.055, 0.02], [tx * 0.8, -0.095, 0.05], 0.012), S.capsule([tx * 0.8, -0.095, 0.05], [tx * 0.3, -0.11, 0.06], 0.011))
                       : S.union(S.capsule([tx, -0.055, 0.02], [tx * 1.05, -0.095, 0.038], 0.012), S.capsule([tx * 1.05, -0.095, 0.038], [tx * 0.9, -0.125, 0.045], 0.011));
    add({ name: 'manopla', bone: hd, f: S.union(cuff, S.smooth(0.01, back, S.xf(S.box(0.04, 0.03, 0.02, 0.012), [0, -0.075, -0.004]))), min: [-0.09, -0.12, -0.08], max: [0.09, 0.06, 0.08], mat: MAT.STEEL, spacing: 0.012, flow: [1, 0, 0],
      detail: (p, n, c) => c > 0.35 ? { mat: MAT.BRONZE } : n[2] < -0.4 && p[1] < -0.03 ? { mat: MAT.LEATHER } : p[1] > -0.02 && vein(p, 60, 0.04) ? { mat: MAT.BRONZE, size: 0.8 } : null });
    add({ name: 'dedos', bone: hd, f: S.union(...fingers, thumb), min: [-0.06, -0.19, -0.02], max: [0.06, -0.04, 0.08], mat: MAT.STEEL, spacing: 0.0085, flow: [0, 1, 0], size: 1.15,
      detail: (p, n) => fp.some(q => (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2 + (p[2] - q[2]) ** 2 < 0.007 ** 2) ? { mat: MAT.DARK } : (n[2] < -0.3 ? { mat: MAT.LEATHER } : null) });
  }

  // ── Pernas (por lado): coxote frontal com correias, malha atrás e na dobra do joelho,
  //    joelheira com aleta, greva com panturrilha e quilha, tornozelo fino, sabatons em lâminas ──
  for (const [th, sh, ft, side] of [[BONE.TH_L, BONE.SH_L, BONE.FT_L, 1], [BONE.TH_R, BONE.SH_R, BONE.FT_R, -1]]) {
    const thigh = S.smooth(0.03, S.roundCone([0, -0.05, 0.004], [0, -0.4, 0.008], 0.082, 0.058), S.xf(S.ellipsoid(0.06, 0.14, 0.05), [0, -0.18, 0.03]));
    add({ name: 'coxote', bone: th, f: thigh, min: [-0.11, -0.44, -0.11], max: [0.11, 0.04, 0.11], mat: MAT.STEEL, spacing: 0.021, flow: [0, 1, 0],
      keep: (p) => p[2] > -0.035 || p[1] < -0.34, detail: (p, n, c) => grooves([-0.07, -0.35])(p) ? { mat: MAT.DARK } : steelDetail(40, 0.028)(p, n, c) });
    add({ name: 'correias', bone: th, f: S.union(S.xf(S.torus(0.079, 0.008), [0, -0.14, -0.006]), S.xf(S.torus(0.07, 0.008), [0, -0.29, -0.004])), min: [-0.1, -0.32, -0.1], max: [0.1, -0.11, 0.1], mat: MAT.LEATHER, spacing: 0.012, flow: [1, 0, 0],
      keep: (p) => p[2] < 0.0, decals: [{ p: [side * 0.075, -0.14, -0.03], n: [side, 0, -0.4], glyph: '¤', mat: MAT.SILVER, size: 0.022 }] });
    add({ name: 'calça de malha', bone: th, f: S.roundCone([0, -0.02, -0.01], [0, -0.4, -0.01], 0.073, 0.055), min: [-0.1, -0.44, -0.1], max: [0.1, 0.06, 0.06], mat: MAT.MAIL, spacing: 0.023, flow: [1, 0, 0], size: 0.8,
      keep: (p) => p[2] < -0.02 });
    add({ name: 'malha do joelho', bone: sh, f: S.xf(S.sphere(0.055), [0, 0.0, -0.012]), min: [-0.07, -0.06, -0.08], max: [0.07, 0.06, 0.02], mat: MAT.MAIL, spacing: 0.017, flow: [1, 0, 0], size: 0.8, keep: (p) => p[2] < -0.01 });
    const poleyn = S.smooth(0.012, S.xf(S.sphere(0.06), [0, 0, 0.026]), S.xf(S.ellipsoid(0.014, 0.078, 0.066), [side * 0.062, 0.0, 0.0]), S.xf(S.ellipsoid(0.05, 0.03, 0.04), [0, 0.06, 0.03]), S.xf(S.ellipsoid(0.048, 0.03, 0.04), [0, -0.06, 0.03]));
    add({ name: 'joelheira', bone: sh, f: S.intersect(poleyn, (x, y, z) => -0.01 - z), min: [-0.09, -0.1, -0.02], max: [0.09, 0.1, 0.1], mat: MAT.STEEL, spacing: 0.014, flow: [0, 1, 0],
      detail: (p, n, c) => grooves([0.04, -0.04], 0.005)(p) && p[2] > 0.05 ? { mat: MAT.DARK } : steelDetail(56, 0.03)(p, n, c),
      decals: [{ p: [0, 0.0, 0.087], n: [0, 0, 1], glyph: '◆', mat: MAT.SILVER, size: 0.03 }] });
    const greave = S.smooth(0.03, S.roundCone([0, -0.06, 0.004], [0, -0.39, 0.004], 0.053, 0.039), S.xf(S.ellipsoid(0.05, 0.11, 0.052), [0, -0.15, -0.016]),
      S.capsule([0, -0.09, 0.054], [0, -0.35, 0.04], 0.007));
    add({ name: 'greva', bone: sh, f: greave, min: [-0.08, -0.45, -0.08], max: [0.08, 0.0, 0.08], mat: MAT.STEEL, spacing: 0.019, flow: [0, 1, 0],
      detail: (p, n, c) => Math.abs(p[0]) < 0.008 && p[2] > 0.035 ? { mat: MAT.SILVER, glyph: '│' } : Math.abs(p[0] * side - 0.045) < 0.006 && p[2] < 0.02 ? { mat: MAT.DARK } : steelDetail(42, 0.026)(p, n, c) });
    add({ name: 'correia da greva', bone: sh, f: S.xf(S.torus(0.052, 0.007), [0, -0.27, -0.008]), min: [-0.07, -0.29, -0.07], max: [0.07, -0.25, 0.07], mat: MAT.LEATHER, spacing: 0.011, flow: [1, 0, 0], keep: (p) => p[2] < -0.01 });
    const sab = S.union(...[0, 1, 2, 3, 4].map(i => S.xf(S.ellipsoid(0.05 - i * 0.004, 0.04 - i * 0.002, 0.045), [0, -0.035, 0.03 + i * 0.03])),
      S.xf(S.ellipsoid(0.03, 0.028, 0.06), [0, -0.045, 0.185]), S.xf(S.ellipsoid(0.05, 0.045, 0.05), [0, -0.03, -0.02]), S.xf(S.ellipsoid(0.045, 0.05, 0.045), [0, 0.02, 0.0]));
    add({ name: 'sabatons', bone: ft, f: S.intersect(sab, S.above(-0.075)), min: [-0.08, -0.08, -0.08], max: [0.08, 0.08, 0.25], mat: MAT.STEEL, spacing: 0.016, flow: [1, 0, 0],
      detail: (p, n, c) => n[1] < -0.5 ? { mat: MAT.LEATHER } : steelDetail(50, 0.03)(p, n, c) });
  }

  // ── Espada longa: pomo em roda, punho de couro, guarda de braços curvos com remates, lâmina com sulco ──
  const blade = (x, y, z) => {
    const t = (y - 0.12) / 1.0;
    const w = 0.029 * (1 - t * 0.35) * (t > 0.88 ? Math.max(0, (1 - t) / 0.12) : 1);
    const th = 0.006 * (1 - Math.abs(x) / 0.034);
    return Math.max(Math.abs(x) - w, Math.abs(z) - th, 0.12 - y, y - 1.12);
  };
  add({ name: 'lâmina', bone: BONE.SWORD, f: blade, min: [-0.04, 0.1, -0.02], max: [0.04, 1.14, 0.02], mat: MAT.BLADE, spacing: 0.012, flow: [0, 1, 0], size: 0.9,
    detail: (p) => Math.abs(p[0]) < 0.0055 && p[1] < 0.86 ? { mat: MAT.IRON, glyph: '│' } : (Math.abs(p[0]) > 0.02 && noise3(p[1] * 60, p[0] * 60, 3) > 0.72 ? { mat: MAT.IRON } : null) });
  const quillon = S.union(S.capsule([0, 0.1, 0], [0.1, 0.106, 0], 0.011), S.capsule([0.1, 0.106, 0], [0.145, 0.15, 0], 0.009), S.xf(S.ellipsoid(0.017, 0.024, 0.014), [0.151, 0.16, 0], [0, 0, -0.6]));
  const guard = S.smooth(0.01, S.mirrorX(quillon), S.xf(S.box(0.028, 0.017, 0.02, 0.006), [0, 0.1, 0]), S.xf(S.ellipsoid(0.018, 0.045, 0.012), [0, 0.14, 0]));
  add({ name: 'guarda', bone: BONE.SWORD, f: guard, min: [-0.18, 0.07, -0.03], max: [0.18, 0.2, 0.03], mat: MAT.BRONZE, spacing: 0.0105, flow: [1, 0, 0] });
  add({ name: 'punho', bone: BONE.SWORD, f: S.capsule([0, -0.17, 0], [0, 0.08, 0], 0.017), min: [-0.03, -0.2, -0.03], max: [0.03, 0.1, 0.03], mat: MAT.LEATHER, spacing: 0.0105, flow: [1, 0.5, 0] });
  const pommel = S.smooth(0.006, S.xf(S.cylinder(0.034, 0.012, 0.006), [0, -0.205, 0], [Math.PI / 2, 0, 0]), S.xf(S.sphere(0.012), [0, -0.245, 0]));
  add({ name: 'pomo', bone: BONE.SWORD, f: pommel, min: [-0.045, -0.26, -0.03], max: [0.045, -0.16, 0.03], mat: MAT.BRONZE, spacing: 0.0105, flow: [0, 1, 0],
    decals: [{ p: [0, -0.205, 0.0135], n: [0, 0, 1], glyph: '✦', mat: MAT.GOLD, size: 0.022 }] });
  const byBone = new Map();
  for (const p of P) { if (!byBone.has(p.bone)) byBone.set(p.bone, []); byBone.get(p.bone).push(p.f); }
  for (const p of P) p.aoF = S.union(...byBone.get(p.bone));
  return P;
}


// ─────────────── Pose: cinemática inversa e marcha ───────────────
const frame = (origin, yAxis, fwd) => {
  const y = v3.norm(yAxis);
  let x = v3.norm(v3.cross(y, fwd));
  if (!isFinite(x[0])) x = [1, 0, 0];
  const z = v3.cross(x, y);
  const m = m4.ident();
  m[0] = x[0]; m[1] = x[1]; m[2] = x[2]; m[4] = y[0]; m[5] = y[1]; m[6] = y[2]; m[8] = z[0]; m[9] = z[1]; m[10] = z[2];
  m[12] = origin[0]; m[13] = origin[1]; m[14] = origin[2];
  return m;
};

function ik(a, target, l1, l2, pole) {
  let d = v3.sub(target, a);
  let dist = v3.len(d);
  const max = (l1 + l2) * 0.999;
  if (dist > max) { d = v3.mul(d, max / dist); dist = max; }
  const dir = v3.mul(d, 1 / dist);
  const x = (l1 * l1 - l2 * l2 + dist * dist) / (2 * dist);
  const h = Math.sqrt(Math.max(0, l1 * l1 - x * x));
  let pv = v3.sub(pole, v3.mul(dir, v3.dot(pole, dir)));
  pv = v3.norm(pv);
  const knee = v3.add(v3.add(a, v3.mul(dir, x)), v3.mul(pv, h));
  return { knee, end: v3.add(a, d) };
}

const smooth01 = (t) => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };
/** Interpola chaves [t, valor] com suavização (valores: número ou vetor). */
function keys(list, t) {
  for (let i = 0; i < list.length - 1; i++) {
    const [t0, a] = list[i], [t1, b] = list[i + 1];
    if (t <= t1) { const k = smooth01((t - t0) / (t1 - t0)); return Array.isArray(a) ? a.map((v, j) => v + (b[j] - v) * k) : a + (b - a) * k; }
  }
  return list[list.length - 1][1];
}
// ── Combo de 3 golpes (chaves no espaço do peito: posição da mão direita e direção da lâmina) ──
//  1: diagonal de cima-direita para baixo-esquerda · 2: horizontal de revés · 3: vertical pesado com as duas mãos
export const COMBO = [
  { dur: 0.62, step: 0.22, hit: [0.36, 0.52],
    hand: [[0.26, [-0.24, 0.46, -0.04]], [0.38, [-0.12, 0.34, 0.3]], [0.52, [0.12, 0.02, 0.4]], [0.66, [0.26, -0.12, 0.26]]],
    dir: [[0.26, [-0.25, 0.55, -0.8]], [0.38, [0.1, 0.65, 0.75]], [0.52, [0.55, -0.35, 0.76]], [0.66, [0.72, -0.62, 0.3]]],
    twist: [[0, 0], [0.26, 0.55], [0.42, 0.05], [0.6, -0.45], [0.8, -0.2], [1, 0]], lean: [[0, 0], [0.26, -0.06], [0.48, 0.18], [0.7, 0.12], [1, 0]] },
  { dur: 0.6, step: 0.2, hit: [0.34, 0.5],
    hand: [[0.24, [0.28, 0.16, 0.05]], [0.36, [0.18, 0.2, 0.36]], [0.5, [-0.22, 0.2, 0.36]], [0.66, [-0.36, 0.1, 0.12]]],
    dir: [[0.24, [0.85, 0.1, -0.5]], [0.36, [0.55, 0.12, 0.83]], [0.5, [-0.6, 0.1, 0.8]], [0.66, [-0.9, -0.1, -0.3]]],
    twist: [[0, -0.2], [0.24, -0.6], [0.43, 0.0], [0.62, 0.55], [0.85, 0.2], [1, 0]], lean: [[0, 0.04], [0.3, 0.02], [0.5, 0.14], [1, 0]] },
  { dur: 0.95, step: 0.42, hit: [0.48, 0.6], twoHands: true,
    hand: [[0.36, [-0.06, 0.62, -0.02]], [0.48, [-0.03, 0.42, 0.34]], [0.6, [0.0, -0.02, 0.48]], [0.78, [0.02, -0.1, 0.42]]],
    dir: [[0.36, [-0.05, 0.4, -0.92]], [0.48, [0.0, 0.9, 0.44]], [0.6, [0.02, -0.5, 0.86]], [0.78, [0.04, -0.75, 0.66]]],
    twist: [[0, 0], [0.36, 0.25], [0.55, -0.1], [1, 0]], lean: [[0, 0], [0.36, -0.12], [0.58, 0.32], [0.8, 0.26], [1, 0]] },
];

/**
 * st = { phase, blend (parado→andando), run, breath, time, atk (0..1 ou −1), combo (0..2),
 *        accel (aceleração para a frente, m/s²), turn (velocidade de giro, rad/s), look (ângulo até a direção desejada) }
 * Retorna matrizes dos ossos no espaço do modelo.
 */
export function poseKnight(st) {
  const b = st.blend * st.blend * (3 - 2 * st.blend), run = st.run || 0, T = st.time || 0;
  const ph = st.phase * Math.PI * 2;
  const idle = 1 - b;
  const br = Math.sin(st.breath * Math.PI * 2);
  const at = st.atk >= 0 ? st.atk : -1, A = at >= 0 ? 1 : 0;
  const C = COMBO[st.combo || 0];
  const atkW = A ? smooth01(Math.min(at / 0.12, (1 - at) / 0.22)) : 0;
  // inércia: inclina para a frente ao arrancar, para trás ao frear; inclina para dentro nas curvas
  const accLean = Math.max(-0.16, Math.min(0.2, (st.accel || 0) * 0.035));
  const bank = Math.max(-0.14, Math.min(0.14, -(st.turn || 0) * (0.02 + 0.04 * run) * b));
  const lookAhead = Math.max(-0.7, Math.min(0.7, st.look || 0));     // tronco e cabeça viram antes do quadril
  const w = idle * (0.65 * Math.sin(T * 0.85) + 0.35 * Math.sin(T * 0.31 + 1.7)) * (1 - atkW);
  const bones = new Array(17);
  bones[0] = m4.ident();
  // marcha: desce no contato, sobe na passagem; corrida com fase de voo
  const bob = -(0.024 + 0.03 * run) * Math.cos(ph * 2) * b - (0.014 + 0.02 * run) * b;
  const sway = 0.024 * Math.sin(ph) * b * (1 - run * 0.6) + 0.028 * w;
  const lean = 0.05 * b + 0.17 * run * b + accLean + (A ? keys(C.lean, at) : 0) * atkW;
  const twist = (A ? keys(C.twist, at) : 0) * atkW;
  const stepF = (A ? keys([[0, 0], [C.hit[0] - 0.08, -0.02], [C.hit[1], 0.1], [0.85, 0.06], [1, 0]], at) : 0) * atkW;
  const crouch = (A ? keys([[0, 0], [C.hit[0] - 0.1, 0.03], [C.hit[1], C.twoHands ? 0.1 : 0.06], [0.85, 0.02], [1, 0]], at) : 0) * atkW;
  const pelvis = m4.mul(m4.mul(m4.translate(sway, 0.975 + bob - 0.012 * Math.abs(w) - crouch + br * 0.003 * idle, stepF),
    m4.rotY(0.13 * Math.sin(ph) * b * (1 - run * 0.3) + twist * 0.35 + lookAhead * 0.2)), m4.rotZ(-0.045 * w + 0.035 * Math.sin(ph) * b + bank));
  bones[1] = pelvis;
  const chest = m4.mul(m4.mul(m4.mul(m4.mul(pelvis, m4.translate(0, 0.13, 0)), m4.rotY(-0.22 * Math.sin(ph - 0.35) * b * (1 + run * 0.4) + twist * 0.65 + lookAhead * 0.35)),
    m4.rotZ(0.06 * w - 0.025 * Math.sin(ph) * b - bank * 0.4)), m4.mul(m4.rotX(lean + br * 0.02), m4.translate(0, br * 0.006, 0)));
  bones[2] = chest;
  const look = idle * 0.22 * Math.sin(T * 0.23) * Math.sin(T * 0.11 + 2) * (1 - atkW);
  bones[3] = m4.mul(chest, m4.mul(m4.mul(m4.translate(0, 0.4, 0.005), m4.rotY(look - twist * 0.5 + lookAhead * 0.45)), m4.rotX(-lean * 0.6 + br * 0.012 - 0.04 * idle * Math.sin(T * 0.17))));
  // pernas: calcanhar toca primeiro, o pé rola, a ponta empurra
  const half = (0.3 + 0.2 * run) * b, lift = (0.1 + 0.14 * run) * b;
  for (const [side, th, ph0] of [[1, 10, 0], [-1, 13, 0.5]]) {
    const p = (st.phase + ph0) % 1;
    const swing = p < 0.5, q = swing ? p / 0.5 : (p - 0.5) / 0.5;
    let z = swing ? -Math.cos(q * Math.PI) * half : Math.cos(q * Math.PI) * half;
    const ly = swing ? Math.sin(q * Math.PI) * lift * (q < 0.5 ? 1.15 : 0.85) : 0;
    const relaxed = Math.max(0, -w * side);
    z += relaxed * 0.07 + (side < 0 ? stepF * 1.6 : -stepF * 0.4);
    const hip = m4.point(pelvis, [side * 0.096, -0.04, 0]);
    const ankle = [side * (0.115 + relaxed * 0.02) - sway * 0.3, 0.085 + ly + relaxed * 0.012, z + 0.01 + stepF * 0.5];
    const { knee, end } = ik(hip, ankle, L.thigh, L.shin, [side * 0.12, 0, 1]);
    bones[th] = frame(hip, v3.sub(hip, knee), [0, 0, 1]);
    bones[th + 1] = frame(knee, v3.sub(knee, end), [0, 0, 1]);
    let roll = 0;
    if (b > 0.01) roll = swing ? (q < 0.6 ? 0.35 * Math.sin(q / 0.6 * Math.PI) : -0.22 * Math.sin((q - 0.6) / 0.4 * Math.PI)) : (q < 0.15 ? -0.22 * (1 - q / 0.15) : q > 0.6 ? 0.4 * (q - 0.6) / 0.4 : 0);
    const toe = -roll * b - relaxed * 0.12;
    bones[th + 2] = m4.mul(m4.mul(m4.translate(end[0], end[1], end[2]), m4.rotY(side * 0.08 * idle)), m4.rotX(toe));
  }
  const shL = m4.point(chest, [0.19, 0.325 + br * 0.006, -0.01]), shR = m4.point(chest, [-0.19, 0.325 + br * 0.006, -0.01]);
  // espada: parado = baixa na mão direita; andando = baixa e para trás; correndo = mais junto ao corpo
  const restDir = v3.norm([0.3, -0.79, 0.53]);
  const restGrip = m4.point(pelvis, [-0.235, -0.07 + br * 0.004, 0.13]);
  const walkDir = v3.norm([-0.12 - 0.1 * run, -0.42 + 0.12 * run, -0.9 + run * 0.15]);
  const swingR = 0.06 * Math.sin(ph - 0.5) * b * (1 + run);
  const walkHand = m4.point(pelvis, [-0.27 + 0.04 * run, -0.12 + 0.1 * run, 0.06 + swingR]);
  let sDir = v3.norm(v3.lerp(restDir, walkDir, b));
  let rHand = v3.lerp(restGrip, walkHand, b);
  const lIdle = m4.point(pelvis, [0.27, -0.1, 0.04 + br * 0.006]);
  // braço livre balança contra a perna (atrasado = inércia); correndo, dobra e bombeia
  const sw = Math.sin(ph + Math.PI - 0.5);
  const lWalk = m4.point(pelvis, [0.25 - 0.03 * run, -0.12 + 0.16 * run + 0.05 * run * Math.max(0, sw), 0.14 * sw * (1 + run * 1.2) - 0.02 + 0.06 * run]);
  let lHand = v3.lerp(lIdle, lWalk, b);
  const off = st.offhand || 'none';
  if (off === 'torch') {                       // tocha erguida à frente, um pouco para fora
    const tI = m4.point(pelvis, [0.25, 0.14 + br * 0.004, 0.2]), tW = m4.point(pelvis, [0.26, 0.15 + 0.04 * run, 0.22 + 0.05 * sw * (1 + run)]);
    lHand = v3.lerp(tI, tW, b);
  } else if (off === 'shield') {
    const sI = m4.point(pelvis, [0.27, 0.0, 0.13]), sW = m4.point(pelvis, [0.27, 0.02, 0.14 + 0.05 * sw]);
    lHand = v3.lerp(sI, sW, b);
  }
  const blk = st.block || 0, heal = st.heal >= 0 ? st.heal : -1, swp = st.swap >= 0 ? st.swap : -1;
  if (blk > 0) lHand = v3.lerp(lHand, m4.point(chest, [0.1, 0.12, 0.34]), smooth01(blk));
  if (heal >= 0) lHand = v3.lerp(lHand, m4.point(chest, [0.03, 0.47, 0.2]), smooth01(Math.min(heal / 0.3, (1 - heal) / 0.25)));
  if (swp >= 0) lHand = v3.lerp(lHand, m4.point(pelvis, [0.2, -0.1, -0.14]), smooth01(Math.min(swp / 0.4, (1 - swp) / 0.4)));
  if (A) {
    const toW = (v) => m4.point(chest, v), dirW = (v) => m4.dir(chest, v3.norm(v));
    const h0 = C.hand[0], hN = C.hand[C.hand.length - 1], d0 = C.dir[0], dN = C.dir[C.dir.length - 1];
    let hp, dp;
    if (at < h0[0]) { const k = smooth01(at / h0[0]); hp = v3.lerp(rHand, toW(h0[1]), k); dp = v3.lerp(sDir, dirW(d0[1]), k); }
    else if (at > hN[0]) { const k = smooth01((at - hN[0]) / (1 - hN[0])); hp = v3.lerp(toW(hN[1]), rHand, k); dp = v3.lerp(dirW(dN[1]), sDir, k); }
    else { hp = toW(keys(C.hand, at)); dp = dirW(keys(C.dir, at)); }
    rHand = hp; sDir = v3.norm(dp);
    if (C.twoHands) lHand = v3.lerp(lHand, v3.add(rHand, v3.mul(sDir, -0.09)), smooth01(Math.min((at - 0.1) / 0.2, (0.9 - at) / 0.15)));
    else lHand = v3.lerp(lHand, m4.point(chest, keys([[0, [0.27, -0.25, 0.05]], [0.3, [0.3, -0.05, 0.22]], [0.55, [0.3, -0.18, -0.15]], [1, [0.27, -0.25, 0.05]]], at)), atkW);
  }
  const arm = (sh, hand, ua, side) => {
    const { knee: el, end } = ik(sh, hand, L.upper, L.fore + 0.04, [side * 0.4, -0.25, -1]);
    bones[ua] = frame(sh, v3.sub(sh, el), [0, 0, 1]);
    bones[ua + 1] = frame(el, v3.sub(el, end), [0, 0, 1]);
    bones[ua + 2] = frame(end, v3.sub(el, end), [0, 0, 1]);
  };
  arm(shL, lHand, 4, 1);
  arm(shR, rHand, 7, -1);
  const fist = m4.point(bones[9], [0, -0.115, 0.03]);
  bones[16] = frame(v3.add(fist, v3.mul(sDir, 0.03)), sDir, Math.abs(sDir[0]) > 0.9 ? [0, 0, 1] : [1, 0, 0]);
  // objetos da mão esquerda (matrizes no espaço do modelo)
  const lf = m4.point(bones[6], [0, -0.115, 0.03]);
  const fwdC = m4.dir(chest, [0, 0, 1]), sideC = m4.dir(chest, [1, 0, 0]);
  bones.torch = frame(lf, v3.norm(v3.add([0, 1, 0], v3.mul(fwdC, 0.25))), fwdC);
  const face = v3.norm(v3.lerp(v3.add(v3.mul(sideC, 0.85), v3.mul(fwdC, 0.5)), fwdC, smooth01(blk)));
  bones.shield = frame(v3.add(m4.point(bones[5], [0, -0.16, 0]), v3.mul(face, 0.05)), [0, 1, 0], face);
  return applyBody(bones, st);
}

/** Rolamento, golpe recebido e queda: transformações do corpo inteiro por cima da pose. */
function applyBody(bones, st) {
  const extra = ['torch', 'shield'];
  const all = (M) => { for (let i = 1; i < 17; i++) bones[i] = m4.mul(M, bones[i]); for (const k of extra) bones[k] = m4.mul(M, bones[k]); };
  if (st.roll >= 0) {
    // cambalhota: o corpo se encolhe e gira em volta do centro de massa
    const t = st.roll, k = smooth01(Math.min(t / 0.18, (1 - t) / 0.2));
    const ang = 2 * Math.PI * smooth01((t - 0.08) / 0.75);
    const c = [0, 0.72, 0.25 * t];
    const tuck = m4.mul(m4.translate(0, -0.08 * k, 0), m4.mul(m4.translate(c[0], c[1], c[2]), m4.mul(m4.rotX(ang), m4.translate(-c[0], -c[1], -c[2]))));
    // encolhe pernas e braços em direção ao quadril antes de girar
    const pel = bones[1];
    const pc = [pel[12], pel[13], pel[14]];
    for (let i = 2; i < 17; i++) { const m = bones[i]; const p = [m[12], m[13], m[14]]; const d = v3.sub(p, pc); const q = v3.add(pc, v3.mul(d, 1 - (i < 4 ? 0.3 : 0.42) * k)); m[12] = q[0]; m[13] = q[1] + 0.12 * k; m[14] = q[2]; }
    all(tuck);
  }
  if (st.hurt > 0) { const h = st.hurt; all(m4.mul(m4.translate(0, 0, -0.08 * h), m4.mul(m4.translate(0, 0.9, 0), m4.mul(m4.rotX(-0.32 * h), m4.translate(0, -0.9, 0))))); }
  if (st.dead > 0) {
    const d = st.dead, kneel = smooth01(d / 0.35), fall = smooth01((d - 0.3) / 0.55);
    all(m4.mul(m4.translate(0, -0.42 * kneel, 0.1 * kneel), m4.mul(m4.translate(0, 0.1, 0.25), m4.mul(m4.rotX(1.45 * fall), m4.translate(0, -0.1, -0.25)))));
  }
  return bones;
}

/** Ajuda: posição da ponta da lâmina e de um ponto no meio (no espaço das matrizes dadas). */
export function swordSegment(bones) { return [m4.point(bones[16], [0, 0.25, 0]), m4.point(bones[16], [0, 1.12, 0])]; }

/** Cavaleiro caído: sentado contra a muralha, cabeça tombada, braços largados, espada ao lado. */
export function poseFallen() {
  const bones = new Array(17);
  bones[0] = m4.ident();
  const pelvis = m4.mul(m4.translate(0, 0.22, 0.05), m4.rotX(-0.35));
  bones[1] = pelvis;
  const chest = m4.mul(m4.mul(pelvis, m4.translate(0, 0.13, 0)), m4.mul(m4.rotX(-0.25), m4.rotZ(0.12)));
  bones[2] = chest;
  bones[3] = m4.mul(chest, m4.mul(m4.translate(0, 0.4, 0.005), m4.mul(m4.rotX(0.75), m4.rotZ(0.35))));
  for (const [side, th, kneeUp] of [[1, 10, 0.32], [-1, 13, 0.05]]) {
    const hip = m4.point(pelvis, [side * 0.1, -0.04, 0]);
    const ankle = [side * (0.2 + (1 - kneeUp) * 0.05), 0.07, 0.6 + (0.3 - kneeUp) * 0.6];
    const { knee, end } = ik(hip, ankle, L.thigh, L.shin, [side * 0.3, 1, 0.3]);
    bones[th] = frame(hip, v3.sub(hip, knee), [0, 0, 1]);
    bones[th + 1] = frame(knee, v3.sub(knee, end), [0, 1, 0]);
    bones[th + 2] = m4.mul(m4.translate(end[0], end[1], end[2]), m4.mul(m4.rotX(-0.9), m4.rotZ(side * 0.5)));
  }
  const shL = m4.point(chest, [0.19, 0.325, -0.01]), shR = m4.point(chest, [-0.19, 0.325, -0.01]);
  const hands = [[shL, [0.42, 0.08, 0.2], 4, 1], [shR, [-0.36, 0.06, 0.32], 7, -1]];
  for (const [sh, hand, ua, side] of hands) {
    const { knee: el, end } = ik(sh, hand, L.upper, L.fore + 0.04, [side * 0.6, 0.2, -0.6]);
    bones[ua] = frame(sh, v3.sub(sh, el), [0, 0, 1]);
    bones[ua + 1] = frame(el, v3.sub(el, end), [0, 0, 1]);
    bones[ua + 2] = frame(end, v3.sub(el, end), [0, 1, 0]);
  }
  bones[16] = frame([-0.62, 0.035, 0.15], v3.norm([-0.25, 0.0, 1]), [0, 1, 0]);
  return bones;
}

// ─────────────── Tecidos simulados (Verlet): capa e tabardo ───────────────
const hashU = (s => () => { s = s * 16807 % 2147483647; return s / 2147483647; });

/**
 * Tecido preso a um osso. opts:
 *  cols, rows, w, h — grade física; anchor(u) → ponto local no osso para a borda de cima
 *  out: -1 cai atrás do corpo (capa), +1 cai na frente (tabardo); plane: distância do plano
 *  hem(u) → v onde o tecido termina (bainha rasgada); hole(u,v) → true para furos/rasgos
 *  spacing, size, seed, flip (vira a face externa), drag
 */
export class Cloth {
  constructor(atlas, o) {
    Object.assign(this, { drag: 1, size: 0.055, spacing: 0.03, out: -1, plane: 0.13, flip: false, wet: 0, emblem: null, mats: [MAT.CLOTH, MAT.CLOTH_IN] }, o);
    const { cols, rows } = this;
    this.p = []; this.o = []; this.nrm = [];
    for (let k = 0; k < cols * rows; k++) { this.p.push([0, 1, 0]); this.o.push([0, 1, 0]); this.nrm.push([0, 0, -1]); }
    const R = hashU(Math.abs(Math.round(this.seed || 91)) + 1);
    const pts = [], cell = new Map(), md = this.spacing;
    const key = (x, y) => ((x / md) | 0) + ',' + ((y / md) | 0);
    this.samples = [];
    const fray = atlas.get(','), fray2 = atlas.get('\''), fold = atlas.get('§');
    const tries = Math.round(this.w * this.h / (md * md) * 3.2);
    for (let t = 0; t < tries; t++) {
      const u = R(), v = R();
      const hem = this.hem(u);
      if (v > hem || (this.hole && this.hole(u, v, hem))) continue;
      const x = u * this.w, y = v * this.h, cx = (x / md) | 0, cy = (y / md) | 0;
      let ok = true;
      for (let i = -1; i <= 1 && ok; i++) for (let j = -1; j <= 1 && ok; j++) for (const q of cell.get((cx + i) + ',' + (cy + j)) || []) if ((q[0] - x) ** 2 + (q[1] - y) ** 2 < md * md) { ok = false; break; }
      if (!ok) continue;
      const kk = key(x, y); if (!cell.has(kk)) cell.set(kk, []); cell.get(kk).push([x, y]);
      // célula da grade e pesos bilineares pré-calculados
      const fx = u * (cols - 1), fy = v * (rows - 1);
      const i0 = Math.min(cols - 2, Math.floor(fx)), j0 = Math.min(rows - 2, Math.floor(fy));
      const r = R();
      const edge = hem - v < 0.035;
      const g = edge ? (r < 0.5 ? fray : fray2) : (Math.sin(u * Math.PI * 9 + v * 2.5) > 0.88 ? fold : -1);
      this.samples.push({ k: j0 * cols + i0, tx: fx - i0, ty: fy - j0, g, r, sz: edge ? 0.8 : 1 });
    }
    this.ps = new PointSet(this.samples.length * 2 + 8);
    this.t = 0;
  }
  update(dt, boneW, spheres, wind) {
    const { cols, rows, p, o } = this;
    this.t += dt;
    dt = Math.min(dt, 1 / 30);
    for (let i = 0; i < cols; i++) { const w = m4.point(boneW, this.anchor(i / (cols - 1))); p[i] = w; o[i] = w.slice(); }
    if (!this.inited) {             // nasce pendurado, já no lugar
      this.inited = true;
      for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) {
        const a = this.anchor(i / (cols - 1)), v = j / (rows - 1);
        const w = m4.point(boneW, [a[0], a[1] - v * this.h, a[2] + this.out * 0.05 * v]);
        p[j * cols + i] = w; o[j * cols + i] = w.slice();
      }
    }
    const fwd = v3.norm([boneW[8], 0, boneW[10]]), c0 = [boneW[12], 0, boneW[14]];
    const g = -9.8 * dt * dt * (1 + 0.6 * this.wet), dd = dt * dt * this.drag * (1 - 0.45 * this.wet);   // encharcado: mais pesado
    for (let k = cols; k < p.length; k++) {
      const a = p[k], b = o[k];
      const f = Math.floor(k / cols) / (rows - 1);
      const gust = 1 + 0.6 * Math.sin(this.t * 2.1 + k * 0.7) + 0.3 * Math.sin(this.t * 5.3 + k * 1.3);
      o[k] = a;
      p[k] = [a[0] + (a[0] - b[0]) * 0.985 + wind[0] * dd * (0.4 + f) * gust, a[1] + (a[1] - b[1]) * 0.985 + g, a[2] + (a[2] - b[2]) * 0.985 + wind[2] * dd * (0.4 + f) * gust];
    }
    const rest = this.w / (cols - 1), restV = this.h / (rows - 1), pl = this.plane * this.out;
    for (let it = 0; it < 6; it++) {
      for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) {
        const k = j * cols + i;
        if (i < cols - 1) this._link(k, k + 1, rest);
        if (j < rows - 1) this._link(k, k + cols, restV);
      }
      for (let k = cols; k < p.length; k++) {
        let q = p[k];
        for (const s of spheres) {
          const dx = q[0] - s.c[0], dy = q[1] - s.c[1], dz = q[2] - s.c[2], l = Math.hypot(dx, dy, dz);
          if (l < s.r && l > 1e-6) { const m = s.r / l; q = [s.c[0] + dx * m, s.c[1] + dy * m, s.c[2] + dz * m]; }
        }
        if (q[1] < 0.03) q[1] = 0.03;
        // não atravessa o corpo: fica do seu lado do plano do osso
        const d = (q[0] - c0[0]) * fwd[0] + (q[2] - c0[2]) * fwd[2];
        if (this.out < 0 ? d > pl : d < pl) { const m = d - pl; q = [q[0] - fwd[0] * m, q[1], q[2] - fwd[2] * m]; }
        p[k] = q;
      }
    }
    this._emit();
  }
  _link(a, b, rest) {
    const P = this.p, pa = P[a], pb = P[b];
    const dx = pb[0] - pa[0], dy = pb[1] - pa[1], dz = pb[2] - pa[2], l = Math.hypot(dx, dy, dz) || 1e-6, diff = (l - rest) / l;
    if (a < this.cols && b < this.cols) return;
    if (a < this.cols) { P[b] = [pb[0] - dx * diff, pb[1] - dy * diff, pb[2] - dz * diff]; return; }
    const h = diff * 0.5;
    P[a] = [pa[0] + dx * h, pa[1] + dy * h, pa[2] + dz * h]; P[b] = [pb[0] - dx * h, pb[1] - dy * h, pb[2] - dz * h];
  }
  _emit() {
    const { cols, rows, p, nrm } = this, ps = this.ps;
    // normais por nó (uma vez por quadro) → amostras só interpolam
    for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) {
      const L = p[j * cols + Math.max(0, i - 1)], Rr = p[j * cols + Math.min(cols - 1, i + 1)];
      const U = p[Math.max(0, j - 1) * cols + i], D = p[Math.min(rows - 1, j + 1) * cols + i];
      const n = v3.norm(v3.cross([Rr[0] - L[0], Rr[1] - L[1], Rr[2] - L[2]], [D[0] - U[0], D[1] - U[1], D[2] - U[2]]));
      nrm[j * cols + i] = this.flip ? [-n[0], -n[1], -n[2]] : n;
    }
    ps.n = 0;
    const lerp4 = (A, B, C, D, tx, ty) => {
      const a = 1 - tx, b = 1 - ty;
      return [(A[0] * a + B[0] * tx) * b + (C[0] * a + D[0] * tx) * ty, (A[1] * a + B[1] * tx) * b + (C[1] * a + D[1] * tx) * ty, (A[2] * a + B[2] * tx) * b + (C[2] * a + D[2] * tx) * ty];
    };
    for (const s of this.samples) {
      const k = s.k, k2 = k + cols;
      const P = lerp4(p[k], p[k + 1], p[k2], p[k2 + 1], s.tx, s.ty);
      const n = v3.norm(lerp4(nrm[k], nrm[k + 1], nrm[k2], nrm[k2 + 1], s.tx, s.ty));
      const t = v3.norm(v3.sub(p[k2], p[k]));
      ps.push(P, n, t, this.mats[0], s.g, 0, 0, this.size * s.sz, s.r * 1000);
      ps.push(P, [-n[0], -n[1], -n[2]], t, this.mats[1], -1, 0, 0, this.size * 0.9 * s.sz, s.r * 1000 + 1);
    }
    if (this.emblem) {            // brasão bordado (estandartes)
      const e = this.emblem, fx = e.u * (cols - 1), fy = e.v * (rows - 1), i = Math.floor(fx), j = Math.floor(fy), k = j * cols + i;
      const P = lerp4(p[k], p[k + 1], p[k + cols], p[k + cols + 1], fx - i, fy - j);
      const n = v3.norm(lerp4(nrm[k], nrm[k + 1], nrm[k + cols], nrm[k + cols + 1], fx - i, fy - j));
      ps.push(v3.add(P, v3.mul(n, 0.01)), n, v3.norm(v3.sub(p[k + cols], p[k])), e.mat, e.glyph, 0, 4, e.size, 7);
    }
    return ps;
  }
}

/** Capa vinho longa e larga, presa sobre as ombreiras, bainha em tiras rasgadas e furos. */
export function makeCape(atlas) {
  const tear = (u) => 0.9 - 0.11 * Math.abs(Math.sin(u * 17 + 1)) ** 3 - 0.09 * (Math.sin(u * 43 + 2) > 0.5 ? 1 : 0) - 0.05 * noise3(u * 30, 1, 2);
  return new Cloth(atlas, {
    cols: 11, rows: 16, w: 0.66, h: 1.46, out: -1, plane: 0.12, spacing: 0.031, size: 0.056, seed: 91,
    anchor: (u) => { const x = (u - 0.5) * 0.58, e = Math.abs(u - 0.5) * 2; return [x, 0.35 + 0.05 * e * e, -0.15 + 0.1 * e * e]; },
    hem: tear,
    hole: (u, v, hem) => (v > hem - 0.2 && Math.abs(Math.sin(u * 29 + 0.5)) < 0.1) || (v > 0.45 && noise3(u * 11, v * 9, 5) > 0.8),
  });
}
/** Tabardo vinho na frente, preso ao cinto, em duas abas esfarrapadas que os joelhos empurram. */
export function makeTabard(atlas) {
  return new Cloth(atlas, {
    cols: 5, rows: 8, w: 0.24, h: 0.6, out: 1, plane: 0.14, spacing: 0.024, size: 0.05, seed: 37, flip: true, drag: 0.6,
    anchor: (u) => [(u - 0.5) * 0.24, 0.1, 0.16 + 0.02 * (1 - Math.abs(u - 0.5) * 2)],
    hem: (u) => 0.93 - 0.14 * Math.abs(Math.sin(u * 13)) ** 2 - 0.08 * (Math.sin(u * 37) > 0.6 ? 1 : 0),
    hole: (u, v) => v > 0.45 && Math.abs(u - 0.5) < 0.035,
  });
}

/** Estandarte vinho pendurado no portão, com o 誓 bordado em ouro. */
export function makeBanner(atlas, x, top, z) {
  return new Cloth(atlas, {
    cols: 5, rows: 9, w: 0.62, h: 1.9, out: 1, plane: z, spacing: 0.035, size: 0.06, seed: 11 + Math.round((x + 10) * 10), drag: 0.8,
    anchor: (u) => [x + (u - 0.5) * 0.62, top, z],
    hem: (u) => 0.94 - 0.12 * Math.abs(Math.sin(u * 9)) ** 2,
    hole: (u, v) => v > 0.75 && Math.abs(u - 0.5) < 0.05,
    emblem: { u: 0.5, v: 0.32, glyph: atlas.get('誓'), mat: MAT.GOLD, size: 0.3 },
  });
}

/** Manto real esfarrapado do chefe (roxo apagado). */
export function makeRoyalMantle(atlas) {
  const tear = (u) => 0.86 - 0.16 * Math.abs(Math.sin(u * 13 + 2)) ** 2 - 0.1 * (Math.sin(u * 37) > 0.4 ? 1 : 0);
  return new Cloth(atlas, {
    cols: 10, rows: 14, w: 0.8, h: 1.55, out: -1, plane: 0.1, spacing: 0.036, size: 0.065, seed: 501, mats: [MAT.ROYAL, MAT.ROYAL],
    anchor: (u) => { const x = (u - 0.5) * 0.62, e = Math.abs(u - 0.5) * 2; return [x, 0.42 + 0.03 * e, -0.1 + 0.08 * e * e]; },
    hem: tear,
    hole: (u, v, hem) => (v > hem - 0.25 && Math.abs(Math.sin(u * 23)) < 0.14) || (v > 0.35 && noise3(u * 9, v * 9, 7) > 0.74),
  });
}
