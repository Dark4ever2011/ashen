// ASHEN — Som sintetizado em tempo real (Web Audio). Nenhum arquivo de áudio:
// cada efeito é montado com ruído filtrado, osciladores e envelopes — combina com o mundo feito de símbolos.
// Ambiente contínuo: vento, chuva, fogo (pela distância) e o rumor do terremoto.

export class Audio {
  constructor() {
    this.ctx = null; this.on = true; this.vol = 0.8;
    this.loops = {};
  }
  /** Precisa de um toque do jogador para começar (regra dos navegadores). */
  unlock() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    const c = this.ctx = new AC();
    this.master = c.createGain(); this.master.gain.value = this.on ? this.vol : 0;
    const comp = c.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4;
    this.master.connect(comp); comp.connect(c.destination);
    // eco de pedra (reverberação curta de pátio)
    this.verb = c.createConvolver(); this.verb.buffer = this._impulse(2.2, 2.6);
    this.verbGain = c.createGain(); this.verbGain.gain.value = 0.28;
    this.verb.connect(this.verbGain); this.verbGain.connect(this.master);
    this.sfx = c.createGain(); this.sfx.connect(this.master); this.sfx.connect(this.verb);
    this.amb = c.createGain(); this.amb.connect(this.master);
    this.noise = this._noise(2);
    this.brown = this._noise(4, true);
    this._startLoops();
  }
  setVolume(on, vol) {
    this.on = on; if (vol != null) this.vol = vol;
    if (this.master) this.master.gain.setTargetAtTime(this.on ? this.vol : 0, this.ctx.currentTime, 0.05);
  }
  _noise(sec, brown = false) {
    const c = this.ctx, b = c.createBuffer(1, c.sampleRate * sec, c.sampleRate), d = b.getChannelData(0);
    let last = 0;
    for (let i = 0; i < d.length; i++) { const w = Math.random() * 2 - 1; if (brown) { last = (last + 0.02 * w) / 1.02; d[i] = last * 3.5; } else d[i] = w; }
    return b;
  }
  _impulse(sec, decay) {
    const c = this.ctx, n = c.sampleRate * sec, b = c.createBuffer(2, n, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = b.getChannelData(ch); for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, decay); }
    return b;
  }
  // ── blocos ──
  _src(buf, loop = false) { const s = this.ctx.createBufferSource(); s.buffer = buf; s.loop = loop; return s; }
  _env(node, t, a, peak, d, out) {
    const g = this.ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(peak, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + a + d);
    node.connect(g); g.connect(out || this.sfx); return g;
  }
  _filt(type, f, q = 1) { const b = this.ctx.createBiquadFilter(); b.type = type; b.frequency.value = f; b.Q.value = q; return b; }
  /** Ruído filtrado com envelope (e varredura opcional de frequência). */
  burst({ type = 'bandpass', f = 1000, f2 = null, q = 1, a = 0.005, d = 0.2, gain = 0.5, delay = 0, rate = 1, brown = false, out }) {
    if (!this.ctx || !this.on) return;
    const t = this.ctx.currentTime + delay;
    const s = this._src(brown ? this.brown : this.noise); s.playbackRate.value = rate;
    const fl = this._filt(type, f, q);
    if (f2) fl.frequency.exponentialRampToValueAtTime(f2, t + a + d);
    s.connect(fl); this._env(fl, t, a, gain, d, out);
    s.start(t, Math.random() * 1.5); s.stop(t + a + d + 0.05);
  }
  /** Tom com envelope (seno, serra…), com deslize opcional. */
  tone({ wave = 'sine', f = 440, f2 = null, a = 0.005, d = 0.3, gain = 0.3, delay = 0, out, filter }) {
    if (!this.ctx || !this.on) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator(); o.type = wave; o.frequency.setValueAtTime(f, t);
    if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + a + d);
    let n = o;
    if (filter) { const fl = this._filt(filter.type || 'lowpass', filter.f, filter.q || 1); o.connect(fl); n = fl; }
    this._env(n, t, a, gain, d, out);
    o.start(t); o.stop(t + a + d + 0.05);
  }
  // ── efeitos do jogo ──
  play(name, k = 1) {
    if (!this.ctx || !this.on) return;
    const r = () => 0.9 + Math.random() * 0.2;
    switch (name) {
      case 'step':      // bota de ferro na terra + tilintar da armadura
        this.burst({ type: 'lowpass', f: 380 * r(), d: 0.09, gain: 0.32 * k, brown: true });
        if (Math.random() < 0.6) this.tone({ wave: 'triangle', f: 1800 * r(), d: 0.06, gain: 0.03 * k, delay: 0.02 });
        break;
      case 'swing':     // a lâmina cortando o ar
        this.burst({ type: 'bandpass', f: 600, f2: 2600 * r(), q: 2.5, a: 0.04, d: 0.18, gain: 0.35 * k });
        break;
      case 'heavy':     // golpe pesado
        this.burst({ type: 'bandpass', f: 300, f2: 1400, q: 1.6, a: 0.08, d: 0.28, gain: 0.45 });
        break;
      case 'hit':       // lâmina na carne morta
        this.burst({ type: 'lowpass', f: 900, d: 0.16, gain: 0.6, brown: true });
        this.burst({ type: 'bandpass', f: 2400 * r(), q: 3, d: 0.07, gain: 0.25 });
        this.tone({ f: 110, f2: 50, d: 0.18, gain: 0.35 });
        break;
      case 'crit':
        this.play('hit'); this.tone({ wave: 'triangle', f: 1320, d: 0.5, gain: 0.12, delay: 0.02 });
        break;
      case 'wood':      // tábua rachando
        for (let i = 0; i < 3; i++) this.burst({ type: 'bandpass', f: 1200 * r() + i * 300, q: 4, d: 0.05, gain: 0.35, delay: i * 0.025 });
        this.burst({ type: 'lowpass', f: 500, d: 0.15, gain: 0.3, brown: true });
        break;
      case 'break':     // caixote em pedaços
        for (let i = 0; i < 7; i++) this.burst({ type: 'bandpass', f: 800 + Math.random() * 2000, q: 3, d: 0.06 + Math.random() * 0.08, gain: 0.3, delay: i * 0.035 });
        this.burst({ type: 'lowpass', f: 300, d: 0.35, gain: 0.5, brown: true });
        break;
      case 'block':     // aço contra escudo
        for (const f of [523, 1307, 2213, 3301]) this.tone({ wave: 'triangle', f: f * r(), d: 0.35, gain: 0.08 });
        this.burst({ type: 'highpass', f: 3000, d: 0.06, gain: 0.25 });
        break;
      case 'parry':     // aparada: anel claro e longo
        for (const f of [880, 1760, 2637, 3520]) this.tone({ wave: 'sine', f, d: 1.1, gain: 0.09 });
        this.burst({ type: 'highpass', f: 4000, d: 0.08, gain: 0.3 });
        break;
      case 'roll':
        this.burst({ type: 'bandpass', f: 400, f2: 900, q: 1, a: 0.05, d: 0.3, gain: 0.25 });
        this.burst({ type: 'lowpass', f: 300, d: 0.12, gain: 0.35, delay: 0.4, brown: true });
        break;
      case 'hurt':      // impacto no cavaleiro
        this.burst({ type: 'lowpass', f: 600, d: 0.22, gain: 0.7, brown: true });
        this.tone({ wave: 'sawtooth', f: 180, f2: 90, d: 0.25, gain: 0.08, filter: { f: 700 } });
        for (const f of [740, 1680]) this.tone({ wave: 'triangle', f, d: 0.25, gain: 0.05 });
        break;
      case 'heal':      // gole e brilho quente
        this.burst({ type: 'bandpass', f: 500, q: 6, d: 0.12, gain: 0.25 }); this.burst({ type: 'bandpass', f: 420, q: 6, d: 0.12, gain: 0.25, delay: 0.18 });
        [523, 659, 784, 1047].forEach((f, i) => this.tone({ f, d: 0.6, gain: 0.07, delay: 0.35 + i * 0.07 }));
        break;
      case 'pickup':
        [659, 880, 1319].forEach((f, i) => this.tone({ wave: 'triangle', f, d: 0.5, gain: 0.1, delay: i * 0.09 }));
        break;
      case 'swap':
        this.burst({ type: 'bandpass', f: 900, q: 2, d: 0.1, gain: 0.2 }); this.tone({ wave: 'triangle', f: 1400, d: 0.12, gain: 0.05, delay: 0.25 });
        break;
      case 'ignite':    // chama acendendo
        this.burst({ type: 'lowpass', f: 200, f2: 2500, a: 0.15, d: 0.8, gain: 0.55, brown: true });
        this.burst({ type: 'highpass', f: 2000, d: 0.6, gain: 0.12, delay: 0.1 });
        break;
      case 'roar':      // o rei grita: serra grave com formantes + ruído rouco
        for (const [f, g] of [[70, 0.25], [104, 0.18], [141, 0.12]]) this.tone({ wave: 'sawtooth', f: f * k, f2: f * 0.7 * k, a: 0.25, d: 1.7, gain: g, filter: { type: 'bandpass', f: 520, q: 1.4 } });
        this.burst({ type: 'bandpass', f: 700, f2: 300, q: 0.8, a: 0.2, d: 1.6, gain: 0.45 });
        break;
      case 'claw':
        this.burst({ type: 'bandpass', f: 1500, f2: 500, q: 2, a: 0.03, d: 0.22, gain: 0.35 });
        break;
      case 'slam':      // garras no chão: estrondo
        this.tone({ f: 60, f2: 28, d: 0.9, gain: 0.7 });
        this.burst({ type: 'lowpass', f: 400, d: 1.0, gain: 0.8, brown: true });
        for (let i = 0; i < 6; i++) this.burst({ type: 'bandpass', f: 600 + Math.random() * 1500, q: 3, d: 0.1, gain: 0.15, delay: 0.05 + i * 0.06 });
        break;
      case 'quake':     // tremor: rumor longo
        this.burst({ type: 'lowpass', f: 140, a: 0.6, d: 3.5 * k, gain: 0.9, brown: true });
        this.tone({ f: 38, a: 0.5, d: 3.2 * k, gain: 0.35 });
        for (let i = 0; i < 10; i++) this.burst({ type: 'bandpass', f: 400 + Math.random() * 900, q: 2, d: 0.2, gain: 0.12, delay: 0.3 + Math.random() * 3 * k });
        break;
      case 'thunder':
        this.burst({ type: 'highpass', f: 1500, d: 0.12, gain: 0.5 });
        this.burst({ type: 'lowpass', f: 220, a: 0.1, d: 3.2, gain: 0.9 * k, brown: true, delay: 0.25 + Math.random() * 0.6 });
        break;
      case 'bell':      // sino de morte
        for (const [f, g] of [[196, 0.2], [392, 0.12], [587, 0.08], [933, 0.05]]) this.tone({ f, d: 3.5, gain: g });
        break;
      case 'victory':   // acorde que se abre
        [[196, 0], [247, 0.15], [294, 0.3], [392, 0.45], [494, 0.6]].forEach(([f, t]) => this.tone({ wave: 'triangle', f, a: 0.3, d: 3.5, gain: 0.08, delay: t }));
        break;
      case 'ui':
        this.tone({ wave: 'triangle', f: 880, d: 0.06, gain: 0.05 });
        break;
    }
  }
  // ── ambiente contínuo ──
  _startLoops() {
    const c = this.ctx;
    const loop = (filterType, f, q, gain, brown) => {
      const s = this._src(brown ? this.brown : this.noise, true), fl = this._filt(filterType, f, q), g = c.createGain();
      g.gain.value = 0; s.connect(fl); fl.connect(g); g.connect(this.amb); s.start();
      return { s, fl, g, target: gain };
    };
    this.loops.wind = loop('bandpass', 380, 0.7, 0.18, false);
    this.loops.rain = loop('highpass', 1800, 0.5, 0.0, false);
    this.loops.rainLow = loop('lowpass', 600, 0.5, 0.0, true);
    this.loops.fire = loop('bandpass', 900, 0.6, 0.0, true);
    this.loops.rumble = loop('lowpass', 90, 1, 0.0, true);
  }
  /** Chamado a cada quadro: vento, chuva, fogo e tremor. */
  ambient(st) {
    if (!this.ctx || !this.on) return;
    const t = this.ctx.currentTime, L = this.loops;
    const set = (l, v, f) => { l.g.gain.setTargetAtTime(v, t, 0.25); if (f) l.fl.frequency.setTargetAtTime(f, t, 0.3); };
    set(L.wind, 0.05 + 0.12 * st.wind, 250 + 300 * st.wind);
    set(L.rain, 0.22 * st.rain);
    set(L.rainLow, 0.25 * st.rain);
    set(L.fire, 0.35 * st.fire);
    set(L.rumble, 0.8 * st.quake);
    // estalos do fogo
    if (st.fire > 0.05 && Math.random() < st.fire * 0.25) this.burst({ type: 'highpass', f: 2500 + Math.random() * 3000, d: 0.02, gain: 0.12 * st.fire, out: this.amb });
  }
}

/** Narração: voz do aparelho (Android: ponte nativa; navegador: speechSynthesis), em português. */
export class Narrator {
  constructor() { this.on = true; this.voice = null; this._pick(); if ('speechSynthesis' in window) speechSynthesis.onvoiceschanged = () => this._pick(); }
  _pick() {
    if (!('speechSynthesis' in window)) return;
    const vs = speechSynthesis.getVoices();
    this.voice = vs.find(v => /pt[-_]BR/i.test(v.lang) && /male|masculin|Google/i.test(v.name)) || vs.find(v => /pt[-_]BR/i.test(v.lang)) || vs.find(v => /^pt/i.test(v.lang)) || null;
  }
  speak(text) {
    if (!this.on || !text) return;
    const clean = text.replace(/[誓王灰]/g, '').replace(/—/g, ',').replace(/…/g, '...');
    if (window.AndroidTTS) { try { window.AndroidTTS.speak(clean); } catch (e) { /* ok */ } return; }
    if (!('speechSynthesis' in window)) return;
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(clean);
    u.lang = 'pt-BR'; u.rate = 0.92; u.pitch = 0.75; u.volume = 1;
    if (this.voice) u.voice = this.voice;
    speechSynthesis.speak(u);
  }
  stop() {
    if (window.AndroidTTS) { try { window.AndroidTTS.stop(); } catch (e) { /* ok */ } }
    if ('speechSynthesis' in window) speechSynthesis.cancel();
  }
}
