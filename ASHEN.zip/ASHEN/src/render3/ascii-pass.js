// ASHEN — Composição ASCII (direção visual "ASCII artístico de alta densidade", Fase 1).
//
// Fundo preto puro. Os OBJETOS (personagens, construções, pedras, árvores) são desenhados antes num alvo de
// baixa resolução (2×2 amostras por célula): cor iluminada + código do material no alfa + profundidade.
// Aqui cada célula de uma grade fina vira UM caractere nítido sobre preto: a densidade do traço sai da luz,
// a família de caracteres sai do material (metal @#MW%&+:., pedra @#B8Q o=-, madeira, folhagem, pano…).
// O chão não é desenhado: onde só há piso, aparece no máximo um "." ou ":" apagado, e só onde a luz de
// tocha, fogueira ou lustre bate. A composição também grava a profundidade dos objetos, para a grama
// (traços desenhados depois, direto na tela) passar na frente/atrás deles certinho.

import * as THREE from 'three';
import { MATERIALS, MAT } from '../game/glyphs.js';
import { charWidth } from '../engine/typography.js';

// 9 níveis (sombra → luz) × 4 variantes: o mesmo objeto mistura letras, números e símbolos do mesmo "peso"
// (nada de 888III888 chapado). Na sombra os traços ficam ralos e menores até sumirem no preto.
const FAM = {
  metal: [".'`.", ":,-:", ";~+:", "+=*i", "icz+", "x%zv", "%&XK", "&WMN", "@#MW"],
  cloth: [".,'.", ",:;,", ";~:-", "~+=;", "csx+", "xs%o", "%&xa", "&%#S", "@&#%"],
  stone: [".`,.", ":-.:", "-~=:", "=o+c", "oecz", "aQ0O", "Q08D", "8B0Q", "@B8#"],
  brick: [".,'.", ":-,:", "-=:~", "=m+n", "mnoe", "omBw", "8Bmd", "B8#m", "@#B8"],
  wood: [".''.", ":',:", "!:;i", "!li|", "lI!t", "IlLj", "I8H#", "8#HI", "@#8H"],
  leaf: [".,'.", ",'\";", "\"v,'", "vr*;", "vwe*", "w%sv", "%&wW", "&%W@", "@&W%"],
  flesh: [".,'.", ":-,:", "-=:~", "=oc+", "oecs", "eO0a", "O0Q8", "0&8Q", "@&0Q"],
  water: [".-,.", "-~.-", "~-=~", "=~≈-", "≈=~≈", "≈#=≈", "#≈=#", "#@≈#", "@#≈@"],
  fire: ["··.·", "·•·.", "•*·•", "*+•*", "✶*+✶", "✦✶*✦", "火✦✶火", "炎火✦炎", "火炎火炎"],
  coat: [".`'.", ":,;:", "-~:=", "=+~<", "rcvz", "snxu", "dbpq", "%&WM", "@#$N"],
  mane: [".`',", ":;'`", "~;:'", "/\\|(", "){|}", "ʃ|/\\", "lI|!", "ǀ‖|l", "‖|ǀl"],
};
// personagens, criaturas e cavalo: rampa própria, mais rica (caracteres pequenos esculpindo armadura, crina, pano)
const FAMA = {
  metal: [".'`,", ":;-~", "+=<>", "ivcr", "zxsn", "%&kX", "dbpq", "WMNH", "@#$8"],
  cloth: [".,'`", ":;,~", "~-=:", "+=;r", "csxz", "oaxs", "%&#e", "&%#S", "@&$%"],
  stone: [".`,.", ":-.:", "-~=:", "=o+c", "oecz", "aQ0O", "Q08D", "8B0Q", "@B8#"],
  brick: [".,'.", ":-,:", "-=:~", "=m+n", "mnoe", "omBw", "8Bmd", "B8#m", "@#B8"],
  wood: [".''.", ":',:", "!:;i", "!li|", "lI!t", "IlLj", "I8H#", "8#HI", "@#8H"],
  leaf: [".,'.", ",'\";", "\"v,'", "vr*;", "vwe*", "w%sv", "%&wW", "&%W@", "@&W%"],
  flesh: [".,'`", ":-,;", "-=:~", "=oc+", "oecs", "eaO0", "O0Qd", "0&8Q", "@&0Q"],
  water: [".-,.", "-~.-", "~-=~", "=~≈-", "≈=~≈", "≈#=≈", "#≈=#", "#@≈#", "@#≈@"],
  fire: ["··.·", "·•·.", "•*·•", "*+•*", "✶*+✶", "✦✶*✦", "火✦✶火", "炎火✦炎", "火炎火炎"],
  coat: [".`',", ":;,~", "~-=:", "+=<~", "rcvz", "snxw", "mwdb", "MW%&", "@#$N"],
  mane: [".`',", ":;'`", "~;:'", "/\\|(", "){|}", "ʃ|/\\", "lI|!", "ǀ‖|l", "‖|ǀl"],
};
const FAMILY = {};
for (const [f, ids] of Object.entries({
  metal: [MAT.STEEL, MAT.SILVER, MAT.GOLD, MAT.BLADE, MAT.IRON, MAT.MAIL, MAT.BRONZE, MAT.CHITIN],
  cloth: [MAT.CLOTH, MAT.CLOTH_IN, MAT.ROYAL, MAT.LINEN, MAT.WOOL, MAT.LEATHER, MAT.BLOOD],
  stone: [MAT.STONE, MAT.MARBLE, MAT.GRAVEL, MAT.BONE, MAT.DARK, MAT.SNOW, MAT.SAND, MAT.GROUND],
  brick: [MAT.PLASTER],
  wood: [MAT.WOOD, MAT.THATCH],
  leaf: [MAT.LEAF, MAT.LEAF_G, MAT.LEAF_R, MAT.LEAF_Y, MAT.MOSS, MAT.GRASS, MAT.GRASS2, MAT.GRASS3, MAT.FLOWER, MAT.FLOWER_R, MAT.FLOWER_Y, MAT.FLOWER_W, MAT.FLOWER_B, MAT.PETAL_P],
  flesh: [MAT.FLESH, MAT.SKIN, MAT.GOBLIN, MAT.HAIR],
  coat: [MAT.COAT],
  mane: [MAT.MANE],
  water: [MAT.WATER, MAT.RIVER],
  fire: [MAT.EMBER, MAT.SPIRIT, MAT.BLUE],
})) for (const id of ids) if (id != null) FAMILY[id] = f;

/** Linha = código (material+1), 9 colunas do escuro ao claro → índice no atlas. */
function rampTex(atlas) {
  const data = new Uint8Array(36 * 256 * 4);
  for (let code = 1; code < 256; code++) {
    const m = (code - 1) & 127, key = FAMILY[m] || (m < MATERIALS.length ? 'stone' : 'metal'), fam = code > 128 ? FAMA[key] : FAM[key];   // linhas 129+: rampa dos personagens
    for (let x = 0; x < 9; x++) {
      const vs = Array.from(fam[x]);
      for (let v = 0; v < 4; v++) {
        const ch = vs[v % vs.length], g = atlas.get(ch), o = (code * 36 + x * 4 + v) * 4;
        data[o] = g & 255; data[o + 1] = g >> 8; data[o + 2] = charWidth(ch.codePointAt(0)) === 2 ? 255 : 0; data[o + 3] = 255;
      }
    }
  }
  const t = new THREE.DataTexture(data, 36, 256, THREE.RGBAFormat, THREE.UnsignedByteType);
  t.minFilter = t.magFilter = THREE.NearestFilter; t.needsUpdate = true;
  return t;
}
// família de cada código numa textura 256×1 (uniformes em array estouram o limite de alguns celulares)
const FAM_ID = { metal: 1, cloth: 2, stone: 3, brick: 4, wood: 5, leaf: 6, flesh: 7, water: 8, fire: 9, coat: 10, mane: 11 };
function famTex() {
  const d = new Uint8Array(256 * 4);
  for (let c = 1; c < 256; c++) d[c * 4] = FAM_ID[FAMILY[c - 1]] || 3;
  const t = new THREE.DataTexture(d, 256, 1, THREE.RGBAFormat, THREE.UnsignedByteType);
  t.minFilter = t.magFilter = THREE.NearestFilter; t.needsUpdate = true; return t;
}

const VS = 'varying vec2 vUv; void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }';
const FS = `
precision highp float;
#define SUBI 3
#define SUBF 3.0
uniform float uFineK;      // quantas vezes a grade dos personagens é mais fina (2–4, nunca abaixo de ~4 px)
uniform sampler2D tObj, tDepth, tAtlas, tRamp, tAct, tActD;
uniform vec2 uNF;          // perto/longe da câmera (profundidade linear)
uniform vec4 uPBox;        // retângulo do jogador na tela (px)
uniform vec4 uOutA, uOutB, uOutC;   // | / - \   _ ( ) ~   < > = .
float linD(float d) { float z = d * 2.0 - 1.0; return 2.0 * uNF.x * uNF.y / (uNF.y + uNF.x - z * (uNF.y - uNF.x)); }
uniform vec2 uCell, uObjSize;
uniform float uAtlasCols, uAtlasRows, uExposure;
uniform sampler2D tFam, tRefl;
uniform float uWaterY, uRainK;
uniform vec3 uCamPos, uMoonDir, uPlayer, uMoonTint;
uniform vec2 uWind;
uniform mat4 uInvVP;
uniform vec4 uLightPos[6], uLightCol[6];
uniform float uTime;
// paleta em 3 faixas por família (sombra → meio-tom → brilho): a cor também desenha o volume
vec3 g3(vec3 a, vec3 b, vec3 c, float t) { return t < 0.5 ? mix(a, b, t * 2.0) : mix(b, c, t * 2.0 - 1.0); }
vec3 palette(float fam, float lum, vec3 hue) {
  if (fam < 1.5) return g3(vec3(0.03, 0.035, 0.05), vec3(0.3, 0.34, 0.42), vec3(0.88, 0.94, 1.05), lum);   // aço: chumbo → azul frio → prata
  if (fam < 2.5) {                                                                                        // pano: a cor, com dobras vinho
    vec3 dk = hue * vec3(0.16, 0.03, 0.07) + vec3(0.03, 0.0, 0.015);
    return g3(dk, hue * 0.55, mix(hue, vec3(1.0, 0.72, 0.62), 0.3), lum);
  }
  if (fam < 3.5) return g3(vec3(0.02, 0.025, 0.04), vec3(0.22, 0.24, 0.29), vec3(0.62, 0.61, 0.58), lum);  // pedra: azul-negro → ardósia → cinza
  if (fam < 4.5) return g3(vec3(0.05, 0.015, 0.012), vec3(0.36, 0.13, 0.08), vec3(0.76, 0.44, 0.3), lum);  // tijolo/terracota
  if (fam < 5.5) return g3(vec3(0.035, 0.022, 0.014), vec3(0.28, 0.18, 0.1), vec3(0.62, 0.47, 0.32), lum); // madeira
  if (fam < 6.5) return hue.r > hue.g * 1.05 ? g3(vec3(0.05, 0.012, 0.006), vec3(0.4, 0.13, 0.05), vec3(0.8, 0.42, 0.18), lum)   // copa ferrugem
                                             : g3(vec3(0.008, 0.035, 0.035), vec3(0.08, 0.28, 0.2), vec3(0.4, 0.58, 0.34), lum);   // copa: azul-petróleo → musgo → oliva
  if (fam < 7.5) return g3(hue * 0.04, hue * 0.5, mix(hue, vec3(0.92, 0.85, 0.78), 0.35), lum);          // pele/carne
  if (fam < 8.5) return g3(vec3(0.01, 0.02, 0.04), vec3(0.18, 0.26, 0.4), vec3(0.62, 0.75, 0.9), lum);    // água
  if (fam < 9.5) return hue * (0.3 + 1.2 * lum);                                                          // fogo/magia
  if (fam < 10.5) return g3(vec3(0.03, 0.035, 0.048), vec3(0.27, 0.31, 0.4), vec3(0.84, 0.9, 1.0), lum);   // pelagem negra: grafite → aço/chumbo azulado → prata-azulado
  return g3(vec3(0.07, 0.075, 0.09), vec3(0.55, 0.58, 0.65), vec3(0.96, 0.97, 1.0), lum);                       // crina/cauda: cinza → prata → branco acinzentado   // pelagem/cabelo: negro com reflexo prata-azulado
}
// perto de tocha/fogueira/lustre: a cor puxa para dourado/âmbar
vec3 warmUp(vec3 col, vec3 I, float lum) {
  float w = clamp(dot(I, vec3(0.3, 0.59, 0.11)) * 1.6, 0.0, 0.75);
  return mix(col, vec3(1.0, 0.7, 0.34) * (0.25 + 0.95 * lum), w * 0.65);
}
float hs2(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vn(vec2 p) { vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hs2(i), hs2(i + vec2(1, 0)), f.x), mix(hs2(i + vec2(0, 1)), hs2(i + vec2(1, 1)), f.x), f.y); }
float hs(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
// traço nítido em qualquer tamanho: lê o atlas no nível de detalhe do tamanho real do caractere (gPx, em px)
// e binariza com borda curta — caracteres pequenos ficam afiados em vez de borrados
float gPx = 12.0;
float glyph(float g, float wide, vec2 lc) {
  float sx = wide > 0.5 ? 0.88 : 0.58, sy = 0.9;
  vec2 a = vec2(0.5 + (lc.x - 0.5) * sx, 0.5 + (lc.y - 0.5) * sy);
  vec2 cg = vec2(mod(g, uAtlasCols), floor(g / uAtlasCols));
  vec2 auv = vec2((cg.x + a.x) / uAtlasCols, 1.0 - (cg.y + 1.0 - a.y) / uAtlasRows);
  float v = textureLod(tAtlas, auv, max(0.0, log2(57.6 / max(gPx, 1.0)) - 0.6)).a;
  float th = gPx < 7.0 ? 0.2 : 0.34;
  return smoothstep(th, th + 0.16, v);
}
// caractere do nível k (0..8), variante v (0..3); s < 1 encolhe o traço (meio-tom/sombra)
float inkAt(float k, float v, float code, vec2 lc, float s) {
  vec4 r = texelFetch(tRamp, ivec2(int(k) * 4 + int(v), int(code)), 0);
  vec2 q = 0.5 + (lc - 0.5) / s;
  if (q.x < 0.0 || q.y < 0.0 || q.x > 1.0 || q.y > 1.0) return 0.0;
  return glyph(r.r * 255.0 + r.g * 65280.0, r.b, q);
}
uniform vec4 uEdgeG;   // | / - \ (contornos e quinas)
vec3 pools(vec3 wp) { vec3 I = vec3(0.0); for (int i = 0; i < 6; i++) { float r = uLightPos[i].w; if (r <= 0.0) continue; float a = clamp(1.0 - distance(wp, uLightPos[i].xyz) / r, 0.0, 1.0); I += uLightCol[i].rgb * a * a; } return I; }
vec3 worldAt(vec2 gridUv, float d) { vec4 cp = uInvVP * vec4(gridUv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0); return cp.xyz / cp.w; }
void main() {
  vec2 fc = gl_FragCoord.xy;
  vec2 cell = floor(fc / uCell), lc = fract(fc / uCell);
  gPx = uCell.y / uFineK;
  // ── personagens, criaturas, cavalo e objetos interativos: alvo próprio, grade 4× mais fina ──
  {
    vec2 fq = fc / (uCell / uFineK), fcell = floor(fq);
    ivec2 tf = ivec2(fcell);
    vec4 s0 = texelFetch(tAct, tf, 0);
    float d0 = texelFetch(tActD, tf, 0).x, k0 = floor(s0.a * 255.0 + 0.5);
    float dO = texelFetch(tDepth, ivec2(floor(fc / (uCell / SUBF))), 0).x;      // o que o cenário tem na frente
    bool act0 = d0 < 1.0 && k0 > 100.5 && k0 < 235.5 && (dO >= 1.0 || linD(d0) < linD(dO) + 0.35);
    if (act0) {
      bool isP = k0 > 165.5;
      float code = k0 - (isP ? 165.0 : 100.0);
      vec3 c = s0.rgb;
      vec3 wp = worldAt((fcell + 0.5) / (uObjSize * uFineK), d0);
      vec3 I = pools(wp);
      c += c * I * 0.7;                                          // tocha/fogueira acendem o corpo
      float L = dot(c, vec3(0.3, 0.59, 0.11));
      // volume: contraste local (cada caractere comparado com os vizinhos esculpe placas, músculos, crina)
      float rim = 0.0, rimUp = 0.0, rimDn = 0.0, La = 0.0, na = 0.0;
      for (int q = 0; q < 4; q++) {
        ivec2 o = q == 0 ? ivec2(1, 0) : q == 1 ? ivec2(-1, 0) : q == 2 ? ivec2(0, 1) : ivec2(0, -1);
        vec4 sn = texelFetch(tAct, tf + o, 0);
        float kk = floor(sn.a * 255.0 + 0.5);
        if (texelFetch(tActD, tf + o, 0).x >= 1.0 || kk < 100.5 || kk > 235.5) { rim = 1.0; if (q == 2) rimUp = 1.0; if (q == 3) rimDn = 1.0; }
        else { La += dot(sn.rgb, vec3(0.3, 0.59, 0.11)); na += 1.0; }
      }
      if (na > 0.5) L = max(0.0, L + (L - La / na) * 1.6);
      float lum = 0.2 + 0.8 * pow(1.0 - exp(-L * uExposure * 7.0), 0.8);
      // contorno com direção: borda de cima acesa pela lua (prata), de baixo na sombra
      lum = max(lum, rim * (isP ? 0.45 : 0.6));
      lum = max(lum, rimUp * 0.86);
      lum *= 1.0 - rimDn * 0.3;
      float fam = texelFetch(tFam, ivec2(int(code), 0), 0).r * 255.0;
      if (fam > 10.5) lum = 0.3 + 0.7 * lum;                          // crina e cauda: fios claros contra o corpo escuro
      else if (fam > 9.5) lum = 0.06 + 0.78 * pow(lum, 2.6);                   // pelagem negra: corpo em grafite/aço, prata só nos pontos altos e na borda lunar
      if (isP) lum = max(lum, 0.3);                                   // o cavaleiro nunca some na grama escura
      float lj = clamp(lum + (hs(fcell * 1.31 + code) - 0.5) * 0.12, 0.0, 0.999);
      float k = floor(lj * 9.0);
      // variantes do mesmo peso; na borda de capa, crina e cauda os caracteres trocam (movimento)
      bool soft = fam > 1.5 && fam < 2.5 || fam > 9.5;
      float vt = (rim > 0.5 && soft) ? floor(uTime * 3.0 + hs(fcell) * 7.0) : 0.0;
      float v = floor(hs(fcell * 0.73 + code + vt * 1.7) * 3.999);
      float ink = inkAt(k, v, code + 128.0, fract(fq), mix(0.62, 1.0, smoothstep(0.18, 0.6, lj)));
      float mx = max(max(c.r, c.g), max(c.b, 1e-4));
      vec3 col = palette(fam, lum, c / mx);
      if (fam > 1.5 && fam < 2.5) col *= 1.15;
      float gt = isP ? 0.68 : 0.8;
      if ((fam < 1.5 || fam > 9.5) && lj > gt) col = mix(col, vec3(1.0, 1.0, 1.05), (lj - gt) * 3.0);   // brilho prateado no aço e na pelagem
      // borda lunar de cima: prata fria (marfim no cavaleiro, carmesim aceso na capa), mais discreta nos inimigos
      if (rimUp > 0.5) {
        if (isP && fam > 1.5 && fam < 2.5) col = mix(col, vec3(1.0, 0.36, 0.3), 0.5);
        else col = mix(col, isP ? vec3(0.98, 0.96, 0.9) : fam > 9.5 ? vec3(0.8, 0.87, 1.0) : vec3(0.72, 0.78, 0.88), isP ? 0.55 : fam > 9.5 ? 0.6 : 0.3);
      }
      col = warmUp(col, I * 0.3, lum);
      gl_FragColor = vec4(col * ink, 1.0);
      gl_FragDepth = d0;
      return;
    }
    // ── contorno fino do jogador: célula vazia encostada na silhueta → traço conforme o ângulo da borda ──
    if (fc.x > uPBox.x && fc.x < uPBox.z && fc.y > uPBox.y && fc.y < uPBox.w) {
      vec2 g = vec2(0.0); float cnt = 0.0, dP = 1.0;
      for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
        if (i == 0 && j == 0) continue;
        ivec2 t = tf + ivec2(i, j);
        float kk = floor(texelFetch(tAct, t, 0).a * 255.0 + 0.5), dd = texelFetch(tActD, t, 0).x;
        if (dd < 1.0 && kk > 165.5 && kk < 235.5) { g += vec2(float(i), float(j)); cnt += 1.0; dP = min(dP, dd); }
      }
      if (cnt > 0.5 && (dO >= 1.0 || linD(dP) < linD(dO) + 0.35)) {
        vec2 a = abs(g); float h = hs(fcell * 1.7);
        float eg;
        if (cnt > 5.5) eg = uOutC.z;                                                        // reentrância: =
        else if (cnt < 1.5 && (a.x < 0.5 || a.y < 0.5)) eg = a.x > a.y ? (g.x > 0.0 ? uOutC.x : uOutC.y) : (g.y > 0.0 ? uOutB.w : uOutB.x);   // ponta: < > ~ _
        else if (a.x > a.y * 2.0) eg = cnt < 3.5 ? (g.x > 0.0 ? uOutB.y : uOutB.z) : uOutA.x;   // lado: ( ) |
        else if (a.y > a.x * 2.0) eg = g.y < 0.0 ? uOutB.x : (h < 0.3 ? uOutB.w : uOutA.z);     // topo: _   base: - ~
        else eg = g.x * g.y > 0.0 ? uOutA.w : uOutA.y;                                          // diagonais: \ /
        float ink = glyph(eg, 0.0, fract(fq));
        vec3 wp = worldAt((fcell + 0.5) / (uObjSize * uFineK), dP);
        vec3 col = (g.y < -0.5 ? vec3(1.0, 0.97, 0.88) * 1.06 : vec3(0.88, 0.91, 0.96)) * (0.88 + 0.12 * hs(fcell + floor(uTime * 2.0)));   // marfim no alto (elmo, ombros), prata nas laterais
        col = warmUp(col, pools(wp), 0.8);
        gl_FragColor = vec4(col * ink, 1.0);
        gl_FragDepth = dP;
        return;
      }
    }
  }
  gPx = uCell.y;
  // 4 amostras da célula no alvo dos objetos
  vec3 acc = vec3(0.0); float n = 0.0, code = 0.0, dmin = 1.0, floorD = 1.0, best = 9.0;
  vec2 gr = vec2(0.0);                                  // gradiente de luz dentro da célula (quinas e silhueta)
  for (int j = 0; j < SUBI; j++) for (int i = 0; i < SUBI; i++) {
    ivec2 t = ivec2(cell * SUBF) + ivec2(i, j);
    vec4 s = texelFetch(tObj, t, 0);
    float d = texelFetch(tDepth, t, 0).x;
    if (d >= 1.0) continue;
    float k = floor(s.a * 255.0 + 0.5);
    if (k < 0.5) { floorD = min(floorD, d); continue; }
    if (k > 100.5 && k < 235.5) continue;              // personagem: já desenhado na grade fina
    n += 1.0; acc += s.rgb; dmin = min(dmin, d);
    gr += vec2(float(i) - 1.0, float(j) - 1.0) * (1.0 - exp(-dot(s.rgb, vec3(0.3, 0.59, 0.11)) * uExposure));
    float pr = length(vec2(float(i), float(j)) - (SUBF - 1.0) * 0.5) + (k > 239.5 ? -1.0 : 0.0);
    if (pr < best) { best = pr; code = k; }
  }
  if (n > 0.5) {
    vec3 c = acc / n;
    vec3 I0 = pools(worldAt((cell + 0.5) / uObjSize, dmin)); c += c * I0 * 2.2;   // luz das chamas pela cor
    bool actor = code > 100.5 && code < 235.5;
    if (actor) code -= 100.0;
    float L = dot(c, vec3(0.3, 0.59, 0.11));
    float lum = pow(1.0 - exp(-L * uExposure * (actor ? 4.4 : 1.0)), 0.8);
    float fam = texelFetch(tFam, ivec2(int(code), 0), 0).r * 255.0;
    if (fam > 7.5 && fam < 8.5 && uWaterY > -999.0) {
      // ── água negra espelhada: reflexo do mundo, da lua gigante e das nuvens, ondulando ──
      vec2 uvc = (cell + 0.5) / uObjSize;
      vec4 cp = uInvVP * vec4(uvc * 2.0 - 1.0, dmin * 2.0 - 1.0, 1.0);
      vec3 wp = cp.xyz / cp.w;
      vec3 vd = normalize(wp - uCamPos);
      // ondas: correnteza + anéis onde o jogador pisa
      float t = uTime;
      vec2 wv = vec2(sin(wp.z * 2.3 + t * 1.7) + sin(wp.x * 1.1 - t * 1.1), cos(wp.x * 2.0 - t * 1.4)) * 0.018;
      float pdist = length(wp.xz - uPlayer.xz);
      vec2 pdir = (wp.xz - uPlayer.xz) / max(pdist, 0.01);
      float ring = sin(pdist * 14.0 - t * 7.0) * exp(-pdist * 1.6) * smoothstep(0.35, -0.1, abs(uPlayer.y - uWaterY) - 0.2);
      wv += pdir * ring * 0.03;
      wv += vec2(vn(wp.xz * 3.0 + t), vn(wp.xz * 3.0 - t)) * 0.02 * uRainK;
      vec3 rd = reflect(vd, normalize(vec3(wv.x * 2.2, 1.0, wv.y * 2.2)));
      // 1) o que está acima da água (personagem, muros, árvores), do alvo espelhado
      vec4 rc = texture2D(tRefl, uvc + wv * vec2(1.0, 2.2));
      float rl = dot(rc.rgb, vec3(0.3, 0.59, 0.11));
      vec3 col = vec3(0.32, 0.42, 0.6); float L2 = 0.0; float wfam = 3.0;
      // água azul-marinho com faixas de onda (referência), não preto puro
      float band = smoothstep(0.62, 0.95, sin(wp.x * 0.9 + wp.z * 1.7 - t * 0.9 + vn(wp.xz * 0.6) * 4.0) * 0.5 + 0.5);
      float baseL = 0.1 + 0.18 * band;
      if (rc.a < 0.5 / 255.0 && rl > 0.002) {
        L2 = baseL * 0.6;                             // margem/chão refletido: escuro
      } else if (rc.a > 0.5 / 255.0 && rl > 0.004) {
        L2 = pow(1.0 - exp(-rl * uExposure * 3.2), 0.8) * 0.8;
        col = mix(rc.rgb / max(max(rc.r, rc.g), max(rc.b, 1e-4)), vec3(0.6, 0.72, 0.9), 0.45);
      } else {
        // 2) céu refletido: lua cheia gigante (com crateras) e nuvens que correm
        float ang = acos(clamp(dot(rd, uMoonDir), -1.0, 1.0)), R0 = 0.13;
        vec2 mq = vec2(dot(rd, normalize(cross(uMoonDir, vec3(0.0, 1.0, 0.0)))), rd.y - uMoonDir.y) / R0;
        float moon = smoothstep(R0, R0 * 0.96, ang);
        float crater = vn(mq * 4.0 + 3.0) * 0.6 + vn(mq * 9.0) * 0.4;
        float mL = moon * (0.55 + 0.45 * smoothstep(0.35, 0.75, crater)) * (0.75 + 0.25 * (1.0 - length(mq)));
        vec2 cq = rd.xz / max(rd.y, 0.08) * 0.9 + uWind * t * 0.03 + vec2(t * 0.01, 0.0);
        float cl = vn(cq * 1.2) * 0.6 + vn(cq * 2.7 + 5.0) * 0.4;
        float cloud = smoothstep(0.5, 0.78, cl);
        float glow = exp(-max(ang - R0, 0.0) * 9.0) * 0.18;
        L2 = max(mL, cloud * (0.32 + 0.4 * glow * 5.0) * (1.0 - moon * 0.7)) + glow;
        col = mix(vec3(0.72, 0.74, 0.78), uMoonTint, moon);
        if (mL > 0.01) L2 = max(L2, mL);
      }
      if (L2 <= baseL) col = vec3(0.32, 0.42, 0.6);
      L2 = max(L2, baseL);
      // espuma onde o jogador pisa e na margem (vizinho que não é água)
      float foam = smoothstep(0.75, 0.95, ring) * 0.8;
      for (int q = 0; q < 4; q++) {
        ivec2 o = q == 0 ? ivec2(2, 0) : q == 1 ? ivec2(-2, 0) : q == 2 ? ivec2(0, 2) : ivec2(0, -2);
        ivec2 tt = ivec2(cell * SUBF) + o * SUBI / 2;
        float kk = floor(texelFetch(tObj, tt, 0).a * 255.0 + 0.5);
        float dd = texelFetch(tDepth, tt, 0).x;
        if (dd < 1.0 && abs(kk - code) > 0.5 && (kk < 100.5 || kk > 235.5)) foam = max(foam, 0.55 + 0.35 * sin(t * 2.0 + wp.x * 3.0));
      }
      L2 = max(L2, foam); col = mix(col, vec3(0.9, 0.95, 1.0), foam);
      if (L2 < 0.06) { gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0); gl_FragDepth = dmin; return; }
      float k2 = floor(clamp(L2 + (hs(cell * 1.7) - 0.5) * 0.1, 0.0, 0.999) * 9.0);
      float ink2 = inkAt(k2, floor(hs(cell * 2.3 + floor(t * 1.5 + hs(cell) * 5.0)) * 3.999), 1.0 + ${MAT.WATER}.0, lc, mix(0.6, 1.0, smoothstep(0.1, 0.5, L2)));
      gl_FragColor = vec4(col * (0.15 + 0.95 * L2) * ink2, 1.0);
      gl_FragDepth = dmin;
      return;
    }
    if (actor) {
      // contorno: célula de personagem com vizinho vazio (ou de outra coisa) → traço aceso, silhueta legível na grama
      float rim = 0.0;
      for (int q = 0; q < 4; q++) {
        ivec2 o = q == 0 ? ivec2(2, 0) : q == 1 ? ivec2(-2, 0) : q == 2 ? ivec2(0, 2) : ivec2(0, -2);
        ivec2 t = ivec2(cell * SUBF) + o * SUBI / 2;
        float kk = floor(texelFetch(tObj, t, 0).a * 255.0 + 0.5);
        if (texelFetch(tDepth, t, 0).x >= 1.0 || kk < 100.5 || kk > 235.5) rim = 1.0;
      }
      lum = 0.24 + 0.76 * lum;
      lum = max(lum, rim * 0.72);
    } else {
      if (lum < 0.07 && (fam < 8.5 || fam > 9.5)) { gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0); gl_FragDepth = dmin; return; }   // sombra: preto
    }
    if (!actor) lum = mix(lum, lum * lum * (3.0 - 2.0 * lum), 0.5);     // mais contraste: volume (topo aceso, base apagando)
    float lj = clamp(lum + (hs(cell * 1.37 + code) - 0.5) * (actor ? 0.08 : 0.13), 0.0, 0.999);   // meio-tom pontilhado entre níveis
    float k = floor(lj * 9.0);
    // movimento sem custo: na borda das copas/água e no fogo, a variante do caractere troca com o tempo
    bool edgeC = n < 8.5;
    float vt = (fam > 8.5 && fam < 9.5) ? floor(uTime * 8.0 + hs(cell) * 9.0)
             : (edgeC && (fam > 5.5 && fam < 6.5 || fam > 1.5 && fam < 2.5)) ? floor(uTime * 1.6 + hs(cell) * 9.0) : 0.0;
    float v = floor(hs(cell * 0.71 + code + vt * 1.3) * 3.999);
    float ink = inkAt(k, v, code, lc, mix(0.58, 1.0, smoothstep(0.12, 0.62, lj)));
    // quinas e silhueta das estruturas: traço orientado pela direção da luz ( | / - \ )
    float gm = length(gr) / 3.0;
    if (!actor && fam > 2.5 && fam < 5.5 && gm > 0.2 && lj > 0.16 && lj < 0.8 && hs(cell * 2.9) < 0.8) {
      vec2 ag = abs(gr);
      float eg = ag.x > ag.y * 2.0 ? uEdgeG.x : ag.y > ag.x * 2.0 ? uEdgeG.z : (gr.x * gr.y > 0.0 ? uEdgeG.w : uEdgeG.y);
      ink = glyph(eg, 0.0, lc);
    }
    float mx = max(max(c.r, c.g), max(c.b, 1e-4));
    vec3 hue = c / mx;
    float shade = actor ? 1.0 : smoothstep(0.07, 0.4, lum);              // estruturas: a sombra dissolve no preto
    vec3 col = warmUp(palette(fam, lum, hue), I0, lum) * shade;
    if (vt > 0.0 && (fam < 8.5 || fam > 9.5)) col *= 0.9 + 0.18 * hs(cell + vt);               // borda viva: leve tremor de cor
    if (actor && fam > 1.5 && fam < 2.5) col *= 1.15;                    // capa: vermelho-escuro vivo
    gl_FragColor = vec4(col * ink, 1.0);
    gl_FragDepth = dmin;
    return;
  }
  // só piso: "." ou ":" apagado onde a luz de tocha/fogueira/lustre bate
  gl_FragDepth = 1.0;
  if (floorD < 1.0 && hs(cell) < 0.6) {
    vec2 uv = (cell + 0.5) / uObjSize;                      // espaço da grade (a projeção dos objetos cobre a grade)
    vec4 cp = uInvVP * vec4(uv * 2.0 - 1.0, floorD * 2.0 - 1.0, 1.0);
    vec3 wp = cp.xyz / cp.w;
    vec3 I = vec3(0.0);
    for (int i = 0; i < 6; i++) { float r = uLightPos[i].w; if (r <= 0.0) continue; float d = distance(wp, uLightPos[i].xyz); float a = clamp(1.0 - d / r, 0.0, 1.0); I += uLightCol[i].rgb * a * a; }
    float e = dot(I, vec3(0.3, 0.59, 0.11));
    if (e > 0.04) {
      float g = e > 0.35 ? 1.0 : 0.0;
      float ink = inkAt(g, floor(hs(cell * 3.1) * 3.999), 1.0 + ${MAT.STONE}.0, lc, 0.8);
      gl_FragColor = vec4(I / max(max(I.r, I.g), max(I.b, 1e-4)) * min(0.55, e * 0.9) * ink, 1.0);
      return;
    }
  }
  gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
}`;

export class AsciiPass {
  constructor(renderer, atlas, atlasTex) {
    this.r = renderer;
    this.objRT = new THREE.WebGLRenderTarget(4, 4, { type: THREE.UnsignedByteType, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter, depthBuffer: true, colorSpace: THREE.NoColorSpace });
    this.objRT.depthTexture = new THREE.DepthTexture(4, 4, THREE.UnsignedIntType);
    // reflexo (mundo espelhado no plano da água), 1 amostra por célula
    // personagens/cavalo/objetos interativos: grade 4× mais fina, com profundidade própria
    this.actRT = new THREE.WebGLRenderTarget(4, 4, { type: THREE.UnsignedByteType, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter, depthBuffer: true, colorSpace: THREE.NoColorSpace });
    this.actRT.depthTexture = new THREE.DepthTexture(4, 4, THREE.UnsignedIntType);
    this.reflRT = new THREE.WebGLRenderTarget(4, 4, { type: THREE.UnsignedByteType, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: true, colorSpace: THREE.NoColorSpace });
    this.mat = new THREE.ShaderMaterial({
      vertexShader: VS, fragmentShader: FS, depthTest: true, depthFunc: THREE.AlwaysDepth, depthWrite: true,
      uniforms: {
        tObj: { value: this.objRT.texture }, tDepth: { value: this.objRT.depthTexture }, tAtlas: { value: atlasTex }, tRamp: { value: rampTex(atlas) },
        uCell: { value: new THREE.Vector2(6, 10) }, uObjSize: { value: new THREE.Vector2(4, 4) }, uAtlasCols: { value: atlas.cols }, uAtlasRows: { value: atlas.rows },
        uExposure: { value: 4.5 }, tFam: { value: famTex() }, uInvVP: { value: new THREE.Matrix4() },
        tRefl: { value: this.reflRT.texture }, uWaterY: { value: -1000 }, uCamPos: { value: new THREE.Vector3() }, uMoonDir: { value: new THREE.Vector3(0.4, 0.75, -0.5) },
        uWind: { value: new THREE.Vector2(1, 0) }, uMoonTint: { value: new THREE.Vector3(0.95, 0.96, 1) }, uPlayer: { value: new THREE.Vector3() }, uRainK: { value: 0 },
        uLightPos: { value: Array.from({ length: 6 }, () => new THREE.Vector4()) }, uLightCol: { value: Array.from({ length: 6 }, () => new THREE.Vector4()) }, uTime: { value: 0 },
        uFineK: { value: 4 }, tAct: { value: this.actRT.texture }, tActD: { value: this.actRT.depthTexture }, uNF: { value: new THREE.Vector2(0.5, 100) }, uPBox: { value: new THREE.Vector4(0, 0, -1, -1) },
        uOutA: { value: new THREE.Vector4(...['|', '/', '-', '\\'].map(c => atlas.get(c))) }, uOutB: { value: new THREE.Vector4(...['_', '(', ')', '~'].map(c => atlas.get(c))) },
        uOutC: { value: new THREE.Vector4(...['<', '>', '=', '.'].map(c => atlas.get(c))) },
        uEdgeG: { value: new THREE.Vector4(atlas.get('|'), atlas.get('/'), atlas.get('-'), atlas.get('\\')) },
      },
    });
    this.scene = new THREE.Scene();
    const q = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.mat); q.frustumCulled = false; this.scene.add(q);
    this.cam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    this.cols = 0; this.rows = 0;
  }
  setSize(w, h, cellH) {
    const ch = Math.max(5, Math.round(cellH)), cw = Math.max(3, Math.round(ch * 0.6));
    this.cols = Math.ceil(w / cw); this.rows = Math.ceil(h / ch);
    this.objRT.setSize(this.cols * 3, this.rows * 3);   // 3×3 amostras por célula: personagens usam 1 por caractere (grade 3× mais fina)
    this.reflRT.setSize(this.cols, this.rows);
    const fk = ch >= 22 ? 5 : 4;   // personagens: 4–5× mais finos que o cenário (traço nítido, sem limite por borrão)
    this.mat.uniforms.uFineK.value = fk;
    this.actRT.setSize(this.cols * fk, this.rows * fk);
    this.mat.uniforms.uCell.value.set(cw, ch); this.mat.uniforms.uObjSize.value.set(this.cols, this.rows);
  }
  /** Ajusta a projeção para o alvo dos objetos cobrir exatamente a grade (cols×cell pode passar da tela). */
  gridScale(w, h) { const c = this.mat.uniforms.uCell.value; return [this.cols * c.x / w, this.rows * c.y / h]; }
  setPlayerBox(b, cam) { this.mat.uniforms.uPBox.value.set(b[0] - 8, b[1] - 8, b[2] + 8, b[3] + 8); const e = cam.projectionMatrix.elements; this.mat.uniforms.uNF.value.set(e[14] / (e[10] - 1), e[14] / (e[10] + 1)); }
  setFrame(cam, lights, time) {
    const u = this.mat.uniforms;
    u.uInvVP.value.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse).invert();
    u.uTime.value = time;
    for (let i = 0; i < 6; i++) {
      const l = lights[i];
      if (!l) { u.uLightPos.value[i].set(0, 0, 0, 0); continue; }
      u.uLightPos.value[i].set(l.pos[0], l.pos[1], l.pos[2], l.radius * 1.2);
      const v = l.value != null ? l.value : 1;
      u.uLightCol.value[i].set(l.col[0] * v, l.col[1] * v, l.col[2] * v, 1);
    }
  }
  /** Plano da água do quadro (null = sem água visível), câmera, lua, vento e jogador (ondas onde ele pisa). */
  setWater(y, f) {
    const u = this.mat.uniforms;
    u.uWaterY.value = y == null ? -1000 : y;
    u.uCamPos.value.fromArray(f.cam); u.uPlayer.value.fromArray(f.focus);
    // a lua gigante fica onde o reflexo do olhar da câmera alcança (um pouco acima e à esquerda do centro da água)
    // (a lua está no infinito: o reflexo dela fica parado na tela enquanto a câmera anda — fixamos esse ponto)
    const iv = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().fromArray(f.proj), new THREE.Matrix4().fromArray(f.view)).invert();
    const a = new THREE.Vector3(-0.42, -0.3, -1).applyMatrix4(iv), b = new THREE.Vector3(-0.42, -0.3, 1).applyMatrix4(iv);
    const d = b.sub(a).normalize();
    u.uMoonDir.value.set(d.x, -d.y, d.z).normalize();
    const mc = f.moonCol || [1, 1, 1], mm = Math.max(mc[0], mc[1], mc[2], 1e-3);
    u.uMoonTint.value.set(mc[0] / mm, mc[1] / mm, mc[2] / mm).lerp(new THREE.Vector3(1, 1, 1), mc[1] / mm > 0.5 ? 0.6 : 0.1);   // Lua Sombria: lua vermelha no reflexo
    u.uWind.value.set((f.wind && f.wind[0]) || 0.6, (f.wind && f.wind[2]) || 0.2); u.uRainK.value = f.rain || 0;
  }
  render() { this.r.render(this.scene, this.cam); }
}
