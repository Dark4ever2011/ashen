// ASHEN 3D — Clima: céu limpo, garoa, chuva e tempestade, mudando sozinho com o tempo.
// Controla a intensidade da chuva (suavizada), o quanto as superfícies estão molhadas
// (molha rápido, seca devagar), relâmpagos (clarões duplos/triplos) e o quanto o fogo enfraquece.

export const WEATHER = {
  limpo: { label: 'Céu limpo', rain: 0, dur: [70, 150] },
  garoa: { label: 'Garoa', rain: 0.3, dur: [40, 90] },
  chuva: { label: 'Chuva', rain: 0.7, dur: [50, 110] },
  tempestade: { label: 'Tempestade', rain: 1, dur: [40, 80], storm: true },
};
const NEXT = { limpo: ['garoa', 'garoa', 'chuva'], garoa: ['limpo', 'chuva', 'chuva'], chuva: ['garoa', 'tempestade', 'limpo'], tempestade: ['chuva', 'chuva', 'garoa'] };

export class Weather {
  constructor(mode = 'auto') {
    this.mode = mode;                      // 'auto' | 'limpo' | 'garoa' | 'chuva' | 'tempestade'
    this.state = mode === 'auto' ? 'limpo' : mode;
    this.timer = 30 + Math.random() * 40;  // primeiro período limpo mais curto
    this.rain = WEATHER[this.state].rain;
    this.wet = this.rain * 0.8;
    this.flash = 0;
    this.bolt = null;                      // sequência do relâmpago atual
    this.nextBolt = 6;
    this.onChange = null;
  }
  setMode(m) {
    this.mode = m;
    if (m !== 'auto') this.state = m;
    this.timer = 60;
    this.onChange && this.onChange(this.state);
  }
  update(dt) {
    if (this.mode === 'auto') {
      this.timer -= dt;
      if (this.timer <= 0) {
        const opts = NEXT[this.state];
        this.state = opts[(Math.random() * opts.length) | 0];
        const d = WEATHER[this.state].dur;
        this.timer = d[0] + Math.random() * (d[1] - d[0]);
        this.onChange && this.onChange(this.state);
      }
    }
    const target = WEATHER[this.state].rain;
    this.rain += (target - this.rain) * Math.min(1, dt / 7);           // chuva engrossa/afina em ~7 s
    if (this.rain > this.wet) this.wet += (this.rain - this.wet) * Math.min(1, dt / 5);
    else this.wet += (this.rain - this.wet) * Math.min(1, dt / 45);    // secar demora
    // relâmpagos só na tempestade (e um pouco na chuva forte)
    const storminess = WEATHER[this.state].storm ? 1 : this.rain > 0.6 ? 0.15 : 0;
    this.nextBolt -= dt * storminess;
    if (storminess > 0 && this.nextBolt <= 0 && !this.bolt) {
      const n = 2 + ((Math.random() * 2) | 0);
      this.bolt = { t: 0, peaks: Array.from({ length: n }, (_, i) => [i * (0.09 + Math.random() * 0.08), 0.55 + Math.random() * 0.45]) };
      this.nextBolt = 5 + Math.random() * 12;
    }
    this.flash = 0;
    if (this.bolt) {
      this.bolt.t += dt;
      for (const [t0, a] of this.bolt.peaks) { const k = this.bolt.t - t0; if (k >= 0 && k < 0.35) this.flash = Math.max(this.flash, a * Math.exp(-k * 11)); }
      if (this.bolt.t > 1) this.bolt = null;
    }
  }
  /** Quanto o fogo perde de força (0 = nada, ~0,5 na tempestade). */
  get fireDamp() { return this.rain * 0.5; }
  get label() { return WEATHER[this.state].label; }
}
