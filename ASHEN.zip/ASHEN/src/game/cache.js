// ASHEN 3D — Cache local (IndexedDB) das nuvens de caracteres já construídas.
// A primeira abertura esculpe o mundo inteiro (lento no celular); as próximas carregam pronto.
// A chave inclui a versão do mundo: mudou a geometria → aumente WORLD_VERSION.

import { PointSet } from './sampler.js';
import { SolidGeom } from './solid.js';

export const WORLD_VERSION = 'mundo-v16-corpos';
const DB = 'ashen-cache', STORE = 'pontos';

function open() {
  return new Promise((res, rej) => {
    if (!('indexedDB' in self)) return rej(new Error('sem IndexedDB'));
    const r = indexedDB.open(DB, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(STORE);
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}
const pack = ps => ({ solid: ps.solid && ps.solid.nv ? ps.solid.pack() : null, n: ps.n, pos: ps.pos.slice(0, ps.n * 3), nrm: ps.nrm.slice(0, ps.n * 3), tan: ps.tan.slice(0, ps.n * 3), attr: ps.attr.slice(0, ps.n * 4), extra: ps.extra.slice(0, ps.n * 2) });
const unpack = o => { const ps = new PointSet(o.n + 1); ps.pos.set(o.pos); ps.nrm.set(o.nrm); ps.tan.set(o.tan); ps.attr.set(o.attr); ps.extra.set(o.extra); ps.n = o.n; if (o.solid) ps.solid = SolidGeom.from(o.solid); return ps; };

/** Lê { nome: PointSet, ... } ou null. */
export async function loadWorld(key) {
  try {
    const db = await open();
    const v = await new Promise((res, rej) => { const q = db.transaction(STORE).objectStore(STORE).get(WORLD_VERSION + ':' + key); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); });
    db.close();
    if (!v) return null;
    const out = {};
    for (const k in v) out[k] = k === 'meta' ? v[k] : unpack(v[k]);
    return out;
  } catch (e) { return null; }
}
export async function saveWorld(key, sets) {
  try {
    const db = await open();
    const v = {};
    for (const k in sets) v[k] = k === 'meta' ? sets[k] : pack(sets[k]);
    await new Promise((res, rej) => {
      const tx = db.transaction(STORE, 'readwrite');
      const st = tx.objectStore(STORE);
      st.clear();                                  // versões antigas saem
      st.put(v, WORLD_VERSION + ':' + key);
      tx.oncomplete = res; tx.onerror = () => rej(tx.error);
    });
    db.close();
  } catch (e) { console.info('[ASHEN] cache indisponível:', e.message); }
}
