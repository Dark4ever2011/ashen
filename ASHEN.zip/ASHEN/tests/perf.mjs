// Mede FPS e custo por passe em emulação mobile (Chrome headless, GPU por software — só referência relativa).
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const url = process.argv[2] || 'http://localhost:8123/index.html';
const preset = process.argv[3] || 'ALTA';
const gpu = process.argv[4] === 'gpu';
const browser = await chromium.launch({ args: gpu ? ['--enable-gpu', '--ignore-gpu-blocklist'] : ['--use-gl=swiftshader', '--enable-unsafe-swiftshader'] });
const page = await (await browser.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 2.625, isMobile: true, hasTouch: true })).newPage();
await page.goto(url);
await page.waitForFunction(() => window.__ASHEN && window.__ASHEN.state === 'title', null, { timeout: 60000 });
await page.evaluate(p => { const g = window.__ASHEN; g.settings.preset = p; g.settings.renderScale = null; g.settings.fpsCap = 0; g.applySettings(false); }, preset);
await page.tap('#start');
await page.waitForTimeout(4000);
const res = await page.evaluate(() => { const g = window.__ASHEN; return { fps: Math.round(g.perf.fps), upd: g.perf.updateMs.toFixed(2), ren: g.perf.renderMs.toFixed(1), W: g.renderer.W, H: g.renderer.H, pass: Object.fromEntries(Object.entries(g.passMs).map(([k, v]) => [k, +v.toFixed(2)])) }; });
console.log(preset, JSON.stringify(res));
await browser.close();
