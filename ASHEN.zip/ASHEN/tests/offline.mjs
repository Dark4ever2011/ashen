// PWA: instala o service worker, corta a rede e recarrega. O jogo precisa abrir offline.
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const url = process.argv[2] || 'http://localhost:8123/index.html';
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 2.625, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', e => errors.push(e.message));
await page.goto(url);
await page.waitForFunction(() => window.__ASHEN && window.__ASHEN.state === 'title', null, { timeout: 60000 });
const sw = await page.evaluate(async () => { const r = await navigator.serviceWorker.ready; return r.active ? r.active.state : 'nenhum'; });
await page.reload();
await page.waitForFunction(() => window.__ASHEN && window.__ASHEN.state === 'title', null, { timeout: 60000 });
const controlled = await page.evaluate(() => !!navigator.serviceWorker.controller);
const cached = await page.evaluate(async () => { const k = await caches.keys(); const c = await caches.open(k[0]); return { cache: k[0], arquivos: (await c.keys()).length }; });
await ctx.setOffline(true);
await page.reload();
let offlineOk = false;
try { await page.waitForFunction(() => window.__ASHEN && window.__ASHEN.state === 'title', null, { timeout: 30000 }); offlineOk = true; } catch (e) { /* falhou */ }
const font = await page.evaluate(() => document.fonts.check('12px AshenMono'));
const manifest = await page.evaluate(async () => { try { const m = await (await fetch('manifest.json')).json(); return `${m.name} · ${m.display} · ${m.orientation} · ${m.icons.length} ícones`; } catch (e) { return 'erro ' + e.message; } });
console.log({ sw, controlled, ...cached, offlineOk, fonteOffline: font, manifest, erros: errors.length ? errors : 'nenhum' });
await browser.close();
