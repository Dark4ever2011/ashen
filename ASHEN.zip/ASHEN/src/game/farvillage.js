// ASHEN 3D — Vau do Moinho (vila distante no Reino Partido) e a casa de Elowen.
// 2 casas, um moinho de vento que gira, um poço, 5 moradores (um é o mercador Hugo).
// Mais ao sul, depois das pedras, a casa de Elowen. Rosas e três tarefas enchem a afeição dela;
// em 100 ela aceita o seu juramento. Casados, a casa dela vira ponto de descanso.

import { m4 } from './math3d.js';
import * as S from './sdf.js';
import { MAT } from './glyphs.js';
import { noise3 } from './math3d.js';
import { PointSet, buildParts } from './sampler.js';
import { flatBones } from './renderer3d.js';
import { poseKnight } from './knight3d.js';
import { houseParts } from './region2.js';
import { SITES, heightAt, LANDMARKS } from './ow.js';
import { FV } from './story3.js';

const I = m4.ident();
const snd = (g, n, k) => g.audio && g.audio.play(n, k);
const V = SITES.village, H = SITES.her;
const KS = 0.955;
const ARCH = LANDMARKS.find(l => l.id === 'arch');

/** Move um pedaço (feito no chão y=0) para cima, até a altura do terreno. */
function lift(P, dy) {
  for (const q of P) {
    const f = q.f, k = q.keep, d = q.detail, a = q.aoF;
    const sh = p => [p[0], p[1] - dy, p[2]];
    q.f = (x, y, z) => f(x, y - dy, z);
    if (a) q.aoF = (x, y, z) => a(x, y - dy, z);
    if (k) q.keep = (p, n, c) => k(sh(p), n, c);
    if (d) q.detail = (p, n, c) => d(sh(p), n, c);
    q.min = [q.min[0], q.min[1] + dy, q.min[2]]; q.max = [q.max[0], q.max[1] + dy, q.max[2]];
    if (q.decals) q.decals = q.decals.map(o => ({ ...o, p: [o.p[0], o.p[1] + dy, o.p[2]] }));
  }
  return P;
}
export const FV_HOUSES = [
  { i: 11, x: V.x - 7, z: V.z + 3, door: 1, hw: 1.9, hd: 1.6 },
  { i: 12, x: V.x + 8, z: V.z - 2, door: -1, hw: 1.8, hd: 1.5 },
];
export const HER_HOUSE = { i: 13, x: H.x, z: H.z - 1.5, door: 1, hw: 2.0, hd: 1.7 };
export const MILL = { x: V.x + 1, z: V.z - 12 };
export const WELL = { x: V.x + 1.5, z: V.z + 4 };
const HUB = [MILL.x, 0, MILL.z + 1.55];
const WOODS = [[-4.5, 1.5], [3.8, 3.2], [-2.2, -5.2], [5.4, -3], [0.8, 6.5]].map(([dx, dz]) => ({ x: H.x + dx, z: H.z + dz }));
export const LOCKET = { x: ARCH.x + 5, z: ARCH.z + 7 };
// rosas selvagens pelo caminho (uma por dia em cada moita)
const WILD_ROSES = [[60, -120], [150, -260], [260, -330], [350, -470], [470, -520], [520, -440], [-120, -200], [90, -560]].map(([dx, z]) => ({ x: SITES.village.x - 580 + dx, z })).filter(w => heightAt(w.x, w.z) > -5);

// ─────────────── modelos ───────────────
function millParts() {
  const { x, z } = MILL, P = [];
  P.push({ name: 'torre do moinho', f: S.subtract(S.shell(S.roundCone([x, 0, z], [x, 8.2, z], 2.1, 1.3), 0.18), (px, py, pz) => Math.max(Math.abs(px - x) - 0.5, py - 1.9, z - pz)), min: [x - 2.3, -0.05, z - 2.3], max: [x + 2.3, 8.4, z + 2.3], mat: MAT.PLASTER, spacing: 0.07, flow: [0, 1, 0],
    detail: (p) => ((p[1] / 0.6 % 1) < 0.08 ? { mat: MAT.WOOD, glyph: '─' } : noise3(p[0], p[1], p[2]) > 0.64 ? { mat: MAT.MOSS } : null) });
  P.push({ name: 'chapéu do moinho', f: (px, py, pz) => Math.max(Math.hypot(px - x, pz - z) - (1.6 - (py - 8.2) * 0.85), 8.1 - py, py - 10.1), min: [x - 1.7, 8.0, z - 1.7], max: [x + 1.7, 10.2, z + 1.7], mat: MAT.THATCH, spacing: 0.07, flow: [0, 1, 0] });
  P.push({ name: 'porta do moinho', f: S.xf(S.box(0.48, 0.95, 0.05), [x, 0.95, z + 1.98]), min: [x - 0.55, 0, z + 1.85], max: [x + 0.55, 2, z + 2.1], mat: MAT.WOOD, spacing: 0.04, flow: [0, 1, 0] });
  return P;
}
/** Pás (espaço do osso 1: eixo apontando +z, cubo na origem). */
function bladeParts() {
  const P = [];
  P.push({ name: 'cubo', bone: 1, f: S.capsule([0, 0, -0.3], [0, 0, 0.3], 0.28), min: [-0.32, -0.32, -0.6], max: [0.32, 0.32, 0.6], mat: MAT.WOOD, spacing: 0.04, flow: [1, 0, 0] });
  for (let k = 0; k < 4; k++) {
    const a = k * Math.PI / 2, c = Math.cos(a), s = Math.sin(a);
    const rot = (x, y) => [x * c + y * s, -x * s + y * c];
    const arm = (x, y, z) => { const [u, v] = rot(x, y); return Math.max(Math.abs(u) - 0.08, Math.abs(z) - 0.06, Math.abs(v - 3) - 3); };
    const sail = (x, y, z) => { const [u, v] = rot(x, y); return Math.max(Math.abs(u - 0.5) - 0.42, Math.abs(z - 0.05) - 0.015, Math.abs(v - 3.5) - 2.3); };
    P.push({ name: 'pá', bone: 1, f: S.union(arm, sail), min: [-6.2, -6.2, -0.1], max: [6.2, 6.2, 0.12], mat: MAT.LINEN, spacing: 0.06, flow: [0, 1, 0],
      keep: (p) => { const [u, v] = rot(p[0], p[1]); return v > 0.2 && Math.abs(u) < 1.0; },
      detail: (p) => { const [u, v] = rot(p[0], p[1]); return Math.abs(u) < 0.1 ? { mat: MAT.WOOD } : ((v * 2.2) % 1 < 0.1 || ((u - 0.08) * 3.3) % 1 < 0.08 ? { mat: MAT.WOOD, glyph: '┼' } : null); } });
  }
  return P;
}
function wellParts() {
  const { x, z } = WELL, P = [];
  P.push({ name: 'poço', f: (px, py, pz) => Math.max(Math.abs(Math.hypot(px - x, pz - z) - 0.72) - 0.14, Math.abs(py - 0.38) - 0.38), min: [x - 0.95, -0.02, z - 0.95], max: [x + 0.95, 0.8, z + 0.95], mat: MAT.STONE, spacing: 0.04, flow: [1, 0, 0],
    detail: (p) => ((p[1] / 0.2 % 1) < 0.14 ? { mat: MAT.DARK, glyph: '─' } : null) });
  P.push({ name: 'água', f: (px, py, pz) => Math.max(Math.hypot(px - x, pz - z) - 0.58, Math.abs(py - 0.5) - 0.01), min: [x - 0.6, 0.45, z - 0.6], max: [x + 0.6, 0.55, z + 0.6], mat: MAT.WATER, spacing: 0.06, flow: [1, 0, 0] });
  const posts = S.union(S.capsule([x - 0.78, 0.6, z], [x - 0.78, 2.0, z], 0.05), S.capsule([x + 0.78, 0.6, z], [x + 0.78, 2.0, z], 0.05), S.capsule([x - 0.85, 1.75, z], [x + 0.85, 1.75, z], 0.04));
  P.push({ name: 'sarilho', f: posts, min: [x - 0.95, 0.5, z - 0.2], max: [x + 0.95, 2.1, z + 0.2], mat: MAT.WOOD, spacing: 0.035, flow: [0, 1, 0] });
  return P;
}
function stallParts() {
  const x = V.x - 2.5, z = V.z + 8, P = [];
  P.push({ name: 'banca do mercador', f: S.union(S.xf(S.box(1.3, 0.05, 0.55), [x, 0.85, z]), ...[-1, 1].flatMap(s => [-1, 1].map(t => S.capsule([x + s * 1.2, 0, z + t * 0.45], [x + s * 1.2, 2.1, z + t * 0.45], 0.05)))), min: [x - 1.4, -0.05, z - 0.65], max: [x + 1.4, 2.2, z + 0.65], mat: MAT.WOOD, spacing: 0.035, flow: [1, 0, 0] });
  P.push({ name: 'toldo', f: (px, py, pz) => Math.max(Math.abs(py - 2.15 + (pz - z) * 0.25) - 0.02, Math.abs(px - x) - 1.45, Math.abs(pz - z) - 0.8), min: [x - 1.5, 1.85, z - 0.9], max: [x + 1.5, 2.45, z + 0.9], mat: MAT.ROYAL, spacing: 0.04, flow: [1, 0, 0],
    detail: (p) => ((((p[0] - x) / 0.35) % 1 + 1) % 1 < 0.5 ? { mat: MAT.LINEN } : null) });
  P.push({ name: 'mercadorias', f: S.union(...[-0.8, -0.3, 0.3, 0.85].map((dx, i) => S.xf(i % 2 ? S.sphere(0.13) : S.cylinder(0.1, 0.16, 0.01), [x + dx, 1.05, z]))), min: [x - 1, 0.88, z - 0.2], max: [x + 1, 1.25, z + 0.2], mat: MAT.GOLD, spacing: 0.02, flow: [0, 1, 0] });
  return P;
}
function gardenParts() {
  const P = [], { x, z } = H;
  // canteiros de rosas e uma cerca baixa em volta da casa dela
  P.push({ name: 'cerca', f: (px, py, pz) => Math.max(Math.abs(Math.max(Math.abs(px - x) - 7, Math.abs(pz - z) - 6)) - 0.05, Math.abs(py - 0.45) - 0.45 + (Math.abs(((px + pz) / 0.6) % 1 - 0.5) < 0.4 && py > 0.75 ? 0 : 0), ((Math.abs(pz - z - 6) < 0.2 && Math.abs(px - x - 2.2) < 1.2) ? 1 : -1)), min: [x - 7.2, -0.05, z - 6.2], max: [x + 7.2, 0.95, z + 6.2], mat: MAT.WOOD, spacing: 0.05, flow: [0, 1, 0],
    keep: (p) => Math.abs(((p[0] + p[2]) / 0.6) % 1) < 0.25 || Math.abs(p[1] - 0.7) < 0.06 || Math.abs(p[1] - 0.35) < 0.06 });
  for (const [dx, dz] of [[-3.5, 3.4], [-1.5, 3.6], [4.5, 3.2], [4.8, -2.5], [-4.6, -2.8]]) {
    const cx = x + dx, cz = z + dz;
    P.push({ name: 'roseira', f: (px, py, pz) => Math.hypot(px - cx, (py - 0.35) * 1.5, pz - cz) - 0.5 - noise3(px * 6, py * 6, pz * 6) * 0.15, min: [cx - 0.7, -0.05, cz - 0.7], max: [cx + 0.7, 0.9, cz + 0.7], mat: MAT.LEAF, spacing: 0.035, flow: [0, 1, 0], pointFlags: 16,
      detail: (p) => (noise3(p[0] * 9, p[1] * 9, p[2] * 9) > 0.6 ? { mat: MAT.BLOOD, glyph: '❀' } : null) });
  }
  return P;
}
function pickPS(kind, atlas) {
  const ps = new PointSet(kind === 'wood' ? 120 : 60);
  if (kind === 'wood') for (let i = 0; i < 110; i++) { const a = (i % 5) * 0.16 - 0.32, t = Math.random() * 1.6 - 0.8, r = Math.random() * 6.28; ps.push([t * 0.5, 0.12 + Math.sin(r) * 0.07 + (i % 2) * 0.1, a + Math.cos(r) * 0.07], [0, 1, 0], [1, 0, 0], i % 9 ? MAT.WOOD : MAT.DARK, atlas.get(i % 3 ? '=' : '≡'), 1, 0, 0.07, i); }
  else if (kind === 'rose') for (let i = 0; i < 70; i++) { const a = Math.random() * 6.28, r = Math.random() * 0.35, h = Math.random() * 0.5; const top = i < 22; ps.push(top ? [Math.cos(a) * 0.3, 0.45 + Math.random() * 0.1, Math.sin(a) * 0.3] : [Math.cos(a) * r, h, Math.sin(a) * r], [0, 1, 0], [1, 0, 0], top ? MAT.FLOWER_R : MAT.LEAF, atlas.get(top ? '❀' : '*'), 1, top ? 0 : 16, top ? 0.09 : 0.06, i); }
  else for (let i = 0; i < 50; i++) { const a = i / 50 * 6.28; ps.push([Math.cos(a) * 0.09, 0.15 + Math.sin(a) * 0.09, 0], [0, 0, 1], [1, 0, 0], i < 40 ? MAT.GOLD : MAT.SPIRIT, atlas.get(i < 40 ? '○' : '◆'), 1, 2, 0.05, i); }
  return ps;
}

// ─────────────── no jogo ───────────────
const PEOPLE3 = [
  { id: 'hugo', kind: 'man', x: V.x - 2.5, z: V.z + 9.1, yaw: Math.PI, sc: 1.04 },
  { id: 'wulf', kind: 'man', x: MILL.x + 1.5, z: MILL.z + 3.2, yaw: 0.4, sc: 1.0 },
  { id: 'edda', kind: 'woman', x: V.x - 5, z: V.z + 5.8, yaw: 2.6, sc: 0.97 },
  { id: 'lysa', kind: 'woman', x: V.x + 5.8, z: V.z + 1, yaw: -1.4, sc: 0.95 },
  { id: 'tobin', kind: 'man', x: WELL.x + 1.6, z: WELL.z + 1.2, yaw: -2.2, sc: 0.68 },
];
export const ELOWEN_AT = { x: H.x + 2.8, z: H.z + 0.6, yaw: 1.6 };

export function initFV(g, sets, atlas) {
  if (!g.inv.fv) g.inv.fv = { aff: 0, met: false, tasks: {}, wood: [], married: false, giftDay: -1, seen: false };
  const fv = g.inv.fv;
  const st = () => ({ blend: 0, phase: Math.random(), breath: Math.random(), time: 0, atk: -1, combo: 0, roll: -1, hurt: 0, dead: 0, heal: -1, swap: -1, block: 0, offhand: 'none', look: 0, accel: 0, turn: 0, run: 0, stance: 'knight' });
  g.fvPeople = [...PEOPLE3, { id: 'elowen', kind: 'lady', ...ELOWEN_AT, sc: 0.97 }].map(q => {
    const m = g.R.addMesh(sets[q.kind]); m.area = 'ow'; m.visible = false;
    return { ...q, mesh: m, st: st(), y: 0 };
  });
  // feixes de lenha e o medalhão
  if (!fv.roseDay) fv.roseDay = {};
  g.fvPicks = [...WOODS.map((w, i) => ({ id: 'wood' + i, kind: 'wood', ...w })), ...WILD_ROSES.map((w, i) => ({ id: 'rose' + i, kind: 'rose', ...w })), { id: 'locket', kind: 'locket', ...LOCKET }].map(q => {
    const m = g.R.addMesh(pickPS(q.kind, atlas), { dynamic: true, bones: [I, I, I] }); m.area = 'ow'; m.visible = false; return { ...q, mesh: m };
  });
  g.fvBlades = null;
  // as construções entram junto com o resto do Reino Partido (na cena do trono / ao carregar)
  (g.owExtras = g.owExtras || []).push(async (at) => {
    const dyV = heightAt(V.x, V.z) - 0.05, dyH = heightAt(H.x, H.z) - 0.05;
    const vill = [...FV_HOUSES.flatMap(h => houseParts(h, false)), ...millParts(), ...wellParts(), ...stallParts()];
    const her = [...houseParts(HER_HOUSE, false), ...gardenParts()];
    const a = await buildParts(lift(vill, dyV), at, { seed: 1300, sizeMul: 2.1 }); const ma = g.R.addMesh(a, { chunk: 8 }); ma.area = 'ow';
    const b = await buildParts(lift(her, dyH), at, { seed: 1400, sizeMul: 2.1 }); const mb = g.R.addMesh(b, { chunk: 8 }); mb.area = 'ow';
    const c = await buildParts(bladeParts(), at, { seed: 1500, sizeMul: 2.1 });
    g.fvBlades = g.R.addMesh(c, { dynamic: true, bones: [I, I] }); g.fvBlades.area = 'ow'; g.fvBlades.noLod = true;
    g.fvLights = [
      { name: 'janela do vau', pos: [V.x - 7, dyV + 1.4, V.z + 3], col: [1, 0.6, 0.3], radius: 7, base: 1.2, flicker: 0.2, area: 'ow', level: 1 },
      { name: 'janela de Elowen', pos: [H.x, dyH + 1.4, H.z - 1.5], col: [1, 0.62, 0.35], radius: 7, base: 1.2, flicker: 0.2, area: 'ow', level: 1 },
    ];
    g.lights.push(...g.fvLights);
    return [
      ...[...FV_HOUSES, HER_HOUSE].map(h => ({ type: 'box', x0: h.x - h.hw - 0.1, z0: h.z - h.hd - 0.1, x1: h.x + h.hw + 0.1, z1: h.z + h.hd + 0.1 })),
      { type: 'circle', x: MILL.x, z: MILL.z, r: 2.2 }, { type: 'circle', x: WELL.x, z: WELL.z, r: 0.9 },
      { type: 'box', x0: V.x - 3.9, z0: V.z + 7.5, x1: V.x - 1.1, z1: V.z + 8.6 },
    ];
  });
}

export function fvStep(g, dt) {
  if (g.area !== 'ow') return;
  const p = g.player, fv = g.inv.fv;
  if (!fv.seen && Math.hypot(p.x - V.x, p.z - V.z) < 40) { fv.seen = true; g.hud.showRegion({ region: 'III · O Reino Partido', title: FV.name, subtitle: '水車の浅瀬' }); }
  for (const q of g.fvPeople) {
    q.y = heightAt(q.x, q.z);
    const d = Math.hypot(p.x - q.x, p.z - q.z);
    const want = d < 4 ? Math.atan2(p.x - q.x, p.z - q.z) : q.yaw;
    q.ang = (q.ang ?? q.yaw) + Math.atan2(Math.sin(want - (q.ang ?? q.yaw)), Math.cos(want - (q.ang ?? q.yaw))) * Math.min(1, dt * 3);
    q.st.time += dt; q.st.breath += dt;
    // ninguém atravessa os moradores
    if (d < 0.55 && d > 1e-4) { p.x = q.x + (p.x - q.x) / d * 0.55; p.z = q.z + (p.z - q.z) / d * 0.55; }
  }
}
export function fvRender(g) {
  const p = g.player, on = g.area === 'ow';
  for (const q of g.fvPeople) {
    q.mesh.visible = on && Math.hypot(p.x - q.x, p.z - q.z) < 60;
    if (!q.mesh.visible) continue;
    const s = KS * q.sc, W = m4.mul(m4.mul(m4.translate(q.x, q.y, q.z), m4.rotY(q.ang ?? q.yaw)), m4.scale(s, s, s));
    const b = poseKnight(q.st).map(m => m4.mul(W, m)); b[0] = I; q.mesh.boneData = flatBones(b, q.mesh.boneData);
  }
  const fv = g.inv.fv;
  for (const k of g.fvPicks) {
    const need = k.kind === 'rose' ? fv.roseDay[k.id] !== g.day : k.kind === 'wood' ? fv.tasks.wood === 'active' && !fv.wood.includes(k.id) : fv.tasks.locket === 'active' && !g.hasItem('locket');
    k.mesh.visible = on && need && Math.hypot(p.x - k.x, p.z - k.z) < 50;
    if (k.mesh.visible) { const y = heightAt(k.x, k.z), M = m4.mul(m4.translate(k.x, y + (k.kind === 'locket' ? 0.1 + 0.05 * Math.sin(g.t * 2) : 0), k.z), m4.rotY(k.kind === 'locket' ? g.t : 0.6)); k.mesh.boneData = flatBones([I, M, M], k.mesh.boneData); }
  }
  if (g.fvBlades) {
    g.fvBlades.visible = on && Math.hypot(p.x - MILL.x, p.z - MILL.z) < 140;
    if (g.fvBlades.visible) { const y = heightAt(MILL.x, MILL.z) + 7.0; g.fvBlades.boneData = flatBones([I, m4.mul(m4.translate(HUB[0], y, HUB[2]), m4.rotZ((g.t || 0) * 0.45))], g.fvBlades.boneData); }
  }
}

export function fvFocus(p, g) {
  if (g.area !== 'ow' || !g.fvPeople) return null;
  const fv = g.inv.fv, list = [];
  for (const q of g.fvPeople) { const d = Math.hypot(p.x - q.x, p.z - q.z); if (d < 1.8) list.push({ id: 'fv:' + q.id, title: q.id === 'elowen' && !fv.met ? 'Moça do jardim' : (FV_NAMES[q.id] || q.id), prompt: q.id === 'hugo' ? 'negociar' : q.id === 'elowen' && g.hasItem('rose') && !fv.married ? 'dar uma rosa' : 'falar', d, x: q.x, z: q.z }); }
  const dw = Math.hypot(p.x - WELL.x, p.z - WELL.z);
  if (dw < 1.7) list.push({ id: 'fv:well', title: 'Poço do Vau', prompt: fv.tasks.water === 'active' && !g.hasItem('water') ? 'encher um balde' : 'olhar o poço', d: dw, x: WELL.x, z: WELL.z });
  for (const k of g.fvPicks) if (k.mesh.visible) { const d = Math.hypot(p.x - k.x, p.z - k.z); if (d < 1.4) list.push({ id: 'fv:' + k.id, title: k.kind === 'wood' ? 'Feixe de lenha' : k.kind === 'rose' ? 'Rosa selvagem' : 'Medalhão de prata', prompt: k.kind === 'rose' ? 'colher uma rosa' : 'pegar', d, x: k.x, z: k.z }); }
  list.sort((a, b) => a.d - b.d);
  return list[0] || null;
}
const FV_NAMES = { hugo: 'Hugo, o mercador', wulf: 'Wulf, o moleiro', edda: 'Edda', lysa: 'Lysa, a escriba', tobin: 'Tobin', elowen: 'Elowen' };

export function fvInteract(g, it) {
  if (!it.id.startsWith('fv:')) return false;
  const k = it.id.slice(3), fv = g.inv.fv;
  if (k === 'hugo') { g.dialog.start(FV.talks.hugo, () => g.openShop({ name: 'Hugo, o mercador', greet: 'Pague em ouro. Sem fiado.' })); return true; }
  if (FV.talks[k]) { g.dialog.start(FV.talks[k], null); return true; }
  if (k === 'well') {
    if (fv.tasks.water === 'active' && !g.hasItem('water')) { g.addItem('water'); snd(g, 'pickup'); g.hud.toast('Você enche um balde com água do Vau.', 2500); }
    else g.hud.message('A água ainda é limpa aqui. Talvez seja por isso que o Vau sobreviveu.', 'Poço do Vau', it);
    return true;
  }
  if (k.startsWith('rose')) { fv.roseDay[k] = g.day; g.addItem('rose'); snd(g, 'pickup'); g.hud.toast('Você colhe uma rosa vermelha.', 1800); g.save(); return true; }
  if (k.startsWith('wood')) { fv.wood.push(k); snd(g, 'pickup'); g.hud.toast(`Feixe de lenha ${fv.wood.length}/5`, 1800); g.save(); return true; }
  if (k === 'locket') { g.addItem('locket'); snd(g, 'pickup'); g.hud.message('Um medalhão de prata, com um retrato pequeno de um soldado dentro.', 'Medalhão de prata', it); g.save(); return true; }
  if (k === 'elowen') { talkHer(g); return true; }
  return false;
}

const TASKS = [['wood', 25], ['water', 20], ['locket', 30]];
function addAff(g, n) { const fv = g.inv.fv; fv.aff = Math.min(100, fv.aff + n); g.hud.toast(`♥ Afeição de Elowen: ${fv.aff}/100`, 2200); }
function talkHer(g) {
  const fv = g.inv.fv, D = FV.her;
  const after = () => { if (fv.aff >= 100 && !fv.married) propose(g); else g.save(); };
  if (fv.married) {
    const lines = [...D.married];
    const gift = fv.giftDay !== g.day && Math.random() < 0.55;
    if (gift) lines.push(...D.gift);
    g.dialog.start(lines, () => {
      g.restAt('elowen'); g.save(); g.hud.toast('Elowen cuida de você: vida e frascos renovados. Progresso salvo.', 3000);
      if (gift) { fv.giftDay = g.day; const r = Math.random(); if (r < 0.45) { g.addGold(120); g.hud.toast('Elowen te deu 120 moedas de ouro.', 2500); } else if (r < 0.8) { g.addItem('pie'); g.hud.toast('Elowen te deu uma torta.', 2500); } else { g.addItem('rose'); g.hud.toast('Elowen te deu uma rosa do jardim.', 2500); } g.save(); }
    });
    return;
  }
  if (!fv.met) { fv.met = true; g.dialog.start(D.first, after); return; }
  if (g.hasItem('rose')) { g.takeItem('rose'); const again = fv.roses > 0; fv.roses = (fv.roses || 0) + 1; g.dialog.start(again ? D.roseAgain : D.rose, () => { addAff(g, 15); after(); }); return; }
  for (const [t, v] of TASKS) {
    if (fv.tasks[t] !== 'active') continue;
    const ok = t === 'wood' ? fv.wood.length >= 5 : g.hasItem(t);
    if (ok) { if (t !== 'wood') g.takeItem(t); fv.tasks[t] = 'done'; g.dialog.start(D.thanks[t], () => { addAff(g, v); after(); }); }
    else g.dialog.start(D.waiting, null);
    return;
  }
  const next = TASKS.find(([t]) => !fv.tasks[t]);
  if (next) { fv.tasks[next[0]] = 'active'; g.dialog.start(D.ask[next[0]], () => g.save()); return; }
  g.dialog.start(D.idle, null);
}
function propose(g) {
  const fv = g.inv.fv;
  g.dialog.start(FV.her.propose, () => {
    const y = heightAt(MILL.x, MILL.z), p = g.player, el = g.fvPeople.find(q => q.id === 'elowen');
    const bx = MILL.x, bz = MILL.z + 5;
    const back = { x: el.x, z: el.z };
    g.cinema.play({
      dur: 14,
      shots: [
        { t0: 0, t1: 7, eye0: [bx + 9, y + 9, bz + 10], eye1: [bx + 5, y + 5, bz + 7], tgt0: [MILL.x, y + 6, MILL.z], tgt1: [bx, y + 1.5, bz] },
        { t0: 7, t1: 14, eye0: [bx + 2.4, y + 1.7, bz + 2.6], eye1: [bx + 1.4, y + 1.5, bz + 1.8], tgt0: [bx, y + 1.3, bz], tgt1: [bx, y + 1.4, bz] },
      ],
      captions: [{ t0: 1.5, t1: 13.4, text: FV.wedding }], titles: [{ t0: 8, t1: 13.5, text: 'JURAMENTO ETERNO' }],
      black: [{ t0: 0, t1: 1.2, a: t => 1 - t / 1.2 }, { t0: 12.8, t1: 14, a: t => (t - 12.8) / 1.2 }],
      events: [
        { t: 0.05, fn: () => { Object.assign(p, { x: bx - 0.45, z: bz, yaw: Math.PI / 2 }); el.x = bx + 0.45; el.z = bz; el.ang = -Math.PI / 2; el.yaw = -Math.PI / 2; g.teleported && g.teleported(); } },
        { t: 9, fn: (skip) => { if (!skip) { snd(g, 'bell'); g.fx.burst([bx, y + 2.6, bz], 90); } } },
      ],
      onEnd: () => {
        el.x = back.x; el.z = back.z; el.yaw = ELOWEN_AT.yaw;
        fv.married = true; snd(g, 'victory'); g.achieve('Juramento Eterno');
        g.hud.toast('Elowen é sua esposa. A casa dela agora é um lugar de descanso.', 4200); g.save();
      },
    });
  });
}
export const ELOWEN_REST = { x: ELOWEN_AT.x - 1.0, z: ELOWEN_AT.z + 1.2 };
