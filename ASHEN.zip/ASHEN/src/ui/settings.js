// ASHEN — Configurações gráficas e de controle (versão 3D)
// Os presets nunca simplificam o cavaleiro nem a arquitetura: mudam a resolução de tela,
// a densidade de efeitos (cinzas, chuva, névoa) e o alcance da sombra.

export const PRESETS = {
  ALTA: { label: 'Alta', desc: 'Resolução máxima, todos os efeitos, sombra longa.', dpr: 2.75, fx: 1, shadow: 11 },
  EQUILIBRADA: { label: 'Equilibrada', desc: 'Mesmo estilo; resolução um pouco menor e efeitos moderados.', dpr: 2.0, fx: 0.8, shadow: 9 },
  DESEMPENHO: { label: 'Desempenho', desc: 'Cavaleiro e arquitetura intactos; menos partículas e resolução menor.', dpr: 1.5, fx: 0.55, shadow: 7 },
};

export const WEATHER_MODES = [['auto', 'Automático'], ['limpo', 'Limpo'], ['garoa', 'Garoa'], ['chuva', 'Chuva'], ['tempestade', 'Tempestade']];

export const DEFAULT_SETTINGS = {
  preset: 'ALTA',
  fpsCap: 60,          // 30 | 60 | 0 (sem limite)
  showPerf: false,
  haptics: true,
  controlScale: 1,
  bindings: null,
  weather: 'auto',
};

export function effective(settings) { return PRESETS[settings.preset] || PRESETS.ALTA; }
