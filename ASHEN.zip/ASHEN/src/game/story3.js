// ASHEN — Reino Partido: a vila do moinho (Vau do Moinho), o mercador e a moça da casa distante.
import { PEOPLE } from './story2.js';
import { FACE_SPECS } from '../ui/portrait.js';

Object.assign(FACE_SPECS, {
  hugo: { ...FACE_SPECS.bram, beard: 1, soot: 0, collar: 'tee', cloth: '#2a2420' },
  wulf: { ...FACE_SPECS.oswin, hair: '#d8cfba', cloth: '#3a3026' },
  edda: { ...FACE_SPECS.maren, hair: '#f6eddc', iris: '#9a6ab8', cloth: '#ead9c8', ribbon: '#d8a0b0' },
  lysa: { ...FACE_SPECS.ilsa, cloth: '#f0f0f0', bow: '#7a1a24' },
  tobin: { ...FACE_SPECS.pip, hair: '#2d1d12', hairShade: '#1b110a', iris: '#5a7a3a', cloth: '#5a3a28', clothShade: '#3e281c' },
  elowen: { style: 'pastel', hair: '#5a2a1e', hairStyle: 'long', face: 'soft', eyes: 'big', iris: '#2f8a64', cloth: '#efe3f4', collar: 'soft', ribbon: '#c8466a' },
});
Object.assign(PEOPLE, {
  hugo: { name: 'Hugo, o mercador', face: 'hugo', cls: 'p-bram' },
  wulf: { name: 'Wulf, o moleiro', face: 'wulf', cls: 'p-oswin' },
  edda: { name: 'Edda', face: 'edda', cls: 'p-maren' },
  lysa: { name: 'Lysa, a escriba', face: 'lysa', cls: 'p-ilsa' },
  tobin: { name: 'Tobin', face: 'tobin', cls: 'p-pip' },
  elowen: { name: 'Elowen', face: 'elowen', cls: 'p-maren' },
});

export const FV = {
  name: 'Vau do Moinho',
  talks: {
    hugo: [['hugo', 'Um cliente! Faz semanas que só passam lobos e mortos por esta estrada.'], ['hugo', 'Ouro é ouro, venha de onde vier. Tenho frascos, pedras de afiar, rosas… e um sino que eu não tocaria nem bêbado.']],
    wulf: [['wulf', 'O moinho ainda gira. Não tem trigo há dois invernos, mas ele gira.'], ['wulf', 'Enquanto as pás andarem, o vau tem um coração. É o que eu digo pra Edda.']],
    edda: [['edda', 'Você veio do palácio? Dizem que lá dentro as velas nunca apagam.'], ['edda', 'Aqui, a gente apaga as nossas cedo. Coisas andam na estrada à noite.']],
    lysa: [['lysa', 'Eu anoto tudo. Quem passa, quem não volta, as luas.'], ['lysa', 'A cada dez dias, a lua pode sangrar. Uma vez em cem. Eu vi uma vez. Não quero ver de novo.']],
    tobin: [['tobin', 'Moço! Você já viu a moça da casa lá embaixo, depois das pedras? A Elowen?'], ['tobin', 'Ela é a mais bonita do reino inteiro. Ela gosta de rosas. Vermelhas.']],
  },
  her: {
    first: [['elowen', 'Ah! Um viajante… desculpe, não recebo muita gente aqui.'], ['elowen', 'Sou Elowen. Cuido do jardim e da casa desde que meu pai foi para a guerra do rei.'], ['you', '…'], ['elowen', 'Você tem um olhar cansado. Fique um pouco, se quiser.']],
    rose: [['elowen', 'Uma rosa vermelha… para mim?'], ['elowen', 'Faz tanto tempo que ninguém me dá flores. Obrigada.']],
    roseAgain: [['elowen', 'Mais uma? Você vai encher a minha casa de rosas.']],
    ask: {
      wood: [['elowen', 'Posso pedir uma ajuda? A lenha acabou e as noites estão frias.'], ['elowen', 'Deixei feixes perto das pedras, em volta da casa. São cinco.']],
      water: [['elowen', 'O meu poço secou. O poço do Vau ainda tem água boa…'], ['elowen', 'Você traria um balde para mim?']],
      locket: [['elowen', 'Perdi o medalhão do meu pai perto do grande arco partido, ao oeste.'], ['elowen', 'Sei que é longe. Não precisa… mas, se passar por lá…']],
    },
    thanks: {
      wood: [['elowen', 'Cinco feixes! A lareira vai durar o inverno inteiro. Obrigada, de verdade.']],
      water: [['elowen', 'Água fresca do Vau… você andou isso tudo por mim?']],
      locket: [['elowen', 'O medalhão… o retrato do meu pai ainda está aqui dentro.'], ['elowen', 'Eu não sei como agradecer. Talvez… só fique um pouco mais.']],
    },
    waiting: [['elowen', 'Sem pressa. Estarei aqui.']],
    idle: [['elowen', 'O jardim fica mais bonito quando você aparece. Não ria.']],
    propose: [['elowen', 'Eu pensei muito… em você, na estrada, nos mortos lá fora.'], ['you', '(Você se ajoelha e oferece o seu juramento, o último que ainda tem.)'], ['elowen', 'Sim. Mil vezes sim.'], ['elowen', 'Mas a minha casa é aqui, com o jardim. Volte sempre para mim. Promete?']],
    married: [['elowen', 'Bem-vindo de volta, meu amor. Descanse. A cama está feita.']],
    gift: [['elowen', 'Guardei isto para você. Não me olhe assim, leve.']],
  },
  wedding: 'Sob as pás do moinho, diante de todo o Vau, vocês trocam juramentos. Pela primeira vez em muito tempo, o reino partido parece inteiro.',
};
