// ASHEN 3D — Pátio diante do Portão do Rei (protótipo da Etapa A).
// Tudo é geometria SDF no espaço do mundo (metros, y para cima, z para a câmera).
// A muralha fica ao norte (z ≈ −4,4); o cavaleiro começa em z ≈ 2.

import * as S from './sdf.js';
import { MAT } from './glyphs.js';
import { noise3, rng } from './math3d.js';

export const isPath = (x, z) => Math.abs(x - 0.35 * Math.sin(z * 0.35)) < 1.05 && z > -4.4;
export const WALL_Z = -4.4, ARCH = { half: 1.3, spring: 2.15, top: 3.45 };

const slab = (axis, a, b) => (x, y, z) => { const v = axis === 0 ? x : axis === 1 ? y : z; return Math.max(a - v, v - b); };

/** Distância 2D de um ponto ao vão do arco ogival (negativa dentro). */
function archOpening(x, y) {
  const { half, spring } = ARCH;
  const rect = Math.max(Math.abs(x) - half, y - spring, -y - 1);
  const r = half * 2;
  const pointed = Math.max(Math.hypot(x - half, y - spring) - r, Math.hypot(x + half, y - spring) - r, spring - y - 0.001);
  return Math.min(rect, pointed);
}

export function sceneParts() { return allParts().filter(p => p.name !== 'chão'); }
export function groundParts() { return allParts().filter(p => p.name === 'chão'); }

function allParts() {
  const P = [];
  const add = o => P.push(o);

  // ── Chão: terra com cinzas, grama morta, caminho de pedras até o portão ──
  const h = (x, z) => 0.04 * noise3(x * 0.7, 0, z * 0.7) + 0.02 * noise3(x * 2.3, 1, z * 2.3);
  const path = (x, z) => Math.abs(x - 0.35 * Math.sin(z * 0.35)) < 1.05 && z > -4.4;
  add({ name: 'chão', f: (x, y, z) => y - h(x, z) + (path(x, z) ? 0.015 : 0), min: [-12, -0.12, -4.3], max: [12, 0.12, 9.5], mat: MAT.GROUND, spacing: 0.22, size: 0.42,
    flowFn: (p) => { const a = (Math.sin(p[0] * 91.7 + p[2] * 47.3) * 43758.5) % 6.28; return [Math.cos(a), 0, Math.sin(a)]; },
    detail: (p) => {
      if (path(p[0], p[2])) {
        const r = Math.floor(p[2] / 0.34), c = Math.floor((p[0] + (r % 2) * 0.17) / 0.38);
        const fu = (p[0] + (r % 2) * 0.17) / 0.38 - c, fv = p[2] / 0.34 - r;
        if (fu < 0.14 || fv < 0.14) return { mat: MAT.DARK, glyph: fu < 0.14 ? '│' : '─', size: 0.8 };
        return { mat: MAT.GRAVEL };
      }
      const g = noise3(p[0] * 0.45, 3, p[2] * 0.45);
      if (g > 0.6) return { mat: MAT.MOSS, size: 0.8 };
      return null;
    } });

  // ── Muralha com arco ogival, ameias e contrafortes ──
  const wallBox = S.xf(S.box(10.5, 2.3, 0.6), [0, 2.3, WALL_Z - 0.6]);
  const opening = (x, y, z) => Math.max(archOpening(x, y), Math.abs(z - (WALL_Z - 0.6)) - 1.0);
  const merlons = (x, y, z) => {
    const k = ((x + 30) % 1.1 + 1.1) % 1.1;
    const local = k - 0.3;
    return Math.max(Math.abs(local) - 0.3, Math.abs(y - 4.9) - 0.32, Math.abs(z - (WALL_Z - 0.2)) - 0.2, Math.abs(x) - 10.4);
  };
  const buttress = S.union(...[-4.3, 4.3].map(bx => S.intersect(S.xf(S.box(0.45, 2.0, 0.55), [bx, 2.0, WALL_Z + 0.35]), (x, y, z) => (y - 3.6) + (z - WALL_Z) * 0.9)));
  const wall = S.union(S.subtract(wallBox, opening), merlons, buttress);
  add({ name: 'muralha', f: wall, min: [-10.6, -0.05, WALL_Z - 1.25], max: [10.6, 5.3, WALL_Z + 0.95], mat: MAT.STONE, spacing: 0.075, flow: [1, 0, 0],
    keep: (p, n) => n[2] > -0.5,
    detail: (p, n, c) => {
      const inArch = archOpening(p[0], p[1]) > -0.55 && archOpening(p[0], p[1]) < 0.05 && p[2] > WALL_Z - 1.3;
      if (inArch && Math.abs(n[2]) < 0.6) return { mat: MAT.BONE };            // aduelas do arco
      if (inArch && archOpening(p[0], p[1]) > -0.4 && n[2] > 0.6) {
        const a = Math.atan2(p[1] - ARCH.spring, p[0]);
        if (p[1] > ARCH.spring && Math.abs(((a * 7) % 1 + 1) % 1 - 0.5) < 0.08) return { mat: MAT.DARK, glyph: '╲', size: 0.9 };
        return { mat: MAT.BONE };
      }
      if (n[2] > 0.6 && p[1] < 4.55) {                                          // cantaria: juntas de argamassa
        const r = Math.floor(p[1] / 0.36), off = (r % 2) * 0.4;
        const fu = ((p[0] + off) / 0.8) % 1, fv = (p[1] / 0.36) % 1;
        if (fv < 0.12) return { mat: MAT.DARK, glyph: '─', size: 0.85 };
        if (((fu % 1) + 1) % 1 < 0.08) return { mat: MAT.DARK, glyph: '│', size: 0.85 };
        if (noise3(p[0] * 0.6, p[1] * 0.6, 5) > 0.72 && p[1] < 2.2) return { mat: MAT.MOSS };
      }
      return null;
    },
    decals: [{ p: [0, ARCH.top + 0.32, WALL_Z + 0.02], n: [0, 0, 1], glyph: '王', mat: MAT.GOLD, size: 0.32, clear: 0.2 },
      ...'灰の王国'.split('').map((ch, i) => ({ p: [-0.75 + i * 0.5, 4.15, WALL_Z + 0.02], n: [0, 0, 1], glyph: ch, mat: MAT.GOLD, size: 0.2, clear: 0.14 }))] });

  // Grade levadiça (ferro), meio erguida
  const bars = (x, y, z) => {
    if (archOpening(x, y) > 0.05) return 1;
    const zz = z - (WALL_Z - 0.55);
    const vx = Math.abs(((x + 30) % 0.34 + 0.34) % 0.34 - 0.17);
    const hy = Math.abs(((y + 30) % 0.48 + 0.48) % 0.48 - 0.24);
    const vbar = Math.hypot(vx, zz) - 0.026;
    const hbar = Math.max(Math.hypot(hy, zz) - 0.02, Math.abs(x) - 1.3);
    return Math.max(Math.min(vbar, hbar), 1.25 - y);
  };
  add({ name: 'grade', f: bars, min: [-1.35, 1.2, WALL_Z - 0.65], max: [1.35, 3.5, WALL_Z - 0.45], mat: MAT.IRON, spacing: 0.028, flow: [0, 1, 0],
    decals: [-1.19, -0.85, -0.51, -0.17, 0.17, 0.51, 0.85, 1.19].map(x => ({ p: [x, 1.2, WALL_Z - 0.52], n: [0, 0, 1], glyph: '▼', mat: MAT.IRON, size: 0.07 })) });

  // Suportes das tochas
  for (const tx of [-2.1, 2.1]) add({ name: 'tocha', f: S.smooth(0.03, S.capsule([tx, 2.05, WALL_Z + 0.02], [tx, 2.05, WALL_Z + 0.28], 0.03), S.xf(S.cylinder(0.07, 0.07, 0.02), [tx, 2.22, WALL_Z + 0.3])), min: [tx - 0.12, 1.9, WALL_Z - 0.05], max: [tx + 0.12, 2.35, WALL_Z + 0.42], mat: MAT.IRON, spacing: 0.022 });

  // ── Coluna quebrada, canelada ──
  const col = (x, y, z) => { const dx = x + 3.3, dz = z + 1.5, a = Math.atan2(dz, dx); return Math.max(Math.hypot(dx, dz) - 0.32 - 0.018 * Math.cos(a * 16), Math.abs(y - 0.9) - 0.9, y - 1.55 - 0.25 * noise3(dx * 5, 0, dz * 5) - 0.2 * dx); };
  const plinth = S.xf(S.box(0.48, 0.13, 0.48, 0.02), [-3.3, 0.13, -1.5]);
  add({ name: 'coluna', f: S.union(col, plinth), min: [-3.85, -0.02, -2.05], max: [-2.75, 2.0, -0.95], mat: MAT.STONE, spacing: 0.035, flow: [0, 1, 0],
    detail: (p, n, c) => (c > 0.4 && p[1] > 1.2 ? { mat: MAT.BONE } : (noise3(p[0] * 3, p[1] * 3, p[2] * 3) > 0.7 ? { mat: MAT.MOSS } : null)) });

  // ── Árvore morta: tronco e galhos recursivos fundidos ──
  const R = rng(5);
  const segs = [];
  const grow = (a, dir, len, r, depth) => {
    const b = [a[0] + dir[0] * len, a[1] + dir[1] * len, a[2] + dir[2] * len];
    segs.push(S.roundCone(a, b, r, r * 0.72));
    if (depth >= 4) return;
    const n = depth < 2 ? 3 : 2;
    for (let i = 0; i < n; i++) {
      const ang = (i / n) * Math.PI * 2 + R() * 1.5;
      const spread = 0.45 + R() * 0.35;
      const nd = [dir[0] * 0.65 + Math.cos(ang) * spread, dir[1] * 0.75 + 0.15, dir[2] * 0.65 + Math.sin(ang) * spread];
      const l = Math.hypot(...nd);
      grow(b, nd.map(v => v / l), len * (0.62 + R() * 0.15), r * 0.62, depth + 1);
    }
  };
  grow([4.3, -0.1, 0.2], [0.08, 1, 0.02], 1.9, 0.2, 0);
  const tree = S.smooth(0.06, ...segs);
  add({ name: 'árvore', f: tree, min: [2.2, -0.15, -1.9], max: [6.4, 5.6, 2.3], mat: MAT.WOOD, spacing: 0.032, pointFlags: 16, flowFn: () => [0, 1, 0],
    detail: (p) => (p[1] < 0.8 && noise3(p[0] * 4, p[1] * 4, p[2] * 4) > 0.62 ? { mat: MAT.MOSS } : null) });

  // ── Braseiro de ferro sobre plinto de pedra ──
  const bx = -1.45, bz = 1.35;
  const bowl = S.intersect(S.shell(S.xf(S.sphere(0.42), [bx, 1.25, bz]), 0.03), S.below(1.18));
  const rim = S.xf(S.torus(0.4, 0.035), [bx, 1.17, bz]);
  const legs = S.union(...[0, 1, 2].map(i => { const a = i * 2.094 + 0.4; return S.capsule([bx + Math.cos(a) * 0.32, 0.24, bz + Math.sin(a) * 0.32], [bx + Math.cos(a) * 0.12, 0.92, bz + Math.sin(a) * 0.12], 0.035); }));
  add({ name: 'braseiro', f: S.smooth(0.03, bowl, rim, legs), min: [bx - 0.5, 0.15, bz - 0.5], max: [bx + 0.5, 1.25, bz + 0.5], mat: MAT.IRON, spacing: 0.026, flow: [0, 1, 0],
    detail: (p, n, c) => (c > 0.4 ? { mat: MAT.SILVER } : null),
    decals: Array.from({ length: 22 }, (_, i) => { const a = i * 2.4, r = 0.08 + (i % 5) * 0.06; return { p: [bx + Math.cos(a) * r, 1.15, bz + Math.sin(a) * r], n: [0, 1, 0], glyph: ['•', '*', '·', '✶'][i % 4], mat: MAT.EMBER, size: 0.07, flags: 2 }; }) });
  add({ name: 'plinto', f: S.xf(S.box(0.5, 0.12, 0.5, 0.03), [bx, 0.12, bz]), min: [bx - 0.55, -0.02, bz - 0.55], max: [bx + 0.55, 0.26, bz + 0.55], mat: MAT.STONE, spacing: 0.035, flow: [1, 0, 0] });

  // ── Lápides ──
  const graves = [[3.0, 3.6, -0.12, '墓'], [4.3, 4.3, 0.15, null], [5.5, 3.3, -0.05, '眠']];
  graves.forEach(([gx, gz, tilt, ch], i) => {
    const stone = S.smooth(0.02, S.xf(S.box(0.32, 0.42, 0.09, 0.02), [0, 0.42, 0]), S.xf(S.cylinder(0.32, 0.09, 0.02), [0, 0.84, 0], [Math.PI / 2, 0, 0]));
    const f = S.xf(stone, [gx, 0, gz], [tilt, 0, tilt * 0.6]);
    add({ name: 'lápide', f, min: [gx - 0.6, -0.05, gz - 0.4], max: [gx + 0.6, 1.3, gz + 0.4], mat: MAT.STONE, spacing: 0.03, flow: [0, 1, 0],
      detail: (p, n, c) => (c > 0.45 ? { mat: MAT.BONE } : (noise3(p[0] * 5, p[1] * 5, i) > 0.72 ? { mat: MAT.MOSS } : null)),
      decals: ch ? [{ p: [gx, 0.62, gz + 0.095 + tilt * 0.0], n: [0, 0, 1], glyph: ch, mat: MAT.BONE, size: 0.24, clear: 0.15 }] : [] });
  });

  // ── Rochas ──
  [[-5.6, 2.2, 0.55], [6.6, 1.0, 0.7], [-6.8, -2.4, 0.9], [1.9, 5.4, 0.4], [-3.4, 4.6, 0.5]].forEach(([rx, rz, r], i) => {
    const f = (x, y, z) => Math.hypot((x - rx) / 1.25, (y - r * 0.35) / 0.8, (z - rz)) - r - 0.12 * (noise3(x * 2.5, y * 2.5 + i, z * 2.5) - 0.5);
    add({ name: 'rocha', f, min: [rx - r * 1.5, -0.1, rz - r * 1.2], max: [rx + r * 1.5, r * 1.2, rz + r * 1.2], mat: MAT.STONE, spacing: 0.04, flow: [1, 0.2, 0],
      detail: (p, n) => (n[1] > 0.6 && noise3(p[0] * 3, p[2] * 3, i) > 0.5 ? { mat: MAT.MOSS } : null) });
  });
  return P;
}


/** Colisores estáticos no plano do chão (x,z). */
export const COLLIDERS = [
  { type: 'box', x0: -11, z0: -7, x1: 11, z1: WALL_Z + 0.05 },
  { type: 'box', x0: -4.8, z0: WALL_Z - 0.2, x1: -3.8, z1: WALL_Z + 0.95 },
  { type: 'box', x0: 3.8, z0: WALL_Z - 0.2, x1: 4.8, z1: WALL_Z + 0.95 },
  { type: 'circle', x: -3.3, z: -1.5, r: 0.5 },
  { type: 'circle', x: 4.3, z: 0.2, r: 0.35 },
  { type: 'circle', x: -1.45, z: 1.35, r: 0.55 },
  { type: 'circle', x: 3.0, z: 3.6, r: 0.38 }, { type: 'circle', x: 4.3, z: 4.3, r: 0.38 }, { type: 'circle', x: 5.5, z: 3.3, r: 0.38 },
  { type: 'circle', x: -5.6, z: 2.2, r: 0.7 }, { type: 'circle', x: 6.6, z: 1.0, r: 0.85 }, { type: 'circle', x: -6.8, z: -2.4, r: 1.1 }, { type: 'circle', x: 1.9, z: 5.4, r: 0.5 }, { type: 'circle', x: -3.4, z: 4.6, r: 0.6 },
];
export const BOUNDS = { x0: -10.5, z0: -4.4, x1: 10.5, z1: 9 };
export const LIGHTS = [
  { name: 'braseiro', pos: [-1.45, 1.6, 1.35], col: [1.0, 0.55, 0.22], radius: 7.5, base: 1.6, flicker: 0.28 },
  { name: 'tocha', pos: [-2.1, 2.55, WALL_Z + 0.45], col: [1.0, 0.5, 0.2], radius: 4.8, base: 1.15, flicker: 0.35 },
  { name: 'tocha', pos: [2.1, 2.55, WALL_Z + 0.45], col: [1.0, 0.5, 0.2], radius: 4.8, base: 1.15, flicker: 0.35 },
];
