// ASHEN 3D — teste de jogabilidade: abertura, tocha, caixotes/escudo, troca de mão, rolamento, chefe.
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await browser.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 2.625, isMobile: true, hasTouch: true });
const page = await ctx.newPage();
const logs = [];
page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') logs.push(`[${m.type()}] ${m.text()}`); });
page.on('pageerror', e => logs.push(`[pageerror] ${e.message}`));
const t0 = Date.now();
await page.goto('http://localhost:8123/');
await page.waitForFunction(() => window.__ASHEN && window.__ASHEN.ready, null, { timeout: 300000 });
console.log('carregou em', ((Date.now() - t0) / 1000).toFixed(1), 's');
const g = (f, a) => page.evaluate(f, a);
await page.tap('#start');
// abertura: 3 quadros
for (const [n, t] of [['abert-1', 3], ['abert-2', 10], ['abert-3', 17], ['abert-5', 36]]) {
  await g(t => { window.__ASHEN.cinema.cur.t = t; }, t); await page.waitForTimeout(900);
  await page.screenshot({ path: `/tmp/c-${n}.png` });
}
await page.tap('#cine-skip'); await page.waitForTimeout(800);
await page.screenshot({ path: '/tmp/c-tocha.png' });
// quebra caixotes até achar o escudo (teleporta e golpeia)
const out = await g(async () => {
  const G = window.__ASHEN, p = G.player; let tries = 0;
  for (let w = 0; w < 400 && (p.wake > 0 || p.dead > 0); w++) await new Promise(r => setTimeout(r, 200));
  for (const b of G.breakables) {
    if (p.hasShield || G.pickups.some(x => x.kind === 'shield')) break;
    p.x = b.x; p.z = b.z + 0.9; p.yaw = Math.PI; G.teleported();
    for (let k = 0; k < 4 && b.alive; k++) { G.input.press('attack'); G.input.release('attack'); await new Promise(r => setTimeout(r, 400)); for (let w = 0; w < 80 && G.player.atk >= 0; w++) await new Promise(r => setTimeout(r, 150)); tries++; }
  }
  const sh = G.pickups.find(x => x.kind === 'shield');
  if (sh) { p.x = sh.x; p.z = sh.z; for (let w = 0; w < 60 && !p.hasShield; w++) await new Promise(r => setTimeout(r, 200)); }
  return { tries, quebrados: G.breakables.filter(b => !b.alive).length, escudo: p.hasShield, frascos: p.flaskMax };
});
console.log('caixotes', JSON.stringify(out));
await page.tap('#message-ok').catch(() => {}); await page.tap('#message-ok').catch(() => {});
await page.waitForTimeout(1500);
await page.screenshot({ path: '/tmp/c-escudo.png' });
await g(() => { const G = window.__ASHEN; G.player.offhand = 'shield'; G.player.hasShield = true; G.input.press('block'); });
await page.waitForTimeout(1200);
await page.screenshot({ path: '/tmp/c-bloqueio.png' });
await g(() => { const G = window.__ASHEN; G.input.release('block'); G.input.press('dodge'); G.input.release('dodge'); });
await page.waitForTimeout(350);
await page.screenshot({ path: '/tmp/c-rolar.png' });
await page.waitForTimeout(1500);
// chefe: vai até o túmulo
await g(() => { const G = window.__ASHEN, p = G.player; p.x = -6.8 + 1.5; p.z = 0.25 + 2.5; G.teleported(); });
for (let w = 0; w < 40; w++) { if (await g(() => window.__ASHEN.cinema.active)) break; await page.waitForTimeout(500); }
const cin = await g(() => window.__ASHEN.cinema.active);
for (const [n, t] of [['boss-1', 1.5], ['boss-2', 5.5], ['boss-3', 8.5]]) {
  await g(t => { const c = window.__ASHEN.cinema.cur; if (c) c.t = t; }, t); await page.waitForTimeout(1500);
  await page.screenshot({ path: `/tmp/c-${n}.png` });
}
await page.tap('#cine-skip').catch(() => {});
await page.waitForTimeout(3000);
await page.screenshot({ path: '/tmp/c-luta.png' });
const st = await g(() => { const G = window.__ASHEN; return { luta: G.fight, chefe: G.boss.state, vidaChefe: G.boss.hp, ato: G.boss.act, vida: G.player.hp.toFixed(0) }; });
console.log('cena do chefe:', cin, JSON.stringify(st));
console.log(logs.slice(0, 20).join('\n') || '(sem erros)');
await browser.close();
