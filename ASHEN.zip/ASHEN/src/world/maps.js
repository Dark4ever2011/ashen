// ASHEN — Mapas
// Região I · Reino das Cinzas — "O Portão do Rei" (área da Fase 1).
// Coordenadas em unidades de mundo (u). y cresce para o sul (para baixo na tela).

import { GATE, WALL } from '../art/architecture.js';

const TILT = 0.72;
const GATE_X = 1800, GATE_Y = 820;
export const WALL_Y = GATE_Y - GATE.recess * 10 / TILT; // base da face do bloco central/muralhas

export const ASHEN_GATE = {
  id: 'reino-das-cinzas/portao',
  region: 'I · Reino das Cinzas',
  title: 'O Portão do Rei',
  subtitle: '灰の王国',
  bounds: { x0: 0, y0: 0, x1: 3600, y1: 2600 },
  walk: { x0: 40, y0: WALL_Y, x1: 3560, y1: 2540 },
  camera: { x0: 0, y0: -200, x1: 3600, y1: 2620 },
  // Perto do portão a câmera sobe para enquadrar torres e muralhas.
  framing: { y0: 1320, y1: 900, dy: -250 },
  ambient: [0.52, 0.55, 0.68],
  wind: 16,
  spawn: { x: 1712, y: 1335 },
  path: [[1760, 2560], [1700, 2380], [1745, 2080], [1880, 1760], [1830, 1450], [1800, 1180], [1800, 860]],
  pathWidth: 74,
  plaza: { x0: 1500, y0: WALL_Y, x1: 2100, y1: 1070 },
  graveyard: { x0: 560, y0: 1180, x1: 1300, y1: 1760 },
  scorch: [{ x: 1640, y: 1215, r: 150 }],
  gate: { x: GATE_X, y: GATE_Y },
  objects: [],
};

const O = ASHEN_GATE.objects;
// Muralha principal, portão e fortaleza ao fundo
O.push({ type: 'gate', x: GATE_X, y: GATE_Y });
{
  const segW = WALL.W * 6 - 6;
  const left = GATE_X - GATE.W * 3 + 30, right = GATE_X + GATE.W * 3 - 30;
  let i = 0;
  for (let x = left; x > -segW; x -= segW, i++) O.push({ type: 'wall', x: x - segW / 2, y: WALL_Y, seed: 11 + i, breach: i === 2, buttress: i % 2 ? 40 : 0 });
  i = 0;
  for (let x = right; x < 3600 + segW; x += segW, i++) O.push({ type: 'wall', x: x + segW / 2, y: WALL_Y, seed: 31 + i, breach: i === 1, buttress: i % 2 ? 0 : 20 });
}
O.push({ type: 'keep', x: GATE_X + 140, y: WALL_Y - 120 });
// Tochas e estandartes no bloco do portão
O.push({ type: 'torch', x: GATE_X - 104, y: WALL_Y + 3, z: 205, seed: 1 });
O.push({ type: 'torch', x: GATE_X + 104, y: WALL_Y + 3, z: 205, seed: 2 });
O.push({ type: 'banner', x: GATE_X - 190, y: WALL_Y + 2, z: 446, seed: 3 });
O.push({ type: 'banner', x: GATE_X + 190, y: WALL_Y + 2, z: 446, seed: 4 });
// Braseiro (fonte de luz, futuro ponto de descanso)
O.push({ type: 'brazier', x: 1640, y: 1215 });
// Restos de colunata na praça
O.push({ type: 'pillar', x: 1545, y: 1010, seed: 1, h: 24, lore: 'pillar' });
O.push({ type: 'pillar', x: 2070, y: 1000, seed: 2, h: 18 });
O.push({ type: 'pillar', x: 2105, y: 1160, seed: 3, h: 28 });
O.push({ type: 'pillar', x: 1505, y: 1185, seed: 4, h: 14 });
// Cavaleiro caído encostado na muralha
O.push({ type: 'fallen', x: 2330, y: WALL_Y + 34 });
// Cemitério
const graves = [
  [700, 1260, 0, 'aldren'], [800, 1280, 1], [905, 1250, 2, 'sono'], [1010, 1290, 1], [1120, 1265, 3, 'rei'],
  [660, 1420, 1], [770, 1450, 2], [880, 1410, 0], [990, 1455, 1], [1100, 1430, 2],
  [720, 1600, 1], [840, 1620, 0], [960, 1590, 1], [1180, 1580, 2],
];
for (const [x, y, v, lore] of graves) O.push({ type: 'grave', x, y, v, lore });
O.push({ type: 'pillar', x: 1250, y: 1380, seed: 7, h: 20 });
// Árvores mortas
const trees = [
  [520, 1150, 1, 1.0], [1350, 1220, 2, 0.9], [610, 1720, 3, 1.1], [1260, 1700, 4, 0.95], [420, 1980, 5, 1.15],
  [1020, 2050, 6, 1.0], [1420, 1950, 7, 0.85], [2280, 1380, 8, 1.05], [2620, 1150, 9, 1.1], [2950, 1420, 10, 1.0],
  [3260, 1180, 11, 1.2], [2460, 1980, 12, 1.0], [2900, 2120, 13, 1.1], [3300, 1900, 14, 0.95], [220, 1400, 15, 1.1],
  [2150, 2300, 16, 0.9], [1250, 2380, 17, 1.0], [600, 2350, 18, 1.15], [3150, 2420, 19, 1.0], [2600, 2480, 20, 1.1],
  [1950, 1520, 21, 0.8], [180, 2220, 22, 1.0], [3450, 1650, 23, 1.05],
];
for (const [x, y, seed, size] of trees) O.push({ type: 'tree', x, y, seed, size });
// Rochas
const rocks = [
  [1480, 1340, 1, 12, 7], [2180, 1250, 2, 9, 5], [2440, 1640, 3, 16, 9], [1580, 1620, 4, 8, 5], [1990, 1950, 5, 11, 6],
  [2750, 1300, 6, 14, 8], [3080, 1750, 7, 10, 6], [400, 1620, 8, 13, 7], [820, 1900, 9, 9, 5], [1360, 2140, 10, 15, 8],
  [2720, 1760, 11, 8, 4], [3380, 1360, 12, 12, 7], [300, 1180, 13, 10, 6], [2380, 1050, 14, 9, 5], [1160, 1080, 15, 11, 6],
  [1900, 2330, 16, 13, 7], [2840, 2300, 17, 10, 5], [520, 2140, 18, 8, 5], [3480, 2100, 19, 12, 6], [1640, 2250, 20, 7, 4],
];
for (const [x, y, seed, w, h] of rocks) O.push({ type: 'rock', x, y, seed, w, h });

// Textos (narrativa ambiental). Escritos para a história original de ASHEN.
export const LORE = {
  brazierUnlit: 'As brasas ainda guardam calor. Ao tocá-las, a chama desperta — como se reconhecesse o juramento gravado em seu peito.',
  brazierLit: 'O fogo crepita. Por um instante você lembra de um nome… e ele se desfaz em cinzas antes de chegar à boca.',
  gate: 'A grade de ferro está selada. Na pedra-chave, o selo do rei: 王. Abaixo, riscado com a ponta de uma espada: «Só o último juramento abre o que o primeiro fechou.»',
  aldren: '«Aqui jaz Ser Aldren, Escudo do Leste. Guardou a palavra até a última cinza.»',
  sono: 'O nome foi raspado da pedra. Restou apenas um ideograma: 眠 — dormir.',
  rei: 'Um túmulo com o selo real, vazio. A terra foi revolvida… de dentro para fora.',
  fallen: 'Um cavaleiro tombado contra a muralha. A armadura é idêntica à sua — até o 誓 gravado no peito. Sob o elmo, apenas cinzas.',
  pillar: 'Restos de uma colunata. Na base, quase apagado: «Ao rei que jurou, e ao reino que ardeu por ele.»',
};
