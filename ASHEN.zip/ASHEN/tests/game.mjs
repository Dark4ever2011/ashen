// Teste de fumaça do jogo no Chrome headless (Playwright).
// node tests/game.mjs <url> <prefixo_saida> [mobile=1|0]
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const [url, out, mobileArg = '1'] = process.argv.slice(2);
const mobile = mobileArg === '1';
const browser = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await browser.newContext(mobile
  ? { viewport: { width: 915, height: 412 }, deviceScaleFactor: 2.625, isMobile: true, hasTouch: true, userAgent: 'Mozilla/5.0 (Linux; Android 14; SM-A566B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Mobile Safari/537.36' }
  : { viewport: { width: 1600, height: 900 }, deviceScaleFactor: 1 });
const page = await ctx.newPage();
const logs = [];
page.on('console', m => logs.push(`[${m.type()}] ${m.text()}`));
page.on('pageerror', e => logs.push(`[pageerror] ${e.message}\n${e.stack}`));
await page.goto(url, { waitUntil: 'load' });
await page.waitForFunction(() => window.__ASHEN && window.__ASHEN.state === 'title', null, { timeout: 60000 });
await page.waitForTimeout(800);
await page.screenshot({ path: `${out}-title.png` });
await (mobile ? page.tap('#start') : page.click('#start'));
await page.waitForTimeout(6500);
await page.screenshot({ path: `${out}-play.png` });
const st = await page.evaluate(() => { const g = window.__ASHEN; return { state: g.state, x: g.player.x, y: g.player.y, W: g.renderer.W, H: g.renderer.H, S: g.renderer.S }; });
console.log('estado', JSON.stringify(st));
console.log(logs.join('\n') || '(sem logs)');
await browser.close();
