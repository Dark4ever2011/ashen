# ASHEN — The Last Oath · 最後の誓い

Action RPG Soulslike dark fantasy, em perspectiva 3/4, **desenhado inteiramente com caracteres** (ASCII, blocos e box-drawing Unicode, kanji). Os caracteres são os próprios gráficos: armaduras gravadas em hachura `╱ ╳ ·`, muralhas em cantaria `▏▁`, fogo `^ * § 火`, névoa `░ ~ ≈`, cinzas `· ˙ ∙`.

Roda no Chrome para Android (referência: Galaxy A56 / Exynos 1580), no navegador do computador e como app instalável (PWA, funciona offline). Sem servidor, sem dependências, sem build.

**Estado atual:** v0.14.0 — Motor Three.js: o mundo é desenhado em 3D sólido e um pós-processamento transforma a tela em caracteres (menos o chão). O motor antigo continua no menu como *Clássico*. Veja `PROGRESS.md`.

Three.js (MIT) vai embutido em `src/vendor/three/` — o jogo continua sem servidor, sem build e funcionando offline.

---

## Jogar

| | Celular (paisagem) | Computador |
|---|---|---|
| Andar | joystick: toque e arraste na metade esquerda | WASD / setas, ou segurar o botão esquerdo do mouse |
| Correr | segurar **»** (dá para usar junto com o joystick) | Shift |
| Interagir | **◈** (acende quando há algo perto) | E, ou clicar no objeto (o cavaleiro anda até ele) |
| Menu / configurações | **≡** ou o gesto "voltar" do Android | Esc |
| Painel de desempenho | menu → *Mostrar desempenho* | F3 |

As teclas podem ser trocadas no menu. Configurações gráficas: **Alta** (padrão), **Equilibrada** e **Desempenho** — as três preservam armaduras, personagens e arquitetura; só mudam resolução interna, mapa de luz e efeitos secundários.

---

## Publicar no GitHub Pages usando só o celular

1. No Chrome do celular, entre em github.com e crie um repositório (ex.: `ashen`), público, com README.
2. No repositório: **Add file → Create new file**. Nome: `.github/workflows/publicar.yml`. Cole o conteúdo do arquivo de mesmo nome que está neste projeto. **Commit changes**.
3. **Settings → Pages → Build and deployment → Source: GitHub Actions**.
4. Volte ao código: **Add file → Upload files** e envie o arquivo **`ASHEN.zip`** inteiro (não precisa extrair). **Commit changes**.
5. Aba **Actions**: o workflow *Publicar ASHEN* extrai o zip, faz o commit dos arquivos e publica. Em ~1 minuto o jogo fica em `https://SEU-USUARIO.github.io/ashen/`.
6. No Chrome, abra o endereço → menu ⋮ → **Adicionar à tela inicial / Instalar app**. Depois do primeiro carregamento, funciona offline.

Para atualizar: envie um `ASHEN.zip` novo (passo 4) — o mesmo workflow cuida do resto. Se quiser editar arquivos direto no celular, o editor web do GitHub (ícone de lápis) funciona bem para arquivos pequenos; para um fluxo com Git completo no Android, o app **Spck Editor** importa zip e faz push.

> Ao publicar uma versão nova, aumente o nome do cache em `service-worker.js` (ex.: `ashen-v0.1.1`) para os aparelhos baixarem os arquivos novos.

---

## Validar no Galaxy A56 (o que ainda depende do aparelho)

1. Abra o jogo, toque em **despertar**, menu **≡ → Mostrar desempenho**.
2. Ande por 5–10 minutos (cemitério, braseiro, portão). O painel mostra FPS, tempo de lógica e de desenho, **custo de cada passe** (chão, sombras, objetos, névoa, luz…), memória de canvas e a média de FPS a cada 10 s. Se o FPS cair com o aparelho esquentando, aparece um aviso sugerindo *Equilibrada* — o jogo nunca reduz a qualidade sozinho.
3. Abra `tools/glyph-test.html`: mede pixel a pixel se cada caractere (inclusive os kanji) cabe na sua célula **com as fontes do seu Android**. Tudo deve ficar verde.
4. `tools/sprite-viewer.html` mostra o cavaleiro em todas as vistas e animações — útil para editar a arte.

---

## Estrutura

```
index.html · manifest.json · service-worker.js · styles/main.css
assets/fonts/      DejaVu Sans Mono (embutida; licença em LICENSE-DejaVu.txt)
assets/icons/      ícones PWA (誓)
src/main.js        laço (rAF + delta time, física em passo fixo 60 Hz, limite de FPS), passes de desenho
src/config.js      constantes (projeção, células, velocidades)
src/engine/        typography (larguras simples/dupla, fontes, encaixe de glifos), renderer, camera,
                   sprite (arte, composição, cache LRU), palette (materiais + hachuras), lighting,
                   particles, atmosphere (névoa), physics, input, animation, perf, canvas
src/art/           knight (peças da armadura por vista), cape, props, architecture
src/entities/      knight-rig (esqueleto tipográfico), player
src/world/         world, maps (Reino das Cinzas — Portão do Rei), objects, terrain
src/ui/            hud, menus, controls, settings, logo
src/systems/       save (localStorage)
tools/             sprite-viewer, glyph-test, make_icons.py
tests/             unit.mjs (Node) + testes de navegador com Playwright
```

Dados de arte ficam em módulos JS (não JSON) para permitir comentários de edição e carregar sem `fetch`.

### Como editar a armadura
Em `src/art/knight.js`, cada peça é uma lista de linhas `[glifos, materiais]`. Dígitos `0–5` nos glifos viram hachura de aço automaticamente (1 = iluminado, 5 = sombra). Códigos de material estão em `src/engine/palette.js`. Abra `tools/sprite-viewer.html` para ver o resultado.

### Testes (num computador, opcional)
```
node tests/unit.mjs                       # 221 verificações, sem navegador
python3 -m http.server 8123               # servidor local
node tests/play.mjs                       # toque real: joystick, multitoque, interação (emulação A56)
node tests/desktop.mjs                    # teclado, mouse, menu, troca de tecla
node tests/offline.mjs                    # PWA offline
node tests/soak.mjs http://localhost:8123/index.html 45   # sessão longa, giro de tela
```
Os testes de navegador usam Playwright.

---

## Modelos .glb (Fase 3)

Coloque os arquivos em `assets/models/` com o nome do personagem e envie o zip:

| Arquivo | Personagem |
|---|---|
| `knight.glb` / `samurai.glb` | jogador (conforme a classe do save) |
| `ghoul.glb`, `skeleton.glb` | mortos e esqueletos (vale, mundo aberto, cripta) |
| `goblin.glb`, `goblinKing.glb` | goblins e o Rei Goblin |
| `boss.glb`, `profano.glb`, `ogre.glb`, `spider.glb`, `hood.glb` | chefes e criaturas |
| `man.glb`, `woman.glb`, `lady.glb` | aldeões |

Sem o arquivo (ou se ele falhar), aquele personagem continua com o corpo atual. Todas as cópias do personagem usam o
modelo, cada uma com seu esqueleto e sua animação: jogador, aldeões, mortos e esqueletos, goblins, inimigos da cripta e
os chefes (Rei, Profano, Ogro, Aranha, Rei Goblin). Ficam sempre com o corpo atual: o cavaleiro caído e Ser Caedmon.

- **Visual:** a cor/textura do arquivo fica, e por cima entram os caracteres gravados em relevo com brilho da luz,
  como no resto do jogo. O tipo de caractere vem do **nome do material** no .glb (ex.: `armadura`/`steel`/`metal`,
  `capa`/`cloth`, `couro`/`leather`, `pele`/`skin`, `ouro`/`gold`, `cabelo`/`hair`, `osso`/`bone`); sem nome, da cor e do metal.
- **Jogador com .glb:** a capa e o tabardo do jogo somem — vale a roupa do modelo. Sem .glb, voltam.
- **Formato:** 1 personagem, em pé, de frente para +Z (padrão do Mixamo), qualquer escala (a altura é ajustada à do
  corpo atual). Até ~30 mil triângulos e texturas de até 2K.
- **Animações** (nome padrão OU o do Mixamo; lista completa em `src/render3/animation-names.js`):
  `Idle`, `Walk`, `Run`, `Attack1`, `Attack2`, `Attack3`, `Roll`, `Block`, `Hit`, `Death`, `Heal`
  — ex.: "Sword And Shield Idle", "Sword And Shield Slash", "Stand To Roll", "Great Sword Death".
  Faltou alguma? Aquele estado fica na animação anterior; sem `Run`, usa `Walk`. Nos inimigos: morte, golpe recebido e
  ataque vêm do combate; parado/andar/correr, da velocidade.
- **Mãos:** a tocha e o escudo vão para a mão esquerda do modelo; se o modelo não tiver espada própria, a espada do
  jogo aparece na mão direita. Nomes de mão aceitos: `mixamorig:LeftHand`/`mixamorigLeftHand`, `LeftHand`, `Hand_L`,
  `hand.L` (e os equivalentes da direita).
- **Espada própria:** um osso/objeto chamado `Sword`, `Weapon`, `Espada` ou `Katana` (ponta em `SwordTip`); com ela,
  a espada do jogo não aparece.
- **Chefes:** Profano, Aranha e Encapuzado usam alturas fixas (2,3 m, 1,3 m, 1,8 m), porque o esqueleto do jogo deles
  não é humano; os demais copiam a altura do corpo atual.
- **Mixamo:** baixe cada animação "with skin" em FBX e junte tudo num .glb (ex.: Blender → Exportar glTF 2.0 binário),
  dando a cada ação o nome da tabela acima.
