// ASHEN 3D — Atmosfera em caracteres: fogo, brasas, fumaça, cinzas e névoa.
// Partículas no espaço 3D (sem iluminação própria). Névoa e fumaça usam transparência,
// fogo e brasas usam soma de luz (aditivo).

export class FX {
  constructor(atlas, max = 2600) {
    this.max = max;
    this.list = [];
    this.data = new Float32Array(max * 10);
    this.g = s => [...s].map(c => atlas.get(c));
    this.FIRE = this.g('火炎^*§~^*');
    this.EMBER = this.g('·•*·✶');
    this.SMOKE = this.g('~≈∼°~');
    this.ASH = this.g('·˙`,·');
    this.FOG = this.g('~≈∼~');
    this.DUST = this.g('·˙‧.');
    this.RAIN = this.g('|¦╎|');
    this.SPLASH = this.g('·˙\'.');
    this.STEAM = this.g('~≈∼°');
    this.LEAF = this.g('‹›,~');
    this.SLASH = this.g('─━═─');
    this.rain = 0;                // 0..1 (clima)
    this.trees = [];              // copas de outono: [x, y, z, r]
    this.leafRate = 0;
    this.sources = [];
    this.wind = [0.35, 0, 0.12];
    this.density = 1;
    this.acc = new Map();
  }
  addFire(pos, radius, rate, smoke = 0) { const s = { pos, radius, rate, smoke, off: false }; this.sources.push(s); return s; }
  /** Rastro da lâmina durante o golpe (aditivo, some em ~0,2 s). */
  slash(a, b) {
    for (let i = 0; i < 3; i++) { const k = Math.random(); this._spawn({ k: 'slash', p: [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k], v: [0, 0, 0], life: 0, ttl: 0.16 + Math.random() * 0.08, size: 0.09, g: this.SLASH[(Math.random() * 4) | 0], rot: Math.atan2(b[1] - a[1], b[0] - a[0]) }); }
  }
  /** Lascas de madeira/pedra voando (caixote quebrado). */
  splinters(pos, col, n = 40) {
    const G = this.g('‡/\\=#,\'');
    for (let i = 0; i < n; i++) { const a = Math.random() * 6.28, s = 1 + Math.random() * 2.5; this._spawn({ k: 'chip', p: [pos[0], pos[1] + Math.random() * 0.4, pos[2]], v: [Math.cos(a) * s, 1.5 + Math.random() * 2.5, Math.sin(a) * s], life: 0, ttl: 0.8 + Math.random() * 0.8, size: 0.06 + Math.random() * 0.05, g: G[(Math.random() * G.length) | 0], rot: Math.random() * 6.28, col }); }
  }
  /** Muralha de névoa da arena (anel). */
  fogRing(c, r, dt) {
    for (let i = 0; i < dt * 60; i++) { const a = Math.random() * 6.28; this._spawn({ k: 'wall', p: [c[0] + Math.cos(a) * r, 0.1 + Math.random() * 2.2, c[1] + Math.sin(a) * r], v: [0, 0.15 + Math.random() * 0.2, 0], life: 0, ttl: 2 + Math.random() * 1.5, size: 0.35 + Math.random() * 0.4, g: this.FOG[(Math.random() * this.FOG.length) | 0], rot: Math.random() * 6.28, seed: Math.random() * 100 }); }
  }
  /** Chamas espectrais violeta (o rei morto-vivo). */
  spirit(pos, n = 2) {
    for (let i = 0; i < n; i++) this._spawn({ k: 'spirit', p: [pos[0] + (Math.random() - 0.5) * 0.4, pos[1] + (Math.random() - 0.5) * 0.3, pos[2] + (Math.random() - 0.5) * 0.4], v: [(Math.random() - 0.5) * 0.2, 0.6 + Math.random() * 0.6, (Math.random() - 0.5) * 0.2], life: 0, ttl: 0.6 + Math.random() * 0.5, size: 0.1 + Math.random() * 0.1, g: this.FIRE[(Math.random() * this.FIRE.length) | 0], rot: (Math.random() - 0.5) * 0.5 });
  }
  /** Cinzas e terra subindo (o túmulo se abrindo, o chefe virando pó). */
  dirt(pos, n = 60, up = 2) {
    for (let i = 0; i < n; i++) { const a = Math.random() * 6.28, s = Math.random() * 1.6; this._spawn({ k: 'chip', p: [pos[0] + Math.cos(a) * 0.5, pos[1], pos[2] + Math.sin(a) * 0.5], v: [Math.cos(a) * s, up * (0.5 + Math.random()), Math.sin(a) * s], life: 0, ttl: 1 + Math.random(), size: 0.05 + Math.random() * 0.06, g: this.ASH[(Math.random() * this.ASH.length) | 0], rot: 0, col: [0.4, 0.36, 0.32] }); }
  }
  /** Faíscas de impacto (lâmina no alvo, aparar). */
  sparks(pos, n = 14, col = [1, 0.8, 0.45]) {
    for (let i = 0; i < n; i++) { const a = Math.random() * 6.28, b = Math.random() * 3; this._spawn({ k: 'spark', p: pos.slice(), v: [Math.cos(a) * b, 1 + Math.random() * 2, Math.sin(a) * b], life: 0, ttl: 0.25 + Math.random() * 0.25, size: 0.05, g: this.EMBER[(Math.random() * this.EMBER.length) | 0], rot: 0, col }); }
  }
  /** Faíscas ao acender o braseiro. */
  burst(pos, n = 60) {
    for (let i = 0; i < n; i++) { const a = Math.random() * 6.28, s = 0.5 + Math.random() * 1.8; this._spawn({ k: 'ember', p: pos.slice(), v: [Math.cos(a) * s * 0.5, 1 + Math.random() * 2.2, Math.sin(a) * s * 0.5], life: 0, ttl: 0.8 + Math.random() * 1.2, size: 0.04 + Math.random() * 0.03, g: this.EMBER[(Math.random() * this.EMBER.length) | 0], rot: 0 }); }
  }
  _spawn(o) { if (this.list.length < this.max) this.list.push(o); }

  update(dt, t, focus) {
    const R = Math.random;
    for (const s of this.sources) {
      if (s.off || (s.area && s.area !== this.area)) continue;
      const k = (this.acc.get(s) || 0) + dt * s.rate * (1 - this.rain * 0.45);
      let n = Math.floor(k); this.acc.set(s, k - n);
      while (n-- > 0) {
        const a = R() * 6.28, r = Math.sqrt(R()) * s.radius;
        this._spawn({ k: 'fire', p: [s.pos[0] + Math.cos(a) * r, s.pos[1], s.pos[2] + Math.sin(a) * r], v: [(R() - 0.5) * 0.2, 0.7 + R() * 0.8, (R() - 0.5) * 0.2], life: 0, ttl: 0.5 + R() * 0.55, size: (0.12 + R() * 0.12) * (s.radius > 0.1 ? 1.4 : 0.8), g: this.FIRE[(R() * this.FIRE.length) | 0], rot: (R() - 0.5) * 0.5 });
        if (R() < 0.12) this._spawn({ k: 'ember', p: [s.pos[0] + Math.cos(a) * r, s.pos[1] + 0.2, s.pos[2] + Math.sin(a) * r], v: [(R() - 0.5) * 0.4, 0.9 + R() * 0.9, (R() - 0.5) * 0.4], life: 0, ttl: 1.6 + R() * 1.6, size: 0.035 + R() * 0.03, g: this.EMBER[(R() * this.EMBER.length) | 0], rot: 0 });
        if (s.smoke && R() < s.smoke) this._spawn({ k: 'smoke', p: [s.pos[0] + (R() - 0.5) * 0.2, s.pos[1] + 0.5, s.pos[2] + (R() - 0.5) * 0.2], v: [0, 0.35 + R() * 0.25, 0], life: 0, ttl: 3 + R() * 2, size: 0.18, g: this.SMOKE[(R() * this.SMOKE.length) | 0], rot: R() * 6.28 });
      }
    }
    // chuva: gotas num volume em volta do foco; ao tocar o chão viram respingos
    const wantRain = Math.round(900 * this.rain * this.density);
    let rain = 0; for (const p of this.list) if (p.k === 'rain') rain++;
    for (let i = 0; rain < wantRain && i < 80; i++, rain++) {
      const sp = 8 + R() * 3;
      this._spawn({ k: 'rain', p: [focus[0] + (R() - 0.5) * 18, 2 + R() * 6, focus[2] + (R() - 0.65) * 15], v: [this.wind[0] * 2.2, -sp, this.wind[2] * 2.2], life: 0, ttl: 2, size: 0.16 + R() * 0.08, g: this.RAIN[(R() * this.RAIN.length) | 0], rot: Math.atan2(this.wind[0] * 2.2, sp) });
    }
    // vapor sobe das chamas quando chove
    if (this.rain > 0.15) for (const s of this.sources) if (R() < dt * s.rate * 0.05 * this.rain) this._spawn({ k: 'steam', p: [s.pos[0] + (R() - 0.5) * s.radius * 2, s.pos[1] + 0.15, s.pos[2] + (R() - 0.5) * s.radius * 2], v: [0, 0.5 + R() * 0.4, 0], life: 0, ttl: 1.6 + R(), size: 0.16 + R() * 0.1, g: this.STEAM[(R() * this.STEAM.length) | 0], rot: R() * 6.28, seed: R() * 100 });
    // folhas de outono soltas pelas rajadas (e pela chuva)
    const lr = this.leafRate * (0.5 + this.rain);
    for (const c of this.trees) if (R() < dt * lr) this._spawn({ k: 'leaf', p: [c[0] + (R() - 0.5) * c[3] * 1.6, c[1] + (R() - 0.5) * c[3], c[2] + (R() - 0.5) * c[3] * 1.6], v: [0, -0.4, 0], life: 0, ttl: 9 + R() * 6, size: 0.08 + R() * 0.04, g: this.LEAF[(R() * this.LEAF.length) | 0], rot: R() * 6.28, seed: R() * 100, col: c[4] });
    // cinzas e névoa mantidas em volta do foco
    let ash = 0, fog = 0, dust = 0;
    for (const p of this.list) { if (p.k === 'ash') ash++; else if (p.k === 'fog') fog++; else if (p.k === 'dust') dust++; }
    const wantDust = Math.round(140 * this.density);
    for (let i = 0; dust < wantDust && i < 20; i++, dust++) this._spawn({ k: 'dust', p: [focus[0] + (R() - 0.5) * 20, 0.02 + R() * 0.22, focus[2] + (R() - 0.6) * 16], v: [0, 0, 0], life: 0, ttl: 6 + R() * 8, size: 0.025 + R() * 0.025, g: this.DUST[(R() * this.DUST.length) | 0], rot: 0, seed: R() * 100 });
    const wantAsh = Math.round(300 * this.density), wantFog = Math.round(110 * this.density);
    for (let i = 0; ash < wantAsh && i < 30; i++, ash++) this._spawn({ k: 'ash', p: [focus[0] + (R() - 0.5) * 22, 0.3 + R() * 5, focus[2] + (R() - 0.6) * 18], v: [0, -0.25 - R() * 0.3, 0], life: 0, ttl: 10 + R() * 10, size: 0.035 + R() * 0.06, g: this.ASH[(R() * this.ASH.length) | 0], rot: R() * 6.28, seed: R() * 100 });
    for (let i = 0; fog < wantFog && i < 20; i++, fog++) this._spawn({ k: 'fog', p: [focus[0] + (R() - 0.5) * 24, 0.15 + R() * 0.9, focus[2] + (R() - 0.6) * 20], v: [0, 0, 0], life: 0, ttl: 14 + R() * 12, size: 0.6 + R() * 0.7, g: this.FOG[(R() * this.FOG.length) | 0], rot: (R() - 0.5) * 0.4, seed: R() * 100 });
    const w = this.wind;
    for (let i = this.list.length - 1; i >= 0; i--) {
      const p = this.list[i];
      p.life += dt;
      if (p.life > p.ttl) { this.list[i] = this.list[this.list.length - 1]; this.list.pop(); continue; }
      if (p.k === 'fire') { p.v[0] += w[0] * dt * 0.8; p.v[1] += 0.6 * dt; }
      else if (p.k === 'ember') { p.v[0] += (Math.sin(t * 3 + i) * 0.8 + w[0]) * dt; p.v[2] += Math.cos(t * 2.3 + i) * 0.6 * dt; p.v[1] *= 1 - dt * 0.3; }
      else if (p.k === 'smoke') { p.v[0] = w[0] * 0.8; p.size += dt * 0.12; }
      else if (p.k === 'ash') {
        // cinzas maiores caem mais devagar e planam; perto do fogo, sobem na corrente quente
        const heavy = 1.3 - p.size * 8;
        let up = 0;
        for (const s of this.sources) { const d = Math.hypot(p.p[0] - s.pos[0], p.p[2] - s.pos[2]); if (d < 1.4 && s.radius > 0.1) up += (1.4 - d) * 0.9; }
        p.v[1] = (-0.12 - 0.32 * heavy) + up + Math.sin(t * 1.3 + p.seed) * 0.06;
        p.v[0] = w[0] * (0.6 + 0.8 * Math.sin(p.seed)) + Math.sin(t * 0.9 + p.seed) * 0.25;
        p.v[2] = w[2] + Math.cos(t * 0.7 + p.seed) * 0.15;
        p.rot += dt * Math.sin(p.seed) * 1.5;
        if (p.p[1] < 0.02) { p.v[1] = 0; p.v[0] = p.v[2] = 0; }
      }
      else if (p.k === 'fog') { p.v[0] = w[0] * 0.5 + Math.sin(t * 0.2 + p.seed) * 0.1; p.v[2] = w[2] * 0.3 + Math.cos(t * 0.13 + p.seed) * 0.05; p.v[1] = Math.sin(t * 0.4 + p.seed) * 0.04; p.rot = Math.sin(t * 0.15 + p.seed) * 0.25; }
      else if (p.k === 'rain') {
        if (p.p[1] <= 0.02) {
          if (R() < 0.35) this._spawn({ k: 'splash', p: [p.p[0], 0.03, p.p[2]], v: [(R() - 0.5) * 0.6, 0.6 + R() * 0.5, (R() - 0.5) * 0.6], life: 0, ttl: 0.18 + R() * 0.1, size: 0.05, g: this.SPLASH[(R() * this.SPLASH.length) | 0], rot: 0 });
          p.life = p.ttl; continue;
        }
      }
      else if (p.k === 'splash') p.v[1] -= 9.8 * dt;
      else if (p.k === 'steam') { p.v[0] = w[0] * 0.6; p.size += dt * 0.15; }
      else if (p.k === 'leaf') {
        // folha caindo: plana em zigue-zague, gira, troca de face (símbolo) enquanto cai
        if (p.p[1] > 0.02) {
          p.v[1] = -0.35 - 0.25 * Math.abs(Math.sin(t * 2 + p.seed)) - this.rain * 0.5;
          p.v[0] = w[0] * 1.4 + Math.sin(t * 2.6 + p.seed) * 0.5; p.v[2] = w[2] * 1.4 + Math.cos(t * 2.1 + p.seed) * 0.35;
          p.rot += dt * 3 * Math.sin(p.seed);
          if (Math.sin(t * 5 + p.seed) > 0.97) p.g = this.LEAF[(R() * this.LEAF.length) | 0];
        } else { p.v[0] = p.v[1] = p.v[2] = 0; p.p[1] = 0.02; }
      }
      else if (p.k === 'slash') { p.v[0] *= 0.9; p.v[2] *= 0.9; }
      else if (p.k === 'chip' || p.k === 'spark') { p.v[1] -= 9.8 * dt; if (p.p[1] < 0.02) { p.p[1] = 0.02; p.v[0] *= 0.6; p.v[2] *= 0.6; p.v[1] = Math.abs(p.v[1]) * 0.25; } p.rot += dt * 6; }
      else if (p.k === 'spirit') { p.v[0] += w[0] * dt * 0.5; }
      else if (p.k === 'wall') { p.rot += dt * 0.3; }
      else if (p.k === 'dust') { p.v[0] = w[0] * (0.8 + Math.sin(t * 2 + p.seed) * 0.6); p.v[2] = w[2] + Math.cos(t * 1.7 + p.seed) * 0.2; p.v[1] = Math.sin(t * 3 + p.seed) * 0.05; }
      p.p[0] += p.v[0] * dt; p.p[1] += p.v[1] * dt; p.p[2] += p.v[2] * dt;
      if ((p.k === 'ash' || p.k === 'fog' || p.k === 'dust' || p.k === 'rain' || p.k === 'leaf') && (Math.abs(p.p[0] - focus[0]) > 13 || Math.abs(p.p[2] - focus[2]) > 12)) p.life = p.ttl;
    }
  }

  /** Preenche o buffer: primeiro os transparentes (névoa, fumaça, cinzas), depois os aditivos. */
  fill() {
    const d = this.data;
    let n = 0;
    const put = (p, r, g, b, a, size) => {
      const o = n * 10;
      d[o] = p.p[0]; d[o + 1] = p.p[1]; d[o + 2] = p.p[2]; d[o + 3] = size;
      d[o + 4] = r; d[o + 5] = g; d[o + 6] = b; d[o + 7] = a; d[o + 8] = p.g; d[o + 9] = p.rot; n++;
    };
    for (const p of this.list) {
      const f = p.life / p.ttl;
      const fade = Math.min(1, p.life * 2) * (1 - f);
      if (p.k === 'fog') put(p, 0.34, 0.36, 0.44, (0.11 + 0.06 * Math.sin(p.life * 0.7 + p.seed)) * Math.sin(Math.PI * f), p.size);
      else if (p.k === 'dust') put(p, 0.45, 0.42, 0.4, 0.55 * Math.sin(Math.PI * f), p.size);
      else if (p.k === 'smoke') put(p, 0.18, 0.17, 0.18, 0.35 * (1 - f), p.size);
      else if (p.k === 'ash') put(p, 0.55, 0.53, 0.52, 0.75 * Math.min(1, p.life) * (f > 0.9 ? (1 - f) * 10 : 1), p.size);
      else if (p.k === 'rain') put(p, 0.55, 0.6, 0.72, 0.55, p.size);
      else if (p.k === 'splash') put(p, 0.6, 0.65, 0.75, 0.7 * (1 - f), p.size);
      else if (p.k === 'steam') put(p, 0.7, 0.7, 0.72, 0.3 * Math.sin(Math.PI * f), p.size);
      else if (p.k === 'chip') { const c = p.col || [0.5, 0.4, 0.3]; put(p, c[0], c[1], c[2], 1 - f * f, p.size); }
      else if (p.k === 'wall') put(p, 0.5, 0.46, 0.6, 0.35 * Math.sin(Math.PI * f), p.size);
      else if (p.k === 'leaf') { const c = p.col || [0.6, 0.25, 0.1]; put(p, c[0], c[1], c[2], Math.min(1, p.life * 3) * (f > 0.85 ? (1 - f) / 0.15 : 1), p.size); }
    }
    const normal = n;
    for (const p of this.list) {
      const f = p.life / p.ttl;
      if (p.k === 'fire') {
        const r = 1, g = 0.85 - f * 0.6, b = 0.45 - f * 0.42;
        put(p, r * (1 - f * 0.3), Math.max(0.15, g), Math.max(0.02, b), 1 - f, p.size * (1 - f * 0.55));
      } else if (p.k === 'ember') put(p, 1, 0.55 - f * 0.3, 0.15, (1 - f) * (0.6 + 0.4 * Math.sin(p.life * 20)), p.size);
      else if (p.k === 'slash') put(p, 1, 0.9, 0.7, (1 - f) * 0.8, p.size * (1 - f * 0.5));
      else if (p.k === 'spark') { const c = p.col; put(p, c[0], c[1], c[2], 1 - f, p.size); }
      else if (p.k === 'spirit') put(p, 0.6, 0.45, 1, (1 - f) * 0.9, p.size * (1 - f * 0.4));
    }
    return { data: d, count: n, normalCount: normal };
  }
}
