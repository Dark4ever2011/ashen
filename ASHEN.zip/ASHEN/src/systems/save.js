// ASHEN — Salvamento local com 3 espaços (localStorage, com tolerância a falhas).
// Configurações são globais; cada save guarda classe, dificuldade, onde parou e tempo de jogo.

const KEY_SETTINGS = 'ashen.settings.v1';
const KEY_OLD = 'ashen.save.v1';
const KEY_ACTIVE = 'ashen.activeSlot';
const slotKey = n => 'ashen.slot.' + n;

function read(key) { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : null; } catch (e) { return null; } }
function write(key, v) { try { localStorage.setItem(key, JSON.stringify(v)); return true; } catch (e) { return false; } }
function del(key) { try { localStorage.removeItem(key); } catch (e) { /* ok */ } }

// o save antigo (de antes dos 3 espaços) vira o Save 1, como Cavaleiro no Difícil
(function migrate() {
  const old = read(KEY_OLD);
  if (old && !read(slotKey(1))) { write(slotKey(1), { cls: 'knight', diff: 'hard', ...old }); if (!read(KEY_ACTIVE)) write(KEY_ACTIVE, 1); }
  if (old) del(KEY_OLD);
})();

export const Save = {
  loadSettings: () => read(KEY_SETTINGS),
  saveSettings: s => write(KEY_SETTINGS, s),
  active: () => read(KEY_ACTIVE) || 1,
  setActive: n => write(KEY_ACTIVE, n),
  slot: n => read(slotKey(n)),
  slots: () => [1, 2, 3].map(n => read(slotKey(n))),
  newGame: (n, cls, diff) => { write(slotKey(n), { cls, diff, created: Date.now(), playTime: 0, where: 'Início da jornada' }); write(KEY_ACTIVE, n); },
  deleteSlot: n => del(slotKey(n)),
  loadGame: () => read(slotKey(Save.active())),
  saveGame: g => { const n = Save.active(), cur = read(slotKey(n)) || {}; return write(slotKey(n), { ...cur, ...g, savedAt: Date.now(), v: 2 }); },
  clearGame: () => { const n = Save.active(), cur = read(slotKey(n)) || {}; write(slotKey(n), { cls: cur.cls || 'knight', diff: cur.diff || 'hard', created: Date.now(), playTime: 0, where: 'Início da jornada' }); },
};

export const DIFFICULTY = {
  normal: { label: 'Normal', taken: 0.7, dealt: 1.25, speed: 1.0, desc: 'Inimigos causam 30% menos dano e têm 20% menos vida.' },
  hard: { label: 'Difícil', taken: 1.0, dealt: 1.0, speed: 1.0, desc: 'O desafio original do ASHEN.' },
  impossible: { label: 'Impossível', taken: 1.5, dealt: 0.714, speed: 1.15, desc: 'Inimigos causam 50% mais dano, têm 40% mais vida e atacam mais rápido.' },
};
export const CLASSES = {
  knight: { label: 'Cavaleiro', kanji: '騎', desc: 'Espada longa e uma mão livre para tocha ou escudo. Bloqueio firme, golpes pesados.' },
  samurai: { label: 'Samurai', kanji: '侍', desc: 'Katana com as duas mãos: cortes para os lados e de cima para baixo. Três cortes seguidos fazem o inimigo sangrar. Apara com a lâmina.' },
};
