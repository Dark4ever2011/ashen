// ASHEN 3D — Jogabilidade: combate soulslike, tocha/escudo, caixotes, itens, o chefe e as cenas.
// main.js cuida do mundo, do movimento e do desenho; aqui ficam as regras do jogo.

import { m4, v3 } from './math3d.js';
import { PointSet } from './sampler.js';
import { flatBones } from './renderer3d.js';
import { COMBO, swordSegment, makeRoyalMantle } from './knight3d.js';
import { BREAKABLES } from './props3d.js';
import { poseBoss, Boss, BSCALE, BOSS_NAME, BOSS_HP } from './boss3d.js';
import { Cinema, openingScene, bossIntroScene } from './cinema.js';
import { STORY } from './story.js';
import * as W from './world3d.js';
import { MAT } from './glyphs.js';

const $ = id => document.getElementById(id);
const I = m4.ident();
const sm = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };
const ARENA = { x: W.ROYAL_TOMB.x, z: W.ROYAL_TOMB.z + 1.6, r: 6.2 };
const COST = { attack: [14, 14, 24], roll: 22 };
const DMG = [42, 42, 74];

export function initGameplay(g, sets, atlas, saved) {
  const R = g.R, p = g.player;
  Object.assign(p, { hp: 100, hpMax: 100, sta: 100, staMax: 100, staWait: 0, flasks: 1, flaskMax: 1, hasShield: false, offhand: 'torch',
    roll: -1, rollDir: 0, hurt: 0, stun: 0, inv: 0, block: 0, blockStart: -9, heal: -1, healDone: false, swap: -1, swapped: false, dead: 0, wake: 0, kb: [0, 0], riposte: 0, swing: 0 });
  const s = saved || {};
  if (s.hasShield) p.hasShield = true;
  if (s.offhand) p.offhand = s.offhand;
  if (Number.isFinite(s.flaskMax)) { p.flaskMax = s.flaskMax; p.flasks = s.flaskMax; }
  g.bossDefeated = !!s.bossDefeated; g.bossSeen = !!s.bossSeen; g.introSeen = !!s.introSeen; g.shieldDropped = !!s.hasShield;
  const broken = new Set(s.broken || []);
  // tocha e escudo (cada um com sua matriz) + chama e luz da tocha
  g.torchMesh = R.addMesh(sets.torch, { occlude: false });
  g.shieldMesh = R.addMesh(sets.shield, { occlude: false });
  g.torchFire = g.fx.addFire([0, 0, 0], 0.05, 28);
  g.torchLight = { name: 'tocha do cavaleiro', pos: [0, 1.6, 0], col: [1.0, 0.58, 0.25], radius: 6, base: 1.25, flicker: 0.3, level: 1 };
  g.lights.push(g.torchLight);
  // caixotes e destroços
  g.breakables = BREAKABLES.map((b, i) => {
    const M = m4.mul(m4.translate(b.x, 0, b.z), m4.rotY(b.rot || i));
    const mesh = R.addMesh(b.kind === 'crate' ? sets.crate : sets.debris, { bones: [I, M] });
    const alive = !broken.has(i);
    mesh.visible = alive;
    return { ...b, i, mesh, alive, hp: b.kind === 'crate' ? 2 : 3 };
  });
  g.pickups = [];
  // chefe
  g.boss = new Boss(W.ROYAL_TOMB);
  if (g.bossDefeated) g.boss.state = 'dead';
  g.bossMesh = R.addMesh(sets.boss);
  g.bossMesh.visible = false;
  g.mantle = makeRoyalMantle(atlas); g.mantle._emit();
  g.mantleMesh = R.addMesh(g.mantle.ps, { dynamic: true });
  g.mantleMesh.visible = false;
  g.bossLight = { name: 'chama roubada', pos: [0, 1.5, 0], col: [0.7, 0.55, 1.0], radius: 7, base: 1.9, flicker: 0.35, level: 0 };
  g.lights.push(g.bossLight);
  g.fight = false;
  g.cinema = new Cinema();
  g.pickupGlyphs = { shield: atlas.get('盾'), flask: atlas.get('薬') };
}

// ─────────────── Itens no chão ───────────────
function spawnPickup(g, kind, x, z) {
  const ps = new PointSet(16);
  const gl = g.pickupGlyphs[kind], col = kind === 'shield' ? MAT.GOLD : MAT.EMBER;
  ps.push([0, 0, 0], [0, 0, 1], [1, 0, 0], col, gl, 1, 2 | 4, 0.26, 1);
  for (let i = 0; i < 6; i++) { const a = i * 1.047; ps.push([Math.cos(a) * 0.22, Math.sin(a * 2) * 0.05, Math.sin(a) * 0.22], [0, 1, 0], [1, 0, 0], MAT.EMBER, g.atlas.get('·'), 1, 2 | 4, 0.06, i + 2); }
  const mesh = g.R.addMesh(ps, { occlude: false, bones: [I, m4.translate(x, 0.6, z)] });
  g.pickups.push({ kind, x, z, mesh, t: 0 });
}
function breakObject(g, b) {
  b.alive = false; b.mesh.visible = false;
  g.fx.splinters([b.x, 0.3, b.z], b.kind === 'crate' ? [0.5, 0.38, 0.24] : [0.42, 0.4, 0.4], b.kind === 'crate' ? 46 : 34);
  const left = g.breakables.filter(o => o.alive).length;
  const p = g.player;
  if (!p.hasShield && !g.shieldDropped && Math.random() < 1 / (left + 1)) { g.shieldDropped = true; spawnPickup(g, 'shield', b.x, b.z); }
  else if (p.flaskMax < 3 && Math.random() < 0.45) spawnPickup(g, 'flask', b.x, b.z);
  g.save();
}

// ─────────────── Dano ───────────────
function hurtPlayer(g, dmg, from) {
  const p = g.player;
  if (p.dead > 0 || p.inv > 0 || g.cinema.active) return;
  if (p.roll >= 0 && p.roll > 0.06 && p.roll < 0.6) return;                         // quadros de invulnerabilidade do rolamento
  const toA = Math.atan2(from[0] - p.x, from[1] - p.z), facing = Math.abs(Math.atan2(Math.sin(toA - p.yaw), Math.cos(toA - p.yaw))) < 1.25;
  const blocking = p.block > 0.6 && p.offhand === 'shield' && p.hasShield && facing && p.heal < 0 && p.swap < 0;
  if (blocking && g.t - p.blockStart < 0.22) {                                         // aparar
    g.boss.doStagger(); p.riposte = 2.6;
    g.fx.sparks(m4.point(g.shieldW, [0, 0, 0.1]), 30, [1, 0.95, 0.7]);
    g.shake = 0.12; buzz(g, [20, 30, 20]);
    g.hud.toast('Aparado! Contra-ataque agora.', 1400);
    return;
  }
  if (blocking) {
    p.sta -= dmg * 1.5; p.staWait = 0.8;
    g.fx.sparks(m4.point(g.shieldW, [0, 0, 0.1]), 12);
    if (p.sta >= 0) { p.hp -= dmg * 0.1; g.shake = 0.06; buzz(g, 15); return; }
    p.sta = 0; dmg *= 0.5;                                                            // guarda quebrada
  }
  p.hp -= dmg; p.hurt = 1; p.stun = 0.45; p.inv = 0.5;
  p.atk = -1; p.heal = -1; p.swap = -1; p.roll = -1;
  const d = Math.hypot(p.x - from[0], p.z - from[1]) || 1;
  p.kb = [(p.x - from[0]) / d * 3.2, (p.z - from[1]) / d * 3.2];
  g.shake = 0.14; buzz(g, [40]);
  if (p.hp <= 0) { p.hp = 0; p.dead = 0.001; showBanner(STORY.death, '', true); }
}
function buzz(g, pat) { if (g.settings.haptics && navigator.vibrate) { try { navigator.vibrate(pat); } catch (e) { /* ok */ } } }
function showBanner(title, text, death) {
  $('banner-title').textContent = title; $('banner-text').textContent = text || '';
  $('banner').classList.toggle('death', !!death);
  $('banner').classList.remove('hidden');
  clearTimeout(showBanner.t); showBanner.t = setTimeout(() => $('banner').classList.add('hidden'), death ? 3200 : 5200);
}

// ─────────────── Antes do movimento: ações e travas ───────────────
/** Retorna { lock, speedMul, vel:[vx,vz]|null } para o movimento do main. */
export function combatPre(g, dt, input, st, wantDir) {
  const p = g.player;
  p.hurt = Math.max(0, p.hurt - dt * 3); p.stun = Math.max(0, p.stun - dt); p.inv = Math.max(0, p.inv - dt); p.riposte = Math.max(0, p.riposte - dt);
  p.kb = [p.kb[0] * (1 - Math.min(1, dt * 7)), p.kb[1] * (1 - Math.min(1, dt * 7))];
  // levantando (abertura)
  if (p.wake > 0) { p.wake = Math.max(0, p.wake - dt / 4); p.dead = p.wake; return { lock: true }; }
  // morte → volta ao braseiro
  if (p.dead > 0) {
    p.dead = Math.min(1, p.dead + dt / 1.8);
    p.deadT = (p.deadT || 0) + dt;
    if (p.deadT > 3.6) respawn(g);
    return { lock: true };
  }
  const busy = p.roll >= 0 || p.heal >= 0 || p.swap >= 0 || p.stun > 0;
  // rolar
  if (input.take('dodge') && p.roll < 0 && p.stun <= 0 && p.heal < 0 && p.sta > 1) {
    p.roll = 0; p.sta -= COST.roll; p.staWait = 0.6; p.atk = -1; p.queued = false;
    p.rollDir = wantDir != null ? wantDir : p.yaw; p.yaw = p.rollDir;
  }
  // curar
  if (input.take('heal')) {
    if (p.flasks > 0 && !busy && p.atk < 0) { p.heal = 0; p.healDone = false; }
    else if (p.flasks <= 0) g.hud.toast('Sem frascos. Descanse junto à chama.', 1600);
  }
  // trocar tocha ⇄ escudo
  if (input.take('swap') && p.hasShield && !busy && p.atk < 0) { p.swap = 0; p.swapped = false; }
  // bloquear (segurar) — a janela de aparar começa no instante em que aperta
  const wantBlock = input.isHeld('block') && p.hasShield && p.offhand === 'shield' && p.roll < 0 && p.heal < 0 && p.swap < 0 && p.atk < 0 && p.stun <= 0;
  if (wantBlock && p.block < 0.05) p.blockStart = g.t;
  p.block += ((wantBlock ? 1 : 0) - p.block) * Math.min(1, dt * 12);
  // ataque: precisa de estamina; não ataca rolando, curando ou atordoado
  if (input.take('attack') && !busy && p.block < 0.5) {
    if (p.atk < 0 && p.sta > 1) { p.atk = 0; p.combo = 0; p.queued = false; p.sta -= COST.attack[0]; p.staWait = 0.5; p.swing++; p.hitSet = new Set(); }
    else if (p.atk > 0.25 && p.combo < 2) p.queued = true;
  }
  if (p.atk >= 0) {
    const C = COMBO[p.combo];
    const prev = p.atk;
    p.atk += dt / C.dur;
    const a0 = C.hit[0] - 0.12, a1 = C.hit[1];
    if (p.atk > a0 && prev < a1) { const k = (Math.min(p.atk, a1) - Math.max(prev, a0)) / (a1 - a0); p.x += Math.sin(p.yaw) * C.step * k; p.z += Math.cos(p.yaw) * C.step * k; }
    if (p.queued && p.atk >= 0.68 && p.sta > 1) { p.combo++; p.atk = 0; p.queued = false; p.sta -= COST.attack[p.combo]; p.staWait = 0.5; p.swing++; p.hitSet = new Set(); }
    else if (p.atk >= 1) { p.atk = -1; p.combo = 0; p.queued = false; }
  }
  // estamina volta quando não está gastando
  p.staWait -= dt;
  if (p.staWait <= 0 && p.roll < 0 && p.atk < 0) p.sta = Math.min(p.staMax, p.sta + dt * (p.block > 0.5 ? 14 : 40));
  // progresso das ações
  if (p.roll >= 0) {
    const t0 = p.roll; p.roll += dt / 0.62;
    const v = 5.2 * (1 - sm((p.roll - 0.1) / 0.8)) * (p.roll < 0.85 ? 1 : 0.3);
    if (p.roll >= 1) p.roll = -1;
    void t0;
    return { lock: true, vel: [Math.sin(p.rollDir) * v, Math.cos(p.rollDir) * v] };
  }
  if (p.heal >= 0) {
    p.heal += dt / 1.3;
    if (!p.healDone && p.heal > 0.55) { p.healDone = true; p.flasks--; p.hp = Math.min(p.hpMax, p.hp + 55); g.fx.burst(m4.point(g.knightBones[3], [0, 0.1, 0.15]), 18); }
    if (p.heal >= 1) p.heal = -1;
    return { lock: false, speedMul: 0.3 };
  }
  if (p.swap >= 0) {
    p.swap += dt / 0.7;
    if (!p.swapped && p.swap > 0.5) { p.swapped = true; p.offhand = p.offhand === 'torch' ? 'shield' : 'torch'; g.save(); }
    if (p.swap >= 1) p.swap = -1;
    return { lock: false, speedMul: 0.6 };
  }
  if (p.stun > 0) return { lock: true, vel: p.kb };
  return { lock: false, speedMul: p.block > 0.5 ? 0.45 : 1, vel: (Math.abs(p.kb[0]) + Math.abs(p.kb[1]) > 0.05) ? p.kb : null };
}

function respawn(g) {
  const p = g.player;
  $('banner').classList.add('hidden');
  Object.assign(p, { hp: p.hpMax, sta: p.staMax, flasks: p.flaskMax, dead: 0, deadT: 0, roll: -1, heal: -1, swap: -1, atk: -1, stun: 0, hurt: 0, kb: [0, 0] });
  if (g.fight) endFight(g, false);
  g.respawn();
}

// ─────────────── Depois do movimento: golpes, chefe, itens, arena ───────────────
export function combatPost(g, dt) {
  const p = g.player, B = g.boss;
  // a lâmina acerta o chefe e os caixotes (uma vez por golpe)
  if (p.atk >= 0 && g.knightBones) {
    const C = COMBO[p.combo];
    if (p.atk > C.hit[0] - 0.03 && p.atk < C.hit[1] + 0.04) {
      const [a, b] = swordSegment(g.knightBones);
      const pts = [0.2, 0.45, 0.7, 0.95].map(k => v3.lerp(a, b, k));
      const key = p.swing;
      if (B.alive && B.state === 'fight' && !p.hitSet.has('boss')) {
        for (const q of pts) if (Math.hypot(q[0] - B.x, q[2] - B.z) < 0.55 * BSCALE && q[1] < 2.4 * BSCALE) {
          p.hitSet.add('boss');
          const crit = p.riposte > 0 ? 3 : 1; p.riposte = 0;
          const died = B.damage(DMG[p.combo] * crit);
          g.fx.sparks(q, crit > 1 ? 36 : 16, crit > 1 ? [1, 0.9, 0.5] : [0.9, 0.7, 1]);
          g.shake = crit > 1 ? 0.12 : 0.05; buzz(g, crit > 1 ? [30, 20, 40] : 12);
          if (died) bossDies(g);
          break;
        }
      }
      for (const o of g.breakables) {
        if (!o.alive || p.hitSet.has('b' + o.i)) continue;
        for (const q of pts) if (Math.hypot(q[0] - o.x, q[2] - o.z) < 0.62 && q[1] < 1.75) {   // golpe de cima também racha o caixote
          p.hitSet.add('b' + o.i); o.hp--; g.fx.splinters([q[0], q[1], q[2]], o.kind === 'crate' ? [0.5, 0.38, 0.24] : [0.42, 0.4, 0.4], 8); buzz(g, 10);
          if (o.hp <= 0) breakObject(g, o);
          break;
        }
      }
      void key;
    }
  }
  // itens: chega perto e pega
  for (let i = g.pickups.length - 1; i >= 0; i--) {
    const it = g.pickups[i];
    it.t += dt;
    if (it.t > 0.6 && Math.hypot(p.x - it.x, p.z - it.z) < 0.75 && p.dead <= 0) {
      it.mesh.visible = false; g.pickups.splice(i, 1);
      if (it.kind === 'shield') { p.hasShield = true; p.swap = 0; p.swapped = false; g.hud.message(STORY.shield, 'Escudo do Juramento', null); }
      else { p.flaskMax = Math.min(3, p.flaskMax + 1); p.flasks = Math.min(p.flaskMax, p.flasks + 1); g.hud.toast(STORY.flask, 4200); }
      g.fx.burst([it.x, 0.7, it.z], 30); g.save();
    }
  }
  // o chefe desperta quando o cavaleiro chega ao túmulo
  if (!g.bossDefeated && B.state === 'buried' && !g.cinema.active && p.dead <= 0 && Math.hypot(p.x - W.ROYAL_TOMB.x, p.z - W.ROYAL_TOMB.z) < 4.4) startBoss(g);
  if (B.state !== 'buried' && B.state !== 'dead') {
    const ev = B.update(dt, p, p.dead <= 0 && !g.cinema.active);
    for (const e of ev) {
      if (e.type === 'hit') hurtPlayer(g, e.dmg, e.from);
      else if (e.type === 'slam') { g.fx.dirt([e.x, 0.05, e.z], 50, 1.4); g.fx.sparks([e.x, 0.1, e.z], 10, [0.7, 0.55, 1]); g.shake = 0.16; buzz(g, [50]); }
      else if (e.type === 'roar') { g.shake = 0.1; if (e.phase2) { g.fx.dirt([B.x, 1.2, B.z], 40, 2); g.hud.toast('A Chama roubada arde mais forte…', 2200); } }
    }
    // corpo do chefe empurra o cavaleiro
    const dx = p.x - B.x, dz = p.z - B.z, d = Math.hypot(dx, dz), rr = 0.5 * BSCALE + 0.3;
    if (B.state === 'fight' && d < rr && d > 1e-4) { p.x = B.x + dx / d * rr; p.z = B.z + dz / d * rr; }
  }
  // arena cercada pela névoa durante a luta
  if (g.fight) {
    const dx = p.x - ARENA.x, dz = p.z - ARENA.z, d = Math.hypot(dx, dz);
    if (d > ARENA.r) { p.x = ARENA.x + dx / d * ARENA.r; p.z = ARENA.z + dz / d * ARENA.r; }
    g.fx.fogRing([ARENA.x, ARENA.z], ARENA.r + 0.3, dt);
    const bx = B.x - ARENA.x, bz = B.z - ARENA.z, bd = Math.hypot(bx, bz);
    if (bd > ARENA.r - 0.5) { B.x = ARENA.x + bx / bd * (ARENA.r - 0.5); B.z = ARENA.z + bz / bd * (ARENA.r - 0.5); }
  }
}

function startBoss(g) {
  const B = g.boss, p = g.player;
  const begin = () => { g.fight = true; $('boss-name').textContent = BOSS_NAME; $('boss-bar').classList.remove('hidden'); };
  if (g.bossSeen) { B.reset(); B.state = 'rising'; B.rise = 0.4; g.fx.dirt([B.x, 0.05, B.z], 70, 2.2); begin(); return; }
  // a cena: o cavaleiro para de frente para o túmulo
  Object.assign(p, { x: ARENA.x + 1.2, z: ARENA.z + 3.0, atk: -1, roll: -1, heal: -1, speed: 0 });
  p.yaw = Math.atan2(W.ROYAL_TOMB.x - p.x, W.ROYAL_TOMB.z - p.z);
  g.teleported(); g.cam.x = p.x; g.cam.z = p.z;
  B.reset();
  g.cinema.play(bossIntroScene(STORY, W, {
    quake: () => g.fx.dirt([B.x, 0.05, B.z], 60, 1.2),
    rise: () => { B.state = 'rising'; B.rise = 0; g.fx.dirt([B.x, 0.05, B.z], 90, 2.4); },
    roar: (skip) => { if (skip) { B.rise = 1; B.state = 'fight'; } g.shake = 0.15; },
    done: () => { if (B.state !== 'fight') { B.rise = 1; B.state = 'fight'; } g.bossSeen = true; g.save(); begin(); },
  }));
}
function endFight(g, won) {
  g.fight = false;
  $('boss-bar').classList.add('hidden');
  if (!won) { g.boss.reset(); }
}
function bossDies(g) {
  const B = g.boss;
  g.bossDefeated = true;
  showBanner(STORY.bossDefeated, STORY.bossDefeatedText, false);
  setTimeout(() => { endFight(g, true); g.save(); }, 1200);
  g.fx.dirt([B.x, 1.4, B.z], 120, 1.5);
}

// ─────────────── Desenho ───────────────
export function gameplayRender(g, Wm, bones, dt) {
  const p = g.player, R = g.R, B = g.boss;
  g.knightBones = bones;
  // tocha / escudo na mão esquerda (some durante a cura e no meio da troca)
  const hideOff = (p.heal > 0.2 && p.heal < 0.85) || p.dead > 0.6;
  const torchW = m4.mul(Wm, bones.torch), shieldW = m4.mul(Wm, bones.shield);
  g.shieldW = shieldW;
  g.torchMesh.visible = p.offhand === 'torch' && !hideOff;
  g.shieldMesh.visible = p.hasShield && p.offhand === 'shield' && !hideOff;
  g.torchMesh.boneData = flatBones([I, torchW]);
  g.shieldMesh.boneData = flatBones([I, shieldW]);
  const flame = m4.point(torchW, [0, 0.4, 0]);
  g.torchFire.pos[0] = flame[0]; g.torchFire.pos[1] = flame[1]; g.torchFire.pos[2] = flame[2];
  g.torchFire.off = !g.torchMesh.visible;
  g.torchLight.pos = [flame[0], flame[1] + 0.15, flame[2]];
  g.torchLight.level += ((g.torchMesh.visible ? 1 : 0) - g.torchLight.level) * Math.min(1, dt * 6);
  // itens girando no chão
  for (const it of g.pickups) it.mesh.boneData = flatBones([I, m4.mul(m4.translate(it.x, 0.55 + 0.08 * Math.sin(g.t * 2.5), it.z), m4.rotY(g.t * 1.6))]);
  // chefe
  const show = B.state !== 'buried' && !(B.state === 'dead' && B.dead >= 1);
  g.bossMesh.visible = g.mantleMesh.visible = show && B.state !== 'dead';
  if (g.bossMesh.visible) {
    const BW = m4.mul(m4.mul(m4.translate(B.x, 0, B.z), m4.rotY(B.yaw)), m4.scale(BSCALE, BSCALE, BSCALE));
    const pose = poseBoss({ phase: B.phase, blend: B.blend, t: B.t, act: B.act, at: B.at, rise: B.rise, dead: B.dead, hurt: B.hurt });
    const bb = pose.map(m => m4.mul(BW, m)); bb[0] = I;
    g.bossMesh.boneData = flatBones(bb);
    // vira cinza ao morrer: menos caracteres a cada instante
    g.bossMesh.drawCount = Math.round(g.bossMesh.n * (1 - sm((B.dead - 0.55) / 0.45)));
    g.mantleMesh.drawCount = Math.round(g.mantleMesh.n * (1 - sm((B.dead - 0.4) / 0.5)));
    if (B.dead > 0.55) g.fx.dirt(m4.point(bb[2], [0, 0.2, 0]), 3, 1);
    const sub = Math.min(3, Math.max(1, Math.round(dt * 60)));
    for (let i = 0; i < sub; i++) g.mantle.update(dt / sub, bb[2], [{ c: m4.point(bb[2], [0, 0.2, -0.02]), r: 0.26 * BSCALE }, { c: m4.point(bb[1], [0, -0.1, 0]), r: 0.24 * BSCALE }], [g.fx.wind[0], 0, g.fx.wind[2]]);
    R.updateMesh(g.mantleMesh, g.mantle.ps);
    if (B.state !== 'dying' && Math.random() < (B.phase2 ? 0.9 : 0.5)) g.fx.spirit(m4.point(bb[Math.random() < 0.5 ? 4 : 7], [0, 0.05, -0.05]), B.phase2 ? 2 : 1);
    g.bossLight.pos = m4.point(bb[2], [0, 0.35, 0.75]);
    g.bossLight.level += ((B.state === 'dying' ? 0 : (B.phase2 ? 1.4 : 1)) - g.bossLight.level) * Math.min(1, dt * 3);
  } else g.bossLight.level = Math.max(0, g.bossLight.level - dt);
  // HUD
  $('hp-bar').firstElementChild.style.transform = `scaleX(${p.hp / p.hpMax})`;
  $('hp-bar').lastElementChild.style.transform = `scaleX(${p.hp / p.hpMax})`;
  $('st-bar').firstElementChild.style.transform = `scaleX(${Math.max(0, p.sta) / p.staMax})`;
  if (g.fight) { const k = B.hp / BOSS_HP; $('boss-bar').querySelector('i').style.transform = `scaleX(${k})`; $('boss-bar').querySelector('b').style.transform = `scaleX(${k})`; }
  $('heal-n').textContent = p.flasks;
  $('btn-heal').classList.toggle('empty', p.flasks <= 0);
  $('btn-block').classList.toggle('hidden', !(p.hasShield && p.offhand === 'shield'));
  $('btn-swap').classList.toggle('hidden', !p.hasShield);
}

/** Estado salvo do jogo (soma-se ao que o main já guarda). */
export function gameplaySave(g) {
  const p = g.player;
  return { hasShield: p.hasShield, offhand: p.offhand, flaskMax: p.flaskMax, bossDefeated: g.bossDefeated, bossSeen: g.bossSeen, introSeen: g.introSeen,
    broken: g.breakables ? g.breakables.filter(b => !b.alive).map(b => b.i) : [] };
}

/** Descansar no braseiro: cura, renova frascos. */
export function rest(g) { const p = g.player; p.hp = p.hpMax; p.sta = p.staMax; p.flasks = p.flaskMax; }

/** Abertura da história. */
export function playOpening(g, done) {
  const p = g.player;
  const kx = W.BRAZIER.x + 0.9, kz = W.BRAZIER.z + 1.1;
  g.cinema.play(openingScene(STORY, W, {
    lieDown: () => { Object.assign(p, { x: kx, z: kz, yaw: 0.4, dead: 1, wake: 0 }); g.cam.x = kx; g.cam.z = kz; g.teleported(); },
    wake: (skip) => { if (skip) { p.dead = 0; p.wake = 0; } else p.wake = 1; },
    done: () => { if (p.wake <= 0) p.dead = 0; g.introSeen = true; g.save(); done && done(); },
  }));
}
