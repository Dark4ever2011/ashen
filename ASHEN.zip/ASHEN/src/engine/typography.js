// ASHEN — Motor tipográfico
// Largura de caracteres (simples/dupla), fontes, métricas e pintura de glifos em células.
// Regra central: todo glifo é encaixado na sua célula (ou em 2 células se for largo).
// Nada transborda para a célula vizinha na horizontal, independente da fonte disponível.

import { makeCanvas } from './canvas.js';

// Faixas Unicode de largura dupla (East Asian Wide / Fullwidth), em ordem crescente.
const WIDE = [
  [0x1100, 0x115F], [0x2E80, 0x303E], [0x3041, 0x33FF], [0x3400, 0x4DBF], [0x4E00, 0x9FFF],
  [0xA000, 0xA4CF], [0xAC00, 0xD7A3], [0xF900, 0xFAFF], [0xFE30, 0xFE4F], [0xFF00, 0xFF60],
  [0xFFE0, 0xFFE6], [0x1F300, 0x1F64F], [0x1F900, 0x1F9FF], [0x20000, 0x3FFFD],
];

/** 0 = combinante/controle, 1 = simples, 2 = dupla. */
export function charWidth(cp) {
  if (cp < 0x20) return 0;
  if (cp < 0x300) return 1;
  if (cp <= 0x36F) return 0;
  if (cp < 0x1100) return 1;
  for (let i = 0; i < WIDE.length; i++) {
    if (cp < WIDE[i][0]) return 1;
    if (cp <= WIDE[i][1]) return 2;
  }
  return 1;
}

/** Quebra uma linha em células visuais: [{ch, col, w}]. */
export function layoutRow(str) {
  const cells = [];
  let col = 0;
  for (const ch of str) {
    const w = charWidth(ch.codePointAt(0));
    if (w === 0) continue;
    cells.push({ ch, col, w });
    col += w;
  }
  return { cells, width: col };
}

export function visualWidth(str) { return layoutRow(str).width; }

// Pilhas de fontes. "AshenMono" é a DejaVu Sans Mono embutida em assets/fonts.
export const FONTS = {
  mono: '"AshenMono","DejaVu Sans Mono","Noto Sans Mono","Droid Sans Mono","Roboto Mono",Consolas,Menlo,"Courier New",monospace',
  // Kanji com serifa (estilo "gravado") primeiro; caem para gótico sem serifa.
  cjk: '"Noto Serif CJK JP","Noto Serif JP","Source Han Serif JP","Hiragino Mincho ProN","Yu Mincho","MS Mincho",' +
       '"Noto Sans CJK JP","Noto Sans JP","Hiragino Kaku Gothic ProN","Yu Gothic","Meiryo","MS Gothic","Droid Sans Fallback",serif',
};

export const fontStatus = { mono: 'carregando', cjk: 'desconhecida', offscreenFonts: false };

/** Carrega a fonte embutida. Se falhar, segue com a fonte monoespaçada do sistema. */
export async function loadFonts(base = 'assets/fonts/') {
  try {
    if (typeof FontFace !== 'function' || !document.fonts) throw new Error('FontFace indisponível');
    const face = new FontFace('AshenMono', `url(${base}DejaVuSansMono.ttf)`, { display: 'block' });
    const timeout = new Promise((_, rej) => setTimeout(() => rej(new Error('tempo esgotado')), 5000));
    await Promise.race([face.load(), timeout]);
    document.fonts.add(face);
    fontStatus.mono = 'AshenMono (DejaVu Sans Mono embutida)';
  } catch (err) {
    console.warn('[ASHEN] Fonte embutida indisponível, usando fallback:', err.message);
    fontStatus.mono = 'monoespaçada do sistema (fallback)';
  }
  fontStatus.cjk = detectCJKFont();
  fontStatus.offscreenFonts = testOffscreenFonts();
}

/**
 * Verifica a fonte japonesa: tenta identificar o nome (funciona quando ela não é a padrão do sistema)
 * e, sempre, confere se os glifos têm desenho de verdade (e não a "caixa vazia" de glifo ausente).
 */
export function detectCJKFont() {
  const name = detectCJKName();
  const present = cjkGlyphsPresent();
  if (!present) return 'AUSENTE — kanji podem aparecer como caixas; instale uma fonte japonesa';
  return name ? name : 'fonte japonesa do sistema (glifos presentes)';
}

function cjkGlyphsPresent() {
  try {
    const c = document.createElement('canvas'); c.width = 40; c.height = 40;
    const x = c.getContext('2d', { willReadFrequently: true });
    const draw = ch => { x.clearRect(0, 0, 40, 40); x.font = `32px ${FONTS.cjk}`; x.fillStyle = '#fff'; x.textBaseline = 'middle'; x.fillText(ch, 4, 20); return x.getImageData(0, 0, 40, 40).data; };
    const tofu = draw('\uE000'), a = draw('誓');
    let diff = 0, ink = 0;
    for (let i = 3; i < a.length; i += 4) { if (a[i] > 60) ink++; if (Math.abs(a[i] - tofu[i]) > 60) diff++; }
    return ink > 30 && diff > 30;
  } catch (e) { return true; }
}

function detectCJKName() {
  const names = ['Noto Serif CJK JP', 'Noto Sans CJK JP', 'Noto Serif JP', 'Noto Sans JP', 'Hiragino Mincho ProN',
    'Yu Mincho', 'MS Mincho', 'Hiragino Kaku Gothic ProN', 'Yu Gothic', 'Meiryo', 'MS Gothic', 'Droid Sans Fallback'];
  const c = document.createElement('canvas').getContext('2d');
  const sample = '誓灰騎王門';
  const sig = font => { c.font = font; const m = c.measureText(sample); return m.width.toFixed(2) + ':' + (m.actualBoundingBoxAscent || 0).toFixed(2); };
  const baseA = sig('40px monospace'), baseB = sig('40px serif');
  for (const n of names) {
    const a = sig(`40px "${n}",monospace`), b = sig(`40px "${n}",serif`);
    if (a !== baseA && b !== baseB && a === b) return n;
  }
  return '';
}

/** OffscreenCanvas no thread principal enxerga as fontes do documento? Testamos de verdade. */
function testOffscreenFonts() {
  if (typeof OffscreenCanvas === 'undefined') return false;
  try {
    const draw = ctx => { ctx.font = '40px AshenMono, serif'; return ctx.measureText('Wg█').width; };
    const a = draw(document.createElement('canvas').getContext('2d'));
    const b = draw(new OffscreenCanvas(4, 4).getContext('2d'));
    return Math.abs(a - b) < 0.01;
  } catch (e) { return false; }
}

// Blocos desenhados como retângulos exatos (frações da célula): emendas perfeitas, sem depender da fonte.
export const BLOCKS = {
  '█': [[0, 0, 1, 1]], '▀': [[0, 0, 1, .5]], '▄': [[0, .5, 1, 1]], '▌': [[0, 0, .5, 1]], '▐': [[.5, 0, 1, 1]],
  '▖': [[0, .5, .5, 1]], '▗': [[.5, .5, 1, 1]], '▘': [[0, 0, .5, .5]], '▝': [[.5, 0, 1, .5]],
  '▙': [[0, 0, .5, 1], [.5, .5, 1, 1]], '▛': [[0, 0, 1, .5], [0, .5, .5, 1]],
  '▜': [[0, 0, 1, .5], [.5, .5, 1, 1]], '▟': [[.5, 0, 1, 1], [0, .5, .5, 1]],
  '▚': [[0, 0, .5, .5], [.5, .5, 1, 1]], '▞': [[.5, 0, 1, .5], [0, .5, .5, 1]],
  '▔': [[0, 0, 1, .14]], '▁': [[0, .86, 1, 1]], '▂': [[0, .75, 1, 1]], '▃': [[0, .62, 1, 1]],
  '▅': [[0, .38, 1, 1]], '▆': [[0, .25, 1, 1]], '▇': [[0, .12, 1, 1]],
  '▏': [[0, 0, .14, 1]], '▎': [[0, 0, .25, 1]], '▍': [[0, 0, .38, 1]], '▋': [[0, 0, .62, 1]],
  '▊': [[0, 0, .75, 1]], '▉': [[0, 0, .88, 1]], '▕': [[.86, 0, 1, 1]],
};

// Diagonais desenhadas como traços exatos de canto a canto: emendam com a célula vizinha
// e nunca vazam (na DejaVu e em várias fontes elas passam da largura da célula).
export const DIAGONALS = { '╱': [[0, 1, 1, 0]], '╲': [[0, 0, 1, 1]], '╳': [[0, 1, 1, 0], [0, 0, 1, 1]] };

/**
 * Pintor de glifos para uma célula de tamanho fixo (em pixels do dispositivo).
 * Mede a fonte real e calcula tamanho, base e escala horizontal para que
 * '█', '│' e '─' encostem exatamente nas bordas da célula.
 * Uso: paint(...) várias vezes e depois end(ctx) para restaurar a transformação.
 */
export class GlyphPainter {
  constructor() {
    this.m = document.createElement('canvas').getContext('2d');
    this.wide = new Map();
    this.narrow = new Map();
    this.setCell(6, 10);
  }

  setCell(cw, ch) {
    if (this.cw === cw && this.ch === ch) return;
    this.cw = cw; this.ch = ch;
    const m = this.m;
    m.font = `100px ${FONTS.mono}`;
    const blk = m.measureText('│');
    const asc = blk.actualBoundingBoxAscent || 92, desc = blk.actualBoundingBoxDescent || 24;
    const adv = m.measureText('M').width || 60;
    this.monoPx = ch * 100 / (asc + desc);
    this.monoAdv = adv * this.monoPx / 100;
    this.monoSX = cw / this.monoAdv;
    this.monoBase = ch / 2 + (asc - desc) / 2 * this.monoPx / 100;
    this.monoFont = `${this.monoPx.toFixed(3)}px ${FONTS.mono}`;

    m.font = `bold 100px ${FONTS.cjk}`;
    const k = m.measureText('口');
    const kasc = k.actualBoundingBoxAscent || 80, kdesc = k.actualBoundingBoxDescent || 8;
    this.cjkPx = ch * 1.04;
    this.cjkBase = ch / 2 + (kasc - kdesc) / 2 * this.cjkPx / 100;
    this.cjkFont = `bold ${this.cjkPx.toFixed(3)}px ${FONTS.cjk}`;
    this.wide.clear();
    this.narrow.clear();
  }

  /** Escala horizontal extra para glifos que, em alguma fonte de fallback, sejam mais largos que a célula. */
  _fit(ch, isWide) {
    const map = isWide ? this.wide : this.narrow;
    let s = map.get(ch);
    if (s !== undefined) return s;
    const m = this.m;
    m.font = isWide ? `bold 100px ${FONTS.cjk}` : `100px ${FONTS.mono}`;
    const w100 = m.measureText(ch).width;
    if (isWide) {
      const natural = w100 * this.cjkPx / 100, slot = this.cw * 2 * 0.98;
      s = natural > slot ? slot / natural : 1;
    } else {
      const natural = w100 * this.monoPx / 100 * this.monoSX, slot = this.cw * 1.001;
      s = natural > slot ? slot / natural : 1;
    }
    map.set(ch, s);
    return s;
  }

  /** Pinta um glifo com a célula começando em (x,y). w = 1 ou 2 células. */
  paint(ctx, ch, w, x, y, color) {
    const cw = this.cw, chh = this.ch;
    ctx.fillStyle = color;
    const blk = BLOCKS[ch];
    if (blk) {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      for (let i = 0; i < blk.length; i++) {
        const b = blk[i];
        const x0 = Math.round(x + b[0] * cw), y0 = Math.round(y + b[1] * chh);
        const x1 = Math.round(x + b[2] * cw), y1 = Math.round(y + b[3] * chh);
        ctx.fillRect(x0, y0, Math.max(1, x1 - x0), Math.max(1, y1 - y0));
      }
      return;
    }
    if (ch === ' ') return;
    const dia = DIAGONALS[ch];
    if (dia) {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.strokeStyle = color;
      ctx.lineWidth = Math.max(1, cw * 0.14);
      ctx.lineCap = 'butt';
      ctx.save(); ctx.beginPath(); ctx.rect(x, y, cw, chh); ctx.clip();
      ctx.beginPath();
      for (const d of dia) { ctx.moveTo(x + d[0] * cw, y + d[1] * chh); ctx.lineTo(x + d[2] * cw, y + d[3] * chh); }
      ctx.stroke(); ctx.restore();
      return;
    }
    if (w === 2) {
      if (ctx.font !== this.cjkFont) ctx.font = this.cjkFont;
      const s = this._fit(ch, true);
      ctx.setTransform(s, 0, 0, 1, x + cw, y + this.cjkBase);
    } else {
      if (ctx.font !== this.monoFont) ctx.font = this.monoFont;
      const s = this.monoSX * this._fit(ch, false);
      ctx.setTransform(s, 0, 0, 1, x + cw * 0.5, y + this.monoBase);
    }
    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';
    ctx.fillText(ch, 0, 0);
  }

  /**
   * Pinta um glifo girado. (cx,cy) = centro da célula. angle em radianos.
   * sy permite achatar ao longo do eixo do glifo (escorço).
   */
  paintRotated(ctx, ch, w, cx, cy, angle, color, sy = 1) {
    const cw = this.cw * w, chh = this.ch;
    const cos = Math.cos(angle), sin = Math.sin(angle);
    ctx.fillStyle = color;
    const blk = BLOCKS[ch];
    if (blk) {
      ctx.setTransform(cos, sin, -sin * sy, cos * sy, cx, cy);
      for (const b of blk) {
        ctx.fillRect(-cw / 2 + b[0] * cw - 0.35, -chh / 2 + b[1] * chh - 0.35, (b[2] - b[0]) * cw + 0.7, (b[3] - b[1]) * chh + 0.7);
      }
      return;
    }
    if (ch === ' ') return;
    let s, base;
    if (w === 2) { if (ctx.font !== this.cjkFont) ctx.font = this.cjkFont; s = this._fit(ch, true); base = this.cjkBase; }
    else { if (ctx.font !== this.monoFont) ctx.font = this.monoFont; s = this.monoSX * this._fit(ch, false); base = this.monoBase; }
    ctx.setTransform(cos * s, sin * s, -sin * sy, cos * sy, cx, cy);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';
    ctx.fillText(ch, 0, base - chh / 2);
  }

  end(ctx) { ctx.setTransform(1, 0, 0, 1, 0, 0); }
}

/**
 * Atlas de glifos: carimbos pré-renderizados (glifo + cor) num único canvas.
 * Usado para elementos dinâmicos (fogo, partículas) — drawImage é bem mais barato que fillText.
 */
export class GlyphAtlas {
  constructor(painter, size = 1024) {
    this.p = painter;
    this.size = size;
    this.reset();
  }
  reset() {
    this.canvas = makeCanvas(this.size, this.size);
    this.ctx = this.canvas.getContext('2d');
    this.map = new Map();
    this.x = 1; this.y = 1; this.rowH = 0;
  }
  /** Retorna {sx, sy, w, h} no atlas. Coordenadas incluem 1px de margem. */
  get(ch, color, w = 1) {
    const key = ch + '\u0000' + color + w;
    let e = this.map.get(key);
    if (e) return e;
    const cw = Math.ceil(this.p.cw * w) + 2, chh = Math.ceil(this.p.ch) + 2;
    if (this.x + cw > this.size) { this.x = 1; this.y += this.rowH + 1; this.rowH = 0; }
    if (this.y + chh > this.size) { this.reset(); return this.get(ch, color, w); }
    this.p.paint(this.ctx, ch, w, this.x + 1, this.y + 1, color);
    this.p.end(this.ctx);
    e = { sx: this.x, sy: this.y, w: cw, h: chh };
    this.map.set(key, e);
    this.x += cw + 1;
    this.rowH = Math.max(this.rowH, chh);
    return e;
  }
  /** Desenha o carimbo com a célula começando em (x,y). */
  draw(ctx, ch, color, x, y, w = 1) {
    const e = this.get(ch, color, w);
    ctx.drawImage(this.canvas, e.sx, e.sy, e.w, e.h, x - 1, y - 1, e.w, e.h);
  }
}
