// ASHEN — Arquitetura gótica tipográfica (procedural)
// Cantaria (blocos ▏▁ com argamassa), topo das muralhas visto em 3/4, ameias,
// arco ogival com aduelas e grade levadiça, seteiras, rachaduras, hera e inscrições.

import { TypoGrid } from '../engine/sprite.js';
import { MATERIALS, mixHex, scaleHex } from '../engine/palette.js';
import { rng, hash2, fbm } from '../engine/animation.js';

const CW = 6, CH = 10;
const MORTAR = '#0f0e12';
const STONE = ['#1b1a20', '#25232b', '#302d36', '#3c3943', '#4a4651', '#5a5662', '#6c6774', '#837d89'];

function stoneCol(v) { // v 0..1
  const i = Math.max(0, Math.min(STONE.length - 1.001, v * (STONE.length - 1)));
  const k = Math.floor(i);
  return mixHex(STONE[k], STONE[k + 1], i - k);
}

/** Face frontal em cantaria. light: 0..1 base; grad: escurece para baixo. */
export function ashlar(g, x0, y0, w, h, o = {}) {
  const seed = o.seed || 1, bw = o.bw || 5, bh = o.bh || 2;
  const R = rng(seed);
  const base = o.light ?? 0.5;
  for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) {
    const by = Math.floor((y - y0) / bh);
    const off = (by % 2) * Math.floor(bw / 2);
    const bx = Math.floor((x - x0 + off) / bw);
    const u = (x - x0 + off) % bw, v = (y - y0) % bh;
    const t = (y - y0) / h;
    const hv = hash2(bx, by, seed);
    let lv = base + (hv - 0.5) * 0.16 - t * 0.22 + (1 - (x - x0) / w) * 0.06 + (fbm(x * 0.08, y * 0.08, seed) - 0.5) * 0.18;
    if (o.edgeDark && (x === x0 || x === x0 + w - 1)) lv -= 0.12;
    const bg = stoneCol(lv);
    let ch = ' ', fg = scaleHex(bg, 1.35);
    if (u === 0) { ch = '▏'; fg = MORTAR; }
    else if (v === bh - 1) { ch = '▁'; fg = MORTAR; }
    else {
      const r = R();
      if (r < 0.05) ch = '·';
      else if (r < 0.075) ch = '`';
      else if (r < 0.1) { ch = '░'; fg = scaleHex(bg, 0.7); }
      else if (r < 0.115) { ch = '╱'; fg = scaleHex(bg, 0.55); }
    }
    g.set(x, y, ch, fg, bg);
  }
}

/** Topo das muralhas (caminho de ronda) visto de cima: lajes mais claras (luar). */
export function topSurface(g, x0, y0, w, h, o = {}) {
  const seed = (o.seed || 1) + 99;
  for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) {
    const bx = Math.floor((x - x0 + ((y - y0) % 2) * 2) / 4), by = y - y0;
    const hv = hash2(bx, by, seed);
    const lv = 0.6 + (hv - 0.5) * 0.18 - (y - y0) / h * 0.05 + (fbm(x * 0.1, y * 0.2, seed) - 0.5) * 0.15;
    const bg = stoneCol(lv);
    let ch = ' ', fg = scaleHex(bg, 1.3);
    if ((x - x0 + ((y - y0) % 2) * 2) % 4 === 0) { ch = '▏'; fg = scaleHex(bg, 0.55); }
    else if (hv < 0.12) { ch = '·'; fg = MATERIALS.M; }
    else if (hv > 0.93) { ch = '░'; fg = scaleHex(bg, 0.8); }
    g.set(x, y, ch, fg, bg);
  }
  // Borda frontal iluminada
  for (let x = x0; x < x0 + w; x++) g.set(x, y0 + h - 1, '▀', stoneCol(0.85), stoneCol(0.45));
}

/** Ameias ao longo de uma borda (y = linha de base delas). */
export function merlons(g, x0, y, w, o = {}) {
  const mw = o.mw || 3, gap = o.gap || 2, mh = o.mh || 3, seed = o.seed || 1;
  const R = rng(seed + 7);
  for (let x = x0; x < x0 + w; x++) {
    const k = (x - x0) % (mw + gap);
    if (k >= mw) continue;
    if (o.broken && o.broken(x)) continue;
    const idx = Math.floor((x - x0) / (mw + gap));
    const lost = R() < (o.damage || 0) ? 1 + Math.floor(R() * (mh - 1)) : 0;
    for (let j = 0; j < mh; j++) {
      const yy = y - j;
      if (j >= mh - lost) break;
      const top = j === mh - 1 - lost;
      const lv = 0.5 + (k === 0 ? 0.12 : k === mw - 1 ? -0.1 : 0) - j * 0.02 + hash2(idx, j, seed) * 0.06;
      if (top) g.set(x, yy, '▄', stoneCol(lv + 0.3), null);
      else g.set(x, yy, k === 0 ? '▐' : ' ', stoneCol(lv + 0.15), stoneCol(lv));
    }
  }
}

/** Arco ogival (gótico). Retorna função interior(x,y). */
export function gothicArch(g, cx, base, span, height, o = {}) {
  const a = span / 2;                       // meia largura em colunas
  const ax = a * CW;                        // em px
  const apexH = Math.sqrt(3) * ax;          // altura do ogiva (arco equilátero) em px
  const spring = base - (height - apexH / CH); // linha de nascença (em linhas)
  const ring = o.ring ?? 2;
  const inside = (x, y, grow = 0) => {
    const px = (x + 0.5 - cx) * CW, py = (y + 0.5 - spring) * CH;
    const A = ax + grow * CW;
    if (py >= 0) return Math.abs(px) <= A && y < base;
    // dois círculos de raio 2a centrados nas nascenças opostas
    const r = 2 * ax + grow * CW;
    const d1 = Math.hypot(px - ax, py), d2 = Math.hypot(px + ax, py);
    return d1 <= r && d2 <= r;
  };
  const R = rng(o.seed || 3);
  const top = Math.floor(spring - apexH / CH - ring - 1);
  for (let y = top; y < base; y++) for (let x = Math.floor(cx - a - ring - 1); x <= Math.ceil(cx + a + ring + 1); x++) {
    if (!g.inside(x, y)) continue;
    if (inside(x, y)) {
      // vão escuro com profundidade
      const depth = (y - top) / (base - top);
      const bg = mixHex('#050407', '#0c0a0f', depth * 0.6);
      g.set(x, y, R() < 0.05 ? '·' : ' ', '#1b1720', bg);
    } else if (inside(x, y, ring)) {
      // aduelas: juntas radiais
      const px = (x + 0.5 - cx) * CW, py = (y + 0.5 - spring) * CH;
      const ang = Math.atan2(py, px);
      const seg = Math.floor((ang + Math.PI) / (Math.PI / 14));
      const lv = 0.62 + hash2(seg, 1, 5) * 0.12 - (py > 0 ? 0.08 : 0);
      const bg = stoneCol(lv);
      const prevSeg = Math.floor((Math.atan2(py, px - CW) + Math.PI) / (Math.PI / 14));
      let ch = ' ', fg = scaleHex(bg, 1.3);
      if (py < 0 && prevSeg !== seg) { ch = Math.abs(px) < 3 ? '│' : px < 0 ? '╲' : '╱'; fg = MORTAR; }
      else if (py >= 0 && (y % 2 === 0)) { ch = '▁'; fg = MORTAR; }
      g.set(x, y, ch, fg, bg);
    }
  }
  return { inside, spring, apexY: spring - apexH / CH, top };
}

export function portcullis(g, arch, cx, span, base, openRows) {
  const a = span / 2;
  const bottom = base - openRows;
  for (let y = Math.floor(arch.apexY); y < bottom; y++) for (let x = Math.floor(cx - a); x <= Math.ceil(cx + a); x++) {
    if (!arch.inside(x, y)) continue;
    const vx = (x - Math.floor(cx - a)) % 3 === 1, hy = y % 4 === 0;
    if (vx && hy) g.set(x, y, '╋', '#5a544d', g.getBg(x, y));
    else if (vx) g.set(x, y, '┃', '#4a4540', g.getBg(x, y));
    else if (hy) g.set(x, y, '━', '#3f3a36', g.getBg(x, y));
    if (y === bottom - 1 && vx) g.set(x, y, '▼', '#6b645b', g.getBg(x, y));
  }
}

export function arrowSlit(g, x, y, h) {
  g.set(x, y, '▗', '#0a090c', null);
  for (let j = 1; j < h - 1; j++) g.set(x, y + j, '┃', '#020203', '#0a090c');
  g.set(x, y + h - 1, '▝', '#0a090c', null);
}

export function cracks(g, x0, y0, w, h, n, seed) {
  const R = rng(seed);
  for (let i = 0; i < n; i++) {
    let x = x0 + Math.floor(R() * w), y = y0 + Math.floor(R() * h);
    const len = 3 + Math.floor(R() * 7);
    for (let j = 0; j < len; j++) {
      const dir = R() < 0.5 ? -1 : 1;
      if (!g.inside(x, y) || !g.getBg(x, y)) break;
      g.set(x, y, dir < 0 ? '╲' : '╱', '#09080b');
      x += dir < 0 ? 1 : -1; y += 1;
    }
  }
}

export function ivy(g, x, y, len, seed) {
  const R = rng(seed);
  const cols = ['#2f3a24', '#3e4b2c', '#55613a', '#26301e'];
  for (let j = 0; j < len; j++) {
    x += Math.round((R() - 0.5) * 1.4);
    if (!g.inside(x, y + j) || !g.getBg(x, y + j)) continue;
    g.set(x, y + j, ['⁎', '§', '¦', '⸽', '*', '%'][Math.floor(R() * 6)], cols[Math.floor(R() * 4)]);
    if (R() < 0.4 && g.getBg(x + 1, y + j)) g.set(x + 1, y + j, R() < 0.5 ? '᠅' : '·', cols[Math.floor(R() * 4)]);
  }
}

function inscription(g, x, y, text, fg, bg) { g.text(x, y, text, fg, bg); }

function machicolations(g, x0, y, w) {
  for (let x = x0; x < x0 + w; x++) g.set(x, y, (x - x0) % 3 === 0 ? '┴' : '─', '#0c0b0f', stoneCol(0.3));
  for (let x = x0; x < x0 + w; x++) g.set(x, y + 1, (x - x0) % 3 === 0 ? '▀' : ' ', stoneCol(0.25), (x - x0) % 3 === 0 ? null : '#121116');
}

// ═══════════════ PORTÃO DO REINO ═══════════════
export const GATE = { W: 124, H: 78, towerW: 30, recess: 4 };

export function makeGatehouse(seed = 7) {
  const { W, H, towerW } = GATE;
  const g = new TypoGrid(W, H);
  const cBase = H - 1 - GATE.recess;  // base do bloco central (recuado)
  const cFace = 26, cTop = 19;
  // Bloco central
  topSurface(g, towerW - 2, cTop, W - 2 * towerW + 4, cFace - cTop, { seed });
  merlons(g, towerW - 2, cTop + 1, W - 2 * towerW + 4, { mh: 3, seed: seed + 1, damage: 0.15 });
  ashlar(g, towerW - 2, cFace, W - 2 * towerW + 4, cBase - cFace + 1, { seed: seed + 2, light: 0.46 });
  merlons(g, towerW - 2, cFace - 1, W - 2 * towerW + 4, { mh: 4, seed: seed + 3, damage: 0.12 });
  machicolations(g, towerW - 2, cFace, W - 2 * towerW + 4);
  // Friso com inscrição antiga
  const fy = cFace + 3;
  for (let x = towerW; x < W - towerW; x++) g.set(x, fy, x % 4 === 0 ? '╬' : '═', '#6b6250', stoneCol(0.36));
  inscription(g, W / 2 - 9, fy + 1, '灰 の 王 国 · 誓 約', '#8a7a56', stoneCol(0.34));
  // Arco ogival e grade
  const cx = W / 2, span = 22;
  const arch = gothicArch(g, cx, cBase + 1, span, 40, { ring: 2, seed });
  portcullis(g, arch, cx, span, cBase + 1, 16);
  // Pedra-chave com o selo do rei
  const ky = Math.round(arch.apexY) - 2;
  g.set(cx - 1, ky, '王', MATERIALS.G, '#2a2420');
  g.setBg(cx, ky, '#2a2420');
  g.set(cx - 2, ky, '◣', '#2a2420'); g.set(cx + 1, ky, '◢', '#2a2420');
  // Degraus na soleira
  for (let y = cBase + 1; y < H; y++) for (let x = cx - span / 2 - 3; x < cx + span / 2 + 3; x++) {
    const lv = 0.5 - (y - cBase) * 0.04 + hash2(x >> 2, y, 3) * 0.08;
    g.set(x, y, (y - cBase) % 2 ? '▁' : ' ', MORTAR, stoneCol(lv));
  }
  cracks(g, towerW, cFace, W - 2 * towerW, 40, 9, seed + 5);
  // Torres (mais próximas da câmera: base em H-1)
  for (const side of [0, 1]) {
    const x0 = side ? W - towerW : 0;
    const tTop = side ? 5 : 2, tFace = tTop + 7;
    topSurface(g, x0, tTop, towerW, tFace - tTop, { seed: seed + 10 + side });
    ashlar(g, x0, tFace, towerW, H - tFace, { seed: seed + 20 + side, light: side ? 0.44 : 0.52, edgeDark: true });
    // Talude (base inclinada)
    for (let y = H - 7; y < H; y++) for (let x = x0; x < x0 + towerW; x++) if (g.getBg(x, y)) g.setFg(x, y, MORTAR);
    for (let x = x0; x < x0 + towerW; x++) g.set(x, H - 8, '▄', stoneCol(0.55), stoneCol(0.38));
    machicolations(g, x0, tFace, towerW);
    // Ameias (torre direita parcialmente desabada)
    merlons(g, x0, tTop + 1, towerW, { mh: 2, seed: seed + 30 + side });
    merlons(g, x0, tFace - 1, towerW, { mh: 4, seed: seed + 40 + side, damage: side ? 0.5 : 0.1, broken: side ? (x => x > x0 + 15) : null });
    // Seteiras e janela
    const mx = x0 + towerW / 2;
    arrowSlit(g, mx, tFace + 8, 7);
    arrowSlit(g, mx, tFace + 34, 7);
    g.set(mx - 1, tFace + 20, '田', '#d89a4a', '#120d0a');
    g.setBg(mx, tFace + 20, '#120d0a');
    g.set(mx - 2, tFace + 19, '╭', stoneCol(0.7)); g.set(mx + 1, tFace + 19, '╮', stoneCol(0.7));
    cracks(g, x0, tFace, towerW, H - tFace - 8, 6, seed + 50 + side);
    if (!side) { ivy(g, x0 + 4, tFace + 2, 30, seed + 60); ivy(g, x0 + 9, tFace + 6, 22, seed + 61); }
    else { ivy(g, x0 + 22, tFace + 10, 26, seed + 62); }
  }
  // Escombros na base da torre direita
  const R = rng(seed + 70);
  for (let i = 0; i < 26; i++) {
    const x = W - towerW + 2 + Math.floor(R() * (towerW - 2)), y = H - 1 - Math.floor(R() * 3);
    g.set(x, y, ['▄', '▖', '▗', '▂', '▪'][Math.floor(R() * 5)], stoneCol(0.4 + R() * 0.3), null);
  }
  return { art: g.toArt(), anchor: [W / 2, H], meta: { cBase, arch, cx } };
}

// ═══════════════ MURALHA (segmento) ═══════════════
export const WALL = { W: 64, H: 56 };
export function makeWallSegment(seed = 1, opts = {}) {
  const { W, H } = WALL;
  const g = new TypoGrid(W, H);
  const top = 6, face = 13;
  const breach = opts.breach;
  const R = rng(seed);
  const breachX0 = 18 + Math.floor(R() * 20), breachW = 12 + Math.floor(R() * 8);
  const lowered = x => breach && x >= breachX0 && x < breachX0 + breachW ? Math.round(8 + Math.sin((x - breachX0) / breachW * Math.PI) * 8) : 0;
  topSurface(g, 0, top, W, face - top, { seed });
  merlons(g, 0, top + 1, W, { mh: 2, seed: seed + 1, damage: 0.2 });
  ashlar(g, 0, face, W, H - face, { seed: seed + 2, light: 0.42 + (seed % 3) * 0.03 });
  merlons(g, 0, face - 1, W, { mh: 4, seed: seed + 3, damage: 0.18, broken: x => lowered(x) > 0 });
  machicolations(g, 0, face, W);
  // Brecha: o topo desabou
  if (breach) {
    for (let x = breachX0; x < breachX0 + breachW; x++) {
      const d = lowered(x);
      for (let y = top - 1; y < face + d; y++) g.set(x, y, ' ', null, null);
      g.set(x, face + d, R() < 0.5 ? '▗' : '▖', stoneCol(0.5), null);
      g.set(x, face + d + 1, '▀', stoneCol(0.55), stoneCol(0.3));
    }
    for (let i = 0; i < 30; i++) {
      const x = breachX0 - 4 + Math.floor(R() * (breachW + 8)), y = H - 1 - Math.floor(R() * 4);
      g.set(x, y, ['▄', '▖', '▗', '▂', '▪'][Math.floor(R() * 5)], stoneCol(0.35 + R() * 0.3), null);
    }
  }
  // Contraforte
  if (opts.buttress) {
    const bx = opts.buttress;
    for (let y = face + 6; y < H; y++) {
      const w = 3 + Math.floor((y - face) / 14);
      for (let x = bx; x < bx + w; x++) {
        const lv = 0.5 + (x === bx ? 0.12 : 0) - (y - face) / H * 0.2;
        g.set(x, y, x === bx ? '▐' : (y % 2 ? '▁' : ' '), x === bx ? stoneCol(lv + 0.2) : MORTAR, stoneCol(lv));
      }
    }
  }
  if (R() < 0.7) arrowSlit(g, 8 + Math.floor(R() * 48), face + 6, 6);
  cracks(g, 0, face, W, H - face, 5, seed + 4);
  if (R() < 0.6) ivy(g, 4 + Math.floor(R() * 56), face + 1, 18 + Math.floor(R() * 20), seed + 5);
  // Escorrimento escuro (manchas de umidade)
  for (let i = 0; i < 4; i++) {
    const x = Math.floor(R() * W), y0 = face + 2;
    for (let y = y0; y < y0 + 8 + R() * 18; y++) if (g.getBg(x, y)) g.setBg(x, y, scaleHex(g.getBg(x, y), 0.72));
  }
  return { art: g.toArt(), anchor: [W / 2, H], breach: breach ? [breachX0, breachW] : null };
}

// ═══════════════ FORTALEZA AO FUNDO (silhueta) ═══════════════
export function makeKeep(seed = 5) {
  const W = 170, H = 64;
  const g = new TypoGrid(W, H);
  const R = rng(seed);
  const towers = [
    { x: 8, w: 18, h: 34 }, { x: 30, w: 24, h: 44 }, { x: 60, w: 30, h: 52 }, { x: 96, w: 22, h: 46 },
    { x: 122, w: 18, h: 38 }, { x: 144, w: 20, h: 30 },
  ];
  // Corpo (salão/catedral) ligando as torres
  for (let y = H - 22; y < H; y++) for (let x = 4; x < W - 4; x++) {
    const v = 0.12 + fbm(x * 0.05, y * 0.05, seed) * 0.1;
    g.set(x, y, (x + y) % 7 === 0 ? '╱' : ' ', stoneCol(v + 0.08), stoneCol(v));
  }
  // Telhado de duas águas do salão
  for (let y = H - 30; y < H - 22; y++) {
    const k = y - (H - 30);
    for (let x = 20 + (12 - k); x < W - 20 - (12 - k); x++) g.set(x, y, x % 3 ? '▒' : '╱', stoneCol(0.18), stoneCol(0.1));
  }
  for (const t of towers) {
    const top = H - t.h;
    for (let y = top; y < H; y++) for (let x = t.x; x < t.x + t.w; x++) {
      const u = (x - t.x) / t.w;
      const v = 0.1 + (1 - u) * 0.1 + fbm(x * 0.07, y * 0.07, seed + t.x) * 0.08;
      g.set(x, y, x === t.x ? '▐' : (y % 3 === 0 && (x - t.x) % 4 === 0 ? '▏' : ' '), stoneCol(v + 0.12), x === t.x ? null : stoneCol(v));
    }
    // Agulha cônica
    const ch = Math.min(Math.round(t.w * 0.9), H - t.h - 3);
    for (let k = 0; k < ch; k++) {
      const hw = (t.w / 2) * (1 - k / ch);
      const y = top - 1 - k;
      for (let x = Math.round(t.x + t.w / 2 - hw); x < Math.round(t.x + t.w / 2 + hw); x++) {
        const u = (x - t.x) / t.w;
        g.set(x, y, u < 0.5 ? '╱' : '▒', stoneCol(u < 0.5 ? 0.24 : 0.12), stoneCol(0.08));
      }
    }
    g.set(Math.round(t.x + t.w / 2) - 1, top - ch - 1, '†', stoneCol(0.3));
    // Janelas góticas, algumas com luz fraca (alguém ainda vive lá?)
    for (let y = top + 5; y < H - 24; y += 9) {
      const wx = t.x + Math.floor(t.w / 2) - 1;
      const lit = R() < 0.22;
      g.set(wx, y, '╭', stoneCol(0.25)); g.set(wx + 1, y, '╮', stoneCol(0.25));
      for (let j = 1; j < 4; j++) { g.set(wx, y + j, '▐', lit ? '#8a4a1c' : '#060508', '#060508'); g.set(wx + 1, y + j, '▌', lit ? '#8a4a1c' : '#060508', '#060508'); }
    }
  }
  // Vitral gigante (rosácea) no salão central
  const rx = 75, ry = H - 13;
  for (let y = -5; y <= 5; y++) for (let x = -9; x <= 9; x++) {
    const d = Math.hypot(x * CW, y * CH) / 52;
    if (d > 1) continue;
    const a = Math.atan2(y * CH, x * CW);
    const spoke = Math.abs(Math.sin(a * 4)) < 0.25;
    g.set(rx + x, ry + y, d > 0.85 ? '◦' : spoke ? '✶' : d < 0.2 ? '◉' : '·', d > 0.85 ? stoneCol(0.3) : '#6a2530', '#0b0709');
  }
  return { art: g.toArt(), anchor: [W / 2, H] };
}
