// ASHEN — Salvamento local (localStorage, com tolerância a falhas).
// Configurações e progresso ficam separados. Nada depende de servidor.

const KEY_SETTINGS = 'ashen.settings.v1';
const KEY_GAME = 'ashen.save.v1';

function read(key) {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : null; } catch (e) { return null; }
}
function write(key, v) {
  try { localStorage.setItem(key, JSON.stringify(v)); return true; } catch (e) { return false; }
}

export const Save = {
  loadSettings: () => read(KEY_SETTINGS),
  saveSettings: s => write(KEY_SETTINGS, s),
  loadGame: () => read(KEY_GAME),
  saveGame: g => write(KEY_GAME, { ...g, savedAt: Date.now(), v: 1 }),
  clearGame: () => { try { localStorage.removeItem(KEY_GAME); } catch (e) { /* ok */ } },
};
