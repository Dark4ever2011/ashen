// ASHEN — The Last Oath · jogo principal (mundo 3D tipográfico)
// Geometria 3D invisível → tudo o que aparece na tela é letra, número ou símbolo.
// Física em passo fixo (60 Hz); limite de quadros configurável (o A56 tem tela de 120 Hz).

import { loadFonts } from '../engine/typography.js';
import { Input } from '../engine/input.js';
import { m4, v3 } from './math3d.js';
import { GlyphAtlas } from './glyphs.js';
import { GlyphRenderer, flatBones } from './renderer3d.js';
import { buildParts, lodOrder, PointSet } from './sampler.js';
import { knightParts, poseKnight, poseFallen, makeCape, makeTabard, makeBanner, COMBO } from './knight3d.js';
import { torchParts, shieldParts, crateParts, debrisParts, shrineParts } from './props3d.js';
import { Audio, Narrator } from './audio.js';
import { bossParts } from './boss3d.js';
import { initGameplay, combatPre, combatPost, gameplayRender, gameplaySave, rest, playOpening, colliderOff, extraInteract, ARENA } from './gameplay.js';
import { sceneParts, groundParts, buildTrees, avoidVeg, COLLIDERS, BOUNDS, LIGHTS, TORCHES, BANNERS, INTERACT, LORE, BRAZIER, FALLEN, SPAWN, WALL_Z } from './world3d.js';
import { FX } from './fx3d.js';
import { buildVegetation } from './veg3d.js';
import { Weather } from './weather.js';
import { loadWorld, saveWorld } from './cache.js';
import { Hud } from '../ui/hud.js';
import { Menu } from '../ui/menus.js';
import { setupControls, updateInteractButton } from '../ui/controls.js';
import { DEFAULT_SETTINGS, effective } from '../ui/settings.js';
import { buildLogo } from '../ui/logo.js';
import { Save } from '../systems/save.js';

const $ = id => document.getElementById(id);
const STEP = 1 / 60;
const CAM = { yaw: 0.27, pitch: 0.74, dist: 6.5, fov: 32 * Math.PI / 180, min: 3.7, max: 10 };
const KSCALE = 0.955;                 // ~1,75 m de corpo, ~1,78 m com o elmo
const REGION = { region: 'I · Reino das Cinzas', title: 'O Portão do Rei', subtitle: '灰の王国' };
// todo caractere que pode aparecer precisa estar no atlas antes de ele ir para a GPU
const EXTRA_GLYPHS = '│─╲∴•◆§‹›°⁎✶✦|¦¤†·,\'~≈∼-*+✻═━▼ʌ⁞盾薬‡/\\=#';

const game = window.__ASHEN = window.__ASHEN3D = {
  CAM, state: 'loading', ready: false, t: 0, settings: null,
  player: { x: SPAWN.x, z: SPAWN.z, vx: 0, vz: 0, yaw: 0.3, phase: 0, blend: 0, run: 0, breath: 0, time: 0, atk: -1, combo: 0, queued: false, accel: 0, turn: 0, look: 0, speed: 0 },
  cam: { x: SPAWN.x, z: SPAWN.z }, trail: [], trailAcc: 0, brazierLit: false, focus: null, wind: [1, 0, 0.5],
};

function setLoad(p, text) { $('bar').firstElementChild.style.width = Math.round(p * 100) + '%'; if (text) $('load-text').textContent = text; }
const hashStr = s => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); };

async function boot() {
  $('logo').innerHTML = buildLogo();
  setLoad(0.03, 'carregando a fonte tipográfica…');
  await loadFonts('assets/fonts/');
  game.settings = { ...DEFAULT_SETTINGS, ...(Save.loadSettings() || {}) };
  const saved = Save.loadGame();
  if (saved && Number.isFinite(saved.x) && Number.isFinite(saved.z)) { game.player.x = game.cam.x = saved.x; game.player.z = game.cam.z = saved.z; }
  game.brazierLit = !!(saved && saved.brazierLit);

  // ── atlas: todos os caracteres do mundo ──
  setLoad(0.06, 'gravando o alfabeto das cinzas…');
  const atlas = new GlyphAtlas(64, 32);
  const sParts = sceneParts(), gParts = groundParts(), kParts = knightParts();
  const xParts = { torch: torchParts(), shield: shieldParts(), crate: crateParts(), debris: debrisParts(), boss: bossParts(), shrine: shrineParts() };
  for (const p of [...sParts, ...kParts, ...Object.values(xParts).flat()]) for (const d of p.decals || []) atlas.get(d.glyph);
  for (const c of EXTRA_GLYPHS + '誓獅最後の灰王国約眠墓') atlas.get(c);
  const fx = new FX(atlas, 3800);
  atlas.build();
  const atlasN = atlas.list.length;
  const canvas = $('gl');
  let R;
  try { R = new GlyphRenderer(canvas, atlas); } catch (e) { throw new Error('Este navegador não oferece WebGL2: ' + e.message); }
  Object.assign(game, { R, atlas, fx });

  // ── mundo: do cache local ou esculpido agora ──
  const key = hashStr(atlas.list.join(''));
  let sets = await loadWorld(key);
  const trees = buildTrees();
  if (!sets) {
    $('load-note').textContent = 'Primeira abertura: o mundo é esculpido uma vez e guardado no aparelho.';
    setLoad(0.08, 'esculpindo o chão…');
    const ground = await buildParts(gParts, atlas, { seed: 7, sizeMul: 2.1 });
    const veg = buildVegetation({ count: 2200, area: [BOUNDS.x0, WALL_Z + 0.3, BOUNDS.x1, BOUNDS.z1 + 0.4], avoid: avoidVeg, atlas });
    ground.append(veg.ps);
    const scene = await buildParts(sParts, atlas, { seed: 101, sizeMul: 2.1, onProgress: (f, n) => setLoad(0.1 + f * 0.62, `erguendo o Reino das Cinzas: ${n}`) });
    for (const t of trees) { scene.append(t.wood); scene.append(t.leaves); }
    setLoad(0.74, 'forjando a armadura…');
    const kraw = await buildParts(kParts, atlas, { seed: 17, sizeMul: 2.2, spacingMul: 0.8, onProgress: (f, n) => setLoad(0.74 + f * 0.2, `cavaleiro: ${n}`) });
    const lod = lodOrder(kraw);
    sets = { ground, scene, knight: lod.ps, meta: { levels: lod.levels, veg: [veg.tufts, veg.plants, veg.ps.n] } };
    setLoad(0.94, 'erguendo o rei do túmulo…');
    for (const [k, parts] of Object.entries(xParts)) {
      if (k === 'boss') for (const q of parts) q.aoF = q.f;
      sets[k] = await buildParts(parts, atlas, { seed: 31, sizeMul: k === 'boss' ? 2.15 : 2.1 });
    }
    if (atlas.list.length !== atlasN) console.warn('[ASHEN] caracteres novos depois do atlas:', atlas.list.slice(atlasN).join(''));
    setLoad(0.95, 'guardando o mundo no aparelho…');
    await saveWorld(key, sets);
  } else setLoad(0.9, 'o mundo já estava guardado no aparelho…');
  const { ground, scene, knight } = sets;
  game.vegInfo = sets.meta.veg;

  // ── malhas ──
  game.groundMesh = R.addMesh(ground, { occlude: false, chunk: 3 });
  game.sceneMesh = R.addMesh(scene, { chunk: 2.5 });
  game.knightMesh = R.addMesh(knight);
  // cavaleiro caído: a mesma armadura, numa pose fixa, encostado na muralha
  const fallenW = m4.mul(m4.mul(m4.translate(FALLEN.x, 0, FALLEN.z), m4.rotY(0.15)), m4.scale(KSCALE, KSCALE, KSCALE));
  const fallenBones = poseFallen().map(b => m4.mul(fallenW, b)); fallenBones[0] = m4.ident();
  game.fallenMesh = R.addMesh(knight, { bones: fallenBones });
  const fcape = makeCape(atlas);
  for (let i = 0; i < 260; i++) fcape.update(1 / 60, fallenBones[2], [{ c: m4.point(fallenBones[2], [0, 0.18, -0.02]), r: 0.25 * KSCALE }], [0, 0, 0]);
  R.addMesh(fcape.ps);
  // brasas do braseiro (só aparecem acesas)
  const coals = new PointSet(32);
  for (let i = 0; i < 22; i++) { const a = i * 2.4, r = 0.08 + (i % 5) * 0.06; coals.push([BRAZIER.x + Math.cos(a) * r, 1.15, BRAZIER.z + Math.sin(a) * r], [0, 1, 0], [1, 0, 0], 11, atlas.get(['•', '*', '·', '✶'][i % 4]), 0, 2 | 4, 0.07, i * 7); }
  game.coalMesh = R.addMesh(coals, { occlude: false });
  game.cape = makeCape(atlas); game.cape._emit(); game.capeMesh = R.addMesh(game.cape.ps, { dynamic: true });
  game.tabard = makeTabard(atlas); game.tabard._emit(); game.tabardMesh = R.addMesh(game.tabard.ps, { dynamic: true });
  game.banners = BANNERS.map(b => { const c = makeBanner(atlas, b.x, b.top, b.z); c._emit(); return { c, mesh: R.addMesh(c.ps, { dynamic: true }) }; });
  game.counts = { scene: scene.n + ground.n, knight: knight.n, total: scene.n + ground.n + knight.n * 2 + game.cape.ps.n };
  R.setupParticles(3800);

  // ── fogo, luz, clima ──
  game.fires = { brazier: fx.addFire([BRAZIER.x, 1.12, BRAZIER.z], 0.3, 170, 0.12), torches: TORCHES.map(t => fx.addFire([t[0], t[1], t[2]], 0.06, 32)) };
  fx.trees = trees.filter(t => t.kind === 'autumn').flatMap(t => t.canopy.map(c => [...c, [0.62, 0.24 + Math.random() * 0.25, 0.1]]));
  game.lights = LIGHTS.map(l => ({ ...l, value: l.base, level: l.name === 'braseiro' ? (game.brazierLit ? 1 : 0) : 1 }));
  game.weather = new Weather(game.settings.weather);
  game.weather.onChange = s => showWeather();
  setBrazier(game.brazierLit, false);
  game.audio = new Audio(); game.narrator = new Narrator();
  initGameplay(game, sets, atlas, saved);

  // ── interface ──
  const input = game.input = new Input(canvas);
  if (game.settings.bindings) input.setBindings(game.settings.bindings);
  game.hud = new Hud();
  game.menu = new Menu(game);
  setupControls(game);
  setupZoom(canvas);
  applySettings(false);
  window.addEventListener('resize', onResize);
  window.visualViewport && window.visualViewport.addEventListener('resize', onResize);
  window.addEventListener('orientationchange', () => setTimeout(onResize, 200));
  document.addEventListener('visibilitychange', () => { if (document.hidden && game.state === 'play') game.save(); });
  $('rotate-ok').onclick = () => { game.rotateDismissed = true; checkRotate(); };

  setLoad(1, '');
  $('load-text').textContent = ''; $('load-note').textContent = '';
  game.state = 'title'; game.ready = true;
  document.body.classList.add('title');
  $('loading').classList.add('overlay');
  $('bar').classList.add('hidden');
  const start = $('start');
  start.classList.remove('hidden');
  const touch = matchMedia('(pointer: coarse)').matches;
  $('start-hint').textContent = touch
    ? 'Joystick à esquerda · » corre · ⚔ ataca (toque de novo para o combo) · ◈ interage · dois dedos dão zoom · ≡ menu'
    : 'WASD/setas andam · Shift corre · J ou espaço ataca (combo) · E interage · roda do mouse dá zoom · Esc menu · F3 desempenho';
  start.onclick = () => { game.audio.unlock(); beginPlay(touch); };
  window.addEventListener('pointerdown', () => game.audio.unlock(), { capture: true });
  window.addEventListener('keydown', function k(e) { game.audio.unlock(); if (game.state === 'title' && (e.code === 'Enter' || e.code === 'Space')) { window.removeEventListener('keydown', k); beginPlay(false); } });
  requestAnimationFrame(frame);
}

function beginPlay(touch) {
  if (game.state !== 'title') return;
  if (touch) game.fullscreen();
  $('loading').classList.add('fade');
  setTimeout(() => $('loading').classList.add('hidden'), 950);
  game.state = 'play';
  document.body.classList.remove('title');
  game.input.clearAll();
  const region = () => { game.hud.showRegion(REGION); setTimeout(showWeather, 6500); };
  if (!game.introSeen) playOpening(game, region); else region();
  checkRotate();
}

function setupZoom(canvas) {
  const pts = new Map(); let pinch = null;
  const span = () => { const a = [...pts.values()]; return Math.hypot(a[0][0] - a[1][0], a[0][1] - a[1][1]); };
  const zoomTo = d => { CAM.dist = Math.max(CAM.min, Math.min(CAM.max, d)); };
  canvas.addEventListener('touchstart', e => { for (const t of e.changedTouches) pts.set(t.identifier, [t.clientX, t.clientY]); if (pts.size === 2) pinch = { s: span(), d: CAM.dist }; }, { passive: true });
  canvas.addEventListener('touchmove', e => { for (const t of e.changedTouches) if (pts.has(t.identifier)) pts.set(t.identifier, [t.clientX, t.clientY]); if (pinch && pts.size === 2) { e.preventDefault(); zoomTo(pinch.d * pinch.s / Math.max(20, span())); } }, { passive: false });
  const endT = e => { for (const t of e.changedTouches) pts.delete(t.identifier); if (pts.size < 2) pinch = null; };
  canvas.addEventListener('touchend', endT); canvas.addEventListener('touchcancel', endT);
  canvas.addEventListener('wheel', e => { e.preventDefault(); zoomTo(CAM.dist * Math.exp(e.deltaY * 0.0012)); }, { passive: false });
}

function applySettings(save = true) {
  const g = game, s = g.settings, eff = effective(s);
  const dpr = Math.min(window.devicePixelRatio || 1, eff.dpr);
  g.R.resize(dpr / (window.devicePixelRatio || 1));
  g.fx.density = eff.fx;
  g.shadowHalf = eff.shadow;
  g.input.haptics = s.haptics;
  if (g.audio) g.audio.setVolume(s.sound !== false, s.volume == null ? 0.8 : s.volume);
  if (g.narrator) { g.narrator.on = s.narration !== false; if (!g.narrator.on) g.narrator.stop(); }
  if (g.weather && g.weather.mode !== s.weather) { g.weather.setMode(s.weather); }
  document.documentElement.style.setProperty('--ctrl', s.controlScale);
  g.hud.showPerf(s.showPerf);
  if (save) Save.saveSettings(s);
}
game.applySettings = applySettings;

let resizeT = 0;
function onResize() { clearTimeout(resizeT); resizeT = setTimeout(() => { applySettings(false); checkRotate(); }, 120); }
function checkRotate() {
  const portrait = window.innerHeight > window.innerWidth * 1.05;
  const touch = matchMedia('(pointer: coarse)').matches;
  $('rotate').classList.toggle('hidden', !(portrait && touch && game.state === 'play' && !game.rotateDismissed));
}
game.fullscreen = () => {
  try {
    const el = document.documentElement;
    const p = el.requestFullscreen ? el.requestFullscreen({ navigationUI: 'hide' }) : null;
    if (p && p.then) p.then(() => { try { screen.orientation.lock('landscape').catch(() => {}); } catch (e) { /* ok */ } }).catch(() => {});
  } catch (e) { /* sem tela cheia */ }
};
function showWeather() {
  const el = $('weather-tag');
  el.textContent = '☁︎ ' + game.weather.label;
  el.classList.remove('hidden'); el.style.opacity = 1;
  clearTimeout(showWeather.t);
  showWeather.t = setTimeout(() => { el.style.opacity = 0; }, 3500);
}

// ─────────────── Progresso ───────────────
game.save = () => { const p = game.player; Save.saveGame({ x: +p.x.toFixed(2), z: +p.z.toFixed(2), brazierLit: game.brazierLit, region: 'reino-das-cinzas/portao', ...gameplaySave(game) }); };
game.replayIntro = () => { if (game.state === 'play' && !game.fight) playOpening(game, null); };
game.respawn = () => {
  const p = game.player;
  const at = game.lastRest === 'shrine' && game.shrine ? { x: game.shrine.x + 0.9, z: game.shrine.z + 1.0 } : game.brazierLit ? { x: BRAZIER.x + 0.9, z: BRAZIER.z + 1.1 } : SPAWN;
  Object.assign(p, { x: at.x, z: at.z, vx: 0, vz: 0, atk: -1, speed: 0 });
  game.cam.x = p.x; game.cam.z = p.z;
  game.teleported();
};
/** Depois de um salto de posição, os tecidos renascem pendurados no lugar. */
game.teleported = () => { game.cape.inited = false; game.tabard.inited = false; game.prevBones = null; };
game.resetProgress = () => { Save.clearGame(); game.hud.toast('Progresso apagado. Recarregue a página para recomeçar do início.'); };

function setBrazier(on, animate = true) {
  game.brazierLit = on;
  game.fires.brazier.off = !on;
  game.coalMesh.visible = on;
  if (on && animate) { game.fx.burst([BRAZIER.x, 1.2, BRAZIER.z], 80); game.audio && game.audio.play('ignite'); }
}

function interact(it) {
  const hud = game.hud;
  if (it.id === 'shrine') { rest(game, 'shrine'); hud.message(it.text, it.title, it); game.save(); hud.toast('Você descansa na Brasa do Rei: vida e frascos renovados. Progresso salvo.'); return; }
  if (it.id === 'brazier') {
    if (!game.brazierLit) { setBrazier(true); rest(game, 'brazier'); hud.message(LORE.brazierUnlit, it.title, it); game.save(); }
    else { rest(game, 'brazier'); hud.message(LORE.brazierLit, it.title, it); game.save(); hud.toast('Você descansa: vida e frascos renovados. Progresso salvo.'); }
    return;
  }
  hud.message(it.text, it.title, it);
}
function findFocus(p) {
  let best = null, bd = 1e9;
  for (const it of INTERACT) {
    const d = Math.hypot(p.x - it.x, p.z - it.z);
    if (d < it.r && d < bd) { bd = d; best = it; }
  }
  const ex = extraInteract(p, game);
  if (ex && ex.d < bd) best = ex;
  if (best && best.id === 'brazier') best.prompt = game.brazierLit ? 'descansar junto à chama' : 'acender o braseiro';
  return best;
}

// ─────────────── Física e controle ───────────────
function collide(p, r) {
  for (const c of COLLIDERS) {
    if (colliderOff(game, c)) continue;              // a arena do chefe está limpa
    if (c.type === 'circle') {
      const dx = p.x - c.x, dz = p.z - c.z, d = Math.hypot(dx, dz), rr = r + c.r;
      if (d < rr && d > 1e-6) { p.x = c.x + dx / d * rr; p.z = c.z + dz / d * rr; }
    } else {
      const qx = Math.max(c.x0, Math.min(p.x, c.x1)), qz = Math.max(c.z0, Math.min(p.z, c.z1));
      const dx = p.x - qx, dz = p.z - qz, d = Math.hypot(dx, dz);
      if (d < r) { if (d > 1e-6) { p.x = qx + dx / d * r; p.z = qz + dz / d * r; } else p.z = c.z1 + r; }
    }
  }
  for (const o of game.breakables || []) {
    if (!o.alive) continue;
    const dx = p.x - o.x, dz = p.z - o.z, d = Math.hypot(dx, dz), rr = r + 0.45;
    if (d < rr && d > 1e-6) { p.x = o.x + dx / d * rr; p.z = o.z + dz / d * rr; }
  }
  p.x = Math.max(BOUNDS.x0, Math.min(BOUNDS.x1, p.x)); p.z = Math.max(BOUNDS.z0 + r, Math.min(BOUNDS.z1, p.z));
}
const angDiff = (a, b) => Math.atan2(Math.sin(a - b), Math.cos(a - b));

function step(dt) {
  const g = game, p = g.player, input = g.input, st = input.poll();
  if (input.take('menu')) { g.menu.toggle(); return; }
  if (input.take('debug')) { g.settings.showPerf = !g.settings.showPerf; applySettings(); }
  g.focus = findFocus(p);
  if (input.take('interact')) { if (g.hud.msgOpen) g.hud.advance(); else if (g.focus) interact(g.focus); }
  // ── movimento com peso: acelera e freia aos poucos, gira com limite ──
  const fx = -Math.sin(CAM.yaw), fz = -Math.cos(CAM.yaw), rx = Math.cos(CAM.yaw), rz = -Math.sin(CAM.yaw);
  let wx = rx * st.mx + fx * -st.my, wz = rz * st.mx + fz * -st.my;
  const mag = Math.min(1, Math.hypot(st.mx, st.my));
  const wl = Math.hypot(wx, wz); if (wl > 0) { wx /= wl; wz /= wl; }
  if (g.cinema.active) {
    p.speed = 0; p.blend += (0 - p.blend) * Math.min(1, dt * 4); p.time = g.t;
    if (p.wake > 0) { p.wake = Math.max(0, p.wake - dt / 4); p.dead = p.wake; }
    combatPost(g, dt); world(dt); g.hud.update(dt, p); return;
  }
  const C = combatPre(g, dt, input, st, mag > 0.05 ? Math.atan2(wx, wz) : null);
  if (C.lock) {
    const ox = p.x, oz = p.z;
    if (C.vel) { p.x += C.vel[0] * dt; p.z += C.vel[1] * dt; collide(p, 0.32); }
    p.speed = 0; p.vx = (p.x - ox) / dt; p.vz = (p.z - oz) / dt;
    p.blend += (0 - p.blend) * Math.min(1, dt * 5); p.time = g.t;
    p.breath = (p.breath + dt / 3.0) % 1;
    const k = 1 - Math.exp(-dt * 4.5);
    g.cam.x += (p.x - g.cam.x) * k; g.cam.z += (p.z - g.cam.z) * k;
    combatPost(g, dt); world(dt); g.hud.update(dt, p);
    return;
  }
  const attacking = p.atk >= 0;
  const running = st.run && mag > 0.3 && !attacking && p.sta > 0 && p.block < 0.5;
  p.run += ((running ? 1 : 0) - p.run) * Math.min(1, dt * 3);
  let target = (1.55 + 2.1 * p.run) * (st.analog ? Math.max(0.35, mag) : (mag > 0 ? 1 : 0));
  if (attacking) target *= 0.15;
  target *= C.speedMul == null ? 1 : C.speedMul;
  if (running) { p.sta -= dt * 9; p.staWait = 0.4; }
  let look = 0;
  if (mag > 0.05) {
    const want = Math.atan2(wx, wz), d = angDiff(want, p.yaw);
    look = d;
    // virada grande parado: gira primeiro (com passinhos), depois anda
    if (Math.abs(d) > 1.6 && p.speed < 0.6) target *= 0.2;
    const rate = attacking ? (p.atk < 0.25 ? 6 : 0.8) : (5.5 - 2.2 * p.run);
    const turn = Math.max(-rate * dt, Math.min(rate * dt, d));
    p.yaw += turn;
    p.turn += (turn / dt - p.turn) * Math.min(1, dt * 8);
    if (p.speed < 0.4) p.phase = (p.phase + Math.abs(turn) * 0.16) % 1;
  } else p.turn *= 1 - Math.min(1, dt * 6);
  p.look += (look - p.look) * Math.min(1, dt * 10);
  const accel = target > p.speed ? 3.6 + 1.5 * p.run : 6.5;
  const prevSpeed = p.speed;
  p.speed += Math.max(-accel * dt, Math.min(accel * dt, target - p.speed));
  p.accel += ((p.speed - prevSpeed) / dt - p.accel) * Math.min(1, dt * 10);
  const ox = p.x, oz = p.z;
  p.x += Math.sin(p.yaw) * p.speed * dt; p.z += Math.cos(p.yaw) * p.speed * dt;
  if (C.vel) { p.x += C.vel[0] * dt; p.z += C.vel[1] * dt; }
  collide(p, 0.32);
  const rvx = (p.x - ox) / dt, rvz = (p.z - oz) / dt, sp = Math.hypot(rvx, rvz);
  p.vx = rvx; p.vz = rvz;
  const moving = sp > 0.1;
  p.blend += ((moving ? 1 : 0) - p.blend) * Math.min(1, dt * (moving ? 6 : 3.2));
  if (p.blend < 0.01) p.blend = 0;
  const stride = 4 * (0.3 + 0.2 * p.run);
  const ph0 = p.phase;
  if (moving) p.phase = (p.phase + sp * dt / stride) % 1;
  if (moving && p.blend > 0.3 && (Math.floor(ph0 * 2) !== Math.floor(p.phase * 2))) g.audio.play('step', 0.7 + 0.5 * p.run);
  else if (p.blend > 0.02) {             // ao parar, termina o passo e assenta o pé
    const tgt = p.phase < 0.5 ? 0.5 : 1;
    p.phase = Math.min(tgt, p.phase + dt * 0.9) % 1;
  }
  p.breath = (p.breath + dt / (3.8 - 1.4 * p.blend - 0.9 * p.run)) % 1;
  p.time = g.t;
  if (moving) { g.trailAcc += sp * dt; if (g.trailAcc > 0.33) { g.trailAcc = 0; g.footSide = -(g.footSide || 1); const r = 0.11 * g.footSide; g.trail.unshift([p.x + Math.cos(p.yaw) * r, p.z - Math.sin(p.yaw) * r, g.t]); g.trail.length = Math.min(g.trail.length, 8); } }
  // câmera: acompanha com suavização e antecipação
  const k = 1 - Math.exp(-dt * 4.5);
  // na luta, a câmera enquadra o cavaleiro e o chefe
  const fb = g.fight && g.boss ? 0.38 : 0;
  const fx_ = p.x + rvx * 0.35 + (fb ? (g.boss.x - p.x) * fb : 0), fz_ = p.z + rvz * 0.35 + (fb ? (g.boss.z - p.z) * fb : 0);
  g.cam.x += (fx_ - g.cam.x) * k;
  g.cam.z += (fz_ - g.cam.z) * k;
  g.fightZoom = (g.fightZoom || 0) + ((g.fight ? 1 : 0) - (g.fightZoom || 0)) * Math.min(1, dt * 1.5);
  combatPost(g, dt);
  world(dt);
  g.hud.update(dt, p);
  g.autosave = (g.autosave || 0) + dt;
  if (g.autosave > 25) { g.autosave = 0; g.save(); }
}

/** Ambiente: clima, vento, fogo e partículas (roda também na tela de título). */
function world(dt) {
  const g = game;
  g.t += dt;
  const W = g.weather;
  const hadBolt = !!W.bolt;
  W.update(dt);
  if (W.bolt && !hadBolt) g.audio.play('thunder', 0.6 + 0.4 * W.rain);
  const damp = W.fireDamp;
  for (const l of g.lights) {
    if (l.name === 'braseiro') l.level += ((g.brazierLit ? 1 : 0) - l.level) * Math.min(1, dt * 1.5);
    const s = l.pos[0] * 3.1 + l.pos[2];
    const n = 0.5 + 0.25 * Math.sin(g.t * 9.7 + s) + 0.15 * Math.sin(g.t * 23.1 + s * 2) + 0.1 * Math.sin(g.t * 3.3 + s * 0.5);
    l.pop = (l.pop || 0) * 0.9 + (Math.random() < 0.02 + damp * 0.05 ? 0.35 : 0);
    const base = l.base0 || (l.base0 = l.base);
    l.base = base * l.level * (1 - damp);                       // a chuva abafa a chama
    l.value = l.base * (1 - (l.flicker + damp * 0.3) * n + l.pop * 0.25);
  }
  const wa = 0.35 + 0.5 * Math.sin(g.t * 0.05) + 0.15 * Math.sin(g.t * 0.21);
  const wsd = (0.55 + 0.3 * Math.sin(g.t * 0.17) + 0.15 * Math.sin(g.t * 0.53 + 1.3)) * (1 + W.rain * 0.6);
  g.wind = [Math.cos(wa), Math.sin(wa), wsd];
  g.fx.wind = [g.wind[0] * wsd * 0.7, 0, g.wind[1] * wsd * 0.7];
  g.fx.rain = W.rain;
  g.fx.leafRate = 0.05 + wsd * 0.12;
  g.fx.update(dt, g.t, [g.cam.x, 0, g.cam.z]);
  // som ambiente: vento, chuva, fogo perto, tremor
  const p = g.player;
  let fire = g.player.offhand === 'torch' && g.torchFire && !g.torchFire.off ? 0.25 : 0;
  for (const l of g.lights) { if (l.name === 'tocha do cavaleiro') continue; const d = Math.hypot(l.pos[0] - p.x, l.pos[2] - p.z); fire = Math.max(fire, (l.level == null ? 1 : l.level) * Math.max(0, 1 - d / 6) * (l.name === 'chama roubada' && !g.shrine ? 0 : 1)); }
  g.audio.ambient({ wind: Math.min(1, wsd / 1.4), rain: W.rain, fire: Math.min(1, fire), quake: g.quakeLvl || 0 });
}

// ─────────────── Desenho ───────────────
function render(dtFrame = 1 / 60) {
  const g = game, R = g.R, p = g.player, W = g.weather;
  const Wm = m4.mul(m4.mul(m4.translate(p.x, 0, p.z), m4.rotY(p.yaw)), m4.scale(KSCALE, KSCALE, KSCALE));
  const pose = poseKnight(p);
  const bones = pose.map(b => m4.mul(Wm, b));
  bones[0] = m4.ident();
  bones.torch = pose.torch; bones.shield = pose.shield;
  gameplayRender(g, Wm, bones, dtFrame);
  g.knightMesh.boneData = flatBones(bones);
  boneVelocities(g, bones, dtFrame);
  const frac = Math.max(0.24, Math.min(1, Math.pow(3.6 / CAM.dist, 1.5)));
  g.fallenMesh.visible = Math.hypot(g.cam.x - FALLEN.x, g.cam.z - FALLEN.z) < 12;
  for (const m of [g.knightMesh, g.fallenMesh]) { m.drawCount = Math.round(m.n * frac); m.sizeMul = Math.min(1.9, Math.pow(1 / frac, 0.5) * 0.97); }
  // rastro da lâmina no corte
  if (p.atk >= 0) {
    const C = COMBO[p.combo];
    if (p.atk > C.hit[0] - 0.04 && p.atk < C.hit[1] + 0.06) g.fx.slash(m4.point(bones[16], [0, 0.45, 0]), m4.point(bones[16], [0, 1.1, 0]));
  }
  // tecidos
  const chestW = bones[2];
  const spheres = [
    { c: m4.point(chestW, [0, 0.18, -0.02]), r: 0.25 }, { c: m4.point(chestW, [0.2, 0.27, -0.02]), r: 0.15 }, { c: m4.point(chestW, [-0.2, 0.27, -0.02]), r: 0.15 }, { c: m4.point(chestW, [0, -0.02, -0.02]), r: 0.22 },
    { c: m4.point(bones[1], [0, -0.1, -0.02]), r: 0.22 },
    { c: m4.point(bones[10], [0, -0.2, 0]), r: 0.12 }, { c: m4.point(bones[13], [0, -0.2, 0]), r: 0.12 },
    { c: m4.point(bones[11], [0, -0.2, 0]), r: 0.09 }, { c: m4.point(bones[14], [0, -0.2, 0]), r: 0.09 },
  ];
  for (const q of spheres) q.r *= KSCALE;
  const wind = [g.fx.wind[0] * 1.1 - p.vx * 0.9, 0, g.fx.wind[2] * 0.8 - p.vz * 0.9];
  const legs = spheres.slice(5).map(s => ({ c: s.c, r: s.r + 0.03 }));
  const sub = Math.min(4, Math.max(1, Math.round(dtFrame * 60)));
  g.cape.wet = g.tabard.wet = W.wet;
  for (let i = 0; i < sub; i++) { g.cape.update(dtFrame / sub, chestW, spheres, wind); g.tabard.update(dtFrame / sub, bones[1], legs, wind); }
  R.updateMesh(g.capeMesh, g.cape.ps);
  R.updateMesh(g.tabardMesh, g.tabard.ps);
  const I = m4.ident(), bw = [g.fx.wind[0] * 2.4, 0, g.fx.wind[2] * 2.4];
  for (const b of g.banners) { b.c.wet = W.wet; b.c.update(dtFrame, I, [], bw); R.updateMesh(b.mesh, b.c.ps); }
  // câmera: de perto mais baixa (foto de corpo inteiro), de longe mais alta
  const dist = CAM.dist + (g.fightZoom || 0) * Math.max(0, 7.5 - CAM.dist);
  const zk = (dist - CAM.min) / (CAM.max - CAM.min);
  CAM.pitch = 0.3 + 0.44 * zk;
  const target = [g.cam.x, 0.9 + 0.05 * zk, g.cam.z - 0.2 * zk];
  const eye = [target[0] + Math.sin(CAM.yaw) * Math.cos(CAM.pitch) * dist, target[1] + Math.sin(CAM.pitch) * dist, target[2] + Math.cos(CAM.yaw) * Math.cos(CAM.pitch) * dist];
  const cine = g.cinema.update(g.state === 'play' ? dtFrame : 0);
  if (cine) { eye.splice(0, 3, ...cine.eye); target.splice(0, 3, ...cine.target); }
  g.shake = Math.max(0, (g.shake || 0) - dtFrame * 0.5);
  const sk = (g.shake || 0) + (cine ? cine.shake : 0);
  if (sk > 0) for (const v of [eye, target]) { v[0] += (Math.random() - 0.5) * sk; v[1] += (Math.random() - 0.5) * sk; }
  const view = m4.lookAt(eye, target, [0, 1, 0]);
  const proj = m4.perspective(CAM.fov, R.W / R.H, 1, 70);
  const vp = m4.mul(proj, view);
  const moonDir = v3.norm([-0.5, 0.78, 0.38]);
  const half = g.shadowHalf || 11;
  const lc = cine ? [cine.target[0], 0, cine.target[2]] : [g.cam.x, 0, g.cam.z - 1];
  const lightView = m4.lookAt(v3.add(lc, v3.mul(moonDir, 25)), lc, [0, 1, 0]);
  const lightVP = m4.mul(m4.ortho(-half, half, -half, half, 1, 70), lightView);
  const cloud = 1 - 0.4 * W.rain, fl = W.flash;
  R.frame({
    vp, lightVP, cam: eye, focus: [p.x, 0, p.z], time: g.t,
    pxScale: proj[5] * R.H / 2, glyphScale: 1, bias: 0.06, exposure: 12, shadowSize: 0.55 / half, shadows: true,
    moonDir, moonCol: [0.7 * cloud, 0.76 * cloud, 0.98 * cloud], sky: [0.16 * cloud + 0.02 * W.rain, 0.17 * cloud + 0.02 * W.rain, 0.23 * cloud + 0.03 * W.rain], ground: [0.07, 0.06, 0.06],
    rimDir: v3.norm([0.55, 0.35, -0.75]), rimCol: [0.3 * cloud, 0.36 * cloud, 0.52 * cloud],
    wet: W.wet, rain: W.rain, flash: fl,
    arena: [ARENA.x, ARENA.z, ARENA.r, g.arenaK || 0], arenaKeep: [game.boss ? game.boss.home.x : 0, game.boss ? game.boss.home.z + 0.4 : 0, 1.3],
    trail: g.trail, lights: g.lights, wind: g.wind,
    fog: [0.05 + 0.03 * W.rain, 0.05 + 0.035 * W.rain, 0.07 + 0.04 * W.rain, 0.07 * (1 + W.rain * 0.9)],
    clear: [0.022 + fl * 0.25, 0.019 + fl * 0.27, 0.028 + fl * 0.34], particles: g.fx.fill(),
  });
}

/** Velocidade linear e angular de cada osso (para os caracteres reagirem ao movimento). */
function boneVelocities(g, bones, dt) {
  const vel = g.velData || (g.velData = new Float32Array(18 * 4)), ang = g.angData || (g.angData = new Float32Array(18 * 4));
  const prev = g.prevBones;
  if (prev && dt > 0) {
    for (let i = 1; i < Math.min(18, bones.length); i++) {
      const a = bones[i], b = prev[i];
      for (let k = 0; k < 3; k++) vel[i * 4 + k] = vel[i * 4 + k] * 0.4 + 0.6 * (a[12 + k] - b[12 + k]) / dt;
      const r = (row, col) => a[0 + row] * b[0 + col] + a[4 + row] * b[4 + col] + a[8 + row] * b[8 + col];
      const tr = r(0, 0) + r(1, 1) + r(2, 2), s = 1 / (KSCALE * KSCALE);
      const c = Math.max(-1, Math.min(1, (tr * s - 1) / 2)), th = Math.acos(c);
      const w = [r(2, 1) - r(1, 2), r(0, 2) - r(2, 0), r(1, 0) - r(0, 1)], wl = Math.hypot(w[0], w[1], w[2]);
      for (let k = 0; k < 3; k++) ang[i * 4 + k] = ang[i * 4 + k] * 0.4 + 0.6 * (wl > 1e-6 ? w[k] / wl * th / dt : 0);
    }
  }
  g.prevBones = bones.map(m => m.slice());
  g.knightMesh.velData = vel; g.knightMesh.angData = ang;
}

// ─────────────── Laço ───────────────
let last = 0, acc = 0, fps = 60, frameMs = 16, cpuMs = 0, perfT = 0;
function frame(now) {
  requestAnimationFrame(frame);
  const cap = game.settings.fpsCap;
  if (cap && last && now - last < 1000 / cap - 2) return;
  const dt = last ? Math.min(0.1, (now - last) / 1000) : STEP;
  if (last) { frameMs += ((now - last) - frameMs) * 0.08; fps = 1000 / frameMs; }
  last = now;
  const t0 = performance.now();
  if (game.state === 'play' && !game.menu.open) {
    acc += dt;
    let n = 0;
    while (acc >= STEP && n < 4) { step(STEP); acc -= STEP; n++; }
    if (n >= 4) acc = 0;
  } else { world(dt); game.player.breath = (game.player.breath + dt / 3.8) % 1; game.player.time = game.t; acc = 0; }
  render(dt);
  cpuMs += (performance.now() - t0 - cpuMs) * 0.1;
  const f = game.focus, touch = game.input.lastDevice === 'touch';
  game.hud.setPrompt(game.state === 'play' && !game.menu.open && f ? f.prompt : '', (game.input.bindings.interact[0] || 'E').replace(/^Key/, ''), touch);
  updateInteractButton(f);
  if (game.settings.showPerf && now - perfT > 300) {
    perfT = now;
    const R = game.R, c = game.counts, v = game.vegInfo || [0, 0, 0];
    game.hud.perfText(`FPS ${Math.round(fps)} · CPU ${cpuMs.toFixed(1)} ms · na tela ${R.stats.glyphs.toLocaleString('pt-BR')}
mundo ${c.scene.toLocaleString('pt-BR')} · cavaleiro ${(game.knightMesh.drawCount || c.knight).toLocaleString('pt-BR')}/${c.knight.toLocaleString('pt-BR')}
vegetação ${v[0]} tufos · ${v[1]} plantas · ${v[2]} segmentos
clima ${game.weather.label} · chuva ${(game.weather.rain * 100) | 0}% · molhado ${(game.weather.wet * 100) | 0}%
partículas ${R.stats.particles} · ${R.W}×${R.H} px · ${game.settings.preset}`);
  }
}

function registerSW() {
  try {
    // no aplicativo Android os arquivos já estão no aparelho: sem service worker
    if (/ASHENApp/.test(navigator.userAgent)) return;
    if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./service-worker.js').catch(e => console.info('[ASHEN] SW indisponível:', e.message));
  } catch (e) { /* ok */ }
}
registerSW();

boot().catch(err => { console.error(err); $('load-text').textContent = 'Erro ao iniciar: ' + err.message; });
