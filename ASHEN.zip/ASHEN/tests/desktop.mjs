// Teste desktop: WASD/Shift, E, clique para mover/interagir, Esc (menu), troca de preset, F3, reconfigurar tecla.
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const url = process.argv[2] || 'http://localhost:8123/index.html', out = process.argv[3] || '/tmp/d';
const browser = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader'] });
const page = await (await browser.newContext({ viewport: { width: 1600, height: 900 }, deviceScaleFactor: 1 })).newPage();
const errors = [];
page.on('pageerror', e => errors.push(e.message));
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
const S = () => page.evaluate(() => { const g = window.__ASHEN, p = g.player; return { x: Math.round(p.x), y: Math.round(p.y), view: p.view, run: +p.run.toFixed(2), focus: g.focus ? g.focus.kind : null, msg: g.hud.msgOpen, menu: g.menu.open, preset: g.settings.preset, perf: g.settings.showPerf, W: g.renderer.W }; });
const out_ = [];
const log = async k => out_.push([k, await S()]);
await page.goto(url);
await page.waitForFunction(() => window.__ASHEN && window.__ASHEN.state === 'title', null, { timeout: 60000 });
await page.keyboard.press('Enter');
await page.waitForTimeout(500);
await log('início');
await page.keyboard.down('KeyD'); await page.waitForTimeout(700); await page.keyboard.up('KeyD'); await log('D (leste)');
await page.keyboard.down('KeyA'); await page.keyboard.down('ShiftLeft'); await page.waitForTimeout(900); await log('A+Shift (correr O)');
await page.keyboard.up('KeyA'); await page.keyboard.up('ShiftLeft');
await page.keyboard.down('KeyS'); await page.waitForTimeout(500); await page.keyboard.up('KeyS'); await log('S (sul)');
await page.keyboard.down('KeyW'); await page.waitForTimeout(600); await page.keyboard.up('KeyW'); await log('W (norte)');
// Clique no braseiro: anda até ele e interage
const pos = await page.evaluate(() => { const g = window.__ASHEN, r = g.renderer, b = g.world.props.find(p => p.kind === 'brazier'); return { x: r.dx(b.x) / r.P, y: r.dy(b.y, 40) / r.P }; });
await page.mouse.click(pos.x, pos.y);
await page.waitForTimeout(2500);
await log('clique no braseiro');
await page.screenshot({ path: `${out}-braseiro.png` });
await page.keyboard.press('KeyE'); await page.keyboard.press('KeyE'); await page.waitForTimeout(200); await log('E fecha mensagem');
// Segurar mouse: anda até o cursor
await page.mouse.move(1300, 700); await page.mouse.down(); await page.waitForTimeout(800); await page.mouse.up(); await log('segurou mouse (SE)');
// Menu
await page.keyboard.press('Escape'); await page.waitForTimeout(200); await log('Esc abre menu');
await page.screenshot({ path: `${out}-menu.png` });
await page.click('#menu .seg[data-k="preset"] button[data-v="EQUILIBRADA"]'); await page.waitForTimeout(300); await log('preset EQUILIBRADA');
// Reconfigurar "interagir" para F
await page.evaluate(() => { document.querySelector('details').open = true; });
await page.click('.keys button[data-a="interact"][data-s="0"]');
await page.keyboard.press('KeyF'); await page.waitForTimeout(100);
const bind = await page.evaluate(() => window.__ASHEN.input.bindings.interact.join(','));
out_.push(['tecla interagir', bind]);
await page.click('#m-resume'); await page.waitForTimeout(200); await log('continuar');
await page.keyboard.press('F3'); await page.waitForTimeout(400); await log('F3 painel');
await page.screenshot({ path: `${out}-perf.png` });
for (const [k, v] of out_) console.log(k.padEnd(22), typeof v === 'string' ? v : JSON.stringify(v));
console.log('erros:', errors.length ? errors.join('\n') : 'nenhum');
await browser.close();
