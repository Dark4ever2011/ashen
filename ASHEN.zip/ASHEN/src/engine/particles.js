// ASHEN — Partículas tipográficas
// Pool fixo em arrays tipados (sem alocação por quadro). Cada partícula é um glifo
// carimbado do atlas. Tipos: cinzas (ambiente), brasas (emissivas), poeira dos passos, folhas.

import { noise1 } from './animation.js';

export const P = { ASH: 0, EMBER: 1, DUST: 2, LEAF: 3, SPARK: 4 };

const LOOKS = {
  [P.ASH]: { glyphs: ['·', '˙', '∙', '·', '‧', '`', '⸱', '•'], colors: ['#6e6a68', '#8a8583', '#a29c97', '#5b5856', '#c9c2b8'] },
  [P.EMBER]: { glyphs: ['·', '•', '∙', '*', '˙', '⁕'], colors: ['#ffcf6a', '#ff9a3a', '#ff6a24', '#e0401c', '#a8281a'] },
  [P.DUST]: { glyphs: ['·', '˙', '∙', '⸱', ','], colors: ['#5f574e', '#766c61', '#8a7f72'] },
  [P.LEAF]: { glyphs: ['ˎ', '⸝', ',', '‚', '¸', '˴', '᎗'], colors: ['#5d4a33', '#6f5a3c', '#4a3c2b', '#7b6a4a'] },
  [P.SPARK]: { glyphs: ['✦', '·', '*', '˚'], colors: ['#fff0c2', '#ffd27a', '#ff9a3a'] },
};

export class Particles {
  constructor(max = 1400) {
    this.max = max;
    const f = () => new Float32Array(max);
    this.x = f(); this.y = f(); this.z = f(); this.vx = f(); this.vy = f(); this.vz = f();
    this.life = f(); this.ttl = f(); this.seed = f();
    this.kind = new Uint8Array(max); this.g = new Uint8Array(max); this.c = new Uint8Array(max);
    this.alive = new Uint8Array(max);
    this.free = [];
    for (let i = max - 1; i >= 0; i--) this.free.push(i);
    this.count = 0;
    this.wind = 16;
    this.ashTarget = 220;
    this.ashCount = 0;
    this.secondary = 1; // multiplicador de partículas secundárias (preset)
  }

  spawn(kind, x, y, z, vx, vy, vz, ttl) {
    const i = this.free.pop();
    if (i === undefined) return -1;
    const look = LOOKS[kind];
    this.alive[i] = 1; this.kind[i] = kind;
    this.x[i] = x; this.y[i] = y; this.z[i] = z;
    this.vx[i] = vx; this.vy[i] = vy; this.vz[i] = vz;
    this.life[i] = 0; this.ttl[i] = ttl; this.seed[i] = Math.random() * 1000;
    this.g[i] = (Math.random() * look.glyphs.length) | 0;
    this.c[i] = (Math.random() * look.colors.length) | 0;
    this.count++;
    if (kind === P.ASH) this.ashCount++;
    return i;
  }

  kill(i) {
    if (!this.alive[i]) return;
    this.alive[i] = 0; this.free.push(i); this.count--;
    if (this.kind[i] === P.ASH) this.ashCount--;
  }

  /** Mantém o campo de cinzas em volta da câmera. view em mundo: {x0,y0,x1,y1}. */
  feedAsh(view) {
    const want = Math.round(this.ashTarget);
    let n = 0;
    while (this.ashCount < want && n++ < 24) {
      const x = view.x0 + Math.random() * (view.x1 - view.x0);
      const y = view.y0 + Math.random() * (view.y1 - view.y0);
      const z = 40 + Math.random() * 380;
      this.spawn(P.ASH, x, y, z, this.wind * (0.6 + Math.random() * 0.8), (Math.random() - 0.5) * 6, -(10 + Math.random() * 22), 9 + Math.random() * 10);
    }
    this.view = view;
  }

  update(dt, t) {
    const v = this.view;
    for (let i = 0; i < this.max; i++) {
      if (!this.alive[i]) continue;
      this.life[i] += dt;
      if (this.life[i] >= this.ttl[i]) { this.kill(i); continue; }
      const k = this.kind[i];
      const s = this.seed[i];
      if (k === P.ASH) {
        const flutter = noise1(t * 0.9 + s) - 0.5;
        this.x[i] += (this.vx[i] + flutter * 26) * dt;
        this.y[i] += (this.vy[i] + (noise1(t * 0.7 + s * 2) - 0.5) * 10) * dt;
        this.z[i] += this.vz[i] * dt;
        if (this.z[i] <= 0) { this.z[i] = 0; this.vz[i] = 0; this.vx[i] *= 0.9; if (this.ttl[i] - this.life[i] > 1.2) this.ttl[i] = this.life[i] + 1.2; }
        // Recicla se saiu muito da vista.
        if (v && (this.x[i] < v.x0 - 220 || this.x[i] > v.x1 + 220 || this.y[i] < v.y0 - 260 || this.y[i] > v.y1 + 260)) this.kill(i);
      } else if (k === P.EMBER || k === P.SPARK) {
        this.vx[i] += (this.wind * 0.6 + (noise1(t * 2 + s) - 0.5) * 90 - this.vx[i]) * dt * 0.8;
        this.x[i] += this.vx[i] * dt; this.y[i] += this.vy[i] * dt;
        this.z[i] += this.vz[i] * dt; this.vz[i] *= (1 - dt * 0.4);
      } else if (k === P.DUST) {
        this.x[i] += this.vx[i] * dt; this.y[i] += this.vy[i] * dt; this.z[i] += this.vz[i] * dt;
        this.vx[i] *= (1 - dt * 3); this.vy[i] *= (1 - dt * 3); this.vz[i] -= 30 * dt;
        if (this.z[i] < 0) { this.z[i] = 0; this.vz[i] = 0; }
      } else if (k === P.LEAF) {
        const sway = Math.sin(t * 2.2 + s) * 34;
        this.x[i] += (this.vx[i] + sway + this.wind) * dt; this.y[i] += this.vy[i] * dt;
        this.z[i] += this.vz[i] * dt;
        if (this.z[i] <= 0) { this.z[i] = 0; this.vz[i] = 0; this.vx[i] = 0; this.vy[i] = 0; }
      }
    }
  }

  /** Desenha as partículas de um conjunto de tipos (emissivas são desenhadas depois da luz). */
  draw(r, atlas, emissive) {
    const ctx = r.ctx;
    let n = 0;
    for (let i = 0; i < this.max; i++) {
      if (!this.alive[i]) continue;
      const k = this.kind[i];
      const isEm = k === P.EMBER || k === P.SPARK;
      if (isEm !== emissive) continue;
      const px = r.dx(this.x[i]), py = r.dy(this.y[i], this.z[i]);
      if (px < -20 || py < -20 || px > r.W + 20 || py > r.H + 20) continue;
      const look = LOOKS[k];
      const lf = this.life[i] / this.ttl[i];
      let a = 1;
      if (k === P.ASH) a = Math.min(1, this.life[i] * 1.5) * (lf > 0.85 ? (1 - lf) / 0.15 : 1) * 0.85;
      else if (isEm) a = (1 - lf) * (0.6 + 0.4 * Math.sin(this.life[i] * 18 + this.seed[i]));
      else if (k === P.DUST) a = (1 - lf) * 0.7;
      else a = Math.min(1, (1 - lf) * 3);
      if (a <= 0.02) continue;
      // Brasas esfriam: muda de cor com a idade.
      const ci = isEm ? Math.min(look.colors.length - 1, (lf * look.colors.length) | 0) : this.c[i];
      ctx.globalAlpha = a;
      atlas.draw(ctx, look.glyphs[this.g[i]], look.colors[ci], px - atlas.p.cw / 2, py - atlas.p.ch / 2);
      n++;
    }
    ctx.globalAlpha = 1;
    return n;
  }
}
