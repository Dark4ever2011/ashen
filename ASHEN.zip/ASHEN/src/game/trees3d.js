// ASHEN 3D — Árvores: mortas, verdes e de outono.
// Tronco e galhos são geometria SDF (caracteres de madeira seguindo as fibras); as copas são
// nuvens de caracteres-folha presas aos galhos. No shader, a flag 16 balança a árvore inteira
// (mais no alto) e a flag 128 faz cada folha tremular e trocar de símbolo com o vento.

import * as S from './sdf.js';
import { MAT } from './glyphs.js';
import { noise3, rng } from './math3d.js';
import { PointSet } from './sampler.js';

export const LEAF_FLAG = 128;

// galho = cone arredondado + esfera envolvente (para pular galhos distantes na união)
const seg = (a, b, r1, r2) => ({ a, b, r1, r2, f: S.roundCone(a, b, r1, r2), c: [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2], R: Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]) / 2 + Math.max(r1, r2) });
/** União suave com descarte por esfera envolvente: dezenas de galhos sem custo proporcional. */
function fastUnion(segs, k) {
  return (x, y, z) => {
    let d = 1e9;
    for (const s of segs) {
      if (Math.hypot(x - s.c[0], y - s.c[1], z - s.c[2]) - s.R > d + k) continue;
      const v = s.f(x, y, z), h = Math.max(k - Math.abs(d - v), 0) / k;
      d = Math.min(d, v) - h * h * k * 0.25;
    }
    return d;
  };
}

/**
 * kind: 'dead' | 'green' | 'autumn'. size ≈ 1 → árvore de ~5,5 m.
 * Retorna { wood (PointSet), leaves (PointSet), collider, canopy: [[x,y,z,r]...] }.
 */
export function makeTree(x, z, seed, size, kind) {
  const R = rng(seed * 7919 + 13);
  const segs = [], tips = [];
  const lean = [(R() - 0.5) * 0.18, 1, (R() - 0.5) * 0.18];
  const maxDepth = kind === 'dead' ? 4 : 2;
  const grow = (a, dir, len, r, depth) => {
    const b = [a[0] + dir[0] * len, a[1] + dir[1] * len, a[2] + dir[2] * len];
    segs.push(seg(a, b, r, r * 0.7));
    if (depth >= maxDepth) { tips.push([b, dir, len]); return; }
    const n = depth === 0 ? 3 + (R() < 0.4 ? 1 : 0) : 2 + (R() < 0.35 ? 1 : 0);
    for (let i = 0; i < n; i++) {
      const ang = (i / n) * Math.PI * 2 + R() * 1.6 + depth;
      const spread = (kind === 'dead' ? 0.5 : 0.62) + R() * 0.35;
      const nd = [dir[0] * 0.6 + Math.cos(ang) * spread, dir[1] * (kind === 'dead' ? 0.72 : 0.62) + 0.18, dir[2] * 0.6 + Math.sin(ang) * spread];
      const l = Math.hypot(...nd);
      grow(b, nd.map(v => v / l), len * (0.6 + R() * 0.16), r * 0.6, depth + 1);
    }
  };
  const ll = Math.hypot(...lean);
  const h0 = (kind === 'dead' ? 1.9 : 2.1) * size;
  grow([x, -0.12, z], lean.map(v => v / ll), h0, 0.2 * size, 0);
  // raízes aparentes
  for (let i = 0; i < 4; i++) { const a = i * 1.57 + R(); segs.push(seg([x, 0.18, z], [x + Math.cos(a) * 0.55 * size, -0.05, z + Math.sin(a) * 0.55 * size], 0.1 * size, 0.03)); }
  const wood = fastUnion(segs, 0.06);
  // madeira amostrada direto na superfície de cada galho (muito mais rápido que varrer o volume)
  const woodPts = new PointSet(4096), sp = 0.075;
  for (const g of segs) {
    const d = [g.b[0] - g.a[0], g.b[1] - g.a[1], g.b[2] - g.a[2]], L = Math.hypot(...d);
    if (L < 1e-4) continue;
    const u = d.map(v => v / L);
    const ref = Math.abs(u[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0];
    let v = [u[1] * ref[2] - u[2] * ref[1], u[2] * ref[0] - u[0] * ref[2], u[0] * ref[1] - u[1] * ref[0]];
    const vl = Math.hypot(...v); v = v.map(q => q / vl);
    const w = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
    const nA = Math.max(1, Math.round(L / sp));
    for (let i = 0; i < nA; i++) {
      const t = (i + 0.2 + R() * 0.6) / nA, r = g.r1 + (g.r2 - g.r1) * t;
      const nR = Math.max(r < 0.03 ? 2 : 3, Math.round(2 * Math.PI * r / sp));
      for (let j = 0; j < nR; j++) {
        const an = (j + R() * 0.7 + i * 0.5) / nR * Math.PI * 2, c = Math.cos(an), sn = Math.sin(an);
        const n = [v[0] * c + w[0] * sn, v[1] * c + w[1] * sn, v[2] * c + w[2] * sn];
        const p = [g.a[0] + d[0] * t + n[0] * r, g.a[1] + d[1] * t + n[1] * r, g.a[2] + d[2] * t + n[2] * r];
        if (p[1] < -0.02 || wood(p[0] + n[0] * 0.012, p[1] + n[1] * 0.012, p[2] + n[2] * 0.012) < -0.004) continue;   // dentro de outro galho
        const moss = p[1] < 0.9 && noise3(p[0] * 4, p[1] * 4, p[2] * 4) > 0.6;
        woodPts.push(p, n, u, moss ? MAT.MOSS : MAT.WOOD, -1, 0, 16, sp * 2.1, R() * 1000);
      }
    }
  }
  const part = null;
  // copa: nuvens de folhas nas pontas dos galhos (casca externa mais densa → volume legível)
  const leaves = new PointSet(64);
  const canopy = [];
  if (kind !== 'dead') {
    const mats = kind === 'green' ? [MAT.LEAF_G, MAT.LEAF_G, MAT.LEAF_G, MAT.GRASS2] : [MAT.LEAF_R, MAT.LEAF_Y, MAT.LEAF_R, MAT.LEAF];
    for (const [b, dir] of tips) {
      const r = (0.85 + R() * 0.35) * size;
      const c = [b[0] + dir[0] * r * 0.4, b[1] + r * 0.25, b[2] + dir[2] * r * 0.4];
      canopy.push([...c, r]);
      const n = Math.round(4 * Math.PI * r * r / (0.22 * 0.22) * (kind === 'autumn' ? 0.62 : 0.75));
      for (let i = 0; i < n; i++) {
        // espiral de Fibonacci + jitter radial → distribuição orgânica sem grade
        const t = (i + 0.5) / n, phi = Math.acos(1 - 2 * t), th = i * 2.39996 + R() * 0.4;
        const nx = Math.sin(phi) * Math.cos(th), ny = Math.cos(phi) * 0.85, nz = Math.sin(phi) * Math.sin(th);
        const rr = r * (0.72 + 0.28 * Math.sqrt(R())) * (1 + 0.18 * (noise3(nx * 2 + seed, ny * 2, nz * 2) - 0.5));
        if (ny < -0.55 && R() < 0.6) continue;                          // copa mais aberta por baixo
        const p = [c[0] + nx * rr, c[1] + ny * rr, c[2] + nz * rr];
        const m = mats[(R() * mats.length) | 0];
        const tan = [Math.cos(th + 1.2), (R() - 0.5) * 0.6, Math.sin(th + 1.2)];
        leaves.push(p, [nx, ny / 0.85 * 0.8 + 0.2, nz], tan, m, -1, 0, 16 | LEAF_FLAG, 0.2 + R() * 0.08, R() * 1000);
      }
    }
  }
  return { part, wood: woodPts, leaves, collider: { type: 'circle', x, z, r: 0.32 * size }, canopy, kind };
}
