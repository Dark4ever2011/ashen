// ASHEN 3D — Atlas de caracteres e materiais tipográficos.
// O atlas é gerado na hora a partir da própria fonte (texto desenhado num canvas):
// não existe imagem externa — cada célula do atlas é um caractere.
// Proibido: blocos (█▀▄▌▐), sombreados (░▒▓) e quadrados (■□▪).

import { charWidth } from '../engine/typography.js';

export const MONO = '"AshenMono","DejaVu Sans Mono","Noto Sans Mono","Droid Sans Mono",monospace';
export const CJK = '"Noto Serif CJK JP","Noto Serif JP","Hiragino Mincho ProN","Yu Mincho","Noto Sans CJK JP","Droid Sans Fallback",serif';

export const MAT = { STEEL: 0, SILVER: 1, GOLD: 2, CLOTH: 3, LEATHER: 4, BLADE: 5, STONE: 6, WOOD: 7, GROUND: 8, GRASS: 9, IRON: 10, EMBER: 11, BONE: 12, MOSS: 13, CLOTH_IN: 14, DARK: 15, GRAVEL: 16 };

// cor base (0..1), brilho especular, emissivo, rampa de 8 caracteres (escuro → iluminado)
export const MATERIALS = [
  { name: 'aço negro', c: [0.5, 0.55, 0.66], spec: 0.9, ramp: ['.', ':', '+', 'x', '#', '8', 'W', 'M'] },
  { name: 'prata', c: [0.78, 0.82, 0.88], spec: 1.2, ramp: ['-', '=', '≡', '+', 'H', '#', '*', '✦'] },
  { name: 'ouro velho', c: [0.86, 0.66, 0.30], spec: 1.0, ramp: ['·', ':', '+', '*', '¤', '§', '◆', '✦'] },
  { name: 'tecido vinho', c: [0.56, 0.10, 0.14], spec: 0.1, ramp: ['.', ',', '(', ')', 's', 'S', '§', '&'] },
  { name: 'couro', c: [0.42, 0.28, 0.18], spec: 0.2, ramp: ['.', ':', 'x', 'X', '%', '#', '&', '@'] },
  { name: 'lâmina', c: [0.80, 0.86, 0.92], spec: 1.6, ramp: ['|', 'l', '!', 'I', '|', 'ǀ', '‖', '✦'] },
  { name: 'pedra', c: [0.46, 0.44, 0.48], spec: 0.05, ramp: ['.', ':', '-', '=', '≡', '#', '%', '&'] },
  { name: 'madeira morta', c: [0.48, 0.40, 0.32], spec: 0.05, ramp: ['.', '\'', ':', '|', 'l', '¦', 'I', '‖'] },
  { name: 'terra e cinzas', c: [0.22, 0.2, 0.19], spec: 0.0, ramp: [' ', '.', ',', '`', '\'', '.', ',', ':'] },
  { name: 'grama morta', c: [0.28, 0.28, 0.19], spec: 0.0, ramp: ['\'', ',', '"', 'v', 'ʷ', 'w', 'ψ', 'Y'] },
  { name: 'ferro', c: [0.5, 0.47, 0.45], spec: 0.6, ramp: [':', ';', '+', 'x', '#', '&', '%', '8'] },
  { name: 'brasa', c: [1.0, 0.42, 0.16], spec: 0, emissive: 1, ramp: ['·', '•', '*', '✶', '✦', '火', '炎', '火'] },
  { name: 'osso/pedra clara', c: [0.68, 0.64, 0.58], spec: 0.1, ramp: ['.', ':', '-', '=', '≡', '#', '§', '&'] },
  { name: 'musgo', c: [0.26, 0.32, 0.18], spec: 0, ramp: ['.', ',', '*', '%', '§', '&', '#', '@'] },
  { name: 'forro da capa', c: [0.30, 0.05, 0.08], spec: 0.05, ramp: ['.', ',', ';', '(', ')', '{', '}', '§'] },
  { name: 'vão escuro', c: [0.05, 0.04, 0.06], spec: 0, ramp: [' ', ' ', '.', ' ', '·', ' ', '.', ' '] },
  { name: 'calçamento', c: [0.34, 0.32, 0.34], spec: 0.05, ramp: ['.', '·', ':', '∴', '⁘', '∷', '⁙', '#'] },
];

// Caracteres de contorno (silhueta) e aresta: traços que seguem a forma.
export const EDGE_RAMP = ['-', '-', '─', '─', '═', '═', '━', '━'];
export const RIM_GLYPHS = ['│', '|', '┃', '║'];
export const EXTRA = ['誓', '王', '灰', '国', '門', '眠', '墓', '火', '炎', '•', '◦', '◆', '✦', '✶', '†', '╬', '┼', '╋', '║', '│', '─', '═', '━', '~', '≈', '∼', '˙', '·', '^', '*', '°', '∴', '⁘', 'ˎ', ',', '`', '丫', '个', '▼', '¦', '⌒', '∩', 'Ʌ', 'Λ', 'V', 'ν'];

const FORBIDDEN = /[▀-▟■-▣]/; // blocos e quadrados

export class GlyphAtlas {
  constructor(cell = 64, cols = 32) {
    this.cell = cell; this.cols = cols;
    this.list = []; this.index = new Map();
    const add = ch => { if (ch === ' ' || this.index.has(ch)) return; if (FORBIDDEN.test(ch)) throw new Error('caractere proibido: ' + ch); this.index.set(ch, this.list.length); this.list.push(ch); };
    add('·');
    for (const m of MATERIALS) m.ramp.forEach(add);
    EDGE_RAMP.forEach(add); RIM_GLYPHS.forEach(add); EXTRA.forEach(add);
    for (const ch of '.,:;-=+*#%&@$0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz()[]{}<>/\\|!?\'"`~^_') add(ch);
  }
  get(ch) { if (ch === ' ') return -2; if (!this.index.has(ch)) { this.index.set(ch, this.list.length); this.list.push(ch); } return this.index.get(ch); }

  /** Rampas por material (índices no atlas; -2 = vazio). */
  rampTable() {
    const t = [];
    for (const m of MATERIALS) for (const ch of m.ramp) t.push(ch === ' ' ? -2 : this.get(ch));
    for (const ch of EDGE_RAMP) t.push(this.get(ch));
    return t;
  }

  /** Desenha o atlas (branco sobre transparente). */
  build() {
    const n = this.list.length, rows = Math.ceil(n / this.cols);
    const c = document.createElement('canvas');
    c.width = this.cols * this.cell; c.height = Math.max(1, rows) * this.cell;
    // altura em potência de 2 para mipmaps estáveis
    c.height = Math.pow(2, Math.ceil(Math.log2(c.height)));
    const x = c.getContext('2d');
    x.fillStyle = '#fff'; x.textAlign = 'center'; x.textBaseline = 'middle';
    const S = this.cell;
    this.list.forEach((ch, i) => {
      const cx = (i % this.cols) * S + S / 2, cy = Math.floor(i / this.cols) * S + S / 2;
      const wide = charWidth(ch.codePointAt(0)) === 2;
      x.font = wide ? `bold ${S * 0.78}px ${CJK}` : `bold ${S * 0.8}px ${MONO}`;
      const w = x.measureText(ch).width, max = S * 0.94;
      const k = w > max ? max / w : 1;
      x.save(); x.translate(cx, cy + S * 0.02); x.scale(k, 1); x.fillText(ch, 0, 0); x.restore();
    });
    this.canvas = c;
    this.rows = c.height / S;
    return c;
  }
}
